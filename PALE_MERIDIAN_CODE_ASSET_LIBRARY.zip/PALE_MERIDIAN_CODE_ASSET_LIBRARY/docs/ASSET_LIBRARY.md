# PALE MERIDIAN — ASSET LIBRARY `frontier_service`

Экспериментальный code-generated asset library: 18 модулей фронтирной
sci-fi архитектуры, собранных в два демонстрационных здания
(FRONTIER SERVICE OUTPOST K-17, варианты A и B).

Всё нарисовано чистым Python-рендерером: без image generation, битмапов,
трассировки, 3D/SVG/векторов. PIL используется только для сохранения PNG
и nearest-neighbor масштабирования превью. Каждый PNG воспроизводим из кода.

## Состав библиотеки (18)

### ARCHITECTURE (10)
| id | мир (px) | назначение |
|---|---|---|
| foundation_plinth_A | 96×40×24 | тяжёлый бетонный цоколь: mounting plates, болты, сколы, damp-band, контактная тень; база здания |
| wall_panel_A | 64×16×40 | основной стеновой бай: chamfered recessed panel, structural rails, сервисный канал, octagon intake, диагональный conduit |
| wall_panel_B | 64×16×40 | второй ритм: cartridge bay (5 слотов, один пустой), utility recess с junction box, широкий rail справа |
| inner_corner_A | 48×40×40 | внутренний угол: альков с задней стеной в тени, conduit обходит угол, brace, пол alcove |
| outer_corner_A | 48×48×43 | внешний угол: выступающее крыло + reinforcement column с капителью (`mirror=True` — крыло слева) |
| door_airlock_A | 40×20×44 | герметичная дверь: толстая рама, recessed leaf, клещи-замки, porthole, status panel, порог с worn warning |
| window_recess_A | 32×16×28 | окно в глубокой нише: soffit-тень, стекло с бликами, mullions, выступающий sill с потёками |
| roof_edge_A | 64×20×10 | край крыши: fascia, cap slab, gutter, кабельные вводы, downspout |
| roof_section_A | 64×64×6 | кровля: люк, vent unit с octagon, cable tray, ремонтные платы, tar patch |
| roof_section_B | 64×64×6 | кровля: solar array, grate walkway, цилиндрический фильтр, круглый люк |

### TECHNICAL (6)
| id | мир (px) | назначение |
|---|---|---|
| pipe_cluster_A | 56×40×64 | три трубы разного диаметра: elbows, clamps, valve wheel, patina на стыках |
| service_tower_A | 40×40×106 | вертикаль: бетонный низ с дверью, machine tier с octagon intake, grille tier, exhaust, antenna, лестница |
| utility_spine_A | 24×24×80 | кабельный spine: junction boxes с LED, conduit-стояки, standoff-зазор от стены |
| generator_unit_A | 64×40×40 | генератор: hex grille, maintenance panel с worn warning, control strip, exhaust, skids с глубокой тенью |
| terminal_station_A | 20×16×30 | консоль: экран с текстом, keyboard shelf, pedestal, кабель в пол |
| storage_module_A | 48×24×60 | стеллаж: контейнеры, открытый ящик с глубиной, coil, гнутая стойка |

### PROPS (2)
| id | мир (px) | назначение |
|---|---|---|
| industrial_light_A | 14×10×18 | настенный светильник: bracket, shade, cage, emissive-ядро (glow не запечён) |
| maintenance_cart_A | 30×18×22 | тележка: колёса, toolbox, ключ, coil, банки на нижней полке |

## Материалы и их pixel-language
* **Painted metal** — крупные ровные value-блоки (block-noise cell 7–9), редкие speckle, сколы с голым металлом.
* **Raw metal** — холоднее, жёсткие горизонтальные highlight-штрихи, cell 3–4.
* **Concrete** — крупные зернистые зоны (две block-октавы), матовый отклик, формовочные швы.
* **Rubber/polymer** — тёмный, слабый highlight, почти без dithering.
* **Glass** — dark teal, 2–3 пикселя диагонального отражения, минимальный emissive.
* **Warning paint** — трапеции/полосы под 45° с протёртыми краями и дырами от износа, не candy-stripe.

## Variation system
Параметры (см. `metadata/<id>.json → variantParameters`):
`seed`, `condition(clean|worn|damaged)`, `accent(AMBER|TEAL|COPPER)`,
`tech(0..2)`, геометрические `w/d/z0/mirror/notch_*`, `lit(night)`.
Демо: `preview/variants_wall_A.png`.

## Metadata schema
`metadata/<id>.json`: id, category, family, widthPx/heightPx, worldWidth/
worldDepth/worldHeight (+ метры при 15 px/m), anchor, projection(+params),
materials, **connectionPoints**, compatibleWith, variantParameters, file.
Сводка: `manifest.json` (палитра, проекция, здания K-17-A/B).

## Проверки (`qa_check.py`)
палитра дня / alpha / детерминизм / emissive-бюджет (≤5 px, светильник ≤8) /
бесшовность стыка A|B / форшортенинг sin36° / палитры профилей day-dusk-night.
Результаты: `metadata/qa_results.json` — **QA ALL OK**.
