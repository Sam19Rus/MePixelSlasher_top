# PALE MERIDIAN — CODE ASSET LIBRARY (experimental)

Цель этапа: проверить, способен ли чисто кодовый pixel-art pipeline производить
не один красивый ассет, а **библиотеку совместимых модулей** и собирать из неё
сложное здание без ощущения процедурного конструктора.

Результат: 18 модулей семейства `frontier_service` + здания K-17-A / K-17-B
(день / закат / ночь / крупный план / стыки / разрез).

## Структура
```
PALE_MERIDIAN_CODE_ASSET_LIBRARY/
  source/
    common/        canvas, noise, materials, depth, details, font
    palettes/      frontier_service.py (62 цвета дня + профили dusk/night)
    projection/    tilted_ortho.py (камера N3: pitch 36°, slope 2°, eave 2)
    generators/    architecture.py, technical.py, props.py (18 ассетов)
    build_assets.py      18 standalone PNG (assets/**)
    build_previews.py    листы: библиотека / depth / variants
    build_building.py    K-17-A/B + day/dusk/night + close/tiling/cutaway
    build_manifest.py    metadata/*.json + manifest.json
    qa_check.py          QA-батч -> metadata/qa_results.json
  assets/{architecture,technical,props}/*.png
  metadata/*.json, manifest.json, qa_results.json
  preview/*.png          9+ обязательных превью
  docs/                  ASSET_LIBRARY.md, ARCHITECTURE_RULES.md, REPORT.md
  build/build_all.py     полный прогон
```

## Запуск
```
cd source
python3 build/build_all.py        # или по шагам:
python3 build_assets.py && python3 build_building.py \
 && python3 build_scene.py && python3 build_previews.py \
 && python3 build_manifest.py && python3 qa_check.py
```
Требуется только Python 3 + Pillow (сохранение PNG). Детерминизм гарантирован:
одинаковые параметры -> байт-идентичные PNG.

## Ключевые превью
* `preview/asset_library_sheet.png` — вся библиотека, один масштаб, подписи, 4x-ряд;
* `preview/depth_detail_sheet.png` — 1x/2x/4x сложных ассетов (тени, ниши, материалы);
* `preview/building_day.png` / `building_dusk.png` / `building_night.png`;
* `preview/building_close.png` (4x) / `building_tiling.png` (3x) / `building_cutaway.png`;
* `preview/building_variant_B.png`;
* `preview/variants_wall_A.png` — система вариаций.

## V2 «CLARITY PASS» (2026-09-19)
Уточнённый запрос и правила: `docs/UPGRADE_SPEC_V2.md`; разбор референсов
UNSIGHTED/CrossCode: `work/reference_notes.md`; итог: `docs/REPORT_V2.md`.
* `preview/scene_two_buildings.png` — два здания (K-17-A и K-17-B) на ландшафте, ×3;
* `preview/scene_dusk.png` — та же сцена в сумерках, ×2;
* `preview/scene_closeups.png` — крупные планы ×4 (читаемость);
* все ассеты и превью пересобраны: плоские поверхности, жёсткие собственные
  тени, линии на всех переходах.
