"""
FRONTIER SERVICE OUTPOST K-17 — building assembly from the 18-asset library.

Painter's algorithm in world depth (far -> near). Modules are placed on a
shared structural grid (bay 64, corner 48, plinth 14) so seams, cornice
lines and cable runs continue across sections. Junction shadows, bridging
pipes and cable swags make the masses read as ONE building.

Variants:
  K-17-A  — hall + left garage + right tech wing + rear service tower +
            entrance porch with canopy and steps
  K-17-B  — same library: bays swapped, solar-heavy roof, tower relocated,
            porch replaced by a canopy + external stair, worn/damaged
            conditions, copper accent, props reshuffled
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from projection.tilted_ortho import Scene, VS, HS               # noqa: E402
from common.canvas import Canvas                                # noqa: E402
from common.noise import h2                                     # noqa: E402
from common.materials import (concrete, concrete_slab, ground_field,
                              paint_metal, raw_metal, rubber, warning_patch)
from common.depth import (cast_shadow_ground, contact_shadow, cornice_shadow,
                          pipe_v, pipe_h, elbow_vh, silhouette, junction_shadow)
from common.details import (rivet_line_h, bolt, cable_sag, grime, dust_cap,
                            stencil, rust_weep, chip, clamp)
from palettes.frontier_service import col, LIGHT, shade_color, RAMPS
from generators.architecture import (foundation_plinth_A, wall_panel_A,
                                     wall_panel_B, inner_corner_A,
                                     outer_corner_A, door_airlock_A,
                                     window_recess_A, roof_edge_A,
                                     roof_section_A, roof_section_B)
from generators.technical import (pipe_cluster_A, service_tower_A,
                                  utility_spine_A, generator_unit_A,
                                  terminal_station_A, storage_module_A)
from generators.props import industrial_light_A, maintenance_cart_A

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

PLINTH_H = 14
CW, CH = 560, 300          # canvas
OX, OY = 30, 96            # world origin on screen


# ======================================================================
def new_scene():
    return Scene(CW, CH, ox=OX, oy=OY)


def draw_ground(sc, cv, seed=7):
    """dirt yard + concrete pad + apron + tracks + stains"""
    ground_field(cv, 0, 0, CW - 1, CH - 1, seed=seed, mid=2)
    # aerial perspective: smooth per-row cool-down toward the horizon
    for yy in range(0, 120):
        f = 0.86 + 0.14 * (yy / 120.0)
        cv.rect_shade(0, yy, CW - 1, yy, f)
    # concrete pad under the building + service apron in front
    pad = sc.ground_rect(8, 236, 452, 150)
    concrete_slab(cv, *pad, seed=seed + 1, mid=3, ax=sc.ox, ay=sc.oy)
    cv.hline(pad[0], pad[2], pad[3], col("CONC", 4))
    apron = sc.ground_rect(60, 268, 340, 34)
    concrete_slab(cv, *apron, seed=seed + 2, mid=3, ax=sc.ox, ay=sc.oy)
    cv.hline(apron[0], apron[2], apron[3], col("CONC", 2))
    # tyre tracks: cart <-> garage door
    for i in range(2):
        for xx in range(96, 150):
            yy = sc.sy(252 + i * 3, 0) + int(2 * abs(h2(xx, i, 41) - 0.5))
            cv.set(xx, yy, col("DIRT", 1))
            cv.set(xx + 1, yy + 1, col("DIRT", 1))
    # stains: under generator, under downspouts
    for (sx, sy, rw) in ((392, 244, 10), (52, 240, 6), (330, 236, 5)):
        px, py = sc.sx(sx), sc.sy(sy, 0)
        for yy in range(py, py + 5):
            for xx in range(px - rw // 2, px + rw // 2):
                if h2(xx, yy, 55) > 0.35 + 0.12 * (yy - py):
                    c = cv.get(xx, yy)
                    if c is not None:
                        cv.set(xx, yy, shade_color(LIGHT.profile, 0.75, c))


# ======================================================================
def cargo_door(sc, cv, x, yf, z0, z1, seed=0):
    """wide garage cargo door: recessed leaf, segment seams, guide rails"""
    fr = sc.front_rect(x, yf, 48, z0, z1)
    x0, y0, x1, y1 = fr
    cv.rect(x0 - 1, y0 - 1, x1 + 1, y1 + 1, col("DARK", 0))
    raw_metal(cv, x0, y0, x1, y1, seed=seed + 1, ramp="SLATE", mid=2, cell=6)
    # horizontal segment seams with shadow lines (functional, not lap siding)
    n = 4
    for i in range(1, n):
        yy = y0 + i * (y1 - y0) // n
        cv.hline(x0, x1, yy, col("GUN", 0))
        cv.hline(x0, x1, yy + 1, col("SLATE", 4))
        cv.rect(x0 + 6, yy - 2, x0 + 9, yy - 1, col("GUN", 2))   # hinge blocks
        cv.rect(x1 - 9, yy - 2, x1 - 6, yy - 1, col("GUN", 2))
    # guide rails both sides (proud)
    for rx in (x0 - 3, x1 + 1):
        cv.rect(rx, y0 - 1, rx + 1, y1 + 1, col("GUN", 3))
        cv.vline(rx, y0 - 1, y1 + 1, col("SLATE", 4))
    cv.vline(x1 + 3, y0, y1 + 1, col("DARK", 0))
    # worn warning band across the lower segment
    warning_patch(cv, x0 + 4, y1 - 6, x1 - 4, y1 - 3, seed=seed + 2, wear=0.5)
    stencil(cv, x0 + 16, y0 + 3, "G1", ramp="AMBER", idx=2, wear=0.14,
            seed=seed + 3)
    cv.hline(x0, x1, y0, col("GUN", 0))           # header shadow
    grime(cv, x0, y1 - 3, x1, y1, seed + 4, amt=0.5)


def external_stair(sc, cv, x, yf, z_top, seed=0, up_right=True):
    """external service stair: stepped treads with stepped shadows"""
    steps = 8
    for i in range(steps):
        z0 = i * z_top // steps
        z1 = (i + 1) * z_top // steps
        yy = yf + (steps - i) * 2
        fr = sc.front_rect(x, yy, 14, z0, z1)
        tr = sc.top_rect(x, yy, 14, 4, z1)
        raw_metal(cv, *fr, seed=seed + i, ramp="SLATE", mid=2, cell=4)
        raw_metal(cv, *tr, seed=seed + 90 + i, ramp="SLATE", mid=4, cell=4)
        cv.hline(tr[0], tr[2], tr[3], col("SLATE", 5))
        cv.hline(fr[0], fr[2], fr[3], col("GUN", 0))
        cv.vline(fr[2] + 1, fr[1] + 1, fr[3] + 1, col("DARK", 0))
        cv.hline(fr[0] + 1, fr[2] + 1, fr[3] + 1, col("DARK", 0))
    # railing
    x0 = sc.sx(x)
    y0 = sc.sy(yf + 2, z_top + 8)
    y1 = sc.sy(yf + steps * 2, 8)
    cv.line(x0 + 1, y1, x0 + 13, y0, col("SLATE", 3))
    for i in range(3):
        t = i / 2
        px = int(x0 + 1 + 12 * t)
        py = int(y1 + (y0 - y1) * t)
        cv.vline(px, py, py + 6, col("SLATE", 2))


# ======================================================================
def mass_walls(sc, cv, bays, yf, seed0, variant, top):
    """bays: list of (kind, x, w) along one front plane"""
    for i, (kind, bx, bw) in enumerate(bays):
        s = seed0 + i * 17
        if kind == "wall_A":
            wall_panel_A(sc, cv, bx, yf, seed=s, z0=PLINTH_H, h=top,
                         accent=variant["accent"], cond=variant["cond"],
                         tech=variant["tech"])
        elif kind == "wall_B":
            wall_panel_B(sc, cv, bx, yf, seed=s, z0=PLINTH_H, h=top,
                         accent=variant["accent"], cond=variant["cond"],
                         tech=variant["tech"])
        elif kind == "corner":
            outer_corner_A(sc, cv, bx, yf, seed=s, h=top,
                           z0=PLINTH_H)
        elif kind == "cornerM":
            outer_corner_A(sc, cv, bx, yf, seed=s, h=top,
                           z0=PLINTH_H, mirror=True)
        elif kind == "alcove":
            inner_corner_A(sc, cv, bx, yf, seed=s, h=top,
                           z0=PLINTH_H)


# ======================================================================
VARIANTS = {
    "A": dict(
        accent="AMBER", cond="worn", tech=1,
        hall_top=54, wing_top=44, garage_top=36,
        hall_bays=[("wall_A", 116, 64), ("alcove", 180, 48), ("wall_B", 228, 64),
                   ("corner", 292, 48)],
        wing_bays=[("wall_A", 340, 64), ("corner", 404, 48)],
        garage_bays=[("cornerM", 20, 48)],
        roof_hall=["A", "A", "B", "B"],      # per 56px column, rows front->back
        roof_wing=["A", "slab"],
        roof_garage=["B", "slab"],
        tower_x=252,
    ),
    "B": dict(
        accent="COPPER", cond="damaged", tech=2,
        hall_top=54, wing_top=44, garage_top=36,
        hall_bays=[("wall_B", 116, 64), ("alcove", 180, 48), ("wall_A", 228, 64),
                   ("corner", 292, 48)],
        wing_bays=[("wall_B", 340, 64), ("corner", 404, 48)],
        garage_bays=[("cornerM", 20, 48)],
        roof_hall=["B", "B", "B", "B"],
        roof_wing=["B", "slab"],
        roof_garage=["A", "slab"],
        tower_x=140,
    ),
}


def assemble(variant="A", profile="day", cutaway=False, ground=True,
             scene=None, off=(0, 0)):
    LIGHT.set(profile)
    V = VARIANTS[variant]
    sc = scene if scene is not None else new_scene()
    cv = sc.cv
    ox0, oy0 = sc.ox, sc.oy
    sc.ox += off[0]
    sc.oy += off[1]
    if ground:
        draw_ground(sc, cv, seed=7 if variant == "A" else 9)
    night = profile == "night"

    # ---------------- tower (farthest) ----------------
    tx = V["tower_x"]
    cast_shadow_ground(sc, cv, tx, 86, 48, 106, 44)
    service_tower_A(sc, cv, tx, 86, seed=31 if variant == "A" else 77)

    # ---------------- hall ----------------
    hx, hyf, hw, hd, hz = 116, 190, 224, 96, V["hall_top"]
    cast_shadow_ground(sc, cv, hx, hyf, hw, hz, hd)
    foundation_plinth_A(sc, cv, hx, hyf, seed=11, w=hw)
    mass_walls(sc, cv, V["hall_bays"], hyf, 100, V, hz)
    # garage (nearer) will shadow the hall left junction:
    gj = sc.front_rect(hx, hyf, 12, PLINTH_H, hz - 6)
    # (drawn after garage below)
    # roof: front edge modules + deck rows
    for i in range(3):
        roof_edge_A(sc, cv, hx + i * 64, hyf, seed=140 + i, z0=hz, w=64)
        f = sc.front_rect(hx + i * 64, hyf, 64, hz - 2, hz)
        cornice_shadow(cv, f[0], f[2], f[3] + 1, rows=3)
    roof_edge_A(sc, cv, hx + 192, hyf, seed=143, z0=hz, w=32)
    f = sc.front_rect(hx + 192, hyf, 32, hz - 2, hz)
    cornice_shadow(cv, f[0], f[2], f[3] + 1, rows=3)
    for r, kind in enumerate(V["roof_hall"][:2]):
        pass
    # deck rows: front row d=64, back row d=32
    row_kinds = V["roof_hall"]
    for cx0, kind in ((hx, row_kinds[0]), (hx + 112, row_kinds[1])):
        if kind == "A":
            roof_section_A(sc, cv, cx0, hyf, seed=150 + cx0, z0=hz, w=112, d=64)
        else:
            roof_section_B(sc, cv, cx0, hyf, seed=150 + cx0, z0=hz, w=112, d=64)
    for cx0, kind in ((hx, row_kinds[2]), (hx + 112, row_kinds[3])):
        yb = hyf - 64
        if kind == "slab" or kind in ("A", "B"):
            tr = sc.top_rect(cx0, yb, 112, 32, hz)
            concrete_slab(cv, *tr, seed=160 + cx0, mid=4, ax=sc.ox, ay=sc.oy)
            cv.hline(tr[0], tr[2], tr[3], col("SLATE", 4))
            dust_cap(cv, tr[0] + 2, tr[2] - 2, tr[1] + 1, 161 + cx0, amt=0.3)
            if kind == "B":     # extra solar row on the back strip
                for px in range(tr[0] + 6, tr[2] - 20, 20):
                    cv.rect(px, tr[1] + 4, px + 15, tr[1] + 12, col("GLASS", 1))
                    cv.hline(px, px + 15, tr[1] + 3, col("SLATE", 4))
                    cv.vline(px + 16, tr[1] + 4, tr[1] + 12, col("DARK", 0))
            else:
                cv.rect(tr[0] + 40, tr[1] + 6, tr[0] + 52, tr[1] + 14, col("SLATE", 2))
                cv.outline(tr[0] + 40, tr[1] + 6, tr[0] + 52, tr[1] + 14, col("SLATE", 4))

    # hall->wing bridging pipe over the parapets (roof levels interact)
    pz = hz + 6
    pipe_h(cv, sc.sx(322), sc.sx(352), sc.sy(150, pz), 2, ramp="SLATE", mid=2)
    cv.hline(sc.sx(322), sc.sx(352), sc.sy(150, pz) + 4, col("DARK", 0))
    elbow_vh(cv, sc.sx(320), sc.sy(150, pz), 2, to="+x")
    pipe_v(cv, sc.sx(320), sc.sy(150, pz), sc.sy(150, hz - 2), 2)
    pipe_v(cv, sc.sx(352), sc.sy(150, pz), sc.sy(150, V["wing_top"] - 2), 2)

    silhouette(cv, sc.front_rect(hx, hyf, hw, PLINTH_H, hz))

    # ---------------- wing (set back 12) ----------------
    wx, wyf, ww, wd, wz = 340, 178, 112, 92, V["wing_top"]
    cast_shadow_ground(sc, cv, wx, wyf, ww, wz, wd)
    foundation_plinth_A(sc, cv, wx, wyf, seed=12, w=ww)
    mass_walls(sc, cv, V["wing_bays"], wyf, 200, V, wz)
    # hall mass casts a hard shadow band on the wing left junction
    wf0 = sc.front_rect(wx, wyf, 14, PLINTH_H, wz - 4)
    junction_shadow(cv, wf0[0] - 1, wf0[1], wf0[3], width=4)
    for i in range(2):
        roof_edge_A(sc, cv, wx + i * 64 if i == 0 else wx + 64, wyf,
                    seed=170 + i, z0=wz, w=64 if i == 0 else 48)
        f = sc.front_rect(wx + (0 if i == 0 else 64), wyf, 64 if i == 0 else 48,
                          wz - 2, wz)
        cornice_shadow(cv, f[0], f[2], f[3] + 1, rows=3)
    k = V["roof_wing"][0]
    if k == "A":
        roof_section_A(sc, cv, wx, wyf, seed=180, z0=wz, w=112, d=64)
    else:
        roof_section_B(sc, cv, wx, wyf, seed=180, z0=wz, w=112, d=64)
    silhouette(cv, sc.front_rect(wx, wyf, ww, PLINTH_H, wz), sides=("r",))
    tr = sc.top_rect(wx, wyf - 64, 112, 28, wz)
    concrete_slab(cv, *tr, seed=181, mid=4, ax=sc.ox, ay=sc.oy)
    cv.rect(tr[0] + 30, tr[1] + 4, tr[0] + 44, tr[1] + 12, col("SLATE", 2))
    cv.outline(tr[0] + 30, tr[1] + 4, tr[0] + 44, tr[1] + 12, col("SLATE", 4))
    dust_cap(cv, tr[0] + 2, tr[2] - 2, tr[1] + 1, 182, amt=0.3)

    # ---------------- garage (nearest left) ----------------
    gx, gyf, gw, gd, gz = 20, 214, 96, 76, V["garage_top"]
    cast_shadow_ground(sc, cv, gx, gyf, gw, gz, gd)
    foundation_plinth_A(sc, cv, gx, gyf, seed=13, w=gw)
    mass_walls(sc, cv, V["garage_bays"], gyf, 300, V, gz)
    cargo_door(sc, cv, gx + 48, gyf, PLINTH_H, gz, seed=330)
    roof_edge_A(sc, cv, gx, gyf, seed=190, z0=gz, w=96, h=8)
    f = sc.front_rect(gx, gyf, 96, gz - 2, gz)
    cornice_shadow(cv, f[0], f[2], f[3] + 1, rows=3)
    k = V["roof_garage"][0]
    if k == "A":
        roof_section_A(sc, cv, gx, gyf, seed=200, z0=gz, w=96, d=64)
    else:
        roof_section_B(sc, cv, gx, gyf, seed=200, z0=gz, w=96, d=64)
    tr = sc.top_rect(gx, gyf - 64, 96, 12, gz)
    concrete_slab(cv, *tr, seed=201, mid=4, ax=sc.ox, ay=sc.oy)
    silhouette(cv, sc.front_rect(gx, gyf, gw, PLINTH_H, gz), sides=("l",))
    # garage casts a hard shadow band on the hall left junction
    hj = sc.front_rect(hx, hyf, 12, PLINTH_H, V["hall_top"] - 8)
    junction_shadow(cv, hj[0] - 1, hj[1], hj[3], width=4)

    # external stair: A on garage left, B on hall right
    if variant == "A":
        external_stair(sc, cv, 4, gyf - 4, gz, seed=340)
    else:
        external_stair(sc, cv, 452, hyf - 4, V["hall_top"] - 10, seed=341)

    # ---------------- porch (variant A) / canopy (variant B) --------
    if variant == "A":
        px, pyf, pw, pd, pz = 196, 224, 48, 34, 34
        cast_shadow_ground(sc, cv, px, pyf, pw, pz, pd)
        # porch floor + steps
        fl = sc.ground_rect(px, pyf, pw, pd - 10)
        concrete_slab(cv, *fl, seed=210, mid=3, ax=sc.ox, ay=sc.oy)
        cv.rect_shade(fl[0], fl[1], fl[2], fl[3], 0.8)
        for i, (sy, sz) in enumerate(((pyf + 6, 3), (pyf + 12, 6))):
            sf = sc.front_rect(px + 4, sy, 40, sz - 3, sz)
            st = sc.top_rect(px + 4, sy, 40, 6, sz)
            concrete(cv, *sf, seed=211 + i, mid=3)
            concrete(cv, *st, seed=213 + i, mid=4)
            cv.hline(st[0], st[2], st[3], col("CONC", 5))
            cv.hline(sf[0], sf[2], sf[3] + 1, col("DARK", 0))
        # recessed back wall with the airlock door
        door_airlock_A(sc, cv, px + 4, pyf - 10, seed=220, h=32, z0=0)
        # side reveals (jamb shadows) + columns
        for (cxx, cw) in ((px, 6), (px + pw - 6, 6)):
            cf = sc.front_rect(cxx, pyf, cw, 0, pz)
            ct = sc.top_rect(cxx, pyf, cw, pd - 10, pz)
            raw_metal(cv, *cf, seed=225 + cxx, ramp="SLATE", mid=2)
            concrete(cv, *ct, seed=227 + cxx, mid=4)
            cv.vline(cf[0], cf[1], cf[3], col("SLATE", 4))
            cv.vline(cf[2], cf[1], cf[3], col("SLATE", 0))
            cv.vline(cf[2] + 1, cf[1] + 1, cf[3] + 1, col("DARK", 0))
        cv.vline(sc.sx(px + 6), sc.sy(pyf - 10, 0), sc.sy(pyf - 10, pz), col("DARK", 0))
        # canopy slab + soffit shadow
        ctf = sc.front_rect(px - 3, pyf + 2, pw + 6, pz, pz + 3)
        ctt = sc.top_rect(px - 3, pyf + 2, pw + 6, pd - 8, pz + 3)
        raw_metal(cv, *ctf, seed=230, ramp="SLATE", mid=3)
        concrete(cv, *ctt, seed=231, mid=4)
        cv.hline(ctf[0], ctf[2], ctf[1], col("SLATE", 5))
        cv.hline(ctf[0], ctf[2], ctf[3], col("GUN", 0))
        cv.vline(ctf[2] + 1, ctf[1] + 1, ctf[3] + 1, col("DARK", 0))
        df = sc.front_rect(px + 4, pyf - 10, 40, pz - 4, pz)
        cornice_shadow(cv, df[0], df[2], df[1], rows=2)
        # porch lamps + terminal + cart area
        industrial_light_A(sc, cv, px + 8, pyf - 8, seed=235, with_wall=False,
                           lit=night, z0=18)
        industrial_light_A(sc, cv, px + 34, pyf - 8, seed=236, with_wall=False,
                           lit=night, z0=18)
        terminal_station_A(sc, cv, px + 52, pyf - 2, seed=237)
        # porch casts a hard shadow band on the hall face to its right
        pr = sc.front_rect(px + pw, hyf, 12, PLINTH_H, V["hall_top"] - 12)
        junction_shadow(cv, pr[0] - 1, pr[1], pr[3], width=3)
    else:
        # variant B: simple canopy over a side door + stair already placed
        px, pyf = 228, 190
        door_airlock_A(sc, cv, px + 8, pyf, seed=240, h=38, z0=PLINTH_H)
        ctf = sc.front_rect(px, pyf + 2, 56, 40, 43)
        ctt = sc.top_rect(px, pyf + 2, 56, 20, 43)
        raw_metal(cv, *ctf, seed=241, ramp="SLATE", mid=3)
        concrete(cv, *ctt, seed=242, mid=4)
        cv.hline(ctf[0], ctf[2], ctf[1], col("SLATE", 5))
        cv.hline(ctf[0], ctf[2], ctf[3], col("GUN", 0))
        wf = sc.front_rect(px + 4, pyf, 48, 36, 40)
        cornice_shadow(cv, wf[0], wf[2], wf[1], rows=2)
        industrial_light_A(sc, cv, px + 4, pyf, seed=243, with_wall=False,
                           lit=night, z0=30)
        industrial_light_A(sc, cv, px + 46, pyf, seed=244, with_wall=False,
                           lit=night, z0=30)

    # ---------------- wall-mounted technicals ----------------
    pipe_cluster_A(sc, cv, 244, hyf, seed=250, with_wall=False, z0=PLINTH_H,
                   h=40)
    utility_spine_A(sc, cv, 338, wyf, seed=251, with_wall=False, z0=PLINTH_H,
                    h=30)
    window_recess_A(sc, cv, 128, hyf, seed=252, z0=20, h=32, lit=night)
    window_recess_A(sc, cv, 352, wyf, seed=253, z0=16, h=26, lit=night)
    if variant == "B":
        window_recess_A(sc, cv, 240, hyf, seed=254, z0=20, h=32, lit=night)
        pipe_cluster_A(sc, cv, 372, wyf, seed=255, with_wall=False,
                       z0=PLINTH_H, h=30)
    industrial_light_A(sc, cv, 44, gyf, seed=256, with_wall=False, lit=night,
                       z0=26)
    industrial_light_A(sc, cv, 356, wyf, seed=257, with_wall=False, lit=night,
                       z0=34)

    # ---------------- yard props ----------------
    if variant == "A":
        generator_unit_A(sc, cv, 356, 240, seed=260)
        storage_module_A(sc, cv, 396, 176, seed=261)
        maintenance_cart_A(sc, cv, 128, 246, seed=262)
    else:
        generator_unit_A(sc, cv, 60, 244, seed=263)
        storage_module_A(sc, cv, 300, 188, seed=264)
        maintenance_cart_A(sc, cv, 396, 240, seed=265)
        terminal_station_A(sc, cv, 208, 226, seed=266)

    # ---------------- cables tying sections together ----------------
    cable_sag(cv, sc.sx(tx + 40), sc.sy(86, 100), sc.sx(300), sc.sy(120, 60),
              6, seed=270)
    cable_sag(cv, sc.sx(352), sc.sy(wyf, 44), sc.sx(392), sc.sy(wyf, 40), 4,
              seed=271)
    cable_sag(cv, sc.sx(120), sc.sy(hyf, 54), sc.sx(176), sc.sy(hyf, 52), 5,
              seed=272)
    if variant == "A":
        cable_sag(cv, sc.sx(200), sc.sy(224, 34), sc.sx(240), sc.sy(224, 33),
                  3, seed=273)

    # ---------------- cutaway (interior demo) ----------------
    if cutaway:
        draw_cutaway(sc, cv, V)

    sc.ox, sc.oy = ox0, oy0
    return sc


# ======================================================================
def draw_cutaway(sc, cv, V):
    """section through the hall left bay: wall removed, interior visible"""
    x0, x1 = 120, 176
    z0, z1 = PLINTH_H + 2, V["hall_top"] - 2
    fr = sc.front_rect(x0, 190, x1 - x0, z0, z1)
    ax0, ay0, ax1, ay1 = fr
    # interior volume: dark back wall + floor
    cv.rect(ax0, ay0, ax1, ay1, col("GUN", 1))
    for yy in range(ay0, ay1 + 1):
        for xx in range(ax0, ax1 + 1):
            if h2(xx, yy, 401) > 0.9:
                cv.set(xx, yy, col("GUN", 2))
    # interior floor slab
    fy = ay1 - 5
    cv.hline(ax0, ax1, fy, col("CONC", 3))
    cv.hline(ax0, ax1, fy + 1, col("CONC", 2))
    cv.hline(ax0, ax1, fy + 2, col("CONC", 1))
    # back-wall utility spine + shelf + crates (interior set dressing)
    cv.vline(ax0 + 8, ay0 + 4, fy, col("SLATE", 2))
    cv.vline(ax0 + 9, ay0 + 4, fy, col("SLATE", 1))
    for zz in (8, 16, 24):
        cv.rect(ax0 + 6, fy - zz, ax0 + 11, fy - zz + 2, col("GUN", 3))
        cv.set(ax0 + 10, fy - zz + 1, col("GLOW", 1))
    cv.rect(ax0 + 20, fy - 12, ax0 + 34, fy - 11, col("SLATE", 3))
    cv.rect(ax0 + 22, fy - 18, ax0 + 28, fy - 12, col("TEAL", 3))
    cv.hline(ax0 + 22, ax0 + 28, fy - 18, col("TEAL", 5))
    cv.rect(ax0 + 30, fy - 16, ax0 + 36, fy - 12, col("CREAM", 3))
    cv.hline(ax0 + 30, ax0 + 36, fy - 16, col("CREAM", 5))
    # hanging lamp + warm pool on the floor
    lx = ax0 + 40
    cv.vline(lx, ay0, ay0 + 6, col("RUBBER", 2))
    cv.rect(lx - 3, ay0 + 6, lx + 3, ay0 + 8, col("SLATE", 3))
    cv.hline(lx - 2, lx + 2, ay0 + 9, col("WARM", 2))
    cv.hline(lx - 1, lx + 1, ay0 + 10, col("WARM", 3))
    for i in range(3):
        cv.hline(lx - 6 - i * 2, lx + 6 + i * 2, fy - i, col("WARM", 0))
    # console glow inside
    cv.rect(ax0 + 44, fy - 10, ax0 + 50, fy - 6, col("GUN", 3))
    cv.rect(ax0 + 45, fy - 9, ax0 + 49, fy - 7, col("GLOW", 1))
    # section cut edges: bright cut line + wall thickness
    cv.outline(ax0 - 1, ay0 - 1, ax1 + 1, ay1 + 1, col("CREAM", 5))
    cv.outline(ax0 - 2, ay0 - 2, ax1 + 2, ay1 + 2, col("GUN", 1))
    for xx in range(ax0 - 1, ax1 + 2):
        cv.set(xx, ay0 - 1, col("CREAM", 4))
    # depth shading inside top (soffit of the cut)
    cv.rect_shade(ax0, ay0, ax1, ay0 + 2, 0.6)


# ======================================================================
def glow_pass(cv):
    """night runtime-lighting simulation: 1-2 px halos around emissives"""
    bright = {LIGHT.map[c] for ramp in ("GLOW", "WARM")
              for c in (RAMPS[ramp][2], RAMPS[ramp][3])}
    dim_g = LIGHT.map[RAMPS["GLOW"][0]]
    dim_w = LIGHT.map[RAMPS["WARM"][0]]
    src = [(x, y) for y in range(cv.h) for x in range(cv.w)
           if cv.g[y * cv.w + x] in bright]
    for (x, y) in src:
        warm = cv.g[y * cv.w + x] == LIGHT.map[RAMPS["WARM"][2]] or \
            cv.g[y * cv.w + x] == LIGHT.map[RAMPS["WARM"][3]]
        dim = dim_w if warm else dim_g
        for (dx, dy) in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            c = cv.get(x + dx, y + dy)
            if c is not None and c not in bright:
                cv.set(x + dx, y + dy, dim)
        for (dx, dy) in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
            if h2(x + dx, y + dy, 909) > 0.5:
                c = cv.get(x + dx, y + dy)
                if c is not None and c not in bright:
                    cv.set(x + dx, y + dy, dim)


def save_building(sc, name, scale=1, glow=False):
    if glow:
        glow_pass(sc.cv)
    path = os.path.join(ROOT, "preview", name)
    sc.cv.save(path, scale=scale)
    return path


def crops(sc):
    cv = sc.cv
    close = Canvas(140, 74)
    x0, y0 = sc.sx(185), sc.sy(226, 50)
    for y in range(74):
        for x in range(140):
            close.set(x, y, cv.get(x0 + x, y0 + y))
    tile = Canvas(150, 66)
    x0, y0 = sc.sx(40), sc.sy(214, 62)
    for y in range(66):
        for x in range(150):
            tile.set(x, y, cv.get(x0 + x, y0 + y))
    return close, tile


def main():
    os.makedirs(os.path.join(ROOT, "preview"), exist_ok=True)
    scA = assemble("A", "day")
    save_building(scA, "building_day.png")
    scD = assemble("A", "dusk")
    save_building(scD, "building_dusk.png")
    scN = assemble("A", "night")
    save_building(scN, "building_night.png", glow=True)
    close, tile = crops(scA)
    close.save(os.path.join(ROOT, "preview", "building_close.png"), scale=4)
    tile.save(os.path.join(ROOT, "preview", "building_tiling.png"), scale=3)
    scC = assemble("A", "day", cutaway=True)
    save_building(scC, "building_cutaway.png")
    scB = assemble("B", "day")
    save_building(scB, "building_variant_B.png")
    print("buildings saved")


if __name__ == "__main__":
    main()
