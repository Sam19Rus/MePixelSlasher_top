"""
PALE MERIDIAN — "frontier_service" palette family
=================================================
NEW palette for the code-asset library. Related to the world palette
(same value structure, same dusty frontier mood) but NOT a pixel copy:
creams are warmer/dirtier, gunmetal is bluer, teal is muted-grey,
copper leans red-oxide, plus a new restrained amber and a patina green.

Every ramp runs dark -> light. Painters address colours ONLY through
ramp + index + light-role, so a global LIGHT PROFILE (day/dusk/night)
can remap every colour deterministically.

Ramp budgets (day palette = 62 colours):
  CREAM 6  CONC 6  GUN 6  SLATE 5  TEAL 6  COPPER 6  VERD 4
  AMBER 5  RUBBER 4  GLASS 5  GLOW 4  WARM 4  DIRT 5  DARK 2
"""

CREAM = [          # dirty cream painted metal (main architectural skin)
    (78, 69, 54), (116, 104, 82), (150, 137, 110),
    (182, 168, 137), (206, 193, 160), (230, 220, 189),
]
CONC = [           # warm concrete / composite
    (68, 62, 55), (98, 90, 80), (126, 116, 104),
    (152, 142, 128), (177, 167, 150), (200, 191, 173),
]
GUN = [            # dark gunmetal (rails, frames, machinery)
    (21, 23, 28), (35, 38, 46), (50, 54, 64),
    (67, 72, 84), (87, 93, 106), (113, 120, 133),
]
SLATE = [          # dusty grey / slate secondary metal
    (52, 56, 62), (78, 84, 92), (105, 112, 120),
    (134, 141, 148), (164, 171, 176),
]
TEAL = [           # muted teal paint (cartridges, containers, trim)
    (20, 39, 43), (33, 59, 63), (48, 83, 87),
    (67, 109, 111), (91, 133, 133), (121, 159, 157),
]
COPPER = [         # oxidised copper / rust (wear only, logical spots)
    (58, 32, 20), (88, 46, 26), (122, 64, 34),
    (156, 88, 44), (186, 116, 62), (210, 150, 92),
]
VERD = [           # patina / verdigris accents (damp copper)
    (40, 66, 58), (58, 92, 78), (82, 120, 100), (112, 148, 124),
]
AMBER = [          # restrained amber (stencils, warning, beacons)
    (74, 52, 24), (112, 80, 34), (152, 112, 46),
    (190, 146, 64), (220, 180, 96),
]
RUBBER = [         # rubber / polymer (seals, tyres, grips)
    (15, 15, 18), (27, 27, 31), (41, 41, 46), (57, 57, 62),
]
GLASS = [          # dark teal glass
    (13, 29, 33), (21, 43, 49), (32, 61, 67),
    (47, 83, 87), (108, 158, 154),
]
GLOW = [           # cyan emissive (<= a few px per asset)
    (34, 116, 136), (60, 176, 194), (108, 214, 226), (188, 243, 245),
]
WARM = [           # warm lamp / interior light
    (118, 78, 38), (178, 128, 64), (224, 176, 94), (250, 224, 158),
]
DIRT = [           # ground: dust, gravel, service yard
    (60, 51, 42), (84, 72, 59), (108, 94, 77),
    (130, 114, 94), (152, 135, 111),
]
DARK = [           # near-black AO cores
    (9, 9, 11), (14, 15, 18),
]

RAMPS = {
    "CREAM": CREAM, "CONC": CONC, "GUN": GUN, "SLATE": SLATE, "TEAL": TEAL,
    "COPPER": COPPER, "VERD": VERD, "AMBER": AMBER, "RUBBER": RUBBER,
    "GLASS": GLASS, "GLOW": GLOW, "WARM": WARM, "DIRT": DIRT, "DARK": DARK,
}

ALL_COLORS = sorted({c for ramp in RAMPS.values() for c in ramp})
PALETTE_SIZE = len(ALL_COLORS)          # 62 day colours

# emissive ramps stay lit (even boosted) in dusk/night profiles
EMISSIVE_RAMPS = ("GLOW", "WARM")


# ----------------------------------------------------------------------
# light profiles: deterministic per-colour remaps (no gradients, no AA).
# computed once at import; every profile is a fixed finite colour set.
# ----------------------------------------------------------------------
def _clamp(v):
    return max(0, min(255, int(round(v))))


def _dusk(c, ramp):
    r, g, b = c
    if ramp in EMISSIVE_RAMPS:
        return (_clamp(r * 0.96 + 6), _clamp(g * 0.93 + 4), _clamp(b * 0.88))
    if ramp == "GLASS":
        return (_clamp(r * 0.80 + 22), _clamp(g * 0.72 + 12), _clamp(b * 0.70 + 6))
    # low warm sun: warm the lights, cool+deepen the shadows
    lum = 0.299 * r + 0.587 * g + 0.114 * b
    k = lum / 255.0
    return (_clamp(r * (1.02 + 0.10 * k) * 0.93 + 8),
            _clamp(g * (0.90 + 0.04 * k) * 0.90 + 3),
            _clamp(b * (0.74 + 0.03 * k) * 0.92 + 2))


def _night(c, ramp):
    r, g, b = c
    if ramp == "GLOW":
        return (_clamp(r * 1.04 + 8), _clamp(g * 1.04 + 10), _clamp(b * 1.04 + 10))
    if ramp == "WARM":
        return (_clamp(r * 1.02 + 8), _clamp(g * 0.98 + 4), _clamp(b * 0.90))
    if ramp == "GLASS":
        return (_clamp(r * 0.55 + 6), _clamp(g * 0.60 + 10), _clamp(b * 0.78 + 16))
    # moonless overcast night: strong cool darken
    return (_clamp(r * 0.40 + 5), _clamp(g * 0.45 + 8), _clamp(b * 0.60 + 14))


DAY_MAP = {c: c for ramp in RAMPS for c in RAMPS[ramp]}
DUSK_MAP = {c: _dusk(c, ramp) for ramp in RAMPS for c in RAMPS[ramp]}
NIGHT_MAP = {c: _night(c, ramp) for ramp in RAMPS for c in RAMPS[ramp]}

PROFILES = {"day": DAY_MAP, "dusk": DUSK_MAP, "night": NIGHT_MAP}

# ----------------------------------------------------------------------
# surface-aware shading: shadows darken WHATEVER surface they fall on,
# then snap back to the nearest palette colour (stays pixel-art crisp,
# no new colours, works on concrete / dirt / paint alike).
# ----------------------------------------------------------------------
_SHADE_CACHE = {}


def _nearest(palette_set, c):
    best, bd = palette_set[0], 1e18
    for p in palette_set:
        d = (p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 + (p[2] - c[2]) ** 2
        if d < bd:
            bd, best = d, p
    return best


def shade_color(profile, factor, c):
    key = (profile, factor, c)
    m = _SHADE_CACHE.get(key)
    if m is None:
        pal = sorted(set(PROFILES[profile].values()))
        tgt = (c[0] * factor, c[1] * factor, c[2] * factor)
        m = _nearest(pal, tgt)
        _SHADE_CACHE[key] = m
    return m

# shadow casting parameters per profile (screen-space, world height h):
#   offset = (dirx*h*len, diry_screen*h*len)   sun from upper-left
SHADOW_PARAMS = {
    "day":   {"dirx": 0.82, "diry": 0.34, "len": 0.9,  "strength": 1.0},
    "dusk":  {"dirx": 0.94, "diry": 0.30, "len": 1.7,  "strength": 1.15},
    "night": {"dirx": 0.70, "diry": 0.36, "len": 0.55, "strength": 0.7},
}


class Light:
    """Global light profile consulted by painters and shadow helpers."""

    def __init__(self, profile="day"):
        self.set(profile)

    def set(self, profile):
        self.profile = profile
        self.map = PROFILES[profile]
        self.shadow = SHADOW_PARAMS[profile]

    def col(self, ramp, idx):
        """ramp name + index (clamped) -> profiled RGB tuple"""
        ramp_l = RAMPS[ramp]
        i = max(0, min(len(ramp_l) - 1, idx))
        return self.map[ramp_l[i]]


LIGHT = Light("day")


def col(ramp, idx):
    return LIGHT.col(ramp, idx)
