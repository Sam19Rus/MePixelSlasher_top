"""
Preview sheets:
  preview/asset_library_sheet.png  — all 18 assets, one scale, ID labels,
                                     category bands + a 4x detail row
  preview/depth_detail_sheet.png   — 4 most complex assets at 1x / 2x / 4x
  preview/variants_wall_A.png      — the variation system on one module
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from build_assets import ASSETS, render_asset, ROOT            # noqa: E402
from common.canvas import Canvas                               # noqa: E402
from common.font import text, text_w                           # noqa: E402
from palettes.frontier_service import col, LIGHT               # noqa: E402
from generators.architecture import wall_panel_A               # noqa: E402
from projection.tilted_ortho import Scene                      # noqa: E402

CARD_BG = (36, 39, 46)
SHEET_BG = (24, 26, 31)
LABEL = (198, 206, 214)
DIM = (126, 134, 144)
BAND = (52, 56, 66)


def blit(dst, src, dx, dy):
    for y in range(src.h):
        for x in range(src.w):
            c = src.get(x, y)
            if c is not None:
                dst.set(dx + x, dy + y, c)


# ======================================================================
def asset_library_sheet():
    CATS = [("ARCHITECTURE", "architecture"), ("TECHNICAL", "technical"),
            ("PROPS", "props")]
    CW, CH = 128, 132
    rows = []
    for cname, cid in CATS:
        items = [a for a in ASSETS if a[1] == cid]
        rows.append((cname, items))
    ncols = 6
    W = ncols * CW + 96
    H = 46
    heights = []
    for cname, items in rows:
        nr = (len(items) + ncols - 1) // ncols
        heights.append(nr * CH + 26)
    H += sum(heights) + 150          # + zoom row
    sheet = Canvas(W, H, bg=SHEET_BG)
    text(sheet, 12, 10, "PALE MERIDIAN - CODE ASSET LIBRARY / FRONTIER_SERVICE",
         LABEL, scale=2)
    text(sheet, 12, 24, "18 CODE-GENERATED MODULES - TILTED ORTHOGRAPHIC 36 DEG - 15 PX/M",
         DIM)
    y = 40
    for (cname, items), hh in zip(rows, heights):
        sheet.rect(8, y, W - 8, y + 13, BAND)
        text(sheet, 12, y + 4, cname, LABEL)
        y += 18
        for i, (aid, cat, gen, kw, ctx) in enumerate(items):
            cx = 12 + (i % ncols) * CW
            cy = y + (i // ncols) * CH
            sheet.rect(cx, cy, cx + CW - 8, cy + CH - 20, CARD_BG)
            cv, info = render_asset(aid)
            ax = cx + (CW - 8 - cv.w) // 2
            ay = cy + CH - 24 - cv.h
            blit(sheet, cv, ax, ay)
            text(sheet, cx + 2, cy + CH - 16, aid, LABEL)
            text(sheet, cx + 2, cy + CH - 10, f"{cv.w}x{cv.h}px", DIM)
        y += hh - 8
    # 4x detail row of the small props
    text(sheet, 12, y + 2, "4X DETAIL", LABEL)
    y += 14
    x = 12
    for aid in ("industrial_light_A", "terminal_station_A", "window_recess_A",
                "door_airlock_A"):
        cv, _ = render_asset(aid)
        for yy in range(cv.h):
            for xx in range(cv.w):
                c = cv.get(xx, yy)
                if c is not None:
                    sheet.rect(x + xx * 3, y + yy * 3, x + xx * 3 + 2,
                               y + yy * 3 + 2, c)
        text(sheet, x, y + cv.h * 3 + 4, aid, DIM)
        x += cv.w * 3 + 24
    sheet.save(os.path.join(ROOT, "preview", "asset_library_sheet.png"))
    print("asset_library_sheet.png")


# ======================================================================
def depth_detail_sheet():
    ids = ["door_airlock_A", "inner_corner_A", "generator_unit_A",
           "roof_section_A", "service_tower_A"]
    K = (1, 2, 4)
    colw = []
    cvs = [(aid, render_asset(aid)[0]) for aid in ids]
    W = 40 + sum(c.w * 4 + 46 for _, c in cvs)
    H = 60 + max(c.h for _, c in cvs) * 4 + 30
    sheet = Canvas(W, H, bg=SHEET_BG)
    text(sheet, 12, 10, "DEPTH / SHADOW / MATERIAL DETAIL - 1X / 2X / 4X",
         LABEL, scale=2)
    text(sheet, 12, 26, "CHECK: TOP FACE / FRONT FACE / NICHE / CONTACT SHADOW / EDGE HIGHLIGHT",
         DIM)
    x = 16
    for aid, cv in cvs:
        y = 44
        for k in K:
            for yy in range(cv.h):
                for xx in range(cv.w):
                    c = cv.get(xx, yy)
                    if c is not None:
                        sheet.rect(x + xx * k, y + yy * k, x + xx * k + k - 1,
                                   y + yy * k + k - 1, c)
            text(sheet, x + cv.w * k + 4, y + 4, f"{k}x", DIM)
            y += cv.h * k + 10
        text(sheet, x, H - 12, aid, LABEL)
        x += cv.w * 4 + 46
    sheet.save(os.path.join(ROOT, "preview", "depth_detail_sheet.png"))
    print("depth_detail_sheet.png")


# ======================================================================
def variants_sheet():
    combos = [
        ("clean  amber  tech1", dict(cond="clean", accent="AMBER", tech=1)),
        ("worn   amber  tech1", dict(cond="worn", accent="AMBER", tech=1)),
        ("worn   teal   tech2", dict(cond="worn", accent="TEAL", tech=2)),
        ("damaged copper tech2", dict(cond="damaged", accent="COPPER", tech=2)),
        ("worn   teal   tech1 s7", dict(cond="worn", accent="TEAL", tech=1)),
        ("clean  copper tech0", dict(cond="clean", accent="COPPER", tech=0)),
    ]
    CW, CH = 96, 70
    sheet = Canvas(len(combos) * CW + 24, CH + 60, bg=SHEET_BG)
    text(sheet, 12, 10, "VARIATION SYSTEM - wall_panel_A: CONDITION / ACCENT / TECH DENSITY / SEED",
         LABEL)
    for i, (label, kw) in enumerate(combos):
        sc = Scene(120, 90, ox=20, oy=70)
        wall_panel_A(sc, sc.cv, 0, 0, seed=(7 if "s7" in label else 0), **kw)
        cv = sc.cv
        x = 12 + i * CW
        blit(sheet, cv, x, 26)
        text(sheet, x, 26 + 52, label, DIM)
    sheet.save(os.path.join(ROOT, "preview", "variants_wall_A.png"))
    print("variants_wall_A.png")


if __name__ == "__main__":
    asset_library_sheet()
    depth_detail_sheet()
    variants_sheet()
