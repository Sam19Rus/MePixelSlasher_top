"""
Depth & form primitives — the volumetric grammar of the frontier_service
family. Light: from UPPER-LEFT (sun NW, per N3 shadowDir 0.82/0.34).

Rules encoded here (each shadow has a physical cause, no universal AO):
  * protruding block on a face  -> highlight top+left edge, cast shadow
    strip to the RIGHT and BELOW (depth-proportional, 1..3 px);
  * recess (niche/panel)        -> soffit shadow strip INSIDE the top,
    dark reveal line on the left inside, lit sill strip at the bottom,
    outer frame edges catch light top+left;
  * overhanging slab (cornice)  -> strong 2-3 px shadow band on the face
    below + underside (soffit) dark strip on the slab itself;
  * object standing on ground   -> contact shadow (darkest row adjacent),
    plus long cast shadow to the lower-right when the sun says so;
  * vertical cylinders          -> left highlight column, right terminator,
    faint bounce at the extreme right edge.
"""

from palettes.frontier_service import col, LIGHT, RAMPS, shade_color
from common.noise import h2, bn
from projection.tilted_ortho import VS, HS, EAVE, lean_px


# ================================================================ faces
def face_tones(ramp, mid, face):
    """mid index for a given face orientation (light from upper-left)."""
    if face == "top":
        return min(len(RAMPS[ramp]) - 1, mid + 1)
    if face == "front":
        return mid
    if face == "shadow":      # face turned from the light / under overhang
        return max(0, mid - 2)
    if face == "soffit":      # underside
        return max(0, mid - 3)
    return mid


def edge_highlight(cv, x0, y0, x1, y1, ramp, mid, strength=1):
    """1px light catch on top (+left) edges of a raised face."""
    hi = min(len(RAMPS[ramp]) - 1, mid + 2)
    cv.hline(x0, x1, y0, col(ramp, hi))
    if strength > 1:
        cv.vline(x0, y0, y1, col(ramp, hi))


def edge_shade(cv, x0, y0, x1, y1, ramp, mid):
    """1px terminator on bottom (+right) edges of a raised face."""
    lo = max(0, mid - 2)
    cv.hline(x0, x1, y1, col(ramp, lo))
    cv.vline(x1, y0, y1, col(ramp, lo))


# ================================================================ mass
def draw_mass(sc, cv, x, y_front, w, d, z0, z1,
              mat_top, mat_front, seed,
              cornice=False, lean=False, cast=None, ao_below=0):
    """
    An axis-aligned box (mass) in world coords:
      x, y_front = front-left corner; w width (+x); d depth (toward -y);
      z0..z1 height range. mat_* = (paint_fn, kwargs) filling the face rect.
    Returns (front_rect, top_rect) screen rects for detailing.
    """
    fr = sc.front_rect(x, y_front, w, z0, z1)
    tr = sc.top_rect(x, y_front, w, d, z1) if d > 0 else None
    L = lean_px(z1 - z0) if lean else 0

    # top face (drawn first, sits above the front face on screen)
    if tr:
        tx0, ty0, tx1, ty1 = tr
        if L:  # wall lean: slab reveals slightly and is inset at the sides
            tx0 += 0
            ty1 -= 0
        mat_top(cv, tx0, ty0, tx1, ty1)
        # front lip of the top face: 1px bright edge where it meets the wall
        cv.hline(tx0, tx1, ty1, col(mat_front[1].get("edge_ramp", "CREAM"),
                                    min(len(RAMPS[mat_front[1].get("edge_ramp", "CREAM")]) - 1,
                                        mat_front[1].get("edge_mid", 4) + 2)))
        if cornice:
            # eave overhang: slab extends EAVE px past the face on both sides
            pass  # handled by caller geometry (roof slabs drawn wider)

    # front face
    fx0, fy0, fx1, fy1 = fr
    mat_front[0](cv, fx0, fy0, fx1, fy1, **mat_front[1])

    # contact AO where the mass meets the ground / mass below
    if ao_below:
        for i in range(ao_below):
            t = 0 if i == 0 else 1
            cv.hline(fx0, fx1, fy1 + 1 + i, col("DARK", t))

    # cast shadow (on ground or on the mass behind), lower-right
    if cast:
        _cast_box(cv, fx0, fy0, fx1, fy1, cast)
    return fr, tr


CAST_STEPS = (0.38, 0.52, 0.66)   # hard 3-step self-shadow ramp (spec V2 §4)


def _cast_box(cv, x0, y0, x1, y1, depth):
    """shadow a protruding rect casts on the face behind it: HARD-edged
    L-strip to the right and below, depth-proportional (1..3 px),
    darkest adjacent, no dithering (CrossCode-style flat shadow)."""
    for i in range(1, depth + 1):
        f = CAST_STEPS[min(i - 1, 2)]
        for yy in range(y0 + i, y1 + i + 1):
            c = cv.get(x1 + i, yy)
            if c is not None:
                cv.set(x1 + i, yy, shade_color(LIGHT.profile, f, c))
        for xx in range(x0 + i, x1 + i + 1):
            c = cv.get(xx, y1 + i)
            if c is not None:
                cv.set(xx, y1 + i, shade_color(LIGHT.profile, f, c))


def protrusion_shadow(cv, x0, y0, x1, y1, depth=2):
    """public alias: hard cast shadow of any proud element on its host face"""
    _cast_box(cv, x0, y0, x1, y1, depth)


def mass_separator(cv, x0, y0, x1, y1, shadow=2):
    """Readability rule R4: 1px DARK0 silhouette line on the left/right/
    bottom of a NEARER mass + a hard cast band on the surface to its right
    and below (the farther mass / ground behind it)."""
    cv.vline(x0 - 1, y0, y1, col("DARK", 0))
    cv.vline(x1 + 1, y0, y1, col("DARK", 0))
    cv.hline(x0, x1, y1 + 1, col("DARK", 0))
    for i in range(1, shadow + 1):
        f = CAST_STEPS[min(i, 2)]
        for yy in range(y0 + i, y1 + 1):
            c = cv.get(x1 + 1 + i, yy)
            if c is not None:
                cv.set(x1 + 1 + i, yy, shade_color(LIGHT.profile, f, c))
        for xx in range(x0 + i, x1 + 1 + i):
            c = cv.get(xx, y1 + 1 + i)
            if c is not None:
                cv.set(xx, y1 + 1 + i, shade_color(LIGHT.profile, f, c))


# ================================================================ recess
def recess(cv, x0, y0, x1, y1, depth, base_fn, seed,
           frame_ramp="CREAM", frame_mid=3, sill=True):
    """
    A niche in a wall face. Screen semantics at azimuth 0:
      * frame outer edges catch light (top+left 1px bright);
      * inside: soffit shadow strip (depth px) at the top, dark reveal 1px
        at the left, lit sill strip (depth px) at the bottom when sill=True;
      * back wall painted by base_fn between soffit and sill.
    """
    # outer frame light-catch
    hi = min(len(RAMPS[frame_ramp]) - 1, frame_mid + 2)
    cv.hline(x0 - 1, x1 + 1, y0 - 1, col(frame_ramp, hi))
    cv.vline(x0 - 1, y0 - 1, y1 + 1, col(frame_ramp, hi))
    cv.vline(x1 + 1, y0, y1, col(frame_ramp, max(0, frame_mid - 2)))
    # opening outline
    cv.outline(x0, y0, x1, y1, col("DARK", 0))
    d = min(depth, (y1 - y0) // 3)
    # back wall
    base_fn(cv, x0 + 1, y0 + d, x1 - 1, y1 - (d if sill else 1))
    # soffit shadow inside the top (darkest adjacent, fading in)
    for i in range(d):
        t = 0 if i < max(1, d - 1) else 1
        cv.hline(x0 + 1, x1 - 1, y0 + 1 + i, col("DARK", t) if i == 0 else col("GUN", t))
    # left reveal (jamb in shadow)
    cv.vline(x0 + 1, y0 + 1, y1 - 1, col("DARK", 1))
    if sill:
        # lit sill at the bottom of the niche (catches sky light)
        for i in range(d):
            cv.hline(x0 + 1, x1 - 1, y1 - i,
                     col(frame_ramp, hi) if i == 0 else col(frame_ramp, hi - 1))


# ================================================================ cornice
def cornice_shadow(cv, x0, x1, y, rows=3, strong=True):
    """shadow band an overhanging slab casts on the face below it:
    flat, hard-edged, 3 rows (spec V2 §4)."""
    fs = (0.34, 0.48, 0.62) if strong else (0.50, 0.62, 0.74)
    for i in range(rows):
        f = fs[min(i, 2)]
        for xx in range(x0, x1 + 1):
            c = cv.get(xx, y + i)
            if c is not None:
                cv.set(xx, y + i, shade_color(LIGHT.profile, f, c))


def soffit_strip(cv, x0, x1, y, ramp="GUN"):
    """dark underside strip on the slab itself."""
    cv.hline(x0, x1, y, col(ramp, 0))


# ================================================================ ground shadows
def contact_shadow(cv, x0, x1, y_ground, rows=3, jitter_seed=0):
    """object standing on ground: hard 3-row contact gradient
    (0.30 / 0.42 / 0.56), straight far edge (spec V2 §4)."""
    fs = (0.30, 0.42, 0.56)
    for i in range(rows):
        f = fs[min(i, 2)]
        for x in range(x0, x1 + 1):
            c = cv.get(x, y_ground + i)
            if c is not None:
                cv.set(x, y_ground + i, shade_color(LIGHT.profile, f, c))


def cast_shadow_ground(sc, cv, x, y_front, w, h, d=0):
    """long cast shadow of a mass on the ground plane (sun upper-left):
    FLAT hard-edged shadow figure + 2px darker contact row at the base
    (UNSIGHTED/CrossCode shadow grammar)."""
    sp = LIGHT.shadow
    dx = sp["dirx"] * h * sp["len"]
    dy = sp["diry"] * h * sp["len"]
    x0, x1 = x, x + w
    yb = y_front - (d if d else 0)
    p = sc.P
    hull = [
        p(x0, y_front),
        p(x1, y_front),
        p(x1 + dx, y_front + dy),
        p(x1 + dx, yb + dy),
        p(x0 + dx, yb + dy),
        p(x0, yb),
    ]
    f = 0.52 if sp["strength"] >= 1.0 else 0.62
    cv.poly_shade(hull, f, LIGHT.profile)
    # contact darkening right at the object base (hard, 2 rows)
    bx0, by = p(x0, y_front)
    bx1, _ = p(x1, y_front)
    for i in range(2):
        for xx in range(bx0, bx1 + 1):
            c = cv.get(xx, by + i)
            if c is not None:
                cv.set(xx, by + i, shade_color(LIGHT.profile, 0.36, c))


def silhouette(cv, fr, sides=("l", "r")):
    """1px DARK0 contour on a mass silhouette (readability rule R2)."""
    x0, y0, x1, y1 = fr
    if "l" in sides:
        cv.vline(x0 - 1, y0, y1, col("DARK", 0))
    if "r" in sides:
        cv.vline(x1 + 1, y0, y1, col("DARK", 0))


def junction_shadow(cv, xe, y0, y1, width=4):
    """hard cast band where a nearer mass meets a farther face (R4):
    1px DARK0 contact line at xe, then CAST_STEPS columns to the right."""
    cv.vline(xe, y0, y1, col("DARK", 0))
    for i in range(1, width + 1):
        f = (0.45, 0.58, 0.70)[min(i - 1, 2)]
        for yy in range(y0, y1 + 1):
            c = cv.get(xe + i, yy)
            if c is not None:
                cv.set(xe + i, yy, shade_color(LIGHT.profile, f, c))


# ================================================================ cylinders
def pipe_v(cv, x, y0, y1, r, ramp="SLATE", mid=2, rust_at=None, cast=True):
    """vertical pipe, half-width r (full width 2r+1 approximated).
    Light from the left: highlight column at x-r+1, terminator right.
    cast=True: 1px hard shadow column on the surface behind, to the right."""
    w = 2 * r
    for yy in range(y0, y1 + 1):
        for i in range(w):
            xx = x + i
            if i == 0:
                c = col(ramp, max(0, mid - 2))
            elif i == 1:
                c = col(ramp, min(len(RAMPS[ramp]) - 1, mid + 2))
            elif i == 2:
                c = col(ramp, min(len(RAMPS[ramp]) - 1, mid + 1))
            elif i < w - 2:
                c = col(ramp, mid)
            elif i == w - 2:
                c = col(ramp, max(0, mid - 2))
            else:
                c = col(ramp, max(0, mid - 1))     # bounce edge
            cv.set(xx, yy, c)
    if cast:
        for yy in range(y0, y1 + 1):
            c = cv.get(x + w, yy)
            if c is not None:
                cv.set(x + w, yy, shade_color(LIGHT.profile, 0.5, c))
    if rust_at:
        for (ry, rh) in rust_at:
            for yy in range(ry, ry + rh):
                for i in range(w):
                    if h2(i, yy, 555) < 0.55:
                        cv.set(x + i, yy, col("COPPER", 1 + (i % 3)))


def pipe_h(cv, x0, x1, y, r, ramp="SLATE", mid=2, cast=True):
    """horizontal pipe (along screen x): highlight row near the top,
    1px hard shadow row on the surface below."""
    h = 2 * r
    for i in range(h):
        yy = y + i
        if i == 0:
            c = col(ramp, min(len(RAMPS[ramp]) - 1, mid + 1))
        elif i == 1:
            c = col(ramp, min(len(RAMPS[ramp]) - 1, mid + 2))
        elif i < h - 2:
            c = col(ramp, mid)
        elif i == h - 2:
            c = col(ramp, max(0, mid - 2))
        else:
            c = col(ramp, max(0, mid - 1))
        for xx in range(x0, x1 + 1):
            cv.set(xx, yy, c)
    if cast:
        for xx in range(x0, x1 + 1):
            c = cv.get(xx, y + h)
            if c is not None:
                cv.set(xx, y + h, shade_color(LIGHT.profile, 0.5, c))


def flange_v(cv, x, y, r, ramp="GUN", mid=3):
    """collar/flange ring around a vertical pipe at height y."""
    pipe_v(cv, x - 1, y - 1, y + 2, r + 1, ramp=ramp, mid=mid)


def flange_h(cv, x, y, r, ramp="GUN", mid=3):
    pipe_h(cv, x - 1, x + 2, y - 1, r + 1, ramp=ramp, mid=mid)


def elbow_vh(cv, x, y, r, to="+x", ramp="SLATE", mid=2):
    """90° bend: vertical pipe arriving at (x..x+2r, y) turning horizontal.
    Drawn as a quarter ring + square throat — reads at 1x."""
    import math
    cx, cy = x + r, y
    ro, ri = 2 * r, 1
    a0, a1 = (-math.pi / 2, 0) if to == "+x" else (-math.pi / 2, -math.pi)
    steps = int(abs(a1 - a0) * ro * 2.2)
    for i in range(steps + 1):
        a = a0 + (a1 - a0) * i / steps
        for rr in range(ri, ro):
            px = int(round(cx + rr * math.cos(a)))
            py = int(round(cy + rr * math.sin(a)))
            k = (rr - ri) / max(1, (ro - ri - 1))
            if k < 0.25:
                c = col(ramp, min(len(RAMPS[ramp]) - 1, mid + 2))
            elif k < 0.75:
                c = col(ramp, mid)
            else:
                c = col(ramp, max(0, mid - 2))
            cv.set(px, py, c)
