"""
Material fields — CLARITY PASS (UPGRADE SPEC V2, section 3).

Surface language after the reference study (UNSIGHTED / CrossCode):
  * every material is a FLAT base tone first;
  * structure comes from REGULAR lines (pour courses, machining ribs,
    panel seams) at <= 1 ramp step contrast;
  * value variation only as LARGE block-octave zones (cell >= 12 px) and
    only on extreme noise thresholds, so <= ~12% of the area shifts;
  * per-pixel speckle is GONE (density 0). Wear lives in logical anchors
    and is drawn as discrete shapes by details.py, not here.

Every painter fills a screen-space rect (x0,y0,x1,y1) inclusive.
`mid` = ramp index of the face's mid tone (caller decides orientation).
"""

from common.noise import h2, bn
from palettes.frontier_service import col, RAMPS


# ---------------------------------------------------------------- paint
def paint_metal(cv, x0, y0, x1, y1, seed, ramp, mid, cell=16, speckle=0.0):
    """PAINTED METAL: flat field + sparse large batch zones (no mottle)."""
    lo = max(0, mid - 1)
    hi = min(len(RAMPS[ramp]) - 1, mid + 1)
    base = col(ramp, mid)
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            q = bn(x, y, seed + 7, cell)
            if q < 0.14:
                cv.set(x, y, col(ramp, lo))
            elif q > 0.90:
                cv.set(x, y, col(ramp, hi))
            else:
                cv.set(x, y, base)
    if speckle > 0:
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                r = h2(x, y, seed + 13)
                if r > 1.0 - speckle:
                    cv.set(x, y, col(ramp, hi))
                elif r < speckle * 0.8:
                    cv.set(x, y, col(ramp, lo))


# ---------------------------------------------------------------- raw metal
def raw_metal(cv, x0, y0, x1, y1, seed, ramp="SLATE", mid=2, cell=3):
    """RAW/EXPOSED METAL: flat field + regular horizontal machining ribs."""
    hi = min(len(RAMPS[ramp]) - 1, mid + 1)
    lo = max(0, mid - 1)
    base = col(ramp, mid)
    rib = col(ramp, lo)
    top = col(ramp, hi)
    for y in range(y0, y1 + 1):
        c = top if (y - y0) == 0 else (rib if (y - y0) % cell == cell - 1 else base)
        for x in range(x0, x1 + 1):
            cv.set(x, y, c)


# ---------------------------------------------------------------- concrete
def concrete(cv, x0, y0, x1, y1, seed, mid=3, cell=7):
    """CONCRETE: flat matte field + horizontal pour courses (1px, -1 step)
    + very sparse large zones. No per-pixel grain."""
    lo = max(0, mid - 1)
    hi = min(len(RAMPS["CONC"]) - 1, mid + 1)
    base = col("CONC", mid)
    course = col("CONC", lo)
    for y in range(y0, y1 + 1):
        is_course = (y - y0) % cell == cell - 1
        for x in range(x0, x1 + 1):
            if is_course:
                cv.set(x, y, course)
            else:
                q = bn(x, y, seed + 31, 12)
                if q < 0.16:
                    cv.set(x, y, col("CONC", lo))
                elif q > 0.90:
                    cv.set(x, y, col("CONC", hi))
                else:
                    cv.set(x, y, base)


# ---------------------------------------------------------------- rubber
def rubber(cv, x0, y0, x1, y1, seed):
    """RUBBER/POLYMER: flat dark field, single top light row."""
    for y in range(y0, y1 + 1):
        c = col("RUBBER", 2) if y == y0 else col("RUBBER", 1)
        for x in range(x0, x1 + 1):
            cv.set(x, y, c)


# ---------------------------------------------------------------- glass
def glass(cv, x0, y0, x1, y1, seed, lit=None):
    """GLASS: flat dark teal field + crisp diagonal reflection."""
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            cv.set(x, y, col("GLASS", 1))
    w, h = x1 - x0 + 1, y1 - y0 + 1
    if w >= 6 and h >= 6:
        for k in range(-1, h):
            x = x0 + 2 + k
            y = y0 + k
            if x0 <= x <= x1 - 2 and y0 <= y <= y1:
                cv.set(x, y, col("GLASS", 4))
                if x + 1 <= x1:
                    cv.set(x + 1, y, col("GLASS", 3))
        for k in range(-1, h):
            x = x0 + 2 + w // 2 + k
            y = y0 + k
            if x0 <= x <= x1 - 1 and y0 + 1 <= y <= y1:
                cv.set(x, y, col("GLASS", 3))
    if lit is not None:  # night-lit window override
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                cv.set(x, y, col("WARM", 1 if (x + y) % 9 else 2))


# ---------------------------------------------------------------- warning
def warning_patch(cv, x0, y0, x1, y1, seed, wear=0.22):
    """PAINTED WARNING SURFACE: 45deg amber/slate bars, crisp patch border,
    light abrasion only at the edges."""
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            s = ((x - x0) + (y - y0)) // 3
            bar = s % 2 == 0
            edge = (x in (x0, x1) or y in (y0, y1))
            if edge and h2(x, y, seed + 61) < 0.3:
                continue
            if bar:
                c = col("AMBER", 3)
            else:
                c = col("SLATE", 1)
            d_edge = min(x - x0, x1 - x, y - y0, y1 - y)
            if d_edge < 2 and h2(x, y, seed + 63) < wear * 0.5:
                continue
            cv.set(x, y, c)


# ---------------------------------------------------------------- dirt/ground
def ground_field(cv, x0, y0, x1, y1, seed, mid=2):
    """Service-yard ground: flat base + LARGE tonal zones + discrete
    gravel clusters (2x1) + rare dark pits. No per-pixel static."""
    lo = col("DIRT", max(0, mid - 1))
    base = col("DIRT", mid)
    grv = col("SLATE", 1)
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            cv.set(x, y, base)
            if bn(x, y, seed + 73, 5) > 0.975 and (x + y) % 2 == 0:
                cv.set(x, y, grv)                 # 2x1 gravel cluster head
                cv.set(x + 1, y, grv)
            elif bn(x, y, seed + 74, 9) < 0.02:
                cv.set(x, y, lo)


def concrete_slab(cv, x0, y0, x1, y1, seed, mid=3, ax=0, ay=0):
    """Poured concrete pad (top faces): flat slabs + expansion joints.
    (ax, ay) = world-grid anchor so joints line up across modules."""
    concrete(cv, x0, y0, x1, y1, seed, mid=mid, cell=9)
    for gx in range(x0, x1 + 1):
        if (gx - ax) % 28 == 0 and x0 < gx <= x1:
            cv.vline(gx, y0, y1, col("CONC", max(0, mid - 1)))
    for gy in range(y0, y1 + 1):
        if (gy - ay) % 16 == 0 and y0 < gy <= y1:
            cv.hline(x0, x1, gy, col("CONC", max(0, mid - 1)))
