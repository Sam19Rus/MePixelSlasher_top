"""
Deterministic integer hash noise. No numpy, no floats beyond [0,1).
Same functions/quality bar as the V2 wall benchmark, new salts.
Used ONLY for micro-texture selection and art-directed jitter —
never for compositional decisions.
"""


def h2(x, y, s):
    """stable 2D hash -> [0,1)"""
    n = (x * 374761393 + y * 668265263 + s * 974634721) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65536.0


def h3(x, y, z, s):
    n = (x * 374761393 + y * 668265263 + z * 2246822519 + s * 974634721) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65536.0


def bn(x, y, s, sc):
    """block noise at cell size sc (constant inside each sc×sc cell)"""
    return h2(x // sc, y // sc, s)


def fb(x, y, s):
    """crisp irregular field: two hash octaves, good for masks"""
    return 0.62 * bn(x, y, s, 2) + 0.38 * h2(x, y, s + 91)


def pick(vals, x, y, s):
    """deterministic choice from a list"""
    return vals[int(h2(x, y, s) * len(vals)) % len(vals)]
