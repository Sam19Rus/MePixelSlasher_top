"""
Detail vocabulary of the frontier_service family — the NEW motifs that
replace the old wall experiments (no lap panels, no capsule hatches, no
louver vents, no continuous hazard stripes):

  * rivet / bolt lines on flanged seams
  * chamfered recessed panels (2px 45° corner cuts)
  * octagonal vent grilles with radial blades
  * perforated hex grilles
  * cartridge slot arrays
  * diagonal conduit runs with clamps
  * cable swags (catenaries)
  * trapezoid stencils & worn warning patches
  * chips / scratches / short rust weeps / grime / dust caps
"""

from palettes.frontier_service import col, RAMPS, shade_color, LIGHT
from common.noise import h2, bn
from common.font import text


# ---------------------------------------------------------------- fasteners
def rivet(cv, x, y, ramp="SLATE", hi=4, lo=1):
    cv.set(x, y, col(ramp, hi))
    cv.set(x, y + 1, col(ramp, lo))


def rivet_line_h(cv, x0, x1, y, step, ramp="SLATE", hi=4, lo=1):
    for x in range(x0, x1 + 1, step):
        rivet(cv, x, y, ramp, hi, lo)


def rivet_line_v(cv, x, y0, y1, step, ramp="SLATE", hi=4, lo=1):
    for y in range(y0, y1 + 1, step):
        rivet(cv, x, y, ramp, hi, lo)


def bolt(cv, x, y, ramp="GUN", mid=4):
    """2x2 hex-ish bolt: bright TL, dark BR"""
    cv.set(x, y, col(ramp, min(len(RAMPS[ramp]) - 1, mid + 1)))
    cv.set(x + 1, y, col(ramp, mid))
    cv.set(x, y + 1, col(ramp, mid))
    cv.set(x + 1, y + 1, col(ramp, max(0, mid - 2)))


def bolt_ring(cv, x0, y0, x1, y1, inset=2, ramp="GUN", mid=4):
    bolt(cv, x0 + inset, y0 + inset, ramp, mid)
    bolt(cv, x1 - inset - 1, y0 + inset, ramp, mid)
    bolt(cv, x0 + inset, y1 - inset - 1, ramp, mid)
    bolt(cv, x1 - inset - 1, y1 - inset - 1, ramp, mid)


# ---------------------------------------------------------------- vents
def oct_vent(cv, cx, cy, r, seed=0, ramp="GUN", frame="SLATE",
             frame_mid=3, blades=True):
    """octagonal intake: raised frame, dark interior, radial blades.
    Octagon = max(|dx|,|dy|)<=r AND |dx|+|dy| <= r + r//2 (true cut corners,
    not a diamond)."""
    import math
    cut = max(1, r // 2)
    lim = r + cut
    fr_hi = min(len(RAMPS[frame]) - 1, frame_mid + 2)
    fr_lo = max(0, frame_mid - 2)
    # frame ring
    for y in range(cy - r - 2, cy + r + 3):
        for x in range(cx - r - 2, cx + r + 3):
            dx, dy = abs(x - cx), abs(y - cy)
            outside = max(dx, dy) <= r + 1 and dx + dy <= lim + 1
            inside = max(dx, dy) <= r and dx + dy <= lim
            if outside and not inside:
                c = fr_hi if (y < cy or (y == cy and x < cx)) else fr_lo
                if y >= cy and x < cx - r + cut:
                    c = frame_mid
                cv.set(x, y, col(frame, c))
    # interior: dark cavity with radial blades
    for y in range(cy - r, cy + r + 1):
        for x in range(cx - r, cx + r + 1):
            dx, dy = abs(x - cx), abs(y - cy)
            if max(dx, dy) <= r and dx + dy <= lim:
                cv.set(x, y, col("DARK", 0))
    if blades:
        nb = 8
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r, cx + r + 1):
                ddx, ddy = x - cx, y - cy
                dist = math.hypot(ddx, ddy)
                if dist > r or abs(ddx) + abs(ddy) > lim:
                    continue
                if dist < 1.6:
                    continue
                ang = math.atan2(ddy, ddx) % (2 * math.pi)
                if (ang * nb / (2 * math.pi)) % 1.0 < 0.42:
                    cv.set(x, y, col(ramp, 2 if dist < r * 0.75 else 1))
    # hub + shadow under the hub
    cv.set(cx, cy, col(frame, frame_mid + 1))
    cv.set(cx + 1, cy + 1, col("DARK", 0))
    # inner top soffit shadow (light from above)
    for y in range(cy - r, cy - r + max(1, r // 3)):
        for x in range(cx - r, cx + r + 1):
            dx, dy = abs(x - cx), abs(y - cy)
            if max(dx, dy) <= r and dx + dy <= lim:
                cv.set(x, y, col("DARK", 0))
    # hard 1px cast shadow of the proud frame on the host face
    for y in range(cy - r - 2, cy + r + 3):
        c = cv.get(cx + r + 3, y)
        if c is not None:
            cv.set(cx + r + 3, y, shade_color(LIGHT.profile, 0.5, c))
    for x in range(cx - r - 2, cx + r + 3):
        c = cv.get(x, cy + r + 3)
        if c is not None:
            cv.set(x, cy + r + 3, shade_color(LIGHT.profile, 0.5, c))


def hex_grille(cv, x0, y0, x1, y1, ramp="GUN", hole=0, bright=3):
    """perforated plate grille (generator vents): staggered dark holes."""
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            row = y - y0
            off = 1 if row % 2 else 0
            cellx = (x - x0 + off) % 3
            if cellx < 2 and row % 2 == (row % 2):
                if (x - x0 + off) % 3 < 2 and y % 2 == 0:
                    cv.set(x, y, col(ramp, hole))
                else:
                    cv.set(x, y, col(ramp, bright if (x + y) % 7 == 0 else 2))
            else:
                cv.set(x, y, col(ramp, 2))


# ---------------------------------------------------------------- panels
def chamfer_panel(cv, x0, y0, x1, y1, cut, fill_fn, seed,
                  frame_ramp="GUN", frame_mid=3, depth=2):
    """
    Family signature: recessed panel with 45° cut corners.
    fill_fn paints the panel bottom; then depth shading is applied:
    soffit strip inside top, reveal left, sill bottom, frame light catch.
    """
    wall = cv.get(x0 - 3, y0) or col(frame_ramp, frame_mid)
    cv.chamfer_rect(x0, y0, x1, y1, cut, col("DARK", 0))
    fill_fn(cv, x0 + 1, y0 + depth, x1 - 1, y1 - 1)
    # re-cut the corners: outside-the-chamfer pixels return to wall colour
    for i in range(cut + 1):
        for j in range(cut + 1 - i):
            cv.set(x0 + i, y0 + j, wall)          # TL
            cv.set(x1 - i, y0 + j, wall)          # TR
            cv.set(x0 + i, y1 - j, wall)          # BL
            cv.set(x1 - i, y1 - j, wall)          # BR
    cv.chamfer_outline(x0, y0, x1, y1, cut, col("DARK", 0))
    # soffit shadow (depth px inside the top)
    for i in range(depth):
        for x in range(x0 + cut, x1 - cut + 1):
            cv.set(x, y0 + 1 + i, col("DARK", 0) if i == 0 else col("GUN", 0))
        # chamfer rungs
        if i < cut:
            for xx in (x0 + i + 1, x1 - i - 1):
                cv.set(xx, y0 + 1 + i, col("DARK", 0) if i == 0 else col("GUN", 0))
    # left reveal
    for y in range(y0 + cut, y1 - cut + 1):
        cv.set(x0 + 1, y, col("GUN", 0))
    # sill light catch along the bottom inside
    for x in range(x0 + cut, x1 - cut + 1):
        cv.set(x, y1 - 1, col(frame_ramp, min(len(RAMPS[frame_ramp]) - 1, frame_mid + 2)))
    # frame light-catch on the wall around the opening (top+left)
    cv.chamfer_outline(x0 - 1, y0 - 1, x1 + 1, y1 + 1, cut + 1,
                       col(frame_ramp, min(len(RAMPS[frame_ramp]) - 1, frame_mid + 1)))
    # right/bottom outer edges go dark (panel border terminator)
    cv.vline(x1 + 1, y0 + cut, y1 - cut, col(frame_ramp, max(0, frame_mid - 2)))
    # hard cast shadow of the proud frame onto the wall (right + below)
    for y in range(y0 + cut, y1 - cut + 1):
        c = cv.get(x1 + 2, y)
        if c is not None:
            cv.set(x1 + 2, y, shade_color(LIGHT.profile, 0.55, c))
    for x in range(x0 + cut, x1 - cut + 1):
        c = cv.get(x, y1 + 2)
        if c is not None:
            cv.set(x, y1 + 2, shade_color(LIGHT.profile, 0.55, c))


def cartridge_slots(cv, x0, y0, x1, y1, n, seed, slot_w=None,
                    body_ramp="TEAL", body_mid=3, open_idx=None):
    """row of removable service cartridges (family motif #2).
    open_idx: one slot is empty -> dark cavity with visible depth."""
    gap = 2
    total = x1 - x0 + 1
    slot_w = slot_w or (total - gap * (n - 1)) // n
    for i in range(n):
        sx0 = x0 + i * (slot_w + gap)
        sx1 = sx0 + slot_w - 1
        if sx1 > x1:
            break
        # cavity
        cv.rect(sx0, y0, sx1, y1, col("DARK", 0))
        if open_idx is not None and i == open_idx:
            # empty slot: back wall dimly visible + deep top shadow
            cv.rect(sx0 + 1, y0 + 3, sx1 - 1, y1 - 1, col("GUN", 0))
            cv.hline(sx0 + 1, sx1 - 1, y0 + 3, col("DARK", 0))
            cv.set(sx0 + 2, y1 - 2, col("SLATE", 1))
            continue
        # cartridge body inset 1px
        bx0, by0, bx1, by1 = sx0 + 1, y0 + 1, sx1 - 1, y1 - 1
        cv.rect(bx0, by0, bx1, by1, col(body_ramp, body_mid))
        cv.hline(bx0, bx1, by0 + 2, col(body_ramp, max(0, body_mid - 1)))
        # top shadow (cartridge sits deep), handle notch, label
        cv.hline(bx0, bx1, by0, col("GUN", 0))
        cv.hline(bx0, bx1, by0 + 1, col(body_ramp, max(0, body_mid - 2)))
        hx = (bx0 + bx1) // 2
        cv.rect(hx - 2, by0 + 3, hx + 2, by0 + 4, col("GUN", 1))
        cv.set(hx - 2, by0 + 3, col("SLATE", 3))
        lab = col("CREAM", 4) if h2(i, 7, seed) > 0.5 else col("AMBER", 2)
        cv.rect(bx0 + 2, by1 - 4, bx0 + 5, by1 - 3, lab)
        # right edge terminator
        cv.vline(bx1, by0, by1, col(body_ramp, max(0, body_mid - 2)))
    # hard cast shadow of the whole bay frame on the wall (below + right)
    for x in range(x0, x1 + 1):
        c = cv.get(x, y1 + 1)
        if c is not None:
            cv.set(x, y1 + 1, shade_color(LIGHT.profile, 0.5, c))
    for y in range(y0, y1 + 1):
        c = cv.get(x1 + 1, y)
        if c is not None:
            cv.set(x1 + 1, y, shade_color(LIGHT.profile, 0.5, c))


# ---------------------------------------------------------------- cables
def cable_sag(cv, x0, y0, x1, y1, sag, c=None, thick=1, seed=0):
    """catenary-ish cable between two anchors (screen coords)."""
    c = c or col("RUBBER", 1)
    steps = abs(x1 - x0) + 1
    ch = col("SLATE", 1)
    prev = None
    for i in range(steps):
        t = i / max(1, steps - 1)
        x = x0 + (x1 - x0) * t
        y = y0 + (y1 - y0) * t + sag * 4 * t * (1 - t)
        xi, yi = int(round(x)), int(round(y))
        for k in range(thick):
            cv.set(xi, yi + k, c)
        # sparse top-light only where the run is nearly horizontal
        if prev is not None and yi == prev and h2(xi, 3, seed) > 0.62:
            cv.set(xi, yi - 1, ch)
        prev = yi


def conduit_diag(cv, x0, y0, x1, y1, ramp="SLATE", mid=2):
    """diagonal conduit run (family motif): 2px thick 45°-ish line with
    a highlight pixel above, clamp marks and end collars (anchored)."""
    for (ex, ey) in ((x0, y0), (x1, y1)):
        cv.rect(ex - 1, ey - 2, ex + 1, ey + 2, col("GUN", 3))
        cv.vline(ex - 1, ey - 2, ey + 2, col("SLATE", 4))
        cv.vline(ex + 2, ey - 1, ey + 2, col("DARK", 0))
    steps = max(abs(x1 - x0), abs(y1 - y0)) + 1
    for i in range(steps):
        t = i / max(1, steps - 1)
        x = int(round(x0 + (x1 - x0) * t))
        y = int(round(y0 + (y1 - y0) * t))
        cv.set(x, y, col(ramp, mid))
        cv.set(x, y + 1, col(ramp, max(0, mid - 2)))
        cv.set(x, y - 1, col(ramp, min(len(RAMPS[ramp]) - 1, mid + 2)))
        if i > 0 and i % 9 == 0:
            clamp(cv, x, y)


def clamp(cv, x, y, ramp="GUN", mid=3):
    cv.rect(x - 1, y - 2, x + 1, y + 2, col(ramp, mid))
    cv.set(x - 1, y - 2, col(ramp, mid + 1))
    cv.set(x + 1, y + 2, col(ramp, mid - 2))
    cv.set(x, y, col(ramp, mid - 1))


# ---------------------------------------------------------------- wear
def chip(cv, x, y, seed, n=2, ramp_under="SLATE"):
    """paint chip: bright bare-metal pixels with a dark bite below."""
    for i in range(n):
        cv.set(x + i, y, col(ramp_under, 4))
        cv.set(x + i, y + 1, col(ramp_under, 1))
    cv.set(x - 1, y, col("GUN", 1))


def scratch(cv, x, y, ln, seed, ramp="SLATE", hi=4):
    y1 = y + (1 if h2(x, y, seed) > 0.5 else 0)
    for i in range(ln):
        xx = x + i
        yy = y if i < ln - 1 else y1
        cv.set(xx, yy, col(ramp, hi) if h2(xx, yy, seed + 2) > 0.35 else col(ramp, 1))


def rust_weep(cv, x, y_top, ln, seed, width=1):
    """short tapered rust streak below a fastener/seam (COPPER ramp)."""
    for i in range(ln):
        t = i / ln
        if h2(x, y_top + i, seed + 17) < t * 0.7:
            continue
        cidx = 1 if t < 0.4 else (2 if t < 0.75 else 3)
        for w in range(width if i < ln * 0.4 else max(1, width - 1)):
            cv.set(x + w, y_top + i, col("COPPER", cidx))


def grime(cv, x0, y0, x1, y1, seed, amt=0.3, ramp="DIRT"):
    """dirt concentrating in the bottom 4 rows of a face (logical anchor),
    discrete flecks, no full-field noise."""
    h = y1 - y0 + 1
    for y in range(max(y0, y1 - 4), y1 + 1):
        w = (y - y0 + 1) / h
        for x in range(x0, x1 + 1):
            if h2(x // 1, y, seed + 29) < amt * w * w * w:
                cv.set(x, y, col(ramp, 0 if h2(x, y, seed + 30) > 0.6 else 1))


def dust_cap(cv, x0, x1, y, seed, ramp="DIRT", idx=3, amt=0.28):
    """pale dust collecting on an upward edge (sparse, crisp)."""
    for x in range(x0, x1 + 1):
        if h2(x // 2, y, seed + 37) < amt:
            cv.set(x, y, col(ramp, idx))


def soot(cv, x0, y0, x1, y1, seed, amt=0.6):
    """dark sooty deposit (above exhausts, around seams)."""
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            q = h2(x, y, seed + 43)
            if q < amt * 0.4:
                cv.set(x, y, col("DARK", 1))
            elif q < amt * 0.65:
                cv.set(x, y, col("GUN", 0))


def stencil(cv, x, y, s, ramp="AMBER", idx=2, wear=0.3, seed=0, scale=1):
    text(cv, x, y, s, col(ramp, idx), scale=scale, wear=wear, seed=seed)
