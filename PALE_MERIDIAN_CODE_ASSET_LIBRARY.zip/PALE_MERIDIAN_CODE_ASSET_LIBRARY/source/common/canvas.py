"""
Integer pixel canvas. No AA, no blur, no vectors.
PIL is used ONLY to save/resize PNGs (nearest neighbour for previews).
Pixels are (r,g,b) tuples; None/0 alpha handled by a separate mask.
"""

from PIL import Image


class Canvas:
    def __init__(self, w, h, bg=None):
        self.w, self.h = w, h
        self.g = [bg] * (w * h)          # bg None == transparent

    # -- basic ops -----------------------------------------------------
    def inside(self, x, y):
        return 0 <= x < self.w and 0 <= y < self.h

    def set(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.g[y * self.w + x] = c

    def get(self, x, y):
        if 0 <= x < self.w and 0 <= y < self.h:
            return self.g[y * self.w + x]
        return None

    def set_if(self, x, y, c, pred):
        """paint only over colours passing pred(old)"""
        if 0 <= x < self.w and 0 <= y < self.h:
            i = y * self.w + x
            if pred(self.g[i]):
                self.g[i] = c

    def rect(self, x0, y0, x1, y1, c):
        for y in range(max(0, y0), min(self.h, y1 + 1)):
            row = y * self.w
            for x in range(max(0, x0), min(self.w, x1 + 1)):
                self.g[row + x] = c

    def hline(self, x0, x1, y, c):
        if 0 <= y < self.h:
            for x in range(max(0, x0), min(self.w, x1 + 1)):
                self.g[y * self.w + x] = c

    def vline(self, x, y0, y1, c):
        if 0 <= x < self.w:
            for y in range(max(0, y0), min(self.h, y1 + 1)):
                self.g[y * self.w + x] = c

    def outline(self, x0, y0, x1, y1, c):
        self.hline(x0, x1, y0, c)
        self.hline(x0, x1, y1, c)
        self.vline(x0, y0, y1, c)
        self.vline(x1, y0, y1, c)

    # -- chamfered rect (family signature) -----------------------------
    def chamfer_rect(self, x0, y0, x1, y1, cut, c):
        """filled rect with 45° corner cuts of `cut` px"""
        self.rect(x0 + cut, y0, x1 - cut, y1, c)
        self.rect(x0, y0 + cut, x1, y1 - cut, c)
        for i in range(cut):
            self.hline(x0 + i, x0 + cut - 1, y0 + i, c)      # TL
            self.hline(x1 - cut + 1, x1 - i, y0 + i, c)      # TR
            self.hline(x0 + i, x0 + cut - 1, y1 - i, c)      # BL
            self.hline(x1 - cut + 1, x1 - i, y1 - i, c)      # BR

    def chamfer_outline(self, x0, y0, x1, y1, cut, c):
        self.hline(x0 + cut, x1 - cut, y0, c)
        self.hline(x0 + cut, x1 - cut, y1, c)
        self.vline(x0, y0 + cut, y1 - cut, c)
        self.vline(x1, y0 + cut, y1 - cut, c)
        for i in range(cut):
            self.set(x0 + cut - 1 - i, y0 + i, c)
            self.set(x0 + i, y0 + cut - 1 - i, c)
            self.set(x1 - cut + 1 + i, y0 + i, c)
            self.set(x1 - i, y0 + cut - 1 - i, c)
            self.set(x0 + cut - 1 - i, y1 - i, c)
            self.set(x0 + i, y1 - cut + 1 + i, c)
            self.set(x1 - cut + 1 + i, y1 - i, c)
            self.set(x1 - i, y1 - cut + 1 + i, c)

    # -- lines / curves -------------------------------------------------
    def line(self, x0, y0, x1, y1, c):
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        while True:
            self.set(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy

    def circle_fill(self, cx, cy, r, c):
        r2 = r * r + r * 0.4
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r, cx + r + 1):
                dx, dy = x - cx, y - cy
                if dx * dx + dy * dy <= r2:
                    self.set(x, y, c)

    def ring(self, cx, cy, r, c, thick=1):
        ro2 = (r + 1) * (r + 1)
        ri2 = max(0, (r - thick + 1)) ** 2 - 1
        for y in range(cy - r - 1, cy + r + 2):
            for x in range(cx - r - 1, cx + r + 2):
                d = (x - cx) ** 2 + (y - cy) ** 2
                if ri2 < d <= ro2:
                    self.set(x, y, c)

    def arc(self, cx, cy, r, a0, a1, c, thick=1):
        """arc from angle a0 to a1 (radians, screen space, cw through)"""
        import math
        steps = max(8, int(abs(a1 - a0) * r * 3))
        for i in range(steps + 1):
            a = a0 + (a1 - a0) * i / steps
            x = int(round(cx + r * math.cos(a)))
            y = int(round(cy + r * math.sin(a)))
            for t in range(thick):
                self.set(x, y + t, c)

    # -- scanline polygon (axis-agnostic, integer, deterministic) -------
    def poly(self, pts, c):
        if len(pts) < 3:
            return
        ymin = max(0, min(p[1] for p in pts))
        ymax = min(self.h - 1, max(p[1] for p in pts))
        for y in range(ymin, ymax + 1):
            xs = []
            for i in range(len(pts)):
                x0, y0 = pts[i]
                x1, y1 = pts[(i + 1) % len(pts)]
                if y0 == y1:
                    continue
                if (y0 <= y < y1) or (y1 <= y < y0):
                    t = (y - y0) / (y1 - y0)
                    xs.append(x0 + (x1 - x0) * t)
            xs.sort()
            for i in range(0, len(xs) - 1, 2):
                self.hline(int(round(xs[i])), int(round(xs[i + 1])) - 1, y, c)

    def _scanpairs(self, pts):
        ymin = max(0, min(p[1] for p in pts))
        ymax = min(self.h - 1, max(p[1] for p in pts))
        for y in range(ymin, ymax + 1):
            xs = []
            for i in range(len(pts)):
                x0, y0 = pts[i]
                x1, y1 = pts[(i + 1) % len(pts)]
                if y0 == y1:
                    continue
                if (y0 <= y < y1) or (y1 <= y < y0):
                    t = (y - y0) / (y1 - y0)
                    xs.append(x0 + (x1 - x0) * t)
            xs.sort()
            for i in range(0, len(xs) - 1, 2):
                yield y, int(round(xs[i])), int(round(xs[i + 1])) - 1

    def poly_shade(self, pts, factor, profile=None):
        """darken existing pixels inside a polygon (surface-aware shadow)"""
        from palettes.frontier_service import shade_color, LIGHT
        if profile is None:
            profile = LIGHT.profile
        for y, xa, xb in self._scanpairs(pts):
            for x in range(max(0, xa), min(self.w - 1, xb) + 1):
                i = y * self.w + x
                c = self.g[i]
                if c is not None:
                    self.g[i] = shade_color(profile, factor, c)

    def rect_shade(self, x0, y0, x1, y1, factor, profile=None):
        from palettes.frontier_service import shade_color, LIGHT
        if profile is None:
            profile = LIGHT.profile
        for y in range(max(0, y0), min(self.h, y1 + 1)):
            row = y * self.w
            for x in range(max(0, x0), min(self.w, x1 + 1)):
                c = self.g[row + x]
                if c is not None:
                    self.g[row + x] = shade_color(profile, factor, c)

    # -- io ---------------------------------------------------------------
    def to_image(self, transparent_bg=True):
        im = Image.new("RGBA", (self.w, self.h))
        px = im.load()
        for y in range(self.h):
            row = y * self.w
            for x in range(self.w):
                c = self.g[row + x]
                if c is None:
                    px[x, y] = (0, 0, 0, 0)
                else:
                    px[x, y] = (c[0], c[1], c[2], 255)
        return im

    def save(self, path, scale=1, transparent_bg=True):
        im = self.to_image(transparent_bg)
        if scale != 1:
            im = im.resize((self.w * scale, self.h * scale), Image.NEAREST)
        im.save(path)
        return im


def upscale(im, k):
    return im.resize((im.width * k, im.height * k), Image.NEAREST)
