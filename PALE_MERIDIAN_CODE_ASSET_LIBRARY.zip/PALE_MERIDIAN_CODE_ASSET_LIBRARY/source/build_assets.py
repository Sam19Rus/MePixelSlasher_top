"""
Build the 18 standalone asset PNGs (RGBA, transparent background) +
an iteration contact sheet. Every PNG is fully reproducible from code.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from projection.tilted_ortho import Scene                      # noqa: E402
from common.canvas import Canvas                               # noqa: E402
from common.materials import concrete_slab, ground_field       # noqa: E402
from common.font import text                                   # noqa: E402
from palettes.frontier_service import col, LIGHT               # noqa: E402
from generators.architecture import (foundation_plinth_A, wall_panel_A,
                                     wall_panel_B, inner_corner_A,
                                     outer_corner_A, door_airlock_A,
                                     window_recess_A, roof_edge_A,
                                     roof_section_A, roof_section_B)
from generators.technical import (pipe_cluster_A, service_tower_A,
                                  utility_spine_A, generator_unit_A,
                                  terminal_station_A, storage_module_A)
from generators.props import industrial_light_A, maintenance_cart_A

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

ASSETS = [
    ("foundation_plinth_A", "architecture", foundation_plinth_A, {}, ("ground", 124, 96)),
    ("wall_panel_A",        "architecture", wall_panel_A,        {}, None),
    ("wall_panel_B",        "architecture", wall_panel_B,        {}, None),
    ("inner_corner_A",      "architecture", inner_corner_A,      {}, None),
    ("outer_corner_A",      "architecture", outer_corner_A,      {}, None),
    ("door_airlock_A",      "architecture", door_airlock_A,      {}, None),
    ("window_recess_A",     "architecture", window_recess_A,     {}, None),
    ("roof_edge_A",         "architecture", roof_edge_A,         {}, None),
    ("roof_section_A",      "architecture", roof_section_A,      {}, None),
    ("roof_section_B",      "architecture", roof_section_B,      {}, None),
    ("pipe_cluster_A",      "technical",    pipe_cluster_A,      {}, "wall"),
    ("service_tower_A",     "technical",    service_tower_A,     {}, ("ground", 72, 40)),
    ("utility_spine_A",     "technical",    utility_spine_A,     {}, "wall"),
    ("generator_unit_A",    "technical",    generator_unit_A,    {}, ("ground", 96, 64)),
    ("terminal_station_A",  "technical",    terminal_station_A,  {}, ("ground", 52, 20)),
    ("storage_module_A",    "technical",    storage_module_A,    {}, ("ground", 80, 48)),
    ("industrial_light_A",  "props",        industrial_light_A,  {}, "wall"),
    ("maintenance_cart_A",  "props",        maintenance_cart_A,  {}, ("ground", 64, 32)),
]


def crop(cv, margin=2):
    xs, ys = [], []
    for y in range(cv.h):
        for x in range(cv.w):
            if cv.g[y * cv.w + x] is not None:
                xs.append(x)
                ys.append(y)
    if not xs:
        return cv
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    x0 = max(0, x0 - margin)
    y0 = max(0, y0 - margin)
    x1 = min(cv.w - 1, x1 + margin)
    y1 = min(cv.h - 1, y1 + margin)
    out = Canvas(x1 - x0 + 1, y1 - y0 + 1)
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            out.set(x - x0, y - y0, cv.g[y * cv.w + x])
    return out


def render_asset(asset_id, seed=0, profile="day"):
    LIGHT.set(profile)
    meta = next(a for a in ASSETS if a[0] == asset_id)
    gen, kw, ctx = meta[2], dict(meta[3]), meta[4]
    sc = Scene(240, 240, ox=60, oy=170)
    cv = sc.cv
    if isinstance(ctx, tuple) and ctx[0] == "ground":
        _, pad_w, aw = ctx
        px = aw // 2 - pad_w // 2
        gr = sc.ground_rect(px, 16, pad_w, 42)
        concrete_slab(cv, *gr, seed=seed + 500, mid=3, ax=sc.ox, ay=sc.oy)
    info = gen(sc, cv, 0, 0, seed=seed, **kw)
    return crop(cv), info


def main():
    outdir = os.path.join(ROOT, "assets")
    sizes = {}
    for asset_id, cat, gen, kw, ctx in ASSETS:
        cv, info = render_asset(asset_id)
        path = os.path.join(outdir, cat, asset_id + ".png")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        cv.save(path)
        sizes[asset_id] = (cv.w, cv.h)
        print(f"{asset_id:22s} {cv.w:4d}x{cv.h:<4d} -> {os.path.relpath(path, ROOT)}")
    return sizes


if __name__ == "__main__":
    main()
