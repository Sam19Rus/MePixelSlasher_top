"""
Metadata: per-asset JSON (metadata/<id>.json) + root manifest.json.
connectionPoints are the hooks a future procedural generator will use.
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from build_assets import ASSETS, ROOT, render_asset            # noqa: E402
from palettes.frontier_service import RAMPS, PALETTE_SIZE      # noqa: E402

FAMILY = "frontier_service"

WORLD = {
    "foundation_plinth_A": (96, 40, 24), "wall_panel_A": (64, 16, 40),
    "wall_panel_B": (64, 16, 40), "inner_corner_A": (48, 40, 40),
    "outer_corner_A": (48, 48, 43), "door_airlock_A": (40, 20, 44),
    "window_recess_A": (32, 16, 28), "roof_edge_A": (64, 20, 10),
    "roof_section_A": (64, 64, 6), "roof_section_B": (64, 64, 6),
    "pipe_cluster_A": (56, 40, 64), "service_tower_A": (40, 40, 106),
    "utility_spine_A": (24, 24, 80), "generator_unit_A": (64, 40, 40),
    "terminal_station_A": (20, 16, 30), "storage_module_A": (48, 24, 60),
    "industrial_light_A": (14, 10, 18), "maintenance_cart_A": (30, 18, 22),
}

CONN = {
    "foundation_plinth_A": ["ground_bottom", "wall_top", "left_plinth",
                            "right_plinth", "bolt_plate"],
    "wall_panel_A": ["left_wall", "right_wall", "plinth_bottom", "roof_top",
                     "pipe_mount_right", "cable_mount_top"],
    "wall_panel_B": ["left_wall", "right_wall", "plinth_bottom", "roof_top",
                     "tech_mount", "cable_mount_top"],
    "inner_corner_A": ["left_wall", "right_wall", "plinth_bottom", "roof_top",
                       "alcove_floor", "conduit_mount"],
    "outer_corner_A": ["left_wall", "right_wall", "plinth_bottom", "roof_top",
                       "column_cap"],
    "door_airlock_A": ["door_mount_wall", "threshold_ground", "lintel_top",
                       "power_mount"],
    "window_recess_A": ["window_mount_wall", "power_mount", "sill_bottom"],
    "roof_edge_A": ["wall_bottom", "roof_deck_back", "left_edge", "right_edge",
                    "gutter_outlet"],
    "roof_section_A": ["edge_front", "left_roof", "right_roof", "roof_back",
                       "vent_mount", "tray_out"],
    "roof_section_B": ["edge_front", "left_roof", "right_roof", "roof_back",
                       "cable_mount", "walkway_out"],
    "pipe_cluster_A": ["pipe_mount_wall", "ground_bottom", "roof_top",
                       "pipe_in_left", "pipe_out_right"],
    "service_tower_A": ["ground_bottom", "cable_top", "exhaust_top",
                        "antenna_top", "ladder_mount"],
    "utility_spine_A": ["wall_mount_back", "cable_top", "cable_bottom",
                        "cable_side_right"],
    "generator_unit_A": ["ground_bottom", "power_out_left", "fuel_in_right",
                         "exhaust_top"],
    "terminal_station_A": ["ground_bottom", "power_out_right"],
    "storage_module_A": ["ground_bottom", "wall_back", "top_stack"],
    "industrial_light_A": ["wall_mount_back", "power_in_top"],
    "maintenance_cart_A": ["ground_bottom"],
}

COMPAT = {
    "foundation_plinth_A": ["wall_panel_A", "wall_panel_B", "inner_corner_A",
                            "outer_corner_A"],
    "wall_panel_A": ["wall_panel_A", "wall_panel_B", "inner_corner_A",
                     "outer_corner_A", "roof_edge_A", "foundation_plinth_A",
                     "window_recess_A", "utility_spine_A", "pipe_cluster_A"],
    "wall_panel_B": ["wall_panel_A", "wall_panel_B", "inner_corner_A",
                     "outer_corner_A", "roof_edge_A", "foundation_plinth_A",
                     "window_recess_A", "pipe_cluster_A"],
    "inner_corner_A": ["wall_panel_A", "wall_panel_B", "roof_edge_A"],
    "outer_corner_A": ["wall_panel_A", "wall_panel_B", "roof_edge_A"],
    "door_airlock_A": ["wall_panel_A", "wall_panel_B"],
    "window_recess_A": ["wall_panel_A", "wall_panel_B"],
    "roof_edge_A": ["roof_section_A", "roof_section_B", "wall_panel_A",
                    "wall_panel_B"],
    "roof_section_A": ["roof_section_A", "roof_section_B", "roof_edge_A"],
    "roof_section_B": ["roof_section_A", "roof_section_B", "roof_edge_A"],
    "pipe_cluster_A": ["wall_panel_A", "wall_panel_B", "roof_section_A",
                       "foundation_plinth_A"],
    "service_tower_A": ["roof_section_A", "roof_section_B",
                        "foundation_plinth_A"],
    "utility_spine_A": ["wall_panel_A", "wall_panel_B", "roof_section_A"],
    "generator_unit_A": ["foundation_plinth_A", "utility_spine_A"],
    "terminal_station_A": ["foundation_plinth_A", "wall_panel_A"],
    "storage_module_A": ["wall_panel_A", "wall_panel_B"],
    "industrial_light_A": ["wall_panel_A", "wall_panel_B", "outer_corner_A"],
    "maintenance_cart_A": [],
}

MATS = {
    "foundation_plinth_A": ["concrete", "raw_metal", "rubber"],
    "wall_panel_A": ["painted_metal", "raw_metal", "concrete", "rubber"],
    "wall_panel_B": ["painted_metal", "raw_metal", "glass_emissive", "rubber"],
    "inner_corner_A": ["painted_metal", "concrete", "raw_metal", "rubber"],
    "outer_corner_A": ["painted_metal", "concrete", "raw_metal"],
    "door_airlock_A": ["raw_metal", "painted_metal", "glass", "rubber",
                       "warning_paint", "emissive"],
    "window_recess_A": ["painted_metal", "glass", "raw_metal", "emissive"],
    "roof_edge_A": ["painted_metal", "concrete", "raw_metal", "rubber"],
    "roof_section_A": ["concrete", "raw_metal", "rubber", "painted_metal"],
    "roof_section_B": ["concrete", "glass", "raw_metal", "rubber"],
    "pipe_cluster_A": ["raw_metal", "painted_metal", "patina"],
    "service_tower_A": ["concrete", "painted_metal", "raw_metal", "emissive"],
    "utility_spine_A": ["raw_metal", "rubber", "emissive"],
    "generator_unit_A": ["raw_metal", "rubber", "warning_paint", "glass",
                         "emissive"],
    "terminal_station_A": ["raw_metal", "glass", "emissive", "rubber"],
    "storage_module_A": ["raw_metal", "painted_metal", "rubber"],
    "industrial_light_A": ["raw_metal", "rubber", "emissive"],
    "maintenance_cart_A": ["raw_metal", "painted_metal", "rubber"],
}

VARPARAMS = {
    "wall_panel_A": ["seed", "condition(clean|worn|damaged)",
                     "accent(AMBER|TEAL|COPPER)", "tech(0..2)"],
    "wall_panel_B": ["seed", "condition(clean|worn|damaged)",
                     "accent(AMBER|TEAL|COPPER)", "tech(0..2)"],
    "foundation_plinth_A": ["seed", "w"],
    "roof_edge_A": ["seed", "w", "z0"],
    "roof_section_A": ["seed", "w", "d", "z0"],
    "roof_section_B": ["seed", "w", "d", "z0"],
    "outer_corner_A": ["seed", "mirror", "z0"],
    "inner_corner_A": ["seed", "notch_w", "notch_d", "z0"],
    "door_airlock_A": ["seed", "h", "z0"],
    "window_recess_A": ["seed", "z0", "lit(night)"],
    "pipe_cluster_A": ["seed", "h", "z0"],
    "utility_spine_A": ["seed", "h", "z0"],
    "industrial_light_A": ["seed", "lit(night)", "z0"],
}


def main():
    mdir = os.path.join(ROOT, "metadata")
    os.makedirs(mdir, exist_ok=True)
    entries = []
    for aid, cat, gen, kw, ctx in ASSETS:
        cv, info = render_asset(aid)
        ww, wd, wh = WORLD[aid]
        meta = {
            "id": aid,
            "category": cat,
            "family": FAMILY,
            "widthPx": cv.w,
            "heightPx": cv.h,
            "worldWidth": ww,
            "worldDepth": wd,
            "worldHeight": wh,
            "worldWidthM": round(ww / 15.0, 2),
            "worldHeightM": round(wh / 15.0, 2),
            "anchor": "bottom_center",
            "projection": "tilted_orthographic",
            "projectionParams": {"pitchDeg": 36, "slopeDeg": 2, "eavePx": 2,
                                 "azimuthDeg": 0},
            "scalePxPerM": 15,
            "materials": MATS[aid],
            "connectionPoints": CONN[aid],
            "compatibleWith": COMPAT[aid],
            "variantParameters": VARPARAMS.get(aid, ["seed"]),
            "background": "transparent",
            "file": f"assets/{cat}/{aid}.png",
        }
        with open(os.path.join(mdir, aid + ".json"), "w") as f:
            json.dump(meta, f, indent=2)
        entries.append(meta)
    manifest = {
        "project": "PALE_MERIDIAN_CODE_ASSET_LIBRARY",
        "family": FAMILY,
        "generatedBy": "pure Python pixel renderer (PIL save only)",
        "scalePxPerM": 15,
        "projection": {
            "type": "tilted_orthographic",
            "pitchDeg": 36, "slopeDeg": 2, "eavePx": 2, "azimuthDeg": 0,
            "formula": "sx = x; sy = round(sin36*y - cos36*z)",
            "shadowDir": {"x": 0.82, "y": 0.34},
        },
        "palette": {"dayColors": PALETTE_SIZE,
                    "ramps": {k: len(v) for k, v in RAMPS.items()},
                    "profiles": ["day", "dusk", "night"]},
        "assetCount": len(entries),
        "assets": entries,
        "buildings": {
            "K-17-A": {"files": ["preview/building_day.png",
                                 "preview/building_dusk.png",
                                 "preview/building_night.png",
                                 "preview/building_close.png",
                                 "preview/building_tiling.png",
                                 "preview/building_cutaway.png"],
                       "masses": ["garage(96x76,h36)", "hall(224x96,h54)",
                                  "wing(112x92,h44)", "tower(48x44,h106)",
                                  "porch(48x34,h34)"]},
            "K-17-B": {"files": ["preview/building_variant_B.png"],
                       "changes": ["hall bays swapped A<->B",
                                   "solar-heavy hall roof (4x roof_section_B)",
                                   "tower relocated 252->140",
                                   "porch replaced by canopy + side door",
                                   "external stair moved to hall right",
                                   "condition damaged, accent COPPER, tech 2",
                                   "props reshuffled"]},
        },
    }
    with open(os.path.join(ROOT, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    print("manifest.json +", len(entries), "asset metadata files")


if __name__ == "__main__":
    main()
