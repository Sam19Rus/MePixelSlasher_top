"""
PALE MERIDIAN projection — tilted orthographic top-down (the N3 SELECTED
camera, ported to the asset pipeline):

    sx = x + OX
    sy = OY + round(vs * y - hs * z)

    vs = sin(36deg) = 0.5878   ground/roof foreshortening
    hs = cos(36deg) = 0.8090   wall presence

Conventions:
  * world +x = screen right, world +y = toward the viewer (screen down),
    world +z = up (screen up);
  * azimuth 0 — east/west faces are edge-on (zero width). Volume is carried
    by overlapping masses, top faces, cornices, recesses and shadows;
  * wall lean (RimWorld-style, 2 deg): the top edge of a wall of height h
    sits LEAN_TAN*h world-px further inside the footprint -> roof slabs get
    a small reveal + eaves;
  * a mass footprint is given as (x, y_front, w, d): y_front is the FRONT
    (nearest, largest y) edge; the body extends toward -y by depth d.

Scene = canvas + projection + draw-order helpers. All geometry helpers are
integer-exact: two modules sharing a world edge share screen pixels.
"""

import math

PITCH_DEG = 36.0
SLOPE_DEG = 2.0
VS = math.sin(math.radians(PITCH_DEG))     # 0.5878
HS = math.cos(math.radians(PITCH_DEG))     # 0.8090
LEAN_TAN = math.tan(math.radians(SLOPE_DEG))  # 0.0349
EAVE = 2                                    # cornice overhang, screen px

from common.canvas import Canvas  # noqa: E402


def lean_px(h):
    """inward top-edge offset of a wall of height h (world px)"""
    return max(1, int(round(h * LEAN_TAN)))


class Scene:
    def __init__(self, w, h, ox=0, oy=0):
        self.cv = Canvas(w, h)
        self.ox, self.oy = ox, oy
        self.w, self.h = w, h

    # -- projection -----------------------------------------------------
    def P(self, x, y, z=0):
        return (int(round(x)) + self.ox,
                self.oy + int(round(VS * y - HS * z)))

    def sy(self, y, z=0):
        return self.oy + int(round(VS * y - HS * z))

    def sx(self, x):
        return int(round(x)) + self.ox

    # -- face rectangles (screen space, inclusive coords) ---------------
    def front_rect(self, x, y_front, w, z0, z1):
        """front (south) face of a mass, screen rect"""
        x0 = self.sx(x)
        yb = self.sy(y_front, z0)
        yt = self.sy(y_front, z1)
        return (x0, yt, x0 + w - 1, yb - 1)

    def top_rect(self, x, y_front, w, d, z):
        """top face of a mass at height z, screen rect"""
        x0 = self.sx(x)
        yf = self.sy(y_front, z)
        yb = self.sy(y_front - d, z)
        return (x0, yb, x0 + w - 1, yf - 1)

    def ground_rect(self, x, y_front, w, d):
        """ground/roof quad footprint on screen at z=0"""
        return self.top_rect(x, y_front, w, d, 0)
