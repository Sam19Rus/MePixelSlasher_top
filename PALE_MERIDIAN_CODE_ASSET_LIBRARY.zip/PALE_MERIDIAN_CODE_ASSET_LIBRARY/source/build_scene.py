"""
PALE MERIDIAN — SCENE: two different buildings (K-17-A and K-17-B) on a
suitable arid-plateau landscape (UPGRADE SPEC V2, R6).

Landscape grammar (from the UNSIGHTED / CrossCode study):
  * flat ground field, no static; depth by 4 stepped aerial-perspective bands;
  * gravel service road with crisp edges and ruts;
  * a poured concrete pad under EACH building: lit front edge, dark side
    edges, contact shadow row, expansion joints aligned to the world grid;
  * chunky rock outcrops with lit top / dark right face and a flat cast shadow;
  * sparse discrete dry-grass tufts (shapes, not noise);
  * utility poles with cable swags tying the two buildings together.

Painter order: landscape -> far building (B) -> near building (A) -> foreground.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from projection.tilted_ortho import Scene                        # noqa: E402
from common.noise import h2, bn                                 # noqa: E402
from common.materials import ground_field, concrete_slab        # noqa: E402
from common.depth import contact_shadow, pipe_v, pipe_h        # noqa: E402
from common.details import cable_sag as _cable                  # noqa: E402
from palettes.frontier_service import col, LIGHT, shade_color   # noqa: E402
from build_building import assemble, VARIANTS, save_building, crops  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

CW, CH = 860, 360
OX, OY = 24, 110
OFF_A = (0, 30)
OFF_B = (330, -46)


def new_scene():
    return Scene(CW, CH, ox=OX, oy=OY)


# ------------------------------------------------------------------ landscape
def horizon_bands(cv):
    """smooth per-row aerial perspective (palette-snapped, no band lines)"""
    for yy in range(0, 116):
        f = 0.78 + 0.22 * (yy / 116.0) ** 1.25
        cv.rect_shade(0, yy, CW - 1, yy, f)


def road(sc, cv, y0=344, y1=372, seed=11):
    """gravel service road: flat lighter band, crisp edges, two ruts."""
    a, b = sc.sy(y0, 0), sc.sy(y1, 0)
    cv.rect(0, a, CW - 1, b, col("DIRT", 3))
    cv.hline(0, CW - 1, a, col("DIRT", 1))
    cv.hline(0, CW - 1, b, col("DIRT", 1))
    cv.hline(0, CW - 1, b + 1, col("DIRT", 0))
    for (ry, ph) in ((y0 + 9, 0), (y0 + 19, 3)):
        yy = sc.sy(ry, 0)
        for x in range(0, CW):
            w = 1 if bn(x, 0, seed + ph, 24) > 0.30 else 0
            cv.set(x, yy + w, col("DIRT", 2))
            cv.set(x, yy + 1 + w, col("DIRT", 1))
    # sparse gravel on the road only
    for x in range(0, CW):
        for y in range(a + 2, b - 1):
            if bn(x, y, seed + 5, 5) > 0.985 and (x + y) % 2 == 0:
                cv.set(x, y, col("SLATE", 2))


def pad(sc, cv, off, x=6, yf=258, w=474, d=220, seed=21):
    """poured concrete pad under one building (drawn with its offset)."""
    sc.ox += off[0]
    sc.oy += off[1]
    r = sc.ground_rect(x, yf, w, d)
    concrete_slab(cv, *r, seed=seed, mid=3, ax=sc.ox, ay=sc.oy)
    # crisp pad boundary: lit front edge, dark sides, contact shadow below
    cv.hline(r[0], r[2], r[3], col("CONC", 4))
    cv.hline(r[0], r[2], r[3] + 1, col("DIRT", 0))
    cv.vline(r[0] - 1, r[1], r[3], col("DARK", 0))
    cv.vline(r[2] + 1, r[1], r[3], col("DARK", 0))
    cv.vline(r[2] + 2, r[1] + 2, r[3], shade_color(LIGHT.profile, 0.6,
                                                   col("DIRT", 2)))
    sc.ox -= off[0]
    sc.oy -= off[1]
    return r


def rock(sc, cv, x, y, w, hgt, seed=0):
    """chunky outcrop: chamfered silhouette, lit top, mid front, dark right,
    flat hard cast shadow to the lower-right."""
    px, py = sc.sx(x), sc.sy(y, 0)
    cut = max(2, w // 5)
    cv.poly_shade([(px + 2, py - 1), (px + w + 6, py - 1),
                   (px + w + 10, py + 4), (px + 4, py + 4)], 0.5)
    cv.chamfer_rect(px, py - hgt, px + w - 1, py - 1, cut, col("CONC", 2))
    # lit top band following the chamfer
    cv.hline(px + cut, px + w - 1 - cut, py - hgt, col("CONC", 4))
    cv.hline(px + cut, px + w - 1 - cut, py - hgt + 1, col("CONC", 3))
    for i in range(cut):
        cv.set(px + i, py - hgt + cut - 1 - i, col("CONC", 4))
        cv.set(px + w - 1 - i, py - hgt + cut - 1 - i, col("CONC", 3))
    # dark right face + silhouette lines
    cv.vline(px + w - 1, py - hgt + cut, py - 1, col("CONC", 1))
    cv.vline(px + w, py - hgt + cut, py - 1, col("CONC", 0))
    cv.vline(px - 1, py - hgt + cut, py - 1, col("DARK", 0))
    cv.hline(px, px + w - 1, py, col("DARK", 0))
    # one crisp fracture line + a lit chip
    cv.vline(px + w // 3, py - hgt + cut + 1, py - 2, col("CONC", 1))
    cv.set(px + w // 3 + 1, py - hgt + cut + 1, col("CONC", 3))


def tuft(cv, x, y, seed=0):
    """dry-grass tuft: 5 px discrete shape (not noise)."""
    cv.set(x, y, col("DIRT", 3))
    cv.set(x, y - 1, col("AMBER", 1))
    cv.set(x - 1, y - 2, col("AMBER", 2))
    cv.set(x + 1, y - 2, col("AMBER", 1))
    cv.set(x, y - 3, col("AMBER", 3))


def pole(sc, cv, x, y, h=46, seed=0):
    px = sc.sx(x)
    py0, py1 = sc.sy(y, h), sc.sy(y, 0)
    pipe_v(cv, px, py0, py1, 1, ramp="SLATE", mid=2)
    pipe_h(cv, px - 5, px + 6, py0 + 3, 1, ramp="SLATE", mid=2)
    cv.set(px - 4, py0 + 2, col("CREAM", 4))
    cv.set(px + 5, py0 + 2, col("CREAM", 4))
    contact_shadow(cv, px - 2, px + 3, py1, rows=2)
    return (px, py0)


def draw_landscape(sc, cv, seed=5):
    ground_field(cv, 0, 0, CW - 1, CH - 1, seed=seed, mid=2)
    horizon_bands(cv)
    road(sc, cv, seed=seed + 6)
    # far + side rocks (behind buildings)
    rock(sc, cv, 762, 252, 16, 9, seed=1)
    rock(sc, cv, 8, 300, 12, 7, seed=2)
    # sparse tufts: foreground strip + far left/right margins only
    for gy in range(330, CH - 4, 10):
        for gx in range(0, CW, 18):
            if h2(gx, gy, 77) > 0.86:
                tuft(cv, gx + int(h2(gx, gy, 78) * 11), gy + int(h2(gx, gy, 79) * 5))
    for gy in range(150, 300, 14):
        for gx in list(range(0, 34, 10)) + list(range(CW - 34, CW, 10)):
            if h2(gx, gy, 87) > 0.80:
                tuft(cv, gx + int(h2(gx, gy, 88) * 6), gy + int(h2(gx, gy, 89) * 6))


# ------------------------------------------------------------------ scene
def build_scene(profile="day"):
    LIGHT.set(profile)
    sc = new_scene()
    cv = sc.cv
    draw_landscape(sc, cv, seed=5)

    # far building first: K-17-B on its pad
    pad(sc, cv, OFF_B, seed=22)
    assemble("B", profile, ground=False, scene=sc, off=OFF_B)
    # near building: K-17-A
    pad(sc, cv, OFF_A, seed=21)
    assemble("A", profile, ground=False, scene=sc, off=OFF_A)

    # utility poles + swags tying the compound together (foreground line)
    p1 = pole(sc, cv, 508, 306, h=44, seed=1)
    p2 = pole(sc, cv, 566, 310, h=44, seed=2)
    p3 = pole(sc, cv, 624, 314, h=44, seed=3)
    _cable(cv, p1[0] - 4, p1[1] + 3, p2[0] - 4, p2[1] + 3, 4, seed=61)
    _cable(cv, p2[0] - 4, p2[1] + 3, p3[0] - 4, p3[1] + 3, 4, seed=62)
    # drop-lines from the pole line into each building
    _cable(cv, p1[0] - 4, p1[1] + 3, sc.sx(452) + OFF_A[0],
           sc.sy(178, 44) + OFF_A[1], 5, seed=64)
    # tyre tracks: garage door of A down to the road
    tx = sc.sx(92) + OFF_A[0]
    for yy in range(sc.sy(262, 0) + OFF_A[1], sc.sy(344, 0)):
        drift = int((yy - sc.sy(262, 0)) * 0.10)
        for k in (0, 5):
            cv.set(tx + k + drift, yy, col("DIRT", 1))
            cv.set(tx + k + drift + 1, yy, col("DIRT", 2))
    # long tie-line between the two service towers
    ta = (sc.sx(252 + 40) + OFF_A[0], sc.sy(86, 100) + OFF_A[1])
    tb = (sc.sx(140 + 6) + OFF_B[0], sc.sy(86, 100) + OFF_B[1])
    _cable(cv, ta[0], ta[1], tb[0], tb[1], 9, seed=63)

    # foreground rocks + tufts in front of the road
    rock(sc, cv, 150, 400, 24, 12, seed=3)
    rock(sc, cv, 700, 406, 18, 10, seed=4)
    rock(sc, cv, 430, 410, 14, 8, seed=5)
    for gx in range(0, CW, 22):
        if h2(gx, 900, 81) > 0.55:
            tuft(cv, gx + int(h2(gx, 901, 82) * 12),
                 sc.sy(386, 0) + int(h2(gx, 902, 83) * 16))
    return sc


def closeups(sc):
    """readability proof sheet: three 1x crops upscaled x4 (nearest)."""
    from common.canvas import Canvas
    boxes = ((150, 176, 330, 296), (470, 88, 650, 208), (470, 236, 690, 336))
    gap = 3
    ws = [b[2] - b[0] for b in boxes]
    hs = [b[3] - b[1] for b in boxes]
    sheet = Canvas(sum(ws) + gap * 2, max(hs))
    ox = 0
    for (x0, y0, x1, y1), w, h in zip(boxes, ws, hs):
        for y in range(h):
            for x in range(w):
                sheet.set(ox + x, y, sc.cv.get(x0 + x, y0 + y))
        ox += w + gap
    return sheet


def main():
    os.makedirs(os.path.join(ROOT, "preview"), exist_ok=True)
    sc = build_scene("day")
    sc.cv.save(os.path.join(ROOT, "preview", "scene_master.png"))
    sc.cv.save(os.path.join(ROOT, "preview", "scene_two_buildings.png"), scale=3)
    sd = build_scene("dusk")
    sd.cv.save(os.path.join(ROOT, "preview", "scene_dusk.png"), scale=2)
    closeups(sc).save(os.path.join(ROOT, "preview", "scene_closeups.png"), scale=4)
    print("scene saved")


if __name__ == "__main__":
    main()
