"""
ARCHITECTURE generators — the frontier_service family (assets 1..10).

New visual vocabulary (deliberately NOT the old wall experiments):
  * chamfered recessed panels instead of lap siding
  * raised structural rails + flanged rivet seams instead of thin columns
  * octagon intakes instead of louver vents
  * cartridge bays, diagonal conduits, cable swags
  * trapezoid worn stencils instead of candy hazard stripes

Every generator draws in WORLD coordinates through the shared projection,
so the same code serves the standalone asset PNGs and the building
assembly. Composition -> structure -> materials -> depth -> wear -> micro.
"""

from palettes.frontier_service import col, LIGHT, RAMPS
from common.noise import h2, bn
from common.materials import (paint_metal, raw_metal, concrete, concrete_slab,
                              rubber, glass, ground_field, warning_patch)
from common.depth import (contact_shadow, cast_shadow_ground, cornice_shadow,
                          pipe_v, pipe_h, flange_v, flange_h)
from common.details import (rivet, rivet_line_h, rivet_line_v, bolt, bolt_ring,
                            oct_vent, hex_grille, chamfer_panel, cartridge_slots,
                            cable_sag, conduit_diag, clamp, chip, scratch,
                            rust_weep, grime, dust_cap, soot, stencil)
from projection.tilted_ortho import Scene, VS, HS

WALL_H = 40          # world height of a wall storey (face ~32 px)
MW = 64              # structural bay width


# ======================================================================
# shared context chips (standalone renders only)
# ======================================================================
def wall_chip(sc, cv, x, yf, w, z1, seed):
    """a piece of wall behind wall-mounted assets"""
    fr = sc.front_rect(x, yf, w, 0, z1)
    paint_metal(cv, *fr, seed=seed, ramp="CREAM", mid=2, cell=9)
    cv.hline(fr[0], fr[2], fr[1], col("CREAM", 3))
    grime(cv, fr[0], fr[3] - 4, fr[2], fr[3], seed + 1, amt=0.5)
    return fr


def ground_chip(sc, cv, x, yf, w, d, seed):
    gr = sc.ground_rect(x, yf, w, d)
    concrete_slab(cv, *gr, seed=seed, mid=3, ax=sc.ox, ay=sc.oy)
    return gr


# ======================================================================
# 1. foundation_plinth_A — heavy base module
# ======================================================================
def foundation_plinth_A(sc, cv, x, yf, seed=0, cond="worn", w=96):
    d, h = 40, 16
    cast_shadow_ground(sc, cv, x, yf, w, h, d)
    fr = sc.front_rect(x, yf, w, 0, h)
    tr = sc.top_rect(x, yf, w, d, h)
    concrete(cv, *fr, seed=seed + 1, mid=3, cell=7)
    concrete_slab(cv, *tr, seed=seed + 2, mid=4, ax=sc.ox, ay=sc.oy)
    x0, y0, x1, y1 = fr
    # chamfered top edge of the pour
    cv.hline(x0, x1, y0, col("CONC", 5))
    cv.hline(x0, x1, y0 + 1, col("CONC", 4))
    # damp dark band at the bottom (ground moisture)
    for i in range(4):
        for xx in range(x0, x1 + 1):
            if h2(xx, i, seed + 5) > 0.12 * i:
                cv.set(xx, y1 - i, col("CONC", 0 if i < 2 else 1))
    # pour seam + formwork tie holes
    cv.vline(x0 + w // 2, y0 + 2, y1 - 4, col("CONC", 1))
    for px in (24, w - 24):
        cv.set(x0 + px, y0 + 8, col("CONC", 1))
        cv.set(x0 + px + 1, y0 + 8, col("CONC", 2))
    # mounting plates (asymmetric)
    for (mx, my, mw, mh) in ((14, 5, 12, 7), (w - 36, 7, 10, 6)):
        r = sc.front_rect(x + mx, yf + 1, mw, h - my - mh, h - my)
        raw_metal(cv, *r, seed=seed + 9 + mx, ramp="GUN", mid=3)
        bolt_ring(cv, r[0], r[1], r[2], r[3], inset=1, ramp="SLATE", mid=4)
        cv.vline(r[2] + 1, r[1] + 1, r[3] + 1, col("DARK", 0))   # cast 1px
        cv.hline(r[0] + 1, r[2] + 1, r[3] + 1, col("DARK", 0))
    # stepped higher block on the right (different level)
    sx, sw, sh = x + w - 22, 22, 24
    sfr = sc.front_rect(sx, yf, sw, 0, sh)
    str_ = sc.top_rect(sx, yf, sw, d - 8, sh)
    concrete(cv, *sfr, seed=seed + 3, mid=3)
    concrete_slab(cv, *str_, seed=seed + 4, mid=5, ax=sc.ox, ay=sc.oy)
    cv.hline(sfr[0], sfr[2], sfr[1], col("CONC", 5))
    cv.vline(sfr[0] - 1, sfr[1], sfr[3], col("DARK", 0))        # corner AO
    cv.vline(sfr[2], sfr[1], sfr[3], col("CONC", 1))
    r = sc.front_rect(sx + 6, yf + 1, 10, sh - 12, sh - 5)
    raw_metal(cv, *r, seed=seed + 11, ramp="GUN", mid=3)
    bolt_ring(cv, r[0], r[1], r[2], r[3], inset=1, ramp="SLATE", mid=4)
    # wear
    chip(cv, x0 + 30, y0 + 1, seed + 21, n=2, ramp_under="CONC")
    chip(cv, x0 + w - 14, sfr[1] + 2, seed + 22, n=2, ramp_under="CONC")
    rust_weep(cv, x0 + 20, y0 + 12, 4, seed + 23)
    grime(cv, x0, y1 - 6, x1, y1, seed + 24, amt=0.6)
    dust_cap(cv, x0 + 1, x1 - 1, y0, seed + 25, idx=4, amt=0.35)
    contact_shadow(cv, x0, x1, y1 + 1, rows=2, jitter_seed=seed)
    return {"w": w, "d": d, "h": sh, "front": fr}


# ======================================================================
# 2. wall_panel_A — primary wall module of the new family
# ======================================================================
WEAR_LEVELS = {"clean": 0, "worn": 1, "damaged": 2}


def _extra_damage(cv, x0, y0, x1, y1, seed):
    """damaged condition: dent, deep chips, heavy rust, torn stencil"""
    cv.rect_shade(x0 + 18, y0 + 12, x0 + 26, y0 + 17, 0.72)      # dent
    cv.hline(x0 + 18, x0 + 26, y0 + 12, col("GUN", 0))
    chip(cv, x0 + 8, y0 + 5, seed + 61, n=3)
    chip(cv, x1 - 12, y0 + 20, seed + 62, n=3)
    rust_weep(cv, x0 + 10, y0 + 6, 9, seed + 63)
    rust_weep(cv, x1 - 10, y0 + 21, 8, seed + 64)
    scratch(cv, x0 + 30, y0 + 10, 8, seed + 65)


def wall_panel_A(sc, cv, x, yf, seed=0, accent="AMBER", cond="worn",
                 tech=1, z0=0, h=WALL_H):
    w, d = MW, 16
    fr = sc.front_rect(x, yf, w, z0, h)
    tr = sc.top_rect(x, yf, w, d, h)
    x0, y0, x1, y1 = fr
    # field first
    paint_metal(cv, x0 + 6, y0 + 3, x1 - 6, y1 - 3, seed=seed + 1,
                ramp="CREAM", mid=3, cell=8)
    # top flange rail with rivets
    raw_metal(cv, x0, y0, x1, y0 + 2, seed=seed + 2, ramp="GUN", mid=3)
    rivet_line_h(cv, x0 + 3, x1 - 2, y0 + 1, 7, ramp="SLATE", hi=5, lo=1)
    cv.hline(x0, x1, y0 + 3, col("GUN", 0))                       # flange shadow
    # kick plate
    raw_metal(cv, x0, y1 - 2, x1, y1, seed=seed + 3, ramp="GUN", mid=2)
    cv.hline(x0, x1, y1 - 3, col("GUN", 0))
    # raised structural rails both ends (bay rhythm when tiled)
    for (rx0, rx1) in ((x0, x0 + 5), (x1 - 5, x1)):
        raw_metal(cv, rx0, y0 + 3, rx1, y1 - 3, seed=seed + 4 + rx0,
                  ramp="SLATE", mid=2)
        cv.vline(rx0, y0 + 3, y1 - 3, col("SLATE", 4))            # left light
        cv.vline(rx1, y0 + 3, y1 - 3, col("SLATE", 0))            # terminator
        cv.vline(rx1 + 1, y0 + 4, y1 - 3, col("DARK", 0))         # cast on field
        rivet_line_v(cv, rx0 + 2, y0 + 6, y1 - 5, 8, ramp="SLATE", hi=5, lo=1)
    # parapet cap sliver on top
    if tr:
        concrete(cv, *tr, seed=seed + 5, mid=4)
        cv.hline(tr[0], tr[2], tr[3], col("SLATE", 4))
        dust_cap(cv, tr[0] + 1, tr[2] - 1, tr[3] - 1, seed + 6, amt=0.3)
    # --- composition: big chamfered recessed panel (left of centre) ---
    chamfer_panel(cv, x0 + 10, y0 + 7, x0 + 38, y0 + 25, 2,
                  lambda c, a, b, cc, dd: paint_metal(c, a, b, cc, dd,
                                                      seed=seed + 7,
                                                      ramp="CREAM", mid=2),
                  seed=seed + 7, frame_ramp="CREAM", frame_mid=3, depth=2)
    bolt(cv, x0 + 13, y0 + 10, ramp="SLATE", mid=4)
    bolt(cv, x0 + 35, y0 + 22, ramp="SLATE", mid=4)
    # service channel (vertical dark slot) right of the panel
    cx = x0 + 44
    cv.rect(cx, y0 + 7, cx + 2, y0 + 25, col("RUBBER", 1))
    cv.vline(cx - 1, y0 + 7, y0 + 25, col("CREAM", 4))
    cv.vline(cx + 3, y0 + 7, y0 + 25, col("GUN", 0))
    cv.rect(cx - 1, y0 + 6, cx + 3, y0 + 8, col("GUN", 2))        # top collar
    cv.rect(cx - 1, y0 + 24, cx + 3, y0 + 26, col("GUN", 2))      # bottom collar
    cable_sag(cv, cx + 2, y0 + 8, x1 - 4, y0 + 14, 3, seed=seed + 8)
    # octagon intake, upper right field
    oct_vent(cv, x0 + 52, y0 + 14, 4, seed=seed + 9)
    # diagonal conduit, lower right (family motif)
    if tech >= 1:
        conduit_diag(cv, x0 + 40, y0 + 27, x0 + 55, y0 + 19, ramp="SLATE", mid=2)
    # stencil mark on the field, worn trapezoid companion
    stencil(cv, x0 + 13, y0 + 18, "A" + str(1 + seed % 6), ramp=accent,
            idx=2, wear=0.10, seed=seed + 10)
    if tech >= 2:
        cv.rect(x0 + 48, y0 + 24, x0 + 53, y0 + 27, col("GUN", 2))
        cv.set(x0 + 50, y0 + 25, col("GLOW", 1))
    # --- wear (condition-driven) ---
    wl = WEAR_LEVELS.get(cond, 1)
    if wl >= 1:
        chip(cv, x0 + 37, y0 + 7, seed + 31, n=2)
        scratch(cv, x0 + 20, y0 + 16, 6, seed + 32)
        rust_weep(cv, x0 + 3, y0 + 4, 5, seed + 33)
        rust_weep(cv, x0 + 52, y0 + 19, 4, seed + 34)
        grime(cv, x0 + 6, y1 - 8, x1 - 6, y1 - 3, seed + 35, amt=0.45)
        dust_cap(cv, x0 + 6, x1 - 6, y0 + 3, seed + 36, amt=0.25)
    if wl >= 2:
        _extra_damage(cv, x0, y0, x1, y1, seed)
    return {"w": w, "d": d, "h": h, "front": fr, "top": tr}


# ======================================================================
# 3. wall_panel_B — second rhythm of the same family
# ======================================================================
def wall_panel_B(sc, cv, x, yf, seed=0, accent="TEAL", cond="worn",
                 tech=1, z0=0, h=WALL_H):
    w, d = MW, 16
    fr = sc.front_rect(x, yf, w, z0, h)
    tr = sc.top_rect(x, yf, w, d, h)
    x0, y0, x1, y1 = fr
    paint_metal(cv, x0 + 2, y0 + 3, x1 - 8, y1 - 3, seed=seed + 1,
                ramp="CREAM", mid=3, cell=9)
    # left edge: thin flanged seam (NOT a rail) — asymmetric with panel A
    cv.vline(x0, y0 + 3, y1 - 3, col("CREAM", 4))
    cv.vline(x0 + 1, y0 + 3, y1 - 3, col("GUN", 0))
    rivet_line_v(cv, x0 + 2, y0 + 5, y1 - 5, 9, ramp="SLATE", hi=4, lo=1)
    # right: wide structural rail with double rivet line
    raw_metal(cv, x1 - 7, y0 + 3, x1, y1 - 3, seed=seed + 2, ramp="SLATE", mid=2)
    cv.vline(x1 - 7, y0 + 3, y1 - 3, col("SLATE", 4))
    cv.vline(x1 - 8, y0 + 4, y1 - 3, col("DARK", 0))
    cv.vline(x1, y0 + 3, y1 - 3, col("SLATE", 0))
    rivet_line_v(cv, x1 - 5, y0 + 6, y1 - 5, 7, ramp="SLATE", hi=5, lo=1)
    rivet_line_v(cv, x1 - 2, y0 + 6, y1 - 5, 7, ramp="SLATE", hi=5, lo=1)
    # top flange + kick
    raw_metal(cv, x0, y0, x1, y0 + 2, seed=seed + 3, ramp="GUN", mid=3)
    rivet_line_h(cv, x0 + 4, x1 - 3, y0 + 1, 9, ramp="SLATE", hi=5, lo=1)
    cv.hline(x0, x1, y0 + 3, col("GUN", 0))
    raw_metal(cv, x0, y1 - 2, x1, y1, seed=seed + 4, ramp="GUN", mid=2)
    if tr:
        concrete(cv, *tr, seed=seed + 5, mid=4)
        cv.hline(tr[0], tr[2], tr[3], col("SLATE", 4))
    # --- composition: cartridge bay row (left), utility recess (right) ---
    cartridge_slots(cv, x0 + 7, y0 + 8, x0 + 39, y0 + 19, 5, seed=seed + 6,
                    open_idx=(seed + 2) % 5)
    # shallow wide cover below the cartridges (different depth: 1px)
    cv.rect(x0 + 7, y0 + 23, x0 + 39, y0 + 27, col("CREAM", 2))
    cv.hline(x0 + 7, x0 + 39, y0 + 23, col("GUN", 0))
    cv.hline(x0 + 7, x0 + 39, y0 + 27, col("CREAM", 4))
    cv.vline(x0 + 7, y0 + 23, y0 + 27, col("GUN", 0))
    bolt(cv, x0 + 9, y0 + 25, ramp="SLATE", mid=4)
    bolt(cv, x0 + 36, y0 + 25, ramp="SLATE", mid=4)
    # utility recess with conduits + junction box
    ux = x0 + 44
    cv.rect(ux, y0 + 6, ux + 8, y0 + 26, col("GUN", 1))
    cv.hline(ux, ux + 8, y0 + 6, col("DARK", 0))
    cv.vline(ux, y0 + 6, y0 + 26, col("DARK", 0))
    cv.vline(ux + 8, y0 + 7, y0 + 26, col("SLATE", 3))
    pipe_v(cv, ux + 2, y0 + 7, y0 + 25, 1, ramp="SLATE", mid=2)
    pipe_v(cv, ux + 6, y0 + 7, y0 + 25, 1, ramp="SLATE", mid=1)
    cv.rect(ux + 1, y0 + 14, ux + 7, y0 + 18, col("GUN", 3))       # junction box
    cv.hline(ux + 1, ux + 7, y0 + 14, col("SLATE", 4))
    cv.set(ux + 6, y0 + 16, col("GLOW", 1))
    # cable swag across the top field
    cable_sag(cv, x0 + 3, y0 + 5, ux + 2, y0 + 7, 2, seed=seed + 7)
    stencil(cv, x0 + 43, y0 + 24, "K" + str(2 + seed % 7), ramp=accent,
            idx=2 if accent == "TEAL" else 2, wear=0.12, seed=seed + 8)
    # wear: heavier than A (service side of the bay), condition-driven
    wl = WEAR_LEVELS.get(cond, 1)
    if wl >= 1:
        chip(cv, x0 + 20, y0 + 20, seed + 41, n=2)
        rust_weep(cv, x0 + 15, y0 + 20, 4, seed + 42)
        rust_weep(cv, ux + 3, y0 + 19, 5, seed + 43)
        grime(cv, x0 + 2, y1 - 9, x1 - 8, y1 - 3, seed + 44, amt=0.6)
        scratch(cv, x0 + 30, y0 + 25, 5, seed + 45)
    if wl >= 2:
        _extra_damage(cv, x0, y0, x1, y1, seed)
    return {"w": w, "d": d, "h": h, "front": fr, "top": tr}


# ======================================================================
# 4. inner_corner_A — concave corner (alcove) proving real depth
# ======================================================================
def inner_corner_A(sc, cv, x, yf, seed=0, h=WALL_H, notch_w=20, notch_d=12, z0=0):
    w, d = 48, 40
    fr = sc.front_rect(x, yf, w, z0, h)
    x0, y0, x1, y1 = fr
    nx0, nx1 = x0 + 14, x0 + 34                    # notch opening on screen
    dr = sc.sy(yf) - sc.sy(yf - notch_d)           # ~7 px, positive
    # left & right front stubs
    paint_metal(cv, x0, y0, nx0 - 1, y1, seed=seed + 1, ramp="CREAM", mid=3)
    paint_metal(cv, nx1 + 1, y0, x1, y1, seed=seed + 2, ramp="CREAM", mid=3)
    raw_metal(cv, x0, y0, x1, y0 + 2, seed=seed + 3, ramp="GUN", mid=3)
    cv.hline(x0, x1, y0 + 3, col("GUN", 0))
    # top faces of the stubs
    tl = sc.top_rect(x, yf, 14, d, h)
    trr = sc.top_rect(x + 35, yf, 13, d, h)
    bwall_h = h
    concrete(cv, *tl, seed=seed + 4, mid=4)
    concrete(cv, *trr, seed=seed + 5, mid=4)
    cv.hline(tl[0], tl[2], tl[3], col("SLATE", 4))
    cv.hline(trr[0], trr[2], trr[3], col("SLATE", 4))
    # ---- alcove interior ----
    by0 = y0 - dr                                  # back wall top on screen
    bf = (nx0, by0 + 3, nx1, y1 - dr)              # back wall face rect
    paint_metal(cv, bf[0], bf[1], bf[2], bf[3], seed=seed + 6, ramp="CREAM",
                mid=2, cell=9)
    # soffit shadow: top of the back wall under the (open) sky edge
    for i in range(3):
        cv.hline(bf[0], bf[2], bf[1] + i, col("DARK", 0) if i == 0 else col("GUN", 0))
    # left side wall in shadow: vertical gradient column + AO at the corner
    for i in range(4):
        cv.vline(bf[0] + i, bf[1], bf[3], col("GUN", 0) if i < 2 else col("GUN", 1))
    # right jamb catches light
    cv.vline(bf[2], bf[1], bf[3], col("CREAM", 3))
    cv.rect_shade(bf[0] + 1, bf[1] + 3, bf[2] - 1, bf[3], 0.78)  # recessed wall
    # back wall top band (parapet cap of the receding wall) closes the gap
    btr = sc.top_rect(x + 14, yf - notch_d, notch_w + 1, 6, h)
    concrete(cv, *btr, seed=seed + 13, mid=4)
    cv.hline(btr[0], btr[2], btr[3], col("SLATE", 4))
    cv.hline(btr[0], btr[2], btr[1], col("SLATE", 2))
    # alcove floor: concrete strip, darker, with contact shadow at back wall
    fl = (nx0, y1 - dr + 1, nx1, y1)
    concrete(cv, fl[0], fl[1], fl[2], fl[3], seed=seed + 7, mid=2)
    cv.rect_shade(fl[0], fl[1], fl[2], fl[3], 0.8)
    cv.hline(fl[0], fl[2], fl[1], col("DARK", 0))
    # left stub shadow across the alcove floor (sun from upper-left)
    cv.rect_shade(fl[0] + 1, fl[1], fl[0] + 5, fl[3], 0.62)
    for xx in range(fl[0], fl[2] + 1):
        if h2(xx, 2, seed + 8) > 0.5:
            cv.set(xx, fl[1] + 1, col("CONC", 0))
    # ---- corner proof: conduit bends around the inner corner ----
    pipe_v(cv, bf[0] + 6, bf[1] + 4, bf[3] - 2, 1, ramp="SLATE", mid=2)
    cv.rect(bf[0] + 4, bf[1] + 4, bf[0] + 6, bf[1] + 6, col("GUN", 2))   # elbow collar
    cv.vline(bf[0] + 3, bf[1] + 4, bf[1] + 5, col("SLATE", 2))           # run into side wall
    cv.set(bf[0] + 2, bf[1] + 4, col("SLATE", 1))
    clamp(cv, bf[0] + 6, bf[1] + 12)
    # junction box + diagonal brace on the back wall
    cv.rect(bf[0] + 11, bf[1] + 8, bf[0] + 16, bf[1] + 12, col("GUN", 3))
    cv.hline(bf[0] + 11, bf[0] + 16, bf[1] + 8, col("SLATE", 4))
    cv.set(bf[0] + 15, bf[1] + 10, col("GLOW", 1))
    cv.line(bf[0] + 3, bf[3] - 2, bf[0] + 12, bf[1] + 6, col("SLATE", 2))
    cv.line(bf[0] + 4, bf[3] - 2, bf[0] + 13, bf[1] + 6, col("SLATE", 0))
    # cable over the left stub top onto the front face
    cable_sag(cv, bf[0] + 8, bf[1] + 2, tl[0] + 4, tl[1] + 3, 2, seed=seed + 9)
    cable_sag(cv, tl[0] + 4, tl[3] - 1, x0 + 5, y0 + 8, 2, seed=seed + 10)
    # front-face detailing on stubs (asymmetric)
    chamfer_panel(cv, x0 + 2, y0 + 8, x0 + 11, y0 + 22, 1,
                  lambda c, a, b, cc, dd: paint_metal(c, a, b, cc, dd,
                                                      seed=seed + 11,
                                                      ramp="CREAM", mid=2),
                  seed=seed + 11, frame_ramp="CREAM", frame_mid=3, depth=1)
    oct_vent(cv, nx1 + 7, y0 + 14, 4, seed=seed + 12)
    rivet_line_v(cv, nx1 + 3, y0 + 6, y1 - 5, 8)
    # reveal edges where stubs meet the opening
    cv.vline(nx0 - 1, y0 + 3, y1, col("CREAM", 4))
    cv.vline(nx0, y0 + 3, y1, col("DARK", 0))
    cv.vline(nx1 + 1, y0 + 3, y1, col("GUN", 0))
    # wear
    rust_weep(cv, bf[0] + 6, bf[3] - 6, 4, seed + 21)
    grime(cv, bf[0], bf[3] - 5, bf[2], bf[3], seed + 22, amt=0.55)
    grime(cv, x0, y1 - 6, x1, y1, seed + 23, amt=0.5)
    chip(cv, nx1 + 2, y0 + 6, seed + 24)
    dust_cap(cv, tl[0] + 1, tl[2] - 1, tl[3] - 1, seed + 25, amt=0.3)
    return {"w": w, "d": d, "h": h, "front": fr}


# ======================================================================
# 5. outer_corner_A — convex corner: wrap + reinforcement column
# ======================================================================
def outer_corner_A(sc, cv, x, yf, seed=0, h=WALL_H, mirror=False, z0=0):
    w, d = 48, 48
    if mirror:
        return _outer_corner_mirror(sc, cv, x, yf, seed, h, z0)
    wing_y = yf + 10                     # wing projects toward the viewer
    # main wall face (left part)
    fr = sc.front_rect(x, yf, 36, z0, h)
    paint_metal(cv, *fr, seed=seed + 1, ramp="CREAM", mid=3)
    raw_metal(cv, fr[0], fr[1], fr[2], fr[1] + 2, seed=seed + 2, ramp="GUN", mid=3)
    cv.hline(fr[0], fr[2], fr[1] + 3, col("GUN", 0))
    tl = sc.top_rect(x, yf, 36, d - 10, h)
    concrete(cv, *tl, seed=seed + 3, mid=4)
    cv.hline(tl[0], tl[2], tl[3], col("SLATE", 4))
    # wing: front face lower on screen + long receding top band
    wf = sc.front_rect(x + 36, wing_y, 12, z0, h)
    wt = sc.top_rect(x + 36, wing_y, 12, d, h)
    concrete(cv, *wt, seed=seed + 4, mid=4)
    paint_metal(cv, *wf, seed=seed + 5, ramp="CREAM", mid=3)
    cv.hline(wt[0], wt[2], wt[3], col("SLATE", 4))          # wing cap front lip
    cv.hline(wf[0], wf[2], wf[1] + 3, col("GUN", 0))
    raw_metal(cv, wf[0], wf[1], wf[2], wf[1] + 2, seed=seed + 6, ramp="GUN", mid=3)
    # wing gets its own small chamfered panel + stencil (different read)
    chamfer_panel(cv, wf[0] + 2, wf[1] + 8, wf[2] - 2, wf[1] + 20, 1,
                  lambda c, a, b, cc, dd: paint_metal(c, a, b, cc, dd,
                                                      seed=seed + 7,
                                                      ramp="CREAM", mid=2),
                  seed=seed + 7, frame_ramp="CREAM", frame_mid=3, depth=1)
    stencil(cv, wf[0] + 3, wf[1] + 24, "C1", ramp="AMBER", idx=2, wear=0.4,
            seed=seed + 8)
    # corner reinforcement column: proud of both, slightly taller
    cz = h + 3
    cf = sc.front_rect(x + 31, wing_y + 2, 8, z0, cz)
    ct = sc.top_rect(x + 31, wing_y + 2, 8, 10, cz)
    raw_metal(cv, *cf, seed=seed + 9, ramp="SLATE", mid=2)
    raw_metal(cv, *ct, seed=seed + 10, ramp="SLATE", mid=4)
    cv.vline(cf[0], cf[1], cf[3], col("SLATE", 4))
    cv.vline(cf[2], cf[1], cf[3], col("SLATE", 0))
    cv.vline(cf[2] + 1, cf[1] + 1, cf[3] + 1, col("DARK", 0))   # cast on wing
    cv.hline(ct[0], ct[2], ct[3], col("SLATE", 5))
    rivet_line_v(cv, cf[0] + 3, cf[1] + 4, cf[3] - 3, 6, ramp="SLATE", hi=5, lo=1)
    # cap plate
    cv.rect(cf[0] - 1, cf[1] - 1, cf[2] + 1, cf[1], col("SLATE", 3))
    # cable from cap down the wing face
    cable_sag(cv, cf[2], cf[1] + 3, wf[2] - 1, wf[1] + 10, 3, seed=seed + 11)
    # main-face detail: conduit run + rust, shadow of wing on main wall? sun
    # from left: wing shadow falls away; column shadow on wing drawn above.
    conduit_diag(cv, fr[0] + 4, fr[3] - 6, fr[0] + 26, fr[3] - 14, ramp="SLATE", mid=2)
    rivet_line_h(cv, fr[0] + 2, fr[2] - 2, fr[3] - 3, 8)
    stencil(cv, fr[0] + 6, fr[1] + 7, "B2", ramp="AMBER", idx=2, wear=0.3,
            seed=seed + 13)
    # wear
    rust_weep(cv, cf[0] + 2, cf[3] - 8, 6, seed + 21)
    grime(cv, wf[0], wf[3] - 6, wf[2], wf[3], seed + 22, amt=0.6)
    grime(cv, fr[0], fr[3] - 6, fr[2], fr[3], seed + 23, amt=0.5)
    chip(cv, cf[0] + 1, cf[1] + 6, seed + 24)
    dust_cap(cv, wt[0] + 1, wt[2] - 1, wt[3] - 1, seed + 25, amt=0.3)
    return {"w": w, "d": d, "h": cz, "front": fr}


# ======================================================================
# 6. door_airlock_A — deep sealed door
# ======================================================================
def door_airlock_A(sc, cv, x, yf, seed=0, h=44, z0=0):
    w, d = 40, 20
    fr = sc.front_rect(x, yf + 2, w, z0, h)
    tr = sc.top_rect(x, yf + 2, w, d - 2, h)
    x0, y0, x1, y1 = fr
    # thick proud frame
    raw_metal(cv, x0, y0, x1, y1, seed=seed + 1, ramp="GUN", mid=3)
    concrete(cv, *tr, seed=seed + 2, mid=4)
    cv.hline(tr[0], tr[2], tr[3], col("SLATE", 4))
    cv.vline(x0, y0, y1, col("SLATE", 4))
    cv.vline(x1, y0, y1, col("GUN", 0))
    cv.hline(x0, x1, y1, col("GUN", 0))
    bolt_ring(cv, x0 + 1, y0 + 1, x1 - 1, y1 - 1, inset=1, ramp="SLATE", mid=5)
    # chamfered inner frame edge
    cv.chamfer_outline(x0 + 4, y0 + 4, x1 - 4, y1 - 6, 2, col("GUN", 1))
    # recessed leaf
    lx0, ly0, lx1, ly1 = x0 + 6, y0 + 6, x1 - 6, y1 - 8
    cv.rect(lx0 - 1, ly0 - 1, lx1 + 1, ly1 + 1, col("DARK", 0))      # seal gap
    paint_metal(cv, lx0, ly0, lx1, ly1, seed=seed + 3, ramp="SLATE", mid=2, cell=6)
    # leaf reinforcement band (proud 1px)
    by = (ly0 + ly1) // 2
    cv.rect(lx0, by - 1, lx1, by + 1, col("SLATE", 3))
    cv.hline(lx0, lx1, by - 2, col("SLATE", 5))
    cv.hline(lx0, lx1, by + 2, col("GUN", 0))
    rivet_line_h(cv, lx0 + 2, lx1 - 2, by, 6, ramp="SLATE", hi=5, lo=1)
    for sx in (lx0 + 6, lx0 + 14):
        cv.vline(sx, ly0 + 2, by - 3, col("SLATE", 1))
        cv.vline(sx, by + 3, ly1 - 2, col("SLATE", 1))
    cv.hline(lx0 + 1, lx1 - 1, ly0 + 1, col("GUN", 0))
    grime(cv, lx0, ly1 - 5, lx1, ly1, seed + 40, amt=0.4)
    # porthole: octagon glass
    px, py = lx0 + 8, ly0 + 6
    oct_vent(cv, px, py, 3, seed=seed + 4, blades=False)
    cv.rect(px - 2, py - 2, px + 2, py + 2, col("GLASS", 1))
    cv.set(px - 1, py - 1, col("GLASS", 4))
    cv.set(px, py, col("GLASS", 3))
    cv.set(px - 2, py - 2, col("SLATE", 5))
    cv.set(px - 3, py - 1, col("SLATE", 4))
    # locking clamps, right side (proud, cast 1px shadow)
    for cy in (ly0 + 4, ly1 - 7):
        cv.rect(lx1 - 3, cy, lx1 + 1, cy + 4, col("GUN", 4))
        cv.vline(lx1 - 3, cy, cy + 4, col("SLATE", 5))
        cv.vline(lx1 + 2, cy, cy + 5, col("DARK", 0))
        cv.hline(lx1 - 3, lx1 + 2, cy + 5, col("DARK", 0))
        bolt(cv, lx1 - 2, cy + 1, ramp="SLATE", mid=5)
    # status panel on the frame, left
    sx, sy = x0 + 1, y0 + 10
    cv.rect(sx, sy, sx + 3, sy + 5, col("GLASS", 0))
    cv.set(sx + 1, sy + 1, col("GLOW", 1))
    cv.set(sx + 2, sy + 3, col("GLOW", 1))
    cv.set(sx + 1, sy + 4, col("GLOW", 0))
    # warning lights on the top frame
    cv.set(x0 + 8, y0 + 2, col("AMBER", 3))
    cv.set(x1 - 8, y0 + 2, col("GLOW", 1))
    # threshold step: proud plate with worn warning patch
    st = sc.front_rect(x + 4, yf + 4, 32, z0, z0 + 3)
    stt = sc.top_rect(x + 4, yf + 4, 32, 6, 3)
    raw_metal(cv, *st, seed=seed + 5, ramp="SLATE", mid=2)
    raw_metal(cv, *stt, seed=seed + 6, ramp="SLATE", mid=4)
    cv.hline(stt[0], stt[2], stt[3], col("SLATE", 5))
    warning_patch(cv, st[0] + 6, st[1], st[0] + 20, st[3] - 1, seed=seed + 7,
                  wear=0.5)
    # dark gap under the leaf (deep door recess)
    cv.hline(lx0, lx1, ly1 + 1, col("DARK", 0))
    cv.hline(lx0, lx1, ly1 + 2, col("DARK", 1))
    # small bracket lamp above
    cv.rect(x0 + 18, y0 - 3, x0 + 21, y0 - 2, col("GUN", 2))
    cv.rect(x0 + 17, y0 - 2, x0 + 22, y0 - 1, col("SLATE", 3))
    cv.hline(x0 + 18, x0 + 21, y0 - 1, col("GLASS", 2))
    # wear
    chip(cv, x0 + 5, y0 + 3, seed + 31)
    chip(cv, x1 - 7, y1 - 4, seed + 32)
    rust_weep(cv, lx1 - 1, cy + 6, 4, seed + 33)
    grime(cv, st[0], st[1], st[2], st[3], seed + 34, amt=0.5)
    return {"w": w, "d": d, "h": h, "front": fr}


# ======================================================================
# 7. window_recess_A — deep-set window with sill
# ======================================================================
def window_recess_A(sc, cv, x, yf, seed=0, h=28, z0=0, lit=False):
    w, d = 32, 16
    fr = sc.front_rect(x, yf, w, z0, h)
    x0, y0, x1, y1 = fr
    # flange frame proud 1px
    paint_metal(cv, x0, y0, x1, y1, seed=seed + 1, ramp="CREAM", mid=4, cell=6)
    cv.vline(x0, y0, y1, col("CREAM", 5))
    cv.hline(x0, x1, y0, col("CREAM", 5))
    cv.vline(x1, y0, y1, col("CREAM", 1))
    cv.hline(x0, x1, y1, col("CREAM", 1))
    bolt_ring(cv, x0 + 1, y0 + 1, x1 - 1, y1 - 1, inset=0, ramp="GUN", mid=4)
    # opening + deep niche
    ox0, oy0, ox1, oy1 = x0 + 5, y0 + 6, x0 + 26, y1 - 6
    dep = 3
    cv.outline(ox0 - 1, oy0 - 1, ox1 + 1, oy1 + 1, col("GUN", 1))
    glass(cv, ox0 + 1, oy0 + dep, ox1 - 1, oy1 - 1, seed=seed + 2,
          lit=True if (lit and LIGHT.profile == "night") else None)
    # mullions
    mx = (ox0 + ox1) // 2
    cv.vline(mx, oy0 + dep, oy1 - 1, col("GUN", 2))
    cv.vline(mx + 1, oy0 + dep, oy1 - 1, col("GUN", 4))
    my = (oy0 + oy1) // 2
    cv.hline(ox0 + 1, ox1 - 1, my, col("GUN", 2))
    cv.hline(ox0 + 1, ox1 - 1, my + 1, col("GUN", 4))
    # soffit shadow inside the top
    for i in range(dep):
        cv.hline(ox0, ox1, oy0 + i, col("DARK", 0) if i == 0 else col("GUN", 0))
    cv.vline(ox0, oy0, oy1, col("DARK", 1))                 # left reveal
    cv.vline(ox1, oy0, oy1, col("GLASS", 0))
    # interior light strip (emissive budget 3 px)
    cv.set(ox0 + 3, oy0 + dep, col("GLOW", 0))
    cv.set(ox0 + 4, oy0 + dep, col("GLOW", 1))
    cv.set(ox0 + 5, oy0 + dep, col("GLOW", 0))
    # sill plate proud, with drip edge
    st = sc.top_rect(x + 3, yf + 3, 26, 5, 6)
    sf = sc.front_rect(x + 3, yf + 3, 26, z0 + 4, z0 + 6)
    raw_metal(cv, *sf, seed=seed + 3, ramp="SLATE", mid=3)
    concrete(cv, *st, seed=seed + 4, mid=5)
    cv.hline(st[0], st[2], st[3], col("SLATE", 5))
    cv.hline(sf[0], sf[2], sf[3], col("SLATE", 1))
    cv.vline(sf[2] + 1, sf[1] + 1, sf[3] + 1, col("DARK", 0))
    # water streaks below the sill (grey-brown, short, tapered)
    for (sx, ln) in ((sf[0] + 6, 5), (sf[0] + 17, 4)):
        for i in range(ln):
            t = i / ln
            if h2(sx, i, seed + 21 + sx) < t * 0.6:
                continue
            cv.set(sx, sf[3] + 2 + i, col("DIRT", 0 if t < 0.5 else 1))
            if i < 2:
                cv.set(sx + 1, sf[3] + 2 + i, col("DIRT", 1))
    cv.vline(x0 + 3, y0 + 2, y1 - 2, col("CREAM", 2))
    cv.vline(x1 - 3, y0 + 2, y1 - 2, col("CREAM", 2))
    chip(cv, sf[0] + 22, sf[1], seed + 23)
    grime(cv, x0, y1 - 3, x1, y1, seed + 24, amt=0.4)
    return {"w": w, "d": d, "h": h, "front": fr}


# ======================================================================
# 8. roof_edge_A — parapet / fascia / gutter module
# ======================================================================
def roof_edge_A(sc, cv, x, yf, seed=0, h=10, w=MW, z0=0):
    d = 20
    fr = sc.front_rect(x, yf, w, z0, z0 + h)
    tr = sc.top_rect(x, yf, w, d, z0 + h)
    x0, y0, x1, y1 = fr
    # fascia face
    paint_metal(cv, x0, y0 + 2, x1, y1, seed=seed + 1, ramp="CREAM", mid=3, cell=8)
    # cap slab (proud): front band + top
    raw_metal(cv, x0, y0, x1, y0 + 1, seed=seed + 2, ramp="SLATE", mid=3)
    cv.hline(x0, x1, y0, col("SLATE", 5))
    concrete_slab(cv, *tr, seed=seed + 3, mid=4, ax=sc.ox, ay=sc.oy)
    cv.hline(tr[0], tr[2], tr[3], col("SLATE", 4))
    # gutter channel along the back of the top face
    gy = tr[1] + 2
    cv.hline(tr[0] + 1, tr[2] - 1, gy, col("RUBBER", 1))
    cv.hline(tr[0] + 1, tr[2] - 1, gy + 1, col("RUBBER", 2))
    grime(cv, tr[0] + 1, gy - 1, tr[2] - 1, gy + 2, seed + 4, amt=0.5)
    # fascia seams + stencil
    for sx in (w // 4, w // 4 * 3 - 8):
        cv.vline(x0 + sx, y0 + 3, y1 - 1, col("CREAM", 1))
        rivet(cv, x0 + sx, y0 + 5, ramp="SLATE", hi=4, lo=1)
        rivet(cv, x0 + sx, y1 - 4, ramp="SLATE", hi=4, lo=1)
    stencil(cv, x0 + w // 2 - 6, y0 + 5, "K-17", ramp="AMBER", idx=2,
            wear=0.45, seed=seed + 5)
    # cable entries through the fascia
    for (cx, cy) in ((8, 7), (w - 16, 8)):
        cv.rect(x0 + cx, y0 + cy, x0 + cx + 2, y0 + cy + 2, col("DARK", 0))
        cv.set(x0 + cx, y0 + cy, col("GUN", 2))
        cv.set(x0 + cx + 2, y0 + cy + 2, col("SLATE", 3))
    # downspout on the right, proud with clamps + cast shadow
    px = x1 - 5 if w >= MW else x1 - 4
    pipe_v(cv, px, y0 + 2, y1 + 2, 2, ramp="SLATE", mid=2)
    cv.vline(px + 4, y0 + 3, y1 + 2, col("DARK", 0))
    clamp(cv, px + 1, y0 + 6)
    clamp(cv, px + 1, y1 - 2)
    # soffit underside line + shadow it casts (in assembly on wall below)
    cv.hline(x0, x1, y1, col("GUN", 0))
    # rust weeps from cap seam + gutter
    rust_weep(cv, x0 + w // 4, y0 + 2, 5, seed + 21)
    rust_weep(cv, x0 + w // 4 * 3 - 8, y0 + 2, 4, seed + 22)
    rust_weep(cv, tr[0] + 30, gy + 2, 3, seed + 23)
    chip(cv, x0 + w // 2 + 4, y0 + 4, seed + 24)
    grime(cv, x0, y1 - 4, x1, y1, seed + 25, amt=0.5)
    dust_cap(cv, tr[0] + 2, tr[2] - 2, tr[1] + 1, seed + 26, amt=0.3)
    return {"w": w, "d": d, "h": h, "front": fr, "top": tr}


# ======================================================================
# 9. roof_section_A — deck with hatch, vent unit, cable tray
# ======================================================================
def roof_section_A(sc, cv, x, yf, seed=0, h=6, w=MW, d=64, z0=0):
    pass
    fr = sc.front_rect(x, yf, w, z0, z0 + h)
    tr = sc.top_rect(x, yf, w, d, z0 + h)
    x0, y0, x1, y1 = fr
    paint_metal(cv, x0, y0, x1, y1, seed=seed + 1, ramp="CREAM", mid=3)
    cv.hline(x0, x1, y0, col("CREAM", 5))
    concrete_slab(cv, *tr, seed=seed + 2, mid=4, ax=sc.ox, ay=sc.oy)
    tx0, ty0, tx1, ty1 = tr
    h = z0 + h
    # ---- hatch (front-left) ----
    hx0, hy0 = tx0 + 8, ty0 + 6
    hx1, hy1 = hx0 + 16, hy0 + 14
    cv.rect(hx0 - 1, hy0 - 1, hx1 + 1, hy1 + 1, col("SLATE", 4))   # raised frame
    cv.rect(hx0, hy0, hx1, hy1, col("GUN", 2))
    cv.hline(hx0, hx1, hy0, col("GUN", 4))
    cv.vline(hx0, hy0, hy1, col("GUN", 4))
    cv.vline(hx1, hy0, hy1, col("GUN", 0))
    cv.hline(hx0, hx1, hy1, col("GUN", 0))
    cv.rect(hx0 - 1, hy0 + 2, hx0 - 1, hy0 + 4, col("SLATE", 5))   # hinges
    cv.rect(hx0 - 1, hy1 - 4, hx0 - 1, hy1 - 2, col("SLATE", 5))
    cv.rect(hx1 - 3, hy0 + 6, hx1 - 1, hy0 + 7, col("SLATE", 5))   # handle
    cv.vline(hx1 + 2, hy0 + 1, hy1 + 1, col("DARK", 0))            # cast shadow
    cv.hline(hx0 + 1, hx1 + 2, hy1 + 2, col("DARK", 0))
    # ---- vent unit: small proud mass with octagon on top ----
    vx, vy, vw, vd, vh = x + w - 26, yf - 10, 16, 14, 8
    vfr = sc.front_rect(vx, vy, vw, h, h + vh)
    vtr = sc.top_rect(vx, vy, vw, vd, h + vh)
    raw_metal(cv, *vfr, seed=seed + 3, ramp="GUN", mid=2)
    concrete(cv, *vtr, seed=seed + 4, mid=4)
    cv.hline(vfr[0], vfr[2], vfr[1], col("SLATE", 4))
    cv.vline(vfr[2] + 1, vfr[1] + 1, vfr[3] + 1, col("DARK", 0))
    cv.hline(vfr[0] + 1, vfr[2] + 1, vfr[3] + 1, col("DARK", 0))
    oct_vent(cv, (vtr[0] + vtr[2]) // 2, (vtr[1] + vtr[3]) // 2, 4, seed=seed + 5)
    hex_grille(cv, vfr[0] + 2, vfr[1] + 2, vfr[2] - 2, vfr[3] - 2)
    # ---- cable tray across the deck ----
    ty = ty0 + d - 26
    cv.hline(tx0 + 4, tx1 - 2, ty, col("SLATE", 4))
    cv.hline(tx0 + 4, tx1 - 2, ty + 4, col("SLATE", 1))
    for i in range(3):
        cv.hline(tx0 + 4, tx1 - 2, ty + 1 + i, col(["RUBBER", "RUBBER", "SLATE"][i],
                                                    [1, 2, 2][i]))
    for sx in range(tx0 + 8, tx1 - 4, 12):
        cv.rect(sx, ty + 5, sx + 1, ty + 6, col("GUN", 1))
        cv.set(sx + 2, ty + 6, col("DARK", 0))
    # tray drops over the front edge
    cv.rect(tx1 - 4, ty, tx1 - 1, ty1, col("SLATE", 2))
    cv.vline(tx1 - 4, ty, ty1, col("SLATE", 4))
    # ---- repair plates (irregular, riveted) ----
    cv.rect(tx0 + 28, ty0 + d - 18, tx0 + 37, ty0 + d - 12, col("SLATE", 2))
    cv.outline(tx0 + 28, ty0 + d - 18, tx0 + 37, ty0 + d - 12, col("SLATE", 4))
    for (bx, by) in ((tx0 + 29, ty0 + d - 17), (tx0 + 36, ty0 + d - 17),
                     (tx0 + 29, ty0 + d - 13), (tx0 + 36, ty0 + d - 13)):
        cv.set(bx, by, col("SLATE", 5))
    cv.rect(tx0 + w - 18, ty0 + 26, tx0 + w - 11, ty0 + 31, col("COPPER", 2))
    cv.outline(tx0 + w - 18, ty0 + 26, tx0 + w - 11, ty0 + 31, col("COPPER", 3))
    # tar patch (irregular blob)
    for yy in range(ty0 + d - 22, ty0 + d - 17):
        for xx in range(tx0 + 12, tx0 + 20):
            if h2(xx, yy, seed + 31) > 0.25:
                cv.set(xx, yy, col("RUBBER", 1))
    cv.set(tx0 + 14, ty0 + 43, col("RUBBER", 2))
    # wear
    rust_weep(cv, tx0 + 30, ty0 + d - 11, 3, seed + 41)
    grime(cv, tx0, ty1 - 3, tx1, ty1, seed + 42, amt=0.35)
    dust_cap(cv, tx0 + 2, tx1 - 2, ty0 + 1, seed + 43, amt=0.3)
    return {"w": w, "d": d, "h": h, "front": fr, "top": tr}


# ======================================================================
# 10. roof_section_B — solar array, walkway, filter, round hatch
# ======================================================================
def roof_section_B(sc, cv, x, yf, seed=0, h=6, w=MW, d=64, z0=0):
    pass
    fr = sc.front_rect(x, yf, w, z0, z0 + h)
    tr = sc.top_rect(x, yf, w, d, z0 + h)
    x0, y0, x1, y1 = fr
    paint_metal(cv, x0, y0, x1, y1, seed=seed + 1, ramp="CREAM", mid=3)
    cv.hline(x0, x1, y0, col("CREAM", 5))
    concrete_slab(cv, *tr, seed=seed + 2, mid=4, ax=sc.ox, ay=sc.oy)
    tx0, ty0, tx1, ty1 = tr
    h = z0 + h
    # ---- solar array: 2 rows x 3 panels on low legs ----
    ncols = max(1, (w - 8) // 20)
    for row, py in enumerate((ty0 + 8, ty0 + 24)):
        for col_i in range(ncols):
            px = tx0 + 6 + col_i * 20
            pw, ph = 16, 10
            cv.rect(px - 1, py - 1, px + pw, py + ph, col("SLATE", 3))
            glass(cv, px, py, px + pw - 1, py + ph - 1, seed=seed + 10 + row * 3 + col_i)
            for gx in range(px + 4, px + pw - 1, 5):
                cv.vline(gx, py, py + ph - 1, col("GUN", 1))
            cv.hline(px, px + pw - 1, py + ph // 2, col("GUN", 1))
            cv.hline(px, px + pw - 1, py - 1, col("SLATE", 5))
            # legs + shadow to the right
            cv.set(px + 2, py + ph, col("GUN", 1))
            cv.set(px + pw - 3, py + ph, col("GUN", 1))
            cv.vline(px + pw + 1, py + 1, py + ph + 1, col("DARK", 0))
            cv.hline(px + 1, px + pw + 1, py + ph + 1, col("DARK", 0))
    # ---- service walkway (grate) across the front of the deck ----
    wy = ty0 + d - 20
    cv.rect(tx0 + 3, wy, tx1 - 3, wy + 6, col("GUN", 1))
    for gx in range(tx0 + 4, tx1 - 3, 2):
        cv.vline(gx, wy + 1, wy + 5, col("DARK", 0))
    cv.hline(tx0 + 3, tx1 - 3, wy, col("SLATE", 4))
    cv.hline(tx0 + 3, tx1 - 3, wy + 6, col("DARK", 0))
    for sx in range(tx0 + 8, tx1 - 6, 14):
        cv.set(sx, wy + 7, col("GUN", 1))
    # ---- cylindrical filter near the right ----
    fx, fy = tx1 - 12, ty0 + d - 24
    pipe_v(cv, fx, fy - 8, fy + 2, 3, ramp="SLATE", mid=3)
    cv.rect(fx - 1, fy - 10, fx + 6, fy - 9, col("SLATE", 4))      # cap
    cv.set(fx + 1, fy - 11, col("GUN", 2))
    cv.vline(fx + 7, fy - 8, fy + 2, col("DARK", 0))               # cast
    cv.hline(fx, fx + 7, fy + 3, col("DARK", 0))
    flange_h(cv, fx, fy - 4, 3, ramp="GUN", mid=3)
    # ---- round hatch front-left ----
    rcx, rcy = tx0 + 14, ty0 + d - 12
    cv.circle_fill(rcx, rcy, 5, col("SLATE", 3))
    cv.circle_fill(rcx, rcy, 4, col("GUN", 2))
    cv.ring(rcx, rcy, 4, col("SLATE", 4), thick=1)
    cv.set(rcx - 1, rcy - 2, col("SLATE", 5))
    cv.rect(rcx - 2, rcy - 1, rcx + 2, rcy, col("SLATE", 4))       # handle bar
    for a in range(4):
        bx = rcx + (3 if a == 0 else -3 if a == 1 else 0)
        by = rcy + (0 if a < 2 else (3 if a == 2 else -3))
        cv.set(bx, by, col("SLATE", 5))
    cv.vline(rcx + 6, rcy - 4, rcy + 4, col("DARK", 0))
    # ---- cable routing: conduit filter -> walkway + junction box ----
    cv.rect(fx - 6, fy + 1, fx - 2, fy + 4, col("GUN", 3))
    cv.hline(fx - 6, fx - 2, fy + 1, col("SLATE", 4))
    cv.set(fx - 3, fy + 2, col("GLOW", 1))
    pipe_h(cv, tx0 + 20, fx - 6, fy + 2, 1, ramp="SLATE", mid=2)
    cv.hline(tx0 + 20, fx - 6, fy + 4, col("DARK", 0))
    # ---- patches different from A ----
    cv.rect(tx0 + 30, ty0 + 12, tx0 + 37, ty0 + 17, col("SLATE", 2))
    cv.outline(tx0 + 30, ty0 + 12, tx0 + 37, ty0 + 17, col("SLATE", 4))
    for yy in range(ty0 + d - 30, ty0 + d - 26):
        for xx in range(tx0 + 8, tx0 + 14):
            if h2(xx, yy, seed + 33) > 0.3:
                cv.set(xx, yy, col("RUBBER", 1))
    # wear
    rust_weep(cv, fx + 2, fy + 3, 4, seed + 41)
    rust_weep(cv, tx0 + 32, ty0 + 18, 3, seed + 42)
    grime(cv, tx0, ty1 - 3, tx1, ty1, seed + 43, amt=0.35)
    dust_cap(cv, tx0 + 2, tx1 - 2, ty0 + 1, seed + 44, amt=0.3)
    return {"w": w, "d": d, "h": h, "front": fr, "top": tr}


def _outer_corner_mirror(sc, cv, x, yf, seed=0, h=WALL_H, z0=0):
    """convex corner with the projecting wing on the LEFT (mass left end)."""
    w, d = 48, 48
    wing_y = yf + 10
    # main wall face (right part)
    fr = sc.front_rect(x + 12, yf, 36, z0, h)
    paint_metal(cv, *fr, seed=seed + 1, ramp="CREAM", mid=3)
    raw_metal(cv, fr[0], fr[1], fr[2], fr[1] + 2, seed=seed + 2, ramp="GUN", mid=3)
    cv.hline(fr[0], fr[2], fr[1] + 3, col("GUN", 0))
    tl = sc.top_rect(x + 12, yf, 36, d - 10, h)
    concrete(cv, *tl, seed=seed + 3, mid=4)
    cv.hline(tl[0], tl[2], tl[3], col("SLATE", 4))
    # wing on the left, projecting toward the viewer
    wf = sc.front_rect(x, wing_y, 12, z0, h)
    wt = sc.top_rect(x, wing_y, 12, d, h)
    concrete(cv, *wt, seed=seed + 4, mid=4)
    paint_metal(cv, *wf, seed=seed + 5, ramp="CREAM", mid=3)
    cv.hline(wt[0], wt[2], wt[3], col("SLATE", 4))
    cv.hline(wf[0], wf[2], wf[1] + 3, col("GUN", 0))
    raw_metal(cv, wf[0], wf[1], wf[2], wf[1] + 2, seed=seed + 6, ramp="GUN", mid=3)
    cv.vline(wf[2], wf[1] + 3, wf[3], col("CREAM", 1))
    rivet_line_v(cv, wf[0] + 3, wf[1] + 6, wf[3] - 4, 8)
    stencil(cv, wf[0] + 2, wf[1] + 24, "C2", ramp="AMBER", idx=2, wear=0.4,
            seed=seed + 8)
    # corner reinforcement column
    cz = h + 3
    cf = sc.front_rect(x + 9, wing_y + 2, 8, z0, cz)
    ct = sc.top_rect(x + 9, wing_y + 2, 8, 10, cz)
    raw_metal(cv, *cf, seed=seed + 9, ramp="SLATE", mid=2)
    raw_metal(cv, *ct, seed=seed + 10, ramp="SLATE", mid=4)
    cv.vline(cf[0], cf[1], cf[3], col("SLATE", 4))
    cv.vline(cf[2], cf[1], cf[3], col("SLATE", 0))
    cv.vline(cf[2] + 1, cf[1] + 1, cf[3] + 1, col("DARK", 0))
    cv.hline(ct[0], ct[2], ct[3], col("SLATE", 5))
    rivet_line_v(cv, cf[0] + 3, cf[1] + 4, cf[3] - 3, 6, ramp="SLATE", hi=5, lo=1)
    cv.rect(cf[0] - 1, cf[1] - 1, cf[2] + 1, cf[1], col("SLATE", 3))
    cable_sag(cv, cf[0], cf[1] + 3, wf[0] + 1, wf[1] + 10, 3, seed=seed + 11)
    conduit_diag(cv, fr[2] - 4, fr[3] - 6, fr[2] - 26, fr[3] - 14, ramp="SLATE", mid=2)
    rivet_line_h(cv, fr[0] + 2, fr[2] - 2, fr[3] - 3, 8)
    stencil(cv, fr[2] - 12, fr[1] + 7, "B3", ramp="AMBER", idx=2, wear=0.3,
            seed=seed + 13)
    rust_weep(cv, cf[0] + 2, cf[3] - 8, 6, seed + 21)
    grime(cv, wf[0], wf[3] - 6, wf[2], wf[3], seed + 22, amt=0.6)
    grime(cv, fr[0], fr[3] - 6, fr[2], fr[3], seed + 23, amt=0.5)
    chip(cv, cf[0] + 1, cf[1] + 6, seed + 24)
    dust_cap(cv, wt[0] + 1, wt[2] - 1, wt[3] - 1, seed + 25, amt=0.3)
    return {"w": w, "d": d, "h": cz, "front": fr}
