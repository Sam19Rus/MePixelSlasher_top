"""
PROPS generators (assets 17..18): the library reaches beyond architecture.
"""

from palettes.frontier_service import col
from common.noise import h2
from common.materials import paint_metal, raw_metal, rubber, concrete_slab
from common.depth import contact_shadow, cast_shadow_ground, pipe_v
from common.details import (bolt, cable_sag, chip, scratch, rust_weep, grime,
                            dust_cap, stencil)
from generators.architecture import wall_chip, WALL_H


# ======================================================================
# 17. industrial_light_A — exterior wall lamp with cage
# ======================================================================
def industrial_light_A(sc, cv, x, yf, seed=0, with_wall=True, lit=False, z0=0):
    w, d = 14, 10
    h = 18
    if with_wall:
        wall_chip(sc, cv, x - 4, yf - 6, w + 10, h + 8, seed)
    x0 = sc.sx(x)
    # mounting plate
    py0 = sc.sy(yf - 1, z0 + 16)
    py1 = sc.sy(yf - 1, z0 + 9)
    cv.rect(x0 + 1, py0, x0 + 6, py1, col("GUN", 3))
    cv.vline(x0 + 1, py0, py1, col("SLATE", 4))
    cv.vline(x0 + 6, py0, py1, col("GUN", 0))
    cv.set(x0 + 2, py0 + 1, col("SLATE", 5))
    cv.set(x0 + 2, py1 - 1, col("SLATE", 5))
    # arm at 45° down-right
    cv.line(x0 + 6, py1 - 2, x0 + 9, py1 + 1, col("GUN", 3))
    cv.line(x0 + 6, py1 - 3, x0 + 9, py1, col("SLATE", 4))
    # housing shade (trapezoid): top lit, underside dark
    sy0 = py1 + 1
    cv.hline(x0 + 6, x0 + 13, sy0, col("SLATE", 4))
    cv.hline(x0 + 5, x0 + 14, sy0 + 1, col("SLATE", 3))
    cv.hline(x0 + 4, x0 + 15, sy0 + 2, col("SLATE", 3))
    cv.hline(x0 + 4, x0 + 15, sy0 + 3, col("GUN", 1))          # underside
    cv.set(x0 + 5, sy0 + 1, col("SLATE", 5))
    cv.set(x0 + 4, sy0 + 2, col("SLATE", 5))
    # lens (emissive core, <=5 px; glow added at runtime)
    ly = sy0 + 4
    lens = col("GLOW", 2) if lit else col("GLOW", 1)
    core = col("GLOW", 3) if lit else col("GLOW", 2)
    cv.hline(x0 + 7, x0 + 11, ly, lens)
    cv.hline(x0 + 8, x0 + 10, ly + 1, core)
    # protective cage: vertical bars + bottom arc in front of the lens
    for bx in (x0 + 7, x0 + 10, x0 + 13):
        cv.vline(bx, ly - 1, ly + 2, col("RUBBER", 2))
    cv.hline(x0 + 6, x0 + 14, ly + 3, col("RUBBER", 2))
    cv.set(x0 + 5, ly + 2, col("RUBBER", 2))
    cv.set(x0 + 15, ly + 2, col("RUBBER", 2))
    # shade cast shadow on the wall (below-right)
    for i in range(1, 3):
        cv.hline(x0 + 5 + i, x0 + 15 + i, sy0 + 4 + i, col("DARK", 0) if i == 1 else col("GUN", 0))
    cv.vline(x0 + 16, sy0 + 2, sy0 + 6, col("DARK", 0))
    # chip on the shade edge
    chip(cv, x0 + 14, sy0 + 1, seed + 11, n=1)
    rust_weep(cv, x0 + 2, py1 + 1, 3, seed + 12)
    return {"w": w, "d": d, "h": h}


# ======================================================================
# 18. maintenance_cart_A — service cart
# ======================================================================
def maintenance_cart_A(sc, cv, x, yf, seed=0):
    w, d = 30, 18
    h = 22
    cast_shadow_ground(sc, cv, x, yf, w, h, d)
    yb = sc.sy(yf, 0)
    # wheels (front pair drawn; far wheel peeks)
    for (wx, r, far) in ((8, 4, False), (24, 4, False), (16, 4, True)):
        cx, cy = sc.sx(x + wx), yb - r
        if far:
            cv.circle_fill(cx, cy - 1, r - 1, col("RUBBER", 1))
            continue
        cv.circle_fill(cx, cy, r, col("RUBBER", 1))
        cv.ring(cx, cy, r, col("RUBBER", 0), thick=1)
        cv.circle_fill(cx, cy, 2, col("SLATE", 2))
        cv.circle_fill(cx, cy, 1, col("SLATE", 4))
        cv.set(cx - 1, cy - 2, col("RUBBER", 3))
        cv.set(cx - 3, cy - 3, col("RUBBER", 3))
        # dust on the tyre
        cv.set(cx + 2, cy + 2, col("DIRT", 2))
        cv.set(cx - 2, cy + 3, col("DIRT", 1))
    # frame bed + legs
    bf = sc.front_rect(x + 3, yf, 24, 8, 11)
    bt = sc.top_rect(x + 3, yf, 24, d - 4, 11)
    raw_metal(cv, *bf, seed=seed + 1, ramp="SLATE", mid=3, cell=5)
    raw_metal(cv, *bt, seed=seed + 2, ramp="SLATE", mid=4, cell=5)
    cv.hline(bt[0], bt[2], bt[3], col("SLATE", 5))
    cv.hline(bf[0], bf[2], bf[1], col("SLATE", 4))
    cv.hline(bf[0], bf[2], bf[3], col("GUN", 0))
    cv.vline(bf[2] + 1, bf[1] + 1, bf[3] + 1, col("DARK", 0))
    for lx in (7, 23):
        lg = sc.front_rect(x + lx, yf, 3, 4, 8)
        raw_metal(cv, *lg, seed=seed + 3 + lx, ramp="GUN", mid=2)
    # lower tray with paint cans
    tf = sc.front_rect(x + 8, yf + 2, 14, 4, 7)
    raw_metal(cv, *tf, seed=seed + 5, ramp="SLATE", mid=2)
    cv.hline(tf[0], tf[2], tf[1], col("SLATE", 4))
    c1 = sc.front_rect(x + 10, yf + 2, 4, 7, 11)
    paint_metal(cv, *c1, seed=seed + 6, ramp="CREAM", mid=3, cell=4)
    cv.rect(c1[0], c1[1] + 1, c1[2], c1[1] + 2, col("AMBER", 2))
    cv.hline(c1[0], c1[2], c1[1], col("CREAM", 5))
    c2 = sc.front_rect(x + 16, yf + 2, 4, 7, 10)
    raw_metal(cv, *c2, seed=seed + 7, ramp="SLATE", mid=3, cell=4)
    cv.hline(c2[0], c2[2], c2[1], col("SLATE", 5))
    # toolbox on the bed
    tb = sc.front_rect(x + 6, yf, 11, 11, 17)
    tt = sc.top_rect(x + 6, yf, 11, d - 6, 17)
    paint_metal(cv, *tb, seed=seed + 8, ramp="TEAL", mid=3, cell=5)
    paint_metal(cv, *tt, seed=seed + 9, ramp="TEAL", mid=4, cell=5)
    cv.hline(tb[0], tb[2], tb[1], col("TEAL", 5))
    cv.hline(tb[0], tb[2], tb[1] + 3, col("TEAL", 1))         # lid seam
    cv.hline(tb[0], tb[2], tb[1] + 4, col("TEAL", 4))
    cv.vline(tb[2], tb[1], tb[3], col("TEAL", 1))
    cv.vline(tb[2] + 1, tb[1] + 1, tb[3] + 1, col("DARK", 0))
    cv.rect(tb[0] + 5, tb[1] + 1, tb[0] + 6, tb[1] + 4, col("SLATE", 4))  # latch
    # handle arc on the lid
    cv.hline(tb[0] + 3, tb[0] + 8, tt[1] - 1, col("GUN", 2))
    cv.set(tb[0] + 3, tt[1], col("GUN", 2))
    cv.set(tb[0] + 8, tt[1], col("GUN", 2))
    # wrench sticking out + hanging cable coil
    cv.line(tb[2] - 2, tb[1] - 2, tb[2] + 2, tb[1] - 5, col("SLATE", 4))
    cv.set(tb[2] + 2, tb[1] - 6, col("SLATE", 4))
    cv.set(tb[2] + 3, tb[1] - 5, col("SLATE", 4))
    rcx, rcy = sc.sx(x + 3), yb - 12
    cv.ring(rcx, rcy, 3, col("RUBBER", 2), thick=2)
    cv.set(rcx - 1, rcy - 2, col("RUBBER", 3))
    # push handle to the right with rubber grip
    hx = sc.sx(x + 27)
    cv.line(hx, bf[1] + 1, hx + 2, bf[1] - 6, col("SLATE", 3))
    cv.line(hx + 2, bf[1] - 6, hx + 2, bf[1] - 9, col("RUBBER", 2))
    cv.set(hx + 2, bf[1] - 10, col("RUBBER", 3))
    # contact shadows under wheels
    contact_shadow(cv, sc.sx(x + 4), sc.sx(x + 12), yb + 1, rows=2,
                   jitter_seed=seed + 1)
    contact_shadow(cv, sc.sx(x + 20), sc.sx(x + 28), yb + 1, rows=2,
                   jitter_seed=seed + 2)
    # wear
    chip(cv, tb[0] + 2, tb[1] + 1, seed + 21, n=2)
    scratch(cv, bf[0] + 6, bf[1] + 1, 5, seed + 22)
    rust_weep(cv, tf[0] + 2, tf[3] + 1, 3, seed + 23)
    dust_cap(cv, tt[0] + 1, tt[2] - 1, tt[1] + 1, seed + 24, amt=0.4)
    return {"w": w, "d": d, "h": h}
