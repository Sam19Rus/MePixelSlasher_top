"""
TECHNICAL + FUNCTIONAL generators (assets 11..16) of frontier_service.
Wall-mounted assets draw their own wall chip when standalone; in the
building assembly the same geometry is drawn onto real walls.
"""

from palettes.frontier_service import col, RAMPS
from common.noise import h2
from common.materials import (paint_metal, raw_metal, concrete, concrete_slab,
                              rubber, glass, ground_field, warning_patch)
from common.depth import (contact_shadow, cast_shadow_ground, pipe_v, pipe_h,
                          flange_v, flange_h, elbow_vh, cornice_shadow)
from common.details import (rivet, rivet_line_h, rivet_line_v, bolt, bolt_ring,
                            oct_vent, hex_grille, chamfer_panel, cartridge_slots,
                            cable_sag, conduit_diag, clamp, chip, scratch,
                            rust_weep, grime, dust_cap, soot, stencil)
from generators.architecture import wall_chip, ground_chip, WALL_H


# ======================================================================
# 11. pipe_cluster_A — multi-diameter pipe run with elbows and clamps
# ======================================================================
def pipe_cluster_A(sc, cv, x, yf, seed=0, h=64, with_wall=True, z0=0):
    w, d = 56, 40
    if with_wall:
        wall_chip(sc, cv, x - 4, yf - 6, w + 8, h + 8, seed)
    wx = x
    zb = z0
    # cast shadows of the pipes on the wall (right side, per radius)
    for (px, r, ph) in ((8, 5, 52), (24, 3, 40), (38, 2, h)):
        sx0 = sc.sx(x + px + 2 * r)
        yb = sc.sy(yf - 6, zb)
        yt = sc.sy(yf - 6, zb + ph)
        for i in range(1, 3 if r > 3 else 2):
            cv.vline(sx0 + i, yt + i, yb, col("DARK", 0) if i == 1 else col("GUN", 0))
    # pipe 1: thick, vertical then elbow to +x near the top
    p1 = sc.sx(x + 8)
    zt = zb + 46
    yt = sc.sy(yf - 2, zt)
    yb = sc.sy(yf - 2, zb)
    pipe_v(cv, p1, yt, yb, 5, ramp="SLATE", mid=2)
    flange_v(cv, p1 - 1, yb - 4, 5)
    flange_v(cv, p1 - 1, yt + 14, 5)
    elbow_vh(cv, p1, yt, 5, to="+x")
    pipe_h(cv, p1 + 8, p1 + 30, yt, 5, ramp="SLATE", mid=2)
    cv.hline(p1 + 8, p1 + 30, yt + 10, col("DARK", 0))          # cast below
    cv.hline(p1 + 8, p1 + 30, yt - 1, col("SLATE", 4))
    # end collar into the wall
    ex = p1 + 30
    cv.rect(ex, yt - 1, ex + 2, yt + 10, col("GUN", 3))
    cv.vline(ex + 2, yt - 1, yt + 10, col("GUN", 1))
    # patina at the elbow (damp copper collar)
    cv.set(p1 + 2, yt + 9, col("VERD", 2))
    cv.set(p1 + 3, yt + 10, col("VERD", 1))
    cv.set(p1 + 9, yt + 9, col("VERD", 2))
    # pipe 2: medium, elbow to -x at mid height
    p2 = sc.sx(x + 24)
    z2 = zb + 34
    y2t = sc.sy(yf - 2, z2)
    pipe_v(cv, p2, y2t, yb, 3, ramp="SLATE", mid=2)
    elbow_vh(cv, p2 - 6, y2t, 3, to="-x")
    pipe_h(cv, p2 - 16, p2 - 2, y2t, 3, ramp="SLATE", mid=2)
    cv.hline(p2 - 16, p2 - 2, y2t + 6, col("DARK", 0))
    cv.rect(p2 - 18, y2t - 1, p2 - 16, y2t + 6, col("GUN", 3))
    flange_v(cv, p2 - 1, yb - 3, 3)
    # pipe 3: thin full height with valve wheel
    p3 = sc.sx(x + 38)
    y3t = sc.sy(yf - 2, zb + h)
    pipe_v(cv, p3, y3t, yb, 2, ramp="SLATE", mid=3)
    flange_v(cv, p3 - 1, y3t + 8, 2)
    flange_v(cv, p3 - 1, yb - 6, 2)
    wy = y3t + 24
    cv.ring(p3 + 1, wy, 3, col("AMBER", 2), thick=1)
    cv.set(p3 + 1, wy, col("GUN", 3))
    cv.set(p3 - 2, wy, col("AMBER", 3))
    cv.set(p3 + 4, wy, col("AMBER", 1))
    cv.set(p3 + 1, wy - 3, col("AMBER", 3))
    cv.set(p3 + 1, wy + 3, col("AMBER", 1))
    # clamps to the wall (pairs)
    for (px, r) in ((8, 5), (24, 3), (38, 2)):
        for zz in (zb + 12, zb + 30):
            yy = sc.sy(yf - 2, zz)
            cx0 = sc.sx(x + px)
            cv.rect(cx0 - 1, yy, cx0 + 2 * r, yy + 2, col("GUN", 3))
            cv.hline(cx0 - 1, cx0 + 2 * r, yy, col("SLATE", 4))
            cv.set(cx0 - 2, yy + 1, col("DARK", 0))
            cv.set(cx0 + 2 * r + 1, yy + 1, col("DARK", 0))
    # rust only at logical spots: under clamps and at low joints
    rust_weep(cv, sc.sx(x + 10), sc.sy(yf - 2, zb + 12) + 3, 5, seed + 21)
    rust_weep(cv, sc.sx(x + 26), sc.sy(yf - 2, zb + 30) + 3, 4, seed + 22)
    rust_weep(cv, p1 + 4, yb - 8, 6, seed + 23)
    # ground collars where pipes enter the plinth
    for (px, r) in ((8, 5), (24, 3), (38, 2)):
        cx0 = sc.sx(x + px)
        cv.rect(cx0 - 1, yb - 1, cx0 + 2 * r, yb + 1, col("GUN", 2))
        cv.hline(cx0 - 1, cx0 + 2 * r, yb - 1, col("SLATE", 4))
    return {"w": w, "d": d, "h": h}


# ======================================================================
# 12. service_tower_A — stacked vertical technical module
# ======================================================================
def service_tower_A(sc, cv, x, yf, seed=0, h=96, d=40):
    w = 40
    cast_shadow_ground(sc, cv, x, yf, w, h, d)
    # tier 1: concrete base with access door
    f1 = sc.front_rect(x, yf, w, 0, 30)
    t1 = sc.top_rect(x, yf, w, d, 30)
    concrete(cv, *f1, seed=seed + 1, mid=3)
    chamfer_panel(cv, f1[0] + 6, f1[1] + 4, f1[0] + 20, f1[3] - 4, 2,
                  lambda c, a, b, cc, dd: raw_metal(c, a, b, cc, dd,
                                                    seed=seed + 2, ramp="GUN", mid=2),
                  seed=seed + 2, frame_ramp="CONC", frame_mid=3, depth=2)
    cv.rect(f1[0] + 17, (f1[1] + f1[3]) // 2, f1[0] + 18, (f1[1] + f1[3]) // 2 + 2,
            col("SLATE", 4))                                    # door handle
    stencil(cv, f1[0] + 24, f1[1] + 8, "S1", ramp="AMBER", idx=2, wear=0.4,
            seed=seed + 3)
    grime(cv, f1[0], f1[3] - 5, f1[2], f1[3], seed + 4, amt=0.6)
    # flange band
    fb = sc.front_rect(x, yf, w, 30, 33)
    raw_metal(cv, *fb, seed=seed + 5, ramp="GUN", mid=3)
    rivet_line_h(cv, fb[0] + 2, fb[2] - 2, fb[1] + 1, 6, ramp="SLATE", hi=5, lo=1)
    # tier 2: painted machine housing, octagon intake + vertical cartridges
    f2 = sc.front_rect(x, yf, w, 33, 66)
    paint_metal(cv, *f2, seed=seed + 6, ramp="CREAM", mid=3, cell=8)
    oct_vent(cv, f2[0] + 13, f2[1] + 14, 6, seed=seed + 7)
    # vertical cartridge column on the right
    for i in range(4):
        by = f2[1] + 5 + i * 7
        cv.rect(f2[2] - 12, by, f2[2] - 4, by + 5, col("DARK", 0))
        if i == 2:
            cv.rect(f2[2] - 11, by + 2, f2[2] - 5, by + 4, col("GUN", 0))
            continue
        cv.rect(f2[2] - 11, by + 1, f2[2] - 5, by + 4, col("TEAL", 3))
        cv.hline(f2[2] - 11, f2[2] - 5, by + 1, col("TEAL", 1))
        cv.rect(f2[2] - 9, by + 2, f2[2] - 7, by + 2, col("GUN", 1))
        cv.set(f2[2] - 6, by + 3, col("CREAM", 4) if i % 2 else col("AMBER", 2))
    rust_weep(cv, f2[0] + 13, f2[1] + 21, 6, seed + 8)
    # overhang slab between tier 2 and 3 + cornice shadow below it
    slab = sc.front_rect(x - 1, yf + 1, w + 2, 66, 69)
    slabt = sc.top_rect(x - 1, yf + 1, w + 2, d, 69)
    raw_metal(cv, *slab, seed=seed + 9, ramp="SLATE", mid=3)
    concrete(cv, *slabt, seed=seed + 10, mid=4)
    cv.hline(slab[0], slab[2], slab[1], col("SLATE", 5))
    cv.hline(slab[0], slab[2], slab[3], col("GUN", 0))
    cornice_shadow(cv, f2[0], f2[2], f2[1] - 1, rows=2)
    cv.vline(slab[2] + 1, slab[1] + 1, slab[3] + 1, col("DARK", 0))
    # tier 3: dark gunmetal with grille + LEDs
    f3 = sc.front_rect(x, yf, w, 69, 88)
    raw_metal(cv, *f3, seed=seed + 11, ramp="GUN", mid=2)
    hex_grille(cv, f3[0] + 5, f3[1] + 4, f3[0] + 22, f3[3] - 4)
    cv.rect(f3[2] - 10, f3[1] + 5, f3[2] - 4, f3[3] - 5, col("GUN", 1))
    cv.set(f3[2] - 7, f3[1] + 8, col("GLOW", 1))
    cv.set(f3[2] - 7, f3[1] + 12, col("AMBER", 3))
    rivet_line_v(cv, f3[0] + 2, f3[1] + 3, f3[3] - 3, 6, ramp="SLATE", hi=4, lo=1)
    # top cap + parapet lip
    cap = sc.front_rect(x, yf, w, 88, 92)
    capt = sc.top_rect(x, yf, w, d, 92)
    raw_metal(cv, *cap, seed=seed + 12, ramp="SLATE", mid=3)
    concrete_slab(cv, *capt, seed=seed + 13, mid=4, ax=sc.ox, ay=sc.oy)
    cv.hline(cap[0], cap[2], cap[1], col("SLATE", 5))
    dust_cap(cv, capt[0] + 1, capt[2] - 1, capt[1] + 1, seed + 14, amt=0.3)
    # exhaust stacks + soot
    for (ex, eh) in ((10, 8), (19, 6)):
        px = sc.sx(x + ex)
        ytop = sc.sy(yf, 92 + eh)
        ybase = sc.sy(yf, 92)
        pipe_v(cv, px, ytop, ybase, 2, ramp="SLATE", mid=2)
        cv.rect(px - 1, ytop - 1, px + 4, ytop, col("DARK", 0))
        soot(cv, px - 1, ytop - 3, px + 4, ytop - 2, seed + 20 + ex, amt=0.8)
    # antenna + beacon
    ax = sc.sx(x + 32)
    yat = sc.sy(yf, 92 + 14)
    yb2 = sc.sy(yf, 92)
    cv.vline(ax, yat, yb2, col("SLATE", 3))
    cv.hline(ax - 2, ax + 2, yat + 5, col("SLATE", 2))
    cv.set(ax, yat - 1, col("AMBER", 3))
    cv.set(ax, yat, col("AMBER", 4))
    # service ladder with stepped shadow
    lx = sc.sx(x + 1)
    ly0 = sc.sy(yf + 1, 4)
    ly1 = sc.sy(yf + 1, 64)
    cv.vline(lx, ly1, ly0, col("SLATE", 4))
    cv.vline(lx + 4, ly1, ly0, col("SLATE", 3))
    for yy in range(ly0, ly1, 4):
        cv.hline(lx, lx + 4, yy, col("SLATE", 4))
        cv.hline(lx + 1, lx + 5, yy + 1, col("DARK", 0))     # stepped shadow
    cv.vline(lx + 5, ly1 + 1, ly0 + 1, col("DARK", 0))
    # base contact
    contact_shadow(cv, f1[0], f1[2], f1[3] + 1, rows=2, jitter_seed=seed)
    chip(cv, f2[0] + 4, f2[1] + 3, seed + 31)
    rust_weep(cv, fb[0] + 8, fb[3] + 1, 5, seed + 32)
    return {"w": w, "d": d, "h": 92 + 14}


# ======================================================================
# 13. utility_spine_A — vertical cable spine / connector element
# ======================================================================
def utility_spine_A(sc, cv, x, yf, seed=0, h=80, with_wall=True, z0=0):
    w, d = 24, 24
    if with_wall:
        wall_chip(sc, cv, x - 6, yf - 8, w + 12, h + 10, seed)
    yb = sc.sy(yf - 3, z0)
    yt = sc.sy(yf - 3, z0 + h)
    x0 = sc.sx(x)
    # standoff gap shadow (spine sits 3px off the wall) + cast shadow right
    cv.vline(x0 + 10, yt, yb, col("DARK", 0))
    cv.vline(x0 + 11, yt + 1, yb, col("GUN", 0))
    cv.vline(x0 + 12, yt + 2, yb, col("GUN", 1))
    # central column
    raw_metal(cv, x0, yt, x0 + 9, yb, seed=seed + 1, ramp="GUN", mid=2, cell=4)
    cv.vline(x0, yt, yb, col("SLATE", 4))
    cv.vline(x0 + 9, yt, yb, col("GUN", 0))
    # segment flanges
    for zz in (z0 + 16, z0 + 32, z0 + 48, z0 + 64):
        yy = sc.sy(yf - 3, zz)
        cv.rect(x0 - 1, yy, x0 + 10, yy + 2, col("SLATE", 3))
        cv.hline(x0 - 1, x0 + 10, yy, col("SLATE", 5))
        cv.hline(x0 - 1, x0 + 10, yy + 3, col("DARK", 0))
    # side conduits
    pipe_v(cv, x0 - 4, yt + 2, yb, 1, ramp="SLATE", mid=2)
    pipe_v(cv, x0 + 12, yt + 2, yb, 1, ramp="SLATE", mid=1)
    for zz in (z0 + 10, z0 + 40, z0 + 70):
        clamp(cv, x0 - 3, sc.sy(yf - 3, zz))
        clamp(cv, x0 + 13, sc.sy(yf - 3, zz + 6))
    # junction boxes at three heights, with stub conduits + LEDs
    for i, (zz, bw) in enumerate(((z0 + 20, 8), (z0 + 44, 9), (z0 + 62, 7))):
        by = sc.sy(yf - 3, zz + 6)
        by2 = sc.sy(yf - 3, zz)
        bx = x0 + 1
        cv.rect(bx, by, bx + bw, by2, col("GUN", 3))
        cv.hline(bx, bx + bw, by, col("SLATE", 5))
        cv.vline(bx + bw, by, by2, col("GUN", 0))
        cv.hline(bx + 1, bx + bw - 1, (by + by2) // 2, col("GUN", 1))  # lid seam
        cv.set(bx + 2, by + 1, col("SLATE", 5))
        cv.set(bx + bw - 2, by + 1, col("SLATE", 5))
        led = col("GLOW", 1) if i != 1 else col("AMBER", 3)
        cv.set(bx + bw - 2, (by + by2) // 2 + 1, led)
        # stub conduits in/out (cables continue between boxes)
        cv.vline(bx + 3, by2 - 4, by2, col("SLATE", 2))
        cv.vline(bx + 3, by + 1, by + 4, col("SLATE", 2))
    # top cap with insulators
    cv.rect(x0 - 1, yt - 2, x0 + 10, yt - 1, col("SLATE", 3))
    cv.set(x0 + 2, yt - 3, col("RUBBER", 2))
    cv.set(x0 + 7, yt - 3, col("RUBBER", 2))
    cv.set(x0 + 2, yt - 4, col("SLATE", 4))
    cv.set(x0 + 7, yt - 4, col("SLATE", 4))
    # cable swag leaving to the right (connects sections)
    cable_sag(cv, x0 + 10, sc.sy(yf - 3, z0 + 50), x0 + 22,
              sc.sy(yf - 3, z0 + 46), 3, seed=seed + 5)
    rust_weep(cv, x0 + 4, sc.sy(yf - 3, z0 + 32) + 3, 4, seed + 21)
    return {"w": w, "d": d, "h": h}


# ======================================================================
# 14. generator_unit_A — heavy machine, not a box with a grille
# ======================================================================
def generator_unit_A(sc, cv, x, yf, seed=0, h=36, d=40):
    w = 56
    cast_shadow_ground(sc, cv, x, yf, w, h, d)
    yb = sc.sy(yf, 0)
    # skids + deep underside shadow
    for (sx0, sx1) in ((6, 14), (42, 50)):
        r = sc.front_rect(x + sx0, yf, sx1 - sx0, 0, 4)
        rubber(cv, *r, seed=seed + sx0)
        cv.hline(r[0], r[2], r[1], col("RUBBER", 3))
    contact_shadow(cv, sc.sx(x + 4), sc.sx(x + 52), yb + 1, rows=3,
                   jitter_seed=seed)
    cv.hline(sc.sx(x + 14), sc.sx(x + 42), yb, col("DARK", 0))   # between skids
    # housing
    hf = sc.front_rect(x + 2, yf, 52, 4, 32)
    ht = sc.top_rect(x + 2, yf, 52, d, 32)
    raw_metal(cv, *hf, seed=seed + 1, ramp="SLATE", mid=2, cell=6)
    concrete(cv, *ht, seed=seed + 2, mid=3)
    cv.hline(hf[0], hf[2], hf[1], col("SLATE", 4))
    cv.vline(hf[0], hf[1], hf[3], col("SLATE", 4))
    cv.vline(hf[2], hf[1], hf[3], col("SLATE", 0))
    cv.vline(hf[2] + 1, hf[1] + 1, hf[3] + 1, col("DARK", 0))
    # hex grille vent (left)
    cv.rect(hf[0] + 3, hf[1] + 4, hf[0] + 23, hf[3] - 4, col("GUN", 1))
    hex_grille(cv, hf[0] + 4, hf[1] + 5, hf[0] + 22, hf[3] - 5)
    cv.hline(hf[0] + 3, hf[0] + 23, hf[1] + 4, col("DARK", 0))
    cv.vline(hf[0] + 3, hf[1] + 4, hf[3] - 4, col("DARK", 0))
    cv.hline(hf[0] + 3, hf[0] + 23, hf[3] - 3, col("SLATE", 3))
    # maintenance panel with latch + worn warning patch
    chamfer_panel(cv, hf[0] + 26, hf[1] + 4, hf[0] + 42, hf[3] - 6, 2,
                  lambda c, a, b, cc, dd: raw_metal(c, a, b, cc, dd,
                                                    seed=seed + 3, ramp="SLATE",
                                                    mid=2),
                  seed=seed + 3, frame_ramp="SLATE", frame_mid=2, depth=2)
    cv.rect(hf[0] + 40, (hf[1] + hf[3]) // 2 - 2, hf[0] + 41,
            (hf[1] + hf[3]) // 2 + 1, col("SLATE", 5))
    warning_patch(cv, hf[0] + 28, hf[1] + 7, hf[0] + 36, hf[1] + 10,
                  seed=seed + 4, wear=0.45)
    # control strip (right): screen + LEDs
    cx = hf[2] - 8
    cv.rect(cx, hf[1] + 6, cx + 5, hf[3] - 6, col("GUN", 2))
    cv.hline(cx, cx + 5, hf[1] + 6, col("SLATE", 4))
    cv.rect(cx + 1, hf[1] + 8, cx + 4, hf[1] + 12, col("GLASS", 0))
    cv.set(cx + 2, hf[1] + 9, col("GLOW", 1))
    cv.set(cx + 3, hf[1] + 11, col("GLOW", 0))
    cv.set(cx + 2, hf[3] - 9, col("AMBER", 3))
    cv.set(cx + 4, hf[3] - 9, col("GLOW", 1))
    # top plates + oil cap
    cv.rect(ht[0] + 6, ht[1] + 4, ht[0] + 16, ht[1] + 10, col("SLATE", 3))
    cv.outline(ht[0] + 6, ht[1] + 4, ht[0] + 16, ht[1] + 10, col("SLATE", 4))
    cv.rect(ht[0] + 24, ht[1] + 12, ht[0] + 34, ht[1] + 20, col("SLATE", 2))
    cv.outline(ht[0] + 24, ht[1] + 12, ht[0] + 34, ht[1] + 20, col("SLATE", 4))
    cv.circle_fill(ht[0] + 44, ht[1] + 8, 2, col("GUN", 3))
    cv.set(ht[0] + 43, ht[1] + 7, col("SLATE", 5))
    # exhaust pipe top-right with soot
    px = sc.sx(x + 46)
    ytop = sc.sy(yf - 6, 40)
    ybase = sc.sy(yf - 6, 32)
    pipe_v(cv, px, ytop, ybase, 2, ramp="GUN", mid=3)
    cv.rect(px - 1, ytop - 1, px + 4, ytop, col("DARK", 0))
    soot(cv, px - 1, ytop - 3, px + 4, ytop - 2, seed + 21, amt=0.7)
    cv.vline(px + 5, ytop + 1, ybase + 1, col("DARK", 0))
    # power connection: ground box + cable swag into the housing
    bx = sc.front_rect(x - 6, yf + 4, 7, 0, 8)
    raw_metal(cv, *bx, seed=seed + 5, ramp="GUN", mid=2)
    cv.hline(bx[0], bx[2], bx[1], col("SLATE", 4))
    cv.set(bx[1] + 2, bx[1] + 3, col("AMBER", 3))
    cable_sag(cv, bx[2], bx[1] + 2, hf[0] + 1, hf[1] + 18, 4, seed=seed + 6,
              thick=2)
    # fuel cylinder + hose at right base
    fx = sc.sx(x + 54)
    fy0 = sc.sy(yf + 2, 6)
    fy1 = sc.sy(yf + 2, 0)
    pipe_v(cv, fx, fy0, fy1, 2, ramp="SLATE", mid=2)
    cv.rect(fx - 1, fy0 - 1, fx + 4, fy0, col("SLATE", 4))
    cable_sag(cv, fx, fy0 + 2, hf[2] - 1, hf[3] - 4, 2, seed=seed + 7)
    # worn amber corner stripe on the left post
    for yy in range(hf[1] + 2, hf[3] - 2):
        if h2(1, yy, seed + 8) > 0.25:
            cv.set(hf[0] + 1, yy, col("AMBER", 2 if yy % 4 < 2 else 1))
    # wear
    chip(cv, hf[0] + 24, hf[1] + 1, seed + 31)
    chip(cv, hf[2] - 3, hf[3] - 3, seed + 32)
    rust_weep(cv, hf[0] + 8, hf[3] - 2, 5, seed + 33)
    rust_weep(cv, fx + 1, fy1 - 4, 3, seed + 34)
    grime(cv, hf[0], hf[3] - 6, hf[2], hf[3], seed + 35, amt=0.55)
    dust_cap(cv, ht[0] + 2, ht[2] - 2, ht[1] + 1, seed + 36, amt=0.3)
    return {"w": w + 8, "d": d, "h": 40}


# ======================================================================
# 15. terminal_station_A — pedestal console
# ======================================================================
def terminal_station_A(sc, cv, x, yf, seed=0, h=30):
    w, d = 20, 16
    cast_shadow_ground(sc, cv, x, yf, w, h, d)
    yb = sc.sy(yf, 0)
    # base plate
    bf = sc.front_rect(x + 2, yf, 16, 0, 3)
    bt = sc.top_rect(x + 2, yf, 16, 10, 3)
    raw_metal(cv, *bf, seed=seed + 1, ramp="SLATE", mid=2)
    raw_metal(cv, *bt, seed=seed + 2, ramp="SLATE", mid=4)
    cv.hline(bt[0], bt[2], bt[3], col("SLATE", 5))
    contact_shadow(cv, bf[0], bf[2], yb + 1, rows=2, jitter_seed=seed)
    # pedestal column
    pf = sc.front_rect(x + 7, yf, 6, 3, 16)
    raw_metal(cv, *pf, seed=seed + 3, ramp="GUN", mid=2)
    cv.vline(pf[0], pf[1], pf[3], col("SLATE", 4))
    cv.vline(pf[2], pf[1], pf[3], col("GUN", 0))
    cv.vline(pf[2] + 1, pf[1] + 1, pf[3], col("DARK", 0))
    # cable gland + cable to the ground right
    cv.rect(pf[2] - 2, pf[3] - 3, pf[2], pf[3] - 1, col("RUBBER", 2))
    cable_sag(cv, pf[2], pf[3] - 2, pf[2] + 12, yb, 3, seed=seed + 4)
    # worn sticker on the pedestal
    cv.rect(pf[0] + 1, pf[1] + 4, pf[0] + 3, pf[1] + 6, col("TEAL", 3))
    cv.set(pf[0] + 3, pf[1] + 4, col("CREAM", 3))
    # console head with angled screen
    hf = sc.front_rect(x + 3, yf, 14, 16, 28)
    raw_metal(cv, *hf, seed=seed + 5, ramp="GUN", mid=3, cell=5)
    cv.chamfer_outline(hf[0], hf[1], hf[2], hf[3], 2, col("SLATE", 4))
    sx0, sy0, sx1, sy1 = hf[0] + 2, hf[1] + 3, hf[2] - 4, hf[1] + 10
    glass(cv, sx0, sy0, sx1, sy1, seed=seed + 6)
    for i, ln in enumerate((6, 4, 5)):
        cv.hline(sx0 + 1, sx0 + ln, sy0 + 2 + i * 2, col("SLATE", 3))
    cv.set(sx0 + 6, sy0 + 6, col("AMBER", 3))                  # cursor
    cv.hline(sx0, sx1, sy0 - 1, col("SLATE", 5))               # screen top light
    # keyboard shelf proud with key dots
    kf = sc.front_rect(x + 4, yf + 4, 12, 14, 16)
    kt = sc.top_rect(x + 4, yf + 4, 12, 5, 16)
    raw_metal(cv, *kf, seed=seed + 7, ramp="SLATE", mid=2)
    raw_metal(cv, *kt, seed=seed + 8, ramp="SLATE", mid=4)
    for kx in range(kt[0] + 1, kt[2], 2):
        cv.set(kx, kt[3] - 1, col("SLATE", 2))
        cv.set(kx + 1, kt[1] + 1, col("SLATE", 2))
    cv.hline(kf[0], kf[2], kf[3], col("GUN", 0))
    cv.vline(kf[2] + 1, kf[1] + 1, kf[3] + 1, col("DARK", 0))
    # LEDs on bezel right
    cv.set(hf[2] - 2, hf[1] + 5, col("GLOW", 1))
    cv.set(hf[2] - 2, hf[1] + 7, col("AMBER", 3))
    chip(cv, hf[0] + 1, hf[3] - 2, seed + 21)
    return {"w": w, "d": d, "h": h}


# ======================================================================
# 16. storage_module_A — industrial rack with containers
# ======================================================================
def storage_module_A(sc, cv, x, yf, seed=0, h=52, d=24):
    w = 48
    cast_shadow_ground(sc, cv, x, yf, w, h, d)
    yb = sc.sy(yf, 0)
    # back panel (dim) so open cells have depth
    bk = sc.front_rect(x + 2, yf - 6, 44, 0, h)
    paint_metal(cv, *bk, seed=seed + 1, ramp="GUN", mid=1, cell=8)
    # shelves
    for zz in (16, 32, 48):
        sf = sc.front_rect(x, yf, w, zz, zz + 2)
        st = sc.top_rect(x, yf, w, d, zz + 2)
        raw_metal(cv, *sf, seed=seed + 10 + zz, ramp="SLATE", mid=2)
        raw_metal(cv, *st, seed=seed + 20 + zz, ramp="SLATE", mid=3)
        cv.hline(st[0], st[2], st[3], col("SLATE", 4))
        cv.hline(sf[0], sf[2], sf[3], col("GUN", 0))
    # uprights (proud), one slightly bent
    for i, ux in enumerate((0, 22, 44)):
        uf = sc.front_rect(x + ux, yf + 2, 4, 0, h)
        raw_metal(cv, *uf, seed=seed + 30 + ux, ramp="GUN", mid=2, cell=4)
        cv.vline(uf[0], uf[1], uf[3], col("SLATE", 4))
        cv.vline(uf[2] + 1, uf[1] + 1, uf[3] + 1, col("DARK", 0))
        if i == 1:   # bent upright: 1px jog at mid height
            my = sc.sy(yf + 2, 30)
            cv.set(uf[0], my, col("SLATE", 4))
            cv.set(uf[2] + 1, my + 1, col("DARK", 0))
    # ---- contents ----
    def container(x0, z0, ww, hh, ramp, label):
        cf = sc.front_rect(x + x0, yf - 2, ww, z0, z0 + hh)
        ct = sc.top_rect(x + x0, yf - 2, ww, d - 6, z0 + hh)
        paint_metal(cv, *cf, seed=seed + 40 + x0, ramp=ramp, mid=3, cell=5)
        paint_metal(cv, *ct, seed=seed + 50 + x0, ramp=ramp, mid=4, cell=5)
        cv.hline(cf[0], cf[2], cf[1], col(ramp, 5))
        cv.hline(cf[0], cf[2], cf[1] + 2, col(ramp, 1))       # lid seam
        cv.vline(cf[2], cf[1], cf[3], col(ramp, 1))
        cv.vline(cf[2] + 1, cf[1] + 1, cf[3] + 1, col("DARK", 0))
        cv.rect(cf[0] + 2, cf[1] + 4, cf[0] + 5, cf[1] + 5, label)
        cv.hline(cf[0] + 1, cf[2] - 1, cf[3], col(ramp, 0))
        return cf

    container(6, 4, 10, 10, "TEAL", col("CREAM", 4))
    container(17, 4, 9, 10, "TEAL", col("AMBER", 2))
    # cream crate with stencil
    cc = container(6, 20, 12, 10, "CREAM", col("GUN", 2))
    stencil(cv, cc[0] + 3, cc[1] + 5, "B4", ramp="GUN", idx=3, wear=0.14,
            seed=seed + 60)
    # open cell: dark cavity with item silhouette + deep soffit
    ox0, oz0, ow, oh = 28, 20, 14, 10
    of = sc.front_rect(x + ox0, yf - 4, ow, oz0, oz0 + oh)
    cv.rect(of[0], of[1], of[2], of[3], col("DARK", 0))
    cv.rect(of[0] + 1, of[1] + 3, of[2] - 1, of[3] - 1, col("GUN", 0))
    cv.hline(of[0] + 1, of[2] - 1, of[1] + 1, col("DARK", 0))
    cv.hline(of[0] + 1, of[2] - 1, of[1] + 2, col("GUN", 0))
    cv.rect(of[0] + 3, of[3] - 5, of[0] + 7, of[3] - 2, col("SLATE", 2))  # item
    cv.set(of[0] + 4, of[3] - 6, col("SLATE", 3))
    cv.vline(of[2] + 1, of[1], of[3], col("SLATE", 3))
    # cable coil in top bay
    rcx, rcy = sc.sx(x + 12), sc.sy(yf - 2, 41)
    cv.ring(rcx, rcy, 4, col("RUBBER", 2), thick=2)
    cv.set(rcx - 2, rcy - 3, col("RUBBER", 3))
    cv.set(rcx + 3, rcy + 2, col("DARK", 0))
    container(28, 36, 10, 9, "TEAL", col("CREAM", 4))
    # top: extra container sitting on the rack top
    tc = container(8, 52, 12, 8, "TEAL", col("AMBER", 2))
    ct2 = sc.top_rect(x + 8, yf - 2, 12, d - 6, 60)
    cv.hline(ct2[0], ct2[2], ct2[3] + 1, col("DARK", 0))
    # rack top face band
    rt = sc.top_rect(x, yf, w, d, h)
    raw_metal(cv, *rt, seed=seed + 70, ramp="SLATE", mid=3)
    cv.hline(rt[0], rt[2], rt[3], col("SLATE", 4))
    dust_cap(cv, rt[0] + 2, rt[2] - 2, rt[1] + 1, seed + 71, amt=0.35)
    # feet + rust + grime
    contact_shadow(cv, sc.sx(x), sc.sx(x + w), yb + 1, rows=2, jitter_seed=seed)
    rust_weep(cv, sc.sx(x + 1), yb - 8, 6, seed + 81)
    rust_weep(cv, sc.sx(x + 45), yb - 6, 5, seed + 82)
    grime(cv, bk[0], bk[3] - 4, bk[2], bk[3], seed + 83, amt=0.5)
    return {"w": w, "d": d, "h": 60}
