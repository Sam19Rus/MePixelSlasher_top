"""
QA for the code-asset library:
  1. palette discipline   — every asset pixel belongs to the day palette
  2. alpha discipline     — fully opaque or fully transparent
  3. determinism          — double render is byte-identical (and matches disk)
  4. emissive budget      — GLOW core pixels per asset within budget
  5. tiling continuity    — wall_panel_A + wall_panel_B share a seamless bay
  6. projection sanity    — top-face compression == sin(36) on every asset
  7. building palettes    — day/dusk/night renders stay inside their profiles
Writes metadata/qa_results.json, exits non-zero on failure.
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from PIL import Image                                          # noqa: E402

from build_assets import ASSETS, ROOT, render_asset            # noqa: E402
from palettes.frontier_service import (RAMPS, PROFILES, LIGHT) # noqa: E402
from projection.tilted_ortho import Scene, VS                  # noqa: E402
from generators.architecture import wall_panel_A, wall_panel_B  # noqa: E402

DAY_SET = set(PROFILES["day"].values())
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append({"check": name, "ok": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + (f"  {detail}" if detail else ""))
    return ok


def px_iter(path):
    im = Image.open(path).convert("RGBA")
    return im, im.load()


def main():
    ok_all = True

    # 1+2+4 per asset
    emissive_budget = {"industrial_light_A": 8}
    for aid, cat, gen, kw, ctx in ASSETS:
        path = os.path.join(ROOT, "assets", cat, aid + ".png")
        im, px = px_iter(path)
        bad_pal = bad_alpha = 0
        glow = 0
        glow_set = {RAMPS["GLOW"][2], RAMPS["GLOW"][3]}
        for y in range(im.height):
            for x in range(im.width):
                r, g, b, a = px[x, y]
                if a == 0:
                    continue
                if a != 255:
                    bad_alpha += 1
                if (r, g, b) not in DAY_SET:
                    bad_pal += 1
                if (r, g, b) in glow_set:
                    glow += 1
        bud = emissive_budget.get(aid, 5)
        ok = bad_pal == 0 and bad_alpha == 0 and glow <= bud
        ok_all &= check(f"asset:{aid}", ok,
                        f"pal={bad_pal} alpha={bad_alpha} glow={glow}/{bud}")

    # 3 determinism (in-memory double render + disk match)
    for aid, cat, gen, kw, ctx in ASSETS:
        c1, _ = render_asset(aid)
        c2, _ = render_asset(aid)
        same = c1.g == c2.g
        im, px = px_iter(os.path.join(ROOT, "assets", cat, aid + ".png"))
        disk_ok = True
        for y in range(min(im.height, c1.h)):
            for x in range(min(im.width, c1.w)):
                r, g, b, a = px[x, y]
                cc = c1.get(x, y)
                if cc is None:
                    if a != 0:
                        disk_ok = False
                elif a == 0 or (r, g, b) != cc:
                    disk_ok = False
        ok_all &= check(f"determinism:{aid}", same and disk_ok)

    # 5 tiling continuity A|B
    LIGHT.set("day")
    sc = Scene(140, 60, ox=4, oy=52)
    wall_panel_A(sc, sc.cv, 0, 0, seed=3)
    wall_panel_B(sc, sc.cv, 64, 0, seed=4)
    gaps = 0
    fr = sc.front_rect(0, 0, 128, 0, 40)
    for y in range(fr[1] + 4, fr[3] - 3):
        for x in range(fr[0], fr[2] + 1):
            if sc.cv.get(x, y) is None:
                gaps += 1
    ok_all &= check("tiling:A|B seamless", gaps == 0, f"gaps={gaps}")

    # 6 projection sanity: top face rows == round(d*vs)
    sc = Scene(80, 80, ox=4, oy=70)
    tr = sc.top_rect(0, 0, 64, 16, 40)
    fr = sc.front_rect(0, 0, 64, 0, 40)
    exp_top = round(16 * VS)
    exp_face = round(40 * 0.809017)
    top_rows = tr[3] - tr[1] + 1
    face_rows = fr[3] - fr[1] + 1
    ok_all &= check("projection:foreshortening",
                    abs(top_rows - exp_top) <= 1 and face_rows == exp_face,
                    f"top={top_rows}/{exp_face and exp_top} face={face_rows}/{exp_face}")

    # 7 building profile palettes
    for name, prof in (("building_day.png", "day"),
                       ("building_dusk.png", "dusk"),
                       ("building_night.png", "night"),
                       ("building_variant_B.png", "day"),
                       ("scene_two_buildings.png", "day"),
                       ("scene_dusk.png", "dusk")):
        pset = set(PROFILES[prof].values())
        im, px = px_iter(os.path.join(ROOT, "preview", name))
        bad = 0
        for y in range(im.height):
            for x in range(im.width):
                r, g, b, a = px[x, y]
                if (r, g, b) not in pset:
                    bad += 1
        ok_all &= check(f"building:{name}:{prof}", bad == 0, f"off={bad}")

    with open(os.path.join(ROOT, "metadata", "qa_results.json"), "w") as f:
        json.dump({"all_ok": bool(ok_all), "results": RESULTS}, f, indent=2)
    print("\nQA ALL OK" if ok_all else "\nQA FAILURES PRESENT")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
