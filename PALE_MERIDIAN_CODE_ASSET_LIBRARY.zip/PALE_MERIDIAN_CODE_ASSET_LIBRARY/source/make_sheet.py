"""iteration contact sheet (work/sheet1.png) — 18 assets, 2x, labelled"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from build_assets import ASSETS, render_asset, ROOT            # noqa: E402
from common.canvas import Canvas                               # noqa: E402
from common.font import text                                   # noqa: E402
from palettes.frontier_service import col                      # noqa: E402

CW, CH, SCALE = 122, 142, 2
COLS = 6
ROWS = (len(ASSETS) + COLS - 1) // COLS
sheet = Canvas(COLS * CW * SCALE // 2 + 40, ROWS * CH + 40, bg=(26, 28, 34))
# note: cells at 1x placement, sheet saved at 2x

for i, (aid, cat, gen, kw, ctx) in enumerate(ASSETS):
    cv, info = render_asset(aid)
    cx = (i % COLS) * CW + 10
    cy = (i // COLS) * CH + 16
    # card
    sheet.rect(cx - 4, cy - 4, cx + CW - 14, cy + CH - 22, (38, 41, 48))
    # asset centered, bottom-aligned
    ax = cx + (CW - 20 - cv.w) // 2
    ay = cy + CH - 26 - cv.h
    for y in range(cv.h):
        for x in range(cv.w):
            c = cv.get(x, y)
            if c is not None:
                sheet.set(ax + x, ay + y, c)
    text(sheet, cx - 2, cy + CH - 18, aid, (196, 205, 214), scale=1)
    text(sheet, cx - 2, cy + CH - 12, f"{cv.w}x{cv.h}", (120, 128, 138), scale=1)

sheet.save(os.path.join(ROOT, "work", "sheet1.png"), scale=2)
print("sheet ok", sheet.w, sheet.h)
