# PALE MERIDIAN — Full Project Report (Stage 5: Scene 3 geometry correction + Character Showcase)

2D sci-fi action-RGP visual prototype. Three playable scenes share one pixel-art
pipeline, one palette and one projection abstraction:

| Key | Scene | Projection | Status |
|---|---|---|---|
| 1 | Frontier outpost (stage 1) | oblique 3/4 | approved reference, unchanged |
| 2 | Frontier complex K-7 | AXONOMETRIC / ISOMETRIC | full game scene |
| 3 | Frontier complex K-7 | TILTED ORTHOGRAPHIC TOP-DOWN | full game scene |

Switch: `1 / 2 / 3` or `TAB`. Review keys in every scene: `F1` HUD, `F2` lighting,
`F3` dusk/night/day, `F4` debug geometry. `E` = enter/exit building (same logical
Entrance entity in all scenes).

---

## Architecture

### Modules & responsibilities
```
src/
  rendering/   PixelSurface (the only raster), color, dither(Bayer), noise,
               projection (scene-1 oblique), detail (seams/vents/rust/cables),
               text (3x5 stencil), Renderer (scene-1 pipeline)
  lighting/    LightingSystem: ambient + additive lights, ray-marched lamp
               shadows, clip rects, rect-limited apply, static-light cache
  lab/         profiles (ProjectionProfile/Proj), kit (paintBox/windowOnFace/
               LocalProj/Mat), facePaint (face-local uv drawing),
               rig/robotRig (stage-2 versions), LabScene/LabRenderer/LabGame
               (dev-only six-panel bench, not in user flow)
  entities/    CompositeRig (part-sprite character), Mercenary+Robot (scene 1)
  scenes/      outpostKit2Parts (terrain/mesas/props/vehicle bakers),
               outpostKit2 (assembler: shells, cutaway, interiors, lights,
               colliders, depth), OutpostPlay (playable scene 2/3),
               registry (scene keys)
  world/       scene-1 exterior assembly
  assets/      scene-1 art bakers
  game/        scene-1 Game + Camera
  input/       Input (+synthetic keys for tests), sharedInput
  components/  GameCanvas (scene 1), PlayView (scenes 2/3), ReviewPanel
tools/         png encoder, render-shots (preview frames), smoke, bench
```

### Rendering architecture
Every scene renders into a 480×270 `PixelSurface` in software, then the React
view upscales with integer nearest-neighbour. Pipeline (scenes 2/3):
ground rows (typed-array copy) → baked sun-shadow layer (cutaway-aware) →
depth-sorted renderables (mode-filtered ext/int/both) → drone + composite
character → light accumulation (world-space lights, clipped to view) →
`apply()` multiply with dither → cached atmosphere (vignette + haze) →
prompt/debug/fade.

### Scene architecture
`OutpostPlay` is projection-agnostic: it receives a `SceneBake` from
`bakeOutpost2(new Proj(profile))`. Scene 2 = `SCENE2_AXON`, Scene 3 =
`SCENE3_TILTED`. Same world layout (`O2`, `O2_LAYOUT`, `O2_ROOMS`), same
gameplay code, same entrance logic.

## Projection

### Scene 2 — axonometric
Ground lattice rotated 45°: `g(x,y) = (x−y, (x+y)/2)`; heights extruded
vertically (`hz = 1`); two visible walls per mass (S + E); diamond roof planes;
2:1 stair-step edges. Parameters: `kx 1, ky 0.5, hz 1, side 1, wallScale 1`.

### Scene 3 — tilted orthographic top-down
Camera conceptually pitched ~15° and yawed ~10° about the roof-plane pivot.
Implemented as: ground squash 0.94 + shear 0.05 (ground stays gameplay-readable),
roof depth `ky 0.86` (roof keeps most of its area), wall extrusion
`hz 0.62` (walls read as vertical surfaces), east-face reveal `side 0.55`,
verticals kept pixel-vertical (no stair-stepped leaning edges).
Parameters: `kx 0.12, ky 0.86, hz 0.62, side 0.55, wallScale 0.62,
groundShear 0.05, groundSquash 0.94`.

### World → screen
`Proj.g/inv/lift/box/depth`; all bakers (terrain noise via `inv()`, masses,
decals, shadows, lights) go through it, so the two scenes differ only by the
profile. Face-local detail (windows, louvres, stencils) is drawn through face
uv vectors (`facePaint`), never by transforming bitmaps.

## Depth

`Proj.depth(x, y, baseZ, bias) = depthKey(anchor) + baseZ·0.02 + bias`,
`depthKey` = `x+y` (axon) or `y + 0.05x` (tilted) or `y` (axis).
Documented architectural biases (no per-object pixel offsets):
shellNW −0.4, partition −0.2, shellSE +0.4, shaft +0.5, roof +12 (anchored at
the NW corner so anything standing on the roof sorts after it), tower +20 with
`baseZ = hall height`. Renderables are mode-tagged (`ext` / `int` / `both`) and
sorted per frame by this single key.

## Character

`entities/CompositeRig.ts`: independent pixel-art part sprites — head, torso,
left/right arm, left/right leg, backpack, weapon — each with named anchors
(neck, shoulderNear/Far, hipNear/Far, packMount; arm: shoulder+hand; leg:
hip+foot; weapon: grip+hand2+muzzle). Equipment layers (helmet, shoulder
armour, torso plate, backpack) draw over the base body and change the
silhouette; swapping gear = swapping part sprites. Poses: idle (breath + look),
walk (4-phase independent limbs + torso bob + pack follow), aim (torso lean +
arm reposition + weapon follows hand anchor), turn (orientation swap with pivot
state). Orientations e/w (mirror)/s/n; diagonals reuse nearest cardinal by
design (architecture allows adding diagonal part sets later).

## Interior

One physical world. Cutaway on enter: roof + S/E shells hidden; N/W shells
swap to cut variants; furniture/partitions/shaft appear; terrain, mesas, props,
lights and world coordinates persist. Four connected rooms matching the
exterior masses: crew wing (bunks, lockers, mess table, personal items), ops
hall (consoles + monitors, holo table, armory rack, storage rack, crates),
power room (tanks, manifold with valves, control panel), garage bay
(maintenance pit with hazard lip, workbench + drone parts, tool cabinet,
shelves, spare tracks). Partitions carry door gaps; colliders match.

Projection-adapted cutaway (per §12/13): in axon the cut shells are wall rings
(top faces punched); in tilted, N–S geometry is edge-on, so cut shells become
floor-anchored wall bands + panel rows, partitions become thresholds with door
frame posts, and S/E stubs keep the room edge — no degenerate "blade"
geometry in either projection.

## Visual

Palette: single master palette (`data/palette.ts`) — muted sandy ochres, rust,
cream/dirty metal, dark teal glass, slate interiors, cyan + amber emissives.
Pixel pipeline: all art generated into `PixelSurface` by code; hard edges;
Bayer 2/4/8 dithering for ramps/shadows/falloffs; no AA, no blur, no resample.
Lighting: world-space `SceneLight` list per scene; ambient per time of day
(dusk/night/day); baked sun shadows per projection (`shadow` / `shadowCut`);
additive lamp stamps with shaped falloff; emissive cores stay crisp.

## Assets

Building: 4 masses (hall / crew wing / power tech / garage) + roof-penetrating
tech tower + canopy/stairs/rails + roof machinery (AC×2, vents, hatch, pipe
run, access box) + solar array + shutters + ribbon windows + signage +
extinguisher boxes + wall lamps. Environment: dune field with slope lighting +
wind streaks, compacted pad with deck plates/bolts/stencils/arrows, vehicle
tracks with berms + treads, footpaths + footprints, branching cracks, pebble
clusters, scrub, debris, oil stains, pipe trench, 7 rocks, 8 plants, 2
generators + transformer + insulators, 3 lamp posts, barrier, bench, dish,
water tank on legs, spool, sandbags, sign, cart, drums, 2 containers, crate
stacks, utility vehicle (tracks with hubs, chassis, olive bed + rails + strap,
cream cabin with glass, roof rack + crate, engine + exhaust, bumper + winch,
lights, antenna), drone (composite rig). Mesas: windowed ridge silhouettes with
strata, sun rim, haze and slope-limited profiles (no pixel spikes).

## QA

- `tsc --noEmit`: clean. `vite build`: success (299 kB js / 100 kB gzip).
- Smoke: scene 1 (walk/enter/exit/wander/presets/negative-dt), lab regression,
  scenes 2 & 3 full user flow (approach → E → enter → move inside → return →
  E → exit → aim → turn): all green, no exceptions.
- Bench (single core, Node): scene 2 ≈ 5.1 ms/frame (198 fps), scene 3 ≈
  5.5 ms/frame (182 fps); scene 1 ≈ 5.8 ms.
- Preview frames: `out/50..53-<scene>-*.png` (ext/int/char/vehicle),
  `out/70-compare-ext.png`, `out/71-compare-int.png` (Stage1/2/3 stacked),
  `out/62-rig2-sheet.png` (rig poses/orientations).

## Known issues / remaining limitations (honest)

1. Scene 3 interior reads flatter than Scene 2: tilted cutaway uses low bands
   instead of full walls (projection constraint). Compensated with floor
   cues + furniture + light pools, but vertical interior presence is weaker.
2. Composite rig orientations are 4 cardinals; diagonal movement reuses the
   nearest cardinal set (documented, extensible).
3. Drone and character are screen-aligned billboards; shadows follow the
   projection, bodies do not reorient to iso axes (accepted 2.5D convention).
4. Mesas remain simple haze silhouettes (background budget).
5. Scene 1 merc and scenes 2/3 composite rig are different characters by design
   (stage-1 sprite preserved; new rig is the going-forward system).
6. Interior furniture density is high but still below scene 1's hand-placed
   room in small-prop count (mugs/posters exist in wing only).
7. Partition door posts in tilted are 1-px billboards; readable at 1× but
   minimal.
8. No combat/inventory/quests/factions/saves/audio/open world — out of scope
   by design (visual foundation stage).

## Fixed during this stage

- Cut-shell top faces reading as roofs (ring punch for axon).
- Degenerate diagonal "blades" from edge-on wall top faces in tilted →
  floor-anchored wall bands / thresholds / posts.
- Mesa ridge pixel-spikes → slope-limited profiles.
- Tower south face near-black under dusk ambient → brightened rust ramp.
- Vehicle composition (engine box towering over bed, glass-dominated cabin) →
  recomposed with material separation.
- Holo table colliding with the technical shaft footprint → relocated; hall
  light pools re-aimed.
- `Digit1..6` collision between scene switching and scene-1 quality toggles
  (quality digits removed; F5 preset cycle kept).

## Ready for extension

- `ProjectionProfile/Proj`: new projections without touching bakers.
- Centralised `Proj.depth` + bias table: new architectural layers plug in.
- Mode-tagged renderables: reusable cutaway for any building.
- CompositeRig part/anchor/equipment system: gear swaps, diagonal sets,
  aim-direction sets, attachments.
- LightingSystem clip/rect/static cache: multi-room, multi-view.
- Scene registry + headless tools (shots/smoke/bench): CI-able QA.

---

---

## Stage 5 addendum — Scene 3 geometry correction & Character Showcase

### What was wrong
Scene 3 exterior read as disconnected roof slabs: wall screen height was
double-discounted (`wallScale` then `hz`), roof/wall edges did not share
geometry, and cutaway-oriented shells leaked thin bands into exterior views.

### Geometry fix (not parameter tweaking)
`Proj.tiltedBox()` now builds a physically coherent closed box: verticals stay
pixel-vertical; the roof is exactly the ground quad lifted by `H = h·hz`
(hz = sin of camera tilt); south/east/west walls are exact parallelograms
sharing edges with roof and ground; ground shear expresses yaw. K-7 exterior
masses are single CLOSED sprites (roof + walls + details); the cutaway swaps
each closed mass for an open variant (north + west walls, inner-face detail),
so exterior never shows interior and interior never floats.
Validated first on a simple reference building (`tools/refbuild.ts`,
`out/68-ref-*.png`): closed box, substantial near facade, aligned roof, no
interior leakage — in both Scene 3 and Scene 2 projections.

### Depth corrections
Tower (roof-standing mass) bias raised to keep it above the hall closed mass
in both projections; west back-face band drawn dark in tilted so masses sit
correctly from west/east cameras (`out/85-s3-*.png` multi-camera QA).

### Character Showcase (Part D)
`src/scenes/showcase.ts` + `ShowcaseView`: mercenary at 3x gameplay scale from
independent part sprites via `rigPlacements()` (anchors: neck, shoulders,
hands, hips, feet, pack mount, weapon grip, muzzle). States idle/walk/aim/turn
(auto or keys), equipment toggles change silhouette, debug mode shows part
bounds + anchor labels (`out/80..84-show-*.png`).

### QA performed
- Scene 3 exterior from 4 camera positions: closed shell, zero interior leak.
- Scene 3 interior cutaway: same world, rooms match exterior masses.
- Showcase large-scale: parts independently visible and animated.
- Smoke: scene1 + lab regression + scene2/3 flows + showcase construct: green.
- Bench: scene2 ~5.1 ms, scene3 ~6.2 ms/frame (single core).
- `tsc` clean, `vite build` ok.

### Remaining limitations (honest)
- Tilted west walls are back-facing; drawn as dark grounded bands (accepted
  orthographic convention, verified from multiple cameras).
- Showcase terrain is a simplified strip (review backdrop, not a play area).
- Rig orientations remain 4 cardinals (diagonals reuse nearest).

---

## Stage 4 addendum — 3D PIXEL ART CAMERA LAB (Scene 4)

### Purpose
Answer one question visually: can the environment be built as real 3D
geometry and rendered as high-quality pixel art with a freely controllable
camera, so the ideal gameplay angle can be found by moving the camera instead
of rebuilding 2D geometry?

### Technology
three.js r186 (WebGL2), real scene graph: displaced PlaneGeometry terrain with
vertex-colour material variation; building as footprint -> walls (real height
and thickness, named meshes incl. `roof`, `southWall` for future cutaway) ->
roof slab -> roof equipment (AC, vents, pipes, hatch, antenna, solar);
props as composed boxes/cylinders/dodecahedrons; vehicle group; character as
a camera-facing billboard textured from the 2D CompositeRig (orientation
swaps with camera azimuth quadrant).

### Pixel rendering method
Scene renders into a WebGLRenderTarget at internal resolution (480x270 default,
320x180, 240x135) with NearestFilter + DepthTexture; a post ShaderMaterial
applies linear->sRGB transfer, ordered-dither posterisation, depth-edge
outlines and vignette; the canvas is CSS-upscaled with nearest-neighbour
integer scale. No AA, no temporal smoothing.

### Camera system
CameraRig: yaw/pitch/distance/target + ortho scale or fov; orbit (drag),
zoom (wheel), pan (shift+drag / WASD), keyboard orbit (arrows); modes
orthographic / perspective (V); presets TOP-DOWN, TILTED ORTHO, STRONG 3/4,
SHALLOW 3/4, LOW, FREE (P cycle, R reset); C copies the exact config
(mode/yaw/pitch/distance/target/orthoScale|fov) for later reproduction.

### Lighting
Hemisphere + directional sun (BasicShadowMap for crisp pixel shadows) +
point lights (lamps, door, generator) + emissive quads (windows/door/beacon/
vents); day/dusk/night presets (F3); shadow toggle (F2), quality (F8).

### Results
Screenshots A-E from the SAME 3D scene by camera change only:
out/90-A.png (high top-down), 90-B (tilted ortho), 90-C (strong 3/4),
90-D (shallow 3/4), 90-E (low perspective); comparison sheet
out/91-camera-sheet.png; live HUD capture out/92-lab-hud.png; cutaway
inspection (roof + south wall hidden, interior visible from camera, H key):
out/94-cutaway.png.
Volume, occlusion and silhouettes stay correct while orbiting; bad angles
look bad, good angles (tilted ortho ~pitch 50-60 / yaw 30-40) read
immediately game-like.

### Performance
Headless SwiftShader (software GL): interactive at 480x270; on real GPU the
scene is trivial (<1k draw calls, one shadow map). Pixel post is a single
fullscreen pass at internal resolution.

### Limitations (honest)
- Character is a billboard proxy (orientation-swap), not 3D geometry.
- Materials are flat Lambert + post treatment; no PBR weathering yet.
- Terrain height variation is gentle dunes; no cliffs/erosion yet.
- Post outline uses depth edges only (no normal-based creases).
- Pixel palette is enforced by posterisation, not a true indexed palette LUT.

### Recommendation
Technically viable: real 3D + low-res pixel post gives controllable camera,
correct volume/occlusion from any angle, and preserves the PALE MERIDIAN
pixel language. The decisive factor for production is art pipeline cost
(texturing/authoring to keep the pixel look) rather than rendering feasibility.
Suggested next experiment (not started): index-palette LUT post pass and
pixel-stable texture atlases.

*Stopped here per stage directive. Scenes 1-3 untouched; no gameplay stage
started; awaiting visual review of Scene 4 camera comparisons.*
