# PALE MERIDIAN — stage 1: visual benchmark / style prototype

Небольшая законченная интерактивная сцена в стиле **detailed high-res pixel art**
(top-down / 3/4 sci-fi action RPG). Это **не игра и не vertical slice механик**:
это эталон визуального языка, по которому принимается решение о дальнейшем
направлении проекта.

Сцена: пыльный пограничный аванпост чужой планеты — одно детализированное
здание с входом и интерьером, площадка с техникой, наёмник, патрульный дрон,
локальное освещение и три режима времени суток.

---

## Текущий рабочий flow (Stage N3 — FINAL CAMERA)

| Клавиша | Сцена |
|---|---|
| `1` | **Scene 1** — исходный визуальный эталон (не изменяется) |
| `2` | **N2** — мир Scene 1 в tilted-orthographic проекции (этап N2) |
| `3` | **N3** — benchmark финальной камеры: CrossCode/UNSIGHTED-style
tilted orthographic top-down + лёгкий наклон стен 2° (RimWorld-style) |
| `TAB` | цикл по трём сценам |

N3 (in-game): `E` — cutaway (крыша + южный фасад скрываются, интерьер
остаётся в тех же мировых координатах), `[` / `]` — цикл кандидатов камеры
(42° / 36° / 50°; shipped = 36°), `F1` HUD, `F2` lighting, `F3` время суток.
Персонажи статичны (benchmark): один наёмник у здания, один внутри у верстака.

Модули N3: `src/n3/projection.ts` (чистая математика: sx = x,
sy = y·sin(pitch) − z·cos(pitch), нулевой shear, lean стен h·tan(2°)),
`src/n3/worldN3.ts` (terrain, здание hall+tower+garage+porch+module,
крыша с оборудованием, cutaway-интерьер, пропсы, свет, запечённые тени),
`src/n3/N3Scene.ts` (кадр: ground → тени → depth-sorted спрайты → пар →
персонажи → light pass → атмосфера).

Проверки этапа: `npx tsx tools/smoke-n3.ts` (bake+render всех камер, ext/int,
клавиатурные тумблеры), `npx tsx tools/shots-n3.ts` (кадры A/B/C, D ext,
E cutaway, night/day, zoom стены), `npx tsx tools/cmp-n3-sheet.ts`
(review-лист 3×2: кандидаты камеры + ext + cutaway + zoom),
`npx tsx tools/smoke.ts` (регрессия Scene 1), `npx tsx tools/shots-n2.ts`
(регрессия N2). Отчёт: `REPORT_N3.md`.

История (N1, N2, Scene 2/3, Showcase, 3D Camera Lab) хранится в git/архивах;
в рабочий flow входят только сцены 1/2/3.

---

## Запуск

```bash
npm install
npm run dev        # vite dev-сервер
npm run build      # typecheck + production build
npm run preview    # отдать собранный build
```

Логическое разрешение кадра — **480×270**. На экран оно выводится только
целочисленным масштабированием с nearest-neighbor (`image-rendering: pixelated`),
без сглаживания и без CSS-масштабирования арт-слоя.

## Управление

| Клавиши | Действие |
|---|---|
| `WASD` / стрелки | движение (8 направлений) |
| `Shift` | бег |
| `E` (или `Enter` / `Space`) | войти в модуль / выйти наружу |

## Режим STYLE REVIEW

Инструмент оценки visuals, не игровая фича. Работает и при скрытой панели.

| Клавиша | Действие |
|---|---|
| `F1` | скрыть/показать весь HUD (режим чистого кадра) |
| `F2` | включить/выключить световой проход (lighting on/off) |
| `F3` | время суток: `DUSK → NIGHT → DAY` |
| `F4` | debug-оверлей: коллайдеры, зона двери, радиусы источников света, сетка |

## СЦЕНЫ 2 и 3 (полноценные игровые сцены, этап 4)

Приложение больше не содержит тестовый шестипанельный экран. Доступны три
полноценные сцены одного мира:

| Клавиша | Сцена | Проекция |
|---|---|---|
| `1` | SCENE 1 | oblique 3/4 (утверждённый stage 1) |
| `2` | SCENE 2 | ISOMETRIC / AXONOMETRIC |
| `3` | SCENE 3 | TILTED ORTHOGRAPHIC TOP-DOWN |
| `TAB` | цикл по сценам | |

В сценах 2/3: `WASD` движение, `Shift` бег, `Space` aim (демонстрация рига),
`E` вход/выход через ту же логическую дверь (exterior ↔ interior, cutaway без
смены мира). Главный персонаж — составной риг (head/torso/arms/legs/pack/
weapon + слои экипировки) с позами idle/walk/aim/turn. Интерьер наследует
проекцию сцены и состоит из четырёх соединённых помещений (crew wing | ops
hall | power room | garage bay), соответствующих внешним объёмам.

### SCENE 4 — 3D PIXEL ART CAMERA LAB (`4`)

Экспериментальная лаборатория: **настоящая 3D-сцена** (three.js) рендерится в
низкое внутреннее разрешение (480×270 / 320×180 / 240×135) и выводится как
пиксель-арт (dither-квантизация, depth-outline, виньетка, nearest-neighbour
apскейл). Камера полностью свободная: orbit/zoom/pan, orthographic и
perspective, пресеты TOP-DOWN / TILTED ORTHO / STRONG 3/4 / SHALLOW 3/4 / LOW /
FREE.

Клавиши: `P` пресет · `R` reset · `V` ortho/persp · `C` копировать конфиг
камеры · `K` скачать comparison sheet (5 видов A–E) · стрелки orbit · `WASD`
pan · `-/=` zoom · `F1` HUD · `F2` тени · `F3` day/dusk/night · `F4` outline ·
`F5` internal res · `F6` dither · `F7` posterize · `F8` light quality.
Мышь: drag orbit, wheel zoom, shift+drag pan. `H` — cutaway (скрыть
крышу и южную стену холла для инспекции интерьера).

Скриншоты A–E и sheet: `out/90-A..E.png`, `out/91-camera-sheet.png`
(генерируются headless-Chromium: `node tools/shots3d.mjs` при запущенном
`vite preview`); cutaway-инспекция: `out/94-cutaway.png`.

### CHARACTER SHOWCASE (`5` или `TAB` до конца)

Отдельная review-страница композитного рига: персонаж в 3x от игрового
масштаба на terrain проекта; части (head/torso/arms/legs/pack/weapon + слои
экипировки) рендерятся независимыми спрайтами через якоря. Клавиши:
`1-4` состояния idle/walk/aim/turn, `0` auto-cycle, `Q W E R T` — тумблеры
helmet / shoulder / torso plate / backpack / weapon, `F4` — якоря и границы
частей, `F1` — чистый кадр.

Полный отчёт по архитектуре, проекциям, depth, ригу, интерьеру и QA — в
`REPORT.md`. Сравнительные кадры: `npx tsx tools/render-shots.ts compare` →
`out/70-compare-ext.png`, `out/71-compare-int.png`.

Review-клавиши в сценах 2/3: `F1` HUD, `F2` свет, `F3` dusk/night/day,
`F4` debug-геометрия (коллайдеры, зона двери, depth-маркеры).

Полный отчёт по архитектуре и сравнению проекций — в `REPORT.md`.
Превью кадров: `npx tsx tools/render-shots.ts scenes` → `out/50..53-*.png`.

## PROJECTION LAB (этап 2, dev-only)

Шестипанельный инструмент выведен из пользовательского flow и оставлен как dev-only (`tools/render-shots.ts lab`). Экран **960×540** с шестью панелями, каждая показывает **одну и ту же** маленькую локацию (здание с
интерьером, транспорт, дрон, составной персонаж, контейнеры, камни,
растительность, генератор, фонарь) в своей проекции. Переключение сцен — `TAB`.

| Панель | Проекция | Суть |
|---|---|---|
| A | PURE TOP-DOWN | план/крыши, контрольный вариант |
| B | LIGHT OBLIQUE | верх + низкая стена |
| C | STRONG 3/4 | крыша + фасад + боковая грань |
| D | ISOMETRIC / AXON | ромб 2:1, две стены |
| E | FREE 2.5D | плоский геймплейный пол, высокие объёмы |
| F | DEEP 2.5D | максимальная высота фасадов |

Управление в лабе:

- hover мыши — focus-zoom панели (×2, nearest) с подписью и параметрами;
- клик / `1..6` — EXTERIOR ↔ INTERIOR конкретной панели;
- `F3` — то же для выбранной панели; `F1` — лейблы; `F2` — свет; `F4` — панель параметров проекции (angle / depth / v-height / roof vis / wall vis).

Технически: единый `ProjectionProfile` → `Proj` (world → screen), через него
пекутся **все** ассеты лаба (`src/lab/kit.ts`), поэтому панели отличаются
только проекцией, не ассетами. Интерьер — не отдельная сцена: это то же
физическое пространство, при входе скрываются крыша/южная и восточная стены
(cutaway), окружающийterrain и объекты остаются, внешний свет сохраняется.
Персонаж лаба — риг из частей (head/torso/arms/legs/pack/weapon с якорями и
позами idle/walk/aim/turn), дрон — составной (chassis/head/arm/thruster).
Одна мировая timeline синхронно двигает актёров во всех шести панелях.

Каждая панель изолирована в световом проходе (clip rect), стоимость лаба —
~16 ms/кадр (63 fps) на 6 панелей (`npm run bench`).

Первая сцена не изменялась: добавлены лишь неиспользуемые ею возможности
`LightingSystem` (clip/apply-rect/static-cache) и переключатель `TAB` в `App`.

## QUALITY / PERFORMANCE

Рендер программный (480×270, CPU), поэтому каждый проход имеет измеримую цену.
Баланс качество/производительность настраивается прямо в игре:

| Клавиша | Параметр |
|---|---|
| `F5` | цикл пресетов: `CINEMATIC → BALANCED → PERFORMANCE` |
| `1` | тени ламп (ray-marched occlusion у источников света) |
| `2` | солнечные тени (запечённый слой теней здания/камней/пропсов) |
| `3` | тени сущностей (кастомая маска под наёмником и дроном) |
| `4` | ambient FX (пар, пылинки, голо-шиммер, scanlines экранов) |
| `5` | атмосфера (виньетка + пыльная дымка) |
| `6` | бюджет источников света: `all → 14 → 8` |

Ручные тумблеры переводят пресет в `CUSTOM` (видно в панели). Измерения
(`npm run bench`, ms на кадр = update + полный software-рендер):

| Пресет | exterior | interior |
|---|---|---|
| CINEMATIC | ~5.8 ms (172 fps) | ~3.5 ms (283 fps) |
| BALANCED | ~5.5 ms (181 fps) | ~3.3 ms (302 fps) |
| PERFORMANCE | ~3.8 ms (266 fps) | ~2.7 ms (369 fps) |

Внутренние оптимизации, не влияющие на качество: row-wise копирование земли
typed-array'ами; кэш атмосферы (виньетка/дымка запекаются в alpha-surface и
стоят один blit за кадр); кэш статичных ламп интерьера (константные источники
пекутся в буфер один раз на зону/режим, т.к. камера интерьера неподвижна);
маски теней ламп считаются в ½ разрешения с prefilter коллайдеров по радиусу.

## Оффлайн-ревю (без браузера)

Рендерер полностью независим от DOM, поэтому тот же самый код прогоняется в
Node и складывает кадры в `/out` как PNG — это основной цикл правки арта:

```bash
npm run shots      # все превью: terrain, building, char, robot, scene
npx tsx tools/render-shots.ts scene    # только кадры сцены (dusk/night/day/nolight/interior/close)
npm run smoke      # headless-прогон: дойти до двери, войти, выйти, побродить (ловит runtime-ошибки)
npm run bench      # ms/кадр по пресетам качества (exterior + interior)
```

Полезные файлы в `out/`:
`10-scene-dusk`, `11-scene-night`, `12-scene-day`, `13-scene-nolight`,
`14-interior`, `15-scene-close`, `06-merc-sheet`, `07-robot-sheet`,
`04-building`, `01-terrain-world`.

---

## Художественное направление (зафиксировано)

- **Палитра** — один общий ограниченный набор рамп (`src/data/palette.ts`):
  приглушённый песочно-охристый грунт, ржавчина, dirty metal / cream для
  техники, dark teal стекло, slate для интерьеров; акценты — cyan и amber.
  Все спрайты берут цвета только отсюда, поэтому сцена читается как один мир.
- **Перспектива** — oblique 3/4, не изометрия: земля = мировая плоскость,
  высота экструзируется вверх экрана, глубина сдвинута вдоль вектора
  `PROJ = {kx: 0.34, ky: 0.6}` (`src/rendering/projection.ts`). У каждого
  объёма видны передняя, верхняя и восточная (теневая) грани + rim-light.
- **Pixel art first** — весь арт рисуется попиксельно в программный буфер
  `PixelSurface` (Uint32): никакого canvas-AA, никакого «вектор + пикселизация».
  Мягкие переходы делаются ordered-dithering (Bayer 2/4/8), тени и световые
  пятна — дизерными краями, а не blur.
- **Свет** — поверх запечённой ручной светотени спрайтов работает современный
  проход (`src/lighting/LightingSystem.ts`): ambient по времени суток +
  аддитивные источники с формованным falloff + ray-marched тени от коллайдеров;
  результат умножается покадрово, поэтому пиксельные формы остаются жёсткими.
- **Композиция** — здание как фокус, площадка как midground, дюны/меса и
  остов корабля на горизонте как background, валуны по нижней кромке как
  foreground; свет ведёт взгляд к входу.

## Архитектура

```
src/
  assets/        запекание арта: terrain, architecture, props, character,
                 robot, weapon, interior  (чистые функции -> PixelSurface)
  animation/     Animator:helpers для циклов (фазы шага, bob, blink, flicker)
  components/    GameCanvas (blit + integer scale), ReviewPanel (style review)
  data/          config (разрешения/проекция/солнце), layout (раскладка сцены),
                 palette (мастер-палитра)
  entities/      Mercenary (движение/коллизии/цикл шага), Robot (патруль/hover)
  game/          Game (оркестратор зон и review-состояния), Camera
  input/         Input (клавиатура + синтетические клавиши для тестов)
  lighting/      LightingSystem (ambient + additive lights + shadow march)
  rendering/     PixelSurface (растр), color, dither, noise, projection,
                 detail (панели/заклёпки/вент/кабели/ржавчина), text (3x5 шрифт),
                 Renderer (пайплайн кадра)
  world/         ExteriorScene (сборка экстерьера: тени, пропсы, свет, динамика)
tools/           png-энкодер, render-shots (оффлайн-кадры), smoke (функц. тест)
```

Пайплайн кадра: ground → запечённые солнечные тени → depth-sorted спрайты →
динамические оверлеи (пар, вентилятор, экраны, голограмма, пылинки) →
световой проход → атмосфера (виньетка, пыльная дымка) → fade зон → debug.

## Что сознательно НЕ сделано (scope freeze этапа 1)

Боевая система, инвентарь, квесты, прогрессия, процедурная генерация мира,
фракции, компаньоны, вторая и последующие локации, диалоги, сохранения,
звук, UI-системы вне review-панели. Карта намеренно мала (780×580 экстерьер,
480×270 интерьер) — качество важнее размера.

## Статус

Этап 1 завершён и остановлен до визуального review. Следующий этап
определяется отдельно после правок стиля.
