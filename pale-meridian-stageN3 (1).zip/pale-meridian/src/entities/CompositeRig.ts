import { Color } from '../rendering/color';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, metal, olive, signal, slate, warm } from '../data/palette';

/**
 * COMPOSITE CHARACTER RIG v2.
 *
 * Every part is an independent pixel-art asset with its own silhouette and
 * detail pass, joined by named anchors:
 *
 *   torso  : neck, shoulderNear, shoulderFar, hipNear, hipFar, packMount
 *   head   : neck            arm: shoulder, hand
 *   leg    : hip, foot       weapon: grip, hand2, muzzle
 *   pack   : mount
 *
 * Equipment (helmet, shoulder armour, torso plate, backpack, boots) is layered
 * on top of the base body, so swapping gear changes the silhouette — the rig
 * is designed for GENERATED CHARACTER = BASE BODY + EQUIPMENT + WEAPON.
 *
 * Orientations: 'e' (side, mirrored for 'w'), 's' (front), 'n' (back).
 */

export type Orient2 = 'e' | 'w' | 's' | 'n';
export type RigState2 = 'idle' | 'walk' | 'aim' | 'turn';

export interface RigPose2 {
  state: RigState2;
  phase: number; // 0..3
  orient: Orient2;
  breath: number; // 0|1
  look: number; // -1|0|1
}

export interface Equipment {
  helmet: boolean;
  shoulderArmor: boolean;
  torsoPlate: boolean;
  backpack: boolean;
  weapon: boolean;
}
export const FULL_KIT: Equipment = { helmet: true, shoulderArmor: true, torsoPlate: true, backpack: true, weapon: true };

const P: Record<string, Color> = {
  // suit / skin
  s: slate.s3,
  S: slate.s5,
  t: slate.s7,
  d: slate.s2,
  k: warm.w1, // gloves / boot soles
  K: warm.w3,
  // armour (cream dirty metal)
  a: metal.m8,
  A: metal.m6,
  b: metal.m4,
  B: metal.m2,
  // webbing / pack
  w: olive.o3,
  W: olive.o1,
  p: olive.o2,
  P: olive.o4,
  // visor / lamps
  v: cyan.c2,
  V: cyan.c5,
  c: cyan.c3,
  o: amber.a4,
  r: signal.s3,
  // weapon
  q: warm.w2,
  Q: warm.w5,
  x: warm.w0,
  y: cyan.c4,
  m: warm.w1,
  // helmet shell
  H: metal.m6,
  h: metal.m8,
  g: metal.m4,
  G: metal.m3,
};

interface Part {
  map: string[];
  /** local anchor points by name */
  anchors: Record<string, [number, number]>;
}

const part = (map: string[], anchors: Record<string, [number, number]>): Part => ({ map, anchors });

// ---------------------------------------------------------------- torso sets
const TORSO_SIDE = part(
  [
    '...SSss.....',
    '..SSssss....',
    '..Sssssd....',
    '..Sssssd....',
    '..Sssssd....',
    '..Sssssd....',
    '..wwwwww....',
    '..wWWWWw....',
    '..s.ss.s....',
    '..s.ss.s....',
  ],
  { neck: [5, 0], shoulderNear: [6, 2], shoulderFar: [3, 2], hipNear: [6, 8], hipFar: [3, 8], packMount: [2, 2] },
);
const TORSO_SIDE_PLATE = part(
  [
    '............',
    '..Aaaab.....',
    '..Aaaab.....',
    '..Abbbb.....',
    '..Abbbb.....',
    '..bbbbB.....',
    '............',
    '............',
    '............',
    '............',
  ],
  {},
);
const TORSO_FRONT = part(
  [
    '...SSss...',
    '..SSssss..',
    '..Ssssss..',
    '..Ssssss..',
    '..Ssssss..',
    '..Ssssss..',
    '..wwwwww..',
    '..wWWWWw..',
    '..s.ss.s..',
    '..s.ss.s..',
  ],
  { neck: [5, 0], shoulderL: [2, 2], shoulderR: [7, 2], hipL: [3, 8], hipR: [6, 8], packMount: [5, 2] },
);
const TORSO_FRONT_PLATE = part(
  [
    '..........',
    '.Aaaaab...',
    '.Aacccb...',
    '.Abbbbb...',
    '.Abbbbb...',
    '.bbbbbB...',
    '..........',
    '..........',
    '..........',
    '..........',
  ],
  {},
);
const TORSO_BACK = part(
  [
    '...SSss...',
    '..SSssss..',
    '..Ssssss..',
    '..Ssssss..',
    '..Ssssss..',
    '..Ssssss..',
    '..wwwwww..',
    '..wWWWWw..',
    '..s.ss.s..',
    '..s.ss.s..',
  ],
  { neck: [5, 0], shoulderL: [2, 2], shoulderR: [7, 2], hipL: [3, 8], hipR: [6, 8], packMount: [5, 1] },
);

// ---------------------------------------------------------------- heads
const HEAD_SIDE = part(
  [
    '...ggg....',
    '..ggggg...',
    '..gvvvv...',
    '..gVVvv...',
    '..ggggg...',
    '..GggG....',
    '...ss.....',
  ],
  { neck: [4, 6] },
);
const HEAD_FRONT = part(
  [
    '..gggg....',
    '.ggggg....',
    '.gvvvv....',
    '.gVVvv....',
    '.ggggg....',
    '.GgggG....',
    '..ss......',
  ],
  { neck: [3, 6] },
);
const HEAD_BACK = part(
  [
    '..gggg....',
    '.ggggg....',
    '.ggggg....',
    '.ggggg....',
    '.ggggg....',
    '.GgggG....',
    '..ss......',
  ],
  { neck: [3, 6] },
);
const HELMET_SIDE = part(
  [
    '..hhhh....',
    '.hHHHHh...',
    '.HggggG...',
    '.HggggG...',
    '..GGGG....',
    '..o..g....',
  ],
  { neck: [4, 5] },
);
const HELMET_BACK = part(
  [
    '.hhhh.....',
    'hHHHHh....',
    'HggggG....',
    'HggggG....',
    '.GGGG.....',
    '.g..g.....',
  ],
  { neck: [3, 5] },
);
const HELMET_FRONT = part(
  [
    '.hhhh.....',
    'hHHHHh....',
    'HggggG....',
    'HggggG....',
    '.GGGG.....',
    '.o..o.....',
  ],
  { neck: [3, 5] },
);
const SHOULDER_SIDE = part(
  [
    '.aaa.',
    'AaaaB',
    'AbbbB',
    '.BBB.',
  ],
  { shoulder: [2, 1] },
);
const SHOULDER_FRONT = part(
  [
    'aaa.',
    'aaaB',
    'bbbB',
    'BBB.',
  ],
  { shoulder: [1, 1] },
);

// ---------------------------------------------------------------- packs
const PACK_SIDE = part(
  [
    '.pPPp.',
    'pPPPPp',
    'pPppPp',
    'pppppp',
    'wPppPw',
    'wWWWWw',
    '.pppp.',
    '.kooK.',
  ],
  { mount: [5, 1] },
);
const PACK_BACK = part(
  [
    '.pPPPPp.',
    'pPPPPPPp',
    'pPpPPpPp',
    'pppppppp',
    'wPpPPpPw',
    'wWWWWWWw',
    '.pppppp.',
    '.ko..ok.',
  ],
  { mount: [4, 1] },
);

// ---------------------------------------------------------------- arms
const ARM_SIDE_DOWN = part(
  [
    '.S.',
    '.S.',
    '.s.',
    '.s.',
    '.s.',
    '.K.',
    '.K.',
  ],
  { shoulder: [1, 0], hand: [1, 5] },
);
const ARM_SIDE_SWING_A = part(
  [
    '.S.',
    '.S.',
    '..s',
    '..s',
    '..s',
    '..K',
    '..K',
  ],
  { shoulder: [1, 0], hand: [2, 5] },
);
const ARM_SIDE_SWING_B = part(
  [
    '.S.',
    '.S.',
    's..',
    's..',
    's..',
    'K..',
    'K..',
  ],
  { shoulder: [1, 0], hand: [0, 5] },
);
const ARM_SIDE_AIM = part(
  [
    '.......',
    'SSKKKK.',
    '.......',
    '.......',
  ],
  { shoulder: [1, 1], hand: [5, 1] },
);
const ARM_FRONT_DOWN = part(
  [
    'S.',
    'S.',
    's.',
    's.',
    's.',
    'K.',
    'K.',
  ],
  { shoulder: [0, 0], hand: [0, 5] },
);
const ARM_FRONT_SWING_A = part(
  [
    'S.',
    'S.',
    '.s',
    '.s',
    '.s',
    '.K',
    '.K',
  ],
  { shoulder: [0, 0], hand: [1, 5] },
);
const ARM_FRONT_SWING_B = part(
  [
    '.S',
    '.S',
    's.',
    's.',
    's.',
    'K.',
    'K.',
  ],
  { shoulder: [1, 0], hand: [0, 5] },
);
const ARM_FRONT_AIM_L = part(
  [
    'SS.',
    '.sK',
    '...',
  ],
  { shoulder: [0, 0], hand: [2, 1] },
);
const ARM_FRONT_AIM_R = part(
  [
    '.SS',
    'Ks.',
    '...',
  ],
  { shoulder: [2, 0], hand: [0, 1] },
);

// ---------------------------------------------------------------- legs
const LEG_SIDE_STAND = part(
  [
    '.SS',
    '.Ss',
    '.ss',
    '.bb',
    '.ss',
    '.ss',
    '.KK',
    'Kkk',
    'kkk',
  ],
  { hip: [1, 0], foot: [1, 8] },
);
const LEG_SIDE_W0 = part(
  [
    '.SS',
    '.Ss',
    '..ss',
    '..bb',
    '..ss',
    '..ss',
    '..KK',
    '.Kkk',
    '.kkk',
  ],
  { hip: [1, 0], foot: [2, 8] },
);
const LEG_SIDE_W1 = part(
  [
    '.SS',
    '.Ss',
    '.ss',
    '.bb',
    '.ss',
    '.KK',
    '.Kk',
    'kk.',
    '...',
  ],
  { hip: [1, 0], foot: [1, 7] },
);
const LEG_SIDE_W2 = part(
  [
    'SS.',
    'Ss.',
    'ss.',
    'bb.',
    'ss.',
    'ss.',
    'KK.',
    'kkK',
    'kkk',
  ],
  { hip: [1, 0], foot: [1, 8] },
);
const LEG_FRONT_STAND = part(
  [
    'SS',
    'Ss',
    'ss',
    'bb',
    'ss',
    'ss',
    'KK',
    'kk',
    'kk',
  ],
  { hip: [1, 0], foot: [1, 8] },
);
const LEG_FRONT_W0 = part(
  [
    'SS',
    'Ss',
    '.ss',
    '.bb',
    '.ss',
    '.ss',
    '.KK',
    '.kk',
    '.kk',
  ],
  { hip: [1, 0], foot: [1, 8] },
);
const LEG_FRONT_W1 = part(
  [
    'SS',
    'Ss',
    'ss',
    'bb',
    'ss',
    'KK',
    'Kk',
    'kk',
    '..',
  ],
  { hip: [1, 0], foot: [1, 7] },
);

// ---------------------------------------------------------------- weapons
const WEAPON_SIDE = part(
  [
    '..QQQQQ.......',
    'xxqqqqqqqqxx..',
    'xKqqyyqqqqqQy.',
    '..qqqqqqqqx...',
    '...q.mm.q.....',
    '.....mm.......',
  ],
  { grip: [3, 2], hand2: [9, 2], muzzle: [13, 2] },
);
const WEAPON_FRONT = part(
  [
    '.QQQQQQQQ.',
    'KqqyyqqqQK',
    '.qqqqqqqq.',
    '..mm..mm..',
  ],
  { grip: [3, 1], hand2: [8, 1], muzzle: [9, 1] },
);

// ---------------------------------------------------------------- assembly
export interface RigPlacement {
  name: string;
  map: string[];
  x: number;
  y: number;
  flip: boolean;
}
export interface RigLayout {
  placements: RigPlacement[];
  anchors: Record<string, [number, number]>;
  /** body top (head top) and feet, rig-local */
  top: number;
}

/**
 * Compute the independent part placements for a pose. Parts are separate
 * pixel-art assets joined by explicit anchors; nothing is sliced from a
 * finished full-body sprite.
 */
export function rigPlacements(pose: RigPose2, eq: Equipment): { list: RigPlacement[]; anchors: Record<string, [number, number]>; top: number } {
  const flip = pose.orient === 'w';
  const side = pose.orient === 'e' || pose.orient === 'w';
  const back = pose.orient === 'n';
  const bob = pose.state === 'walk' ? (pose.phase === 1 || pose.phase === 3 ? 0 : 1) : pose.breath;
  const lean = pose.state === 'aim' ? (flip ? -1 : 1) : 0;
  const hipY = -10 + bob;
  const torsoY = hipY - 8;
  const ph = pose.phase;
  const list: RigPlacement[] = [];
  const anchors: Record<string, [number, number]> = {};

  const torso = side ? TORSO_SIDE : back ? TORSO_BACK : TORSO_FRONT;
  const torsoX = -5 + lean;
  const at = (p: Part, name: string, x: number, y: number, f: boolean): [number, number] => {
    const w = Math.max(...p.map.map((r) => r.length));
    const px = x + (f ? w - 1 - p.anchors[name][0] : p.anchors[name][0]);
    const py = y + p.anchors[name][1];
    return [px, py];
  };

  // legs
  if (side) {
    const backLeg = pose.state === 'walk' ? [LEG_SIDE_W2, LEG_SIDE_W1, LEG_SIDE_W0, LEG_SIDE_W1][ph] : LEG_SIDE_STAND;
    const frontLeg = pose.state === 'walk' ? [LEG_SIDE_W0, LEG_SIDE_W1, LEG_SIDE_W2, LEG_SIDE_W1][ph] : LEG_SIDE_STAND;
    const hipF = at(torso, 'hipFar', torsoX, torsoY, flip);
    const hipN = at(torso, 'hipNear', torsoX, torsoY, flip);
    list.push({ name: 'legL', map: backLeg.map, x: hipF[0] - backLeg.anchors.hip[0], y: hipF[1] - backLeg.anchors.hip[1], flip });
    list.push({ name: 'legR', map: frontLeg.map, x: hipN[0] - frontLeg.anchors.hip[0], y: hipN[1] - frontLeg.anchors.hip[1], flip });
    anchors.footL = [list[list.length - 2].x + 1, list[list.length - 2].y + 8];
    anchors.footR = [list[list.length - 1].x + 1, list[list.length - 1].y + 8];
  } else {
    const legL = pose.state === 'walk' ? [LEG_FRONT_W0, LEG_FRONT_W1, LEG_FRONT_STAND, LEG_FRONT_W1][ph] : LEG_FRONT_STAND;
    const legR = pose.state === 'walk' ? [LEG_FRONT_STAND, LEG_FRONT_W1, LEG_FRONT_W0, LEG_FRONT_W1][ph] : LEG_FRONT_STAND;
    const hipL = at(torso, 'hipL', torsoX, torsoY, false);
    const hipR = at(torso, 'hipR', torsoX, torsoY, false);
    list.push({ name: 'legL', map: legL.map, x: hipL[0] - legL.anchors.hip[0], y: hipL[1] - legL.anchors.hip[1], flip: false });
    list.push({ name: 'legR', map: legR.map, x: hipR[0] - legR.anchors.hip[0], y: hipR[1] - legR.anchors.hip[1], flip: false });
    anchors.footL = [list[list.length - 2].x + 1, list[list.length - 2].y + 8];
    anchors.footR = [list[list.length - 1].x + 1, list[list.length - 1].y + 8];
  }
  anchors.hipL = [torsoX + 3, hipY];
  anchors.hipR = [torsoX + 6, hipY];

  // far arm
  if (side) {
    const farArm = pose.state === 'walk' ? [ARM_SIDE_SWING_A, ARM_SIDE_DOWN, ARM_SIDE_SWING_B, ARM_SIDE_DOWN][ph] : ARM_SIDE_DOWN;
    const sh = at(torso, 'shoulderFar', torsoX, torsoY, flip);
    list.push({ name: 'armFar', map: farArm.map, x: sh[0] - (flip ? farArm.map[0].length - 1 - farArm.anchors.shoulder[0] : farArm.anchors.shoulder[0]), y: sh[1] - farArm.anchors.shoulder[1], flip });
  } else if (!back) {
    const sh = at(torso, 'shoulderL', torsoX, torsoY, false);
    const arm = pose.state === 'walk' ? ARM_FRONT_SWING_A : ARM_FRONT_DOWN;
    list.push({ name: 'armL', map: arm.map, x: sh[0] - arm.anchors.shoulder[0], y: sh[1] - arm.anchors.shoulder[1], flip: false });
  } else {
    const sh = at(torso, 'shoulderL', torsoX, torsoY, false);
    list.push({ name: 'armL', map: ARM_FRONT_DOWN.map, x: sh[0], y: sh[1], flip: false });
  }

  // backpack behind torso (side/front)
  if (eq.backpack && !back) {
    const pm = at(torso, 'packMount', torsoX, torsoY, flip);
    const pk = side ? PACK_SIDE : PACK_BACK;
    list.push({ name: 'backpack', map: pk.map, x: pm[0] - (flip ? pk.map[0].length - 1 - pk.anchors.mount[0] : pk.anchors.mount[0]), y: pm[1] - pk.anchors.mount[1], flip });
    anchors.packMount = pm;
  }

  // torso + equipment plates
  list.push({ name: 'torso', map: torso.map, x: torsoX, y: torsoY, flip });
  anchors.neck = at(torso, 'neck', torsoX, torsoY, flip);
  if (side) {
    anchors.shoulderNear = at(torso, 'shoulderNear', torsoX, torsoY, flip);
    anchors.shoulderFar = at(torso, 'shoulderFar', torsoX, torsoY, flip);
  } else {
    anchors.shoulderNear = at(torso, 'shoulderR', torsoX, torsoY, false);
    anchors.shoulderFar = at(torso, 'shoulderL', torsoX, torsoY, false);
  }
  if (eq.torsoPlate && !back) {
    const plate = side ? TORSO_SIDE_PLATE : TORSO_FRONT_PLATE;
    list.push({ name: 'torsoArmor', map: plate.map, x: torsoX, y: torsoY, flip });
  }
  if (eq.backpack && back) {
    const pm = at(torso, 'packMount', torsoX, torsoY, false);
    list.push({ name: 'backpack', map: PACK_BACK.map, x: pm[0] - PACK_BACK.anchors.mount[0], y: pm[1] - PACK_BACK.anchors.mount[1], flip: false });
  }
  if (eq.shoulderArmor) {
    if (side) {
      const sh = at(torso, 'shoulderNear', torsoX, torsoY, flip);
      list.push({ name: 'shoulderArmor', map: SHOULDER_SIDE.map, x: sh[0] - (flip ? 4 - SHOULDER_SIDE.anchors.shoulder[0] : SHOULDER_SIDE.anchors.shoulder[0]), y: sh[1] - SHOULDER_SIDE.anchors.shoulder[1], flip });
    } else {
      const shL = at(torso, 'shoulderL', torsoX, torsoY, false);
      const shR = at(torso, 'shoulderR', torsoX, torsoY, false);
      list.push({ name: 'shoulderArmorL', map: SHOULDER_FRONT.map, x: shL[0] - SHOULDER_FRONT.anchors.shoulder[0], y: shL[1] - SHOULDER_FRONT.anchors.shoulder[1], flip: true });
      list.push({ name: 'shoulderArmorR', map: SHOULDER_FRONT.map, x: shR[0] - SHOULDER_FRONT.anchors.shoulder[0], y: shR[1] - SHOULDER_FRONT.anchors.shoulder[1], flip: false });
    }
  }

  // head + helmet
  const head = side ? HEAD_SIDE : back ? HEAD_BACK : HEAD_FRONT;
  const lookX = side ? (flip ? -pose.look : pose.look) : pose.look;
  const headX = anchors.neck[0] - (flip ? head.map[0].length - 1 - head.anchors.neck[0] : head.anchors.neck[0]) + lookX;
  const headY = anchors.neck[1] - head.anchors.neck[1] - 1 + (pose.state === 'aim' ? 1 : 0);
  list.push({ name: 'head', map: head.map, x: headX, y: headY, flip });
  if (eq.helmet) {
    const helm = side ? HELMET_SIDE : back ? HELMET_BACK : HELMET_FRONT;
    list.push({ name: 'helmet', map: helm.map, x: headX, y: headY - 1, flip });
  }

  // near arm + weapon anchored to hands
  let muzzle: [number, number] = [0, -20];
  if (side) {
    if (pose.state === 'aim') {
      const sh = at(torso, 'shoulderNear', torsoX, torsoY, flip);
      const ax = sh[0] - (flip ? 6 - ARM_SIDE_AIM.anchors.shoulder[0] : ARM_SIDE_AIM.anchors.shoulder[0]);
      const ay = sh[1] - ARM_SIDE_AIM.anchors.shoulder[1];
      list.push({ name: 'armNear', map: ARM_SIDE_AIM.map, x: ax, y: ay, flip });
      const hand = at(ARM_SIDE_AIM, 'hand', ax, ay, flip);
      anchors.handNear = hand;
      if (eq.weapon) {
        const gx = hand[0] - (flip ? WEAPON_SIDE.map[0].length - 1 - WEAPON_SIDE.anchors.grip[0] : WEAPON_SIDE.anchors.grip[0]);
        const gy = hand[1] - WEAPON_SIDE.anchors.grip[1];
        list.push({ name: 'weapon', map: WEAPON_SIDE.map, x: gx, y: gy, flip });
        muzzle = at(WEAPON_SIDE, 'muzzle', gx, gy, flip);
        anchors.weaponGrip = [gx + WEAPON_SIDE.anchors.grip[0], gy + WEAPON_SIDE.anchors.grip[1]];
      }
    } else {
      const nearArm = pose.state === 'walk' ? [ARM_SIDE_SWING_B, ARM_SIDE_DOWN, ARM_SIDE_SWING_A, ARM_SIDE_DOWN][ph] : ARM_SIDE_DOWN;
      const sh = at(torso, 'shoulderNear', torsoX, torsoY, flip);
      const ax = sh[0] - (flip ? nearArm.map[0].length - 1 - nearArm.anchors.shoulder[0] : nearArm.anchors.shoulder[0]);
      const ay = sh[1] - nearArm.anchors.shoulder[1];
      list.push({ name: 'armNear', map: nearArm.map, x: ax, y: ay, flip });
      const hand = at(nearArm, 'hand', ax, ay, flip);
      anchors.handNear = hand;
      if (eq.weapon) {
        const gx = hand[0] - (flip ? WEAPON_SIDE.map[0].length - 1 - WEAPON_SIDE.anchors.grip[0] : WEAPON_SIDE.anchors.grip[0]) - (flip ? -2 : 2);
        const gy = hand[1] - WEAPON_SIDE.anchors.grip[1];
        list.push({ name: 'weapon', map: WEAPON_SIDE.map, x: gx, y: gy, flip });
        muzzle = at(WEAPON_SIDE, 'muzzle', gx, gy, flip);
        anchors.weaponGrip = [gx + WEAPON_SIDE.anchors.grip[0], gy + WEAPON_SIDE.anchors.grip[1]];
      }
    }
  } else {
    const shR = at(torso, 'shoulderR', torsoX, torsoY, false);
    if (pose.state === 'aim') {
      list.push({ name: 'armR', map: ARM_FRONT_AIM_R.map, x: shR[0] - ARM_FRONT_AIM_R.anchors.shoulder[0], y: shR[1] - ARM_FRONT_AIM_R.anchors.shoulder[1], flip: false });
      const shL = at(torso, 'shoulderL', torsoX, torsoY, false);
      list.push({ name: 'armL', map: ARM_FRONT_AIM_L.map, x: shL[0] - ARM_FRONT_AIM_L.anchors.shoulder[0], y: shL[1] - ARM_FRONT_AIM_L.anchors.shoulder[1], flip: false });
      if (eq.weapon) {
        const hx = torsoX + 5;
        const hy = torsoY + 4;
        const gx = hx - WEAPON_FRONT.anchors.grip[0];
        const gy = hy - WEAPON_FRONT.anchors.grip[1];
        list.push({ name: 'weapon', map: WEAPON_FRONT.map, x: gx, y: gy, flip: false });
        muzzle = at(WEAPON_FRONT, 'muzzle', gx, gy, false);
        anchors.handNear = [hx, hy];
        anchors.weaponGrip = [hx, hy];
      }
    } else {
      const arm = pose.state === 'walk' ? ARM_FRONT_SWING_B : ARM_FRONT_DOWN;
      const ax = shR[0] - arm.anchors.shoulder[0];
      const ay = shR[1] - arm.anchors.shoulder[1];
      list.push({ name: 'armR', map: arm.map, x: ax, y: ay, flip: false });
      const hand = at(arm, 'hand', ax, ay, false);
      anchors.handNear = hand;
      if (eq.weapon && !back) {
        const gx = hand[0] - WEAPON_FRONT.anchors.grip[0] + 1;
        const gy = hand[1] - WEAPON_FRONT.anchors.grip[1] + 2;
        list.push({ name: 'weapon', map: WEAPON_FRONT.map, x: gx, y: gy, flip: false });
        muzzle = at(WEAPON_FRONT, 'muzzle', gx, gy, false);
        anchors.weaponGrip = [gx + WEAPON_FRONT.anchors.grip[0], gy + WEAPON_FRONT.anchors.grip[1]];
      }
    }
  }
  anchors.muzzle = muzzle;
  return { list, anchors, top: headY - (eq.helmet ? 2 : 0) };
}

function drawPart(s: PixelSurface, p: Part, x: number, y: number, flip: boolean): void {
  const w = Math.max(...p.map.map((r) => r.length));
  for (let ry = 0; ry < p.map.length; ry++) {
    const row = p.map[ry];
    for (let rx = 0; rx < row.length; rx++) {
      const c = P[row[rx]];
      if (c === undefined) continue;
      s.set(Math.round(x) + (flip ? w - 1 - rx : rx), Math.round(y) + ry, c);
    }
  }
}

/** feet centre at (x, y); returns muzzle screen pos for light glints */
export function drawComposite(s: PixelSurface, x: number, y: number, pose: RigPose2, eq: Equipment): { muzzle: [number, number] } {
  const lay = rigPlacements(pose, eq);
  for (const pl of lay.list) {
    drawPart(s, { map: pl.map, anchors: {} }, x + pl.x, y + pl.y, pl.flip);
  }
  return { muzzle: [x + lay.anchors.muzzle[0], y + lay.anchors.muzzle[1]] };
}
