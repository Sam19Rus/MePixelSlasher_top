import { PixelSurface } from '../rendering/PixelSurface';
import { buildMerc, type Dir, type MercFrames } from '../assets/character';
import { packRGBA, withAlpha } from '../rendering/color';
import { PLAYER } from '../data/config';
import type { Rect } from '../data/layout';
import { SUN } from '../data/config';
import { breathe, stridePhase } from '../animation/Animator';

/** The player: a mercenary with 8-way movement and a 4-phase stride. */
export class Mercenary {
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  dir: Dir = 's';
  moving = false;
  private animT = 0;
  private frames: MercFrames;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.frames = buildMerc();
  }

  get radius(): number {
    return PLAYER.radius;
  }

  update(dt: number, axis: { x: number; y: number }, running: boolean, colliders: Rect[], bounds: Rect): void {
    const target = running ? PLAYER.runSpeed : PLAYER.walkSpeed;
    const ax = axis.x * target;
    const ay = axis.y * target;
    const accel = PLAYER.accel;
    // approach target velocity
    const dvx = ax - this.vx;
    const dvy = ay - this.vy;
    const dl = Math.hypot(dvx, dvy);
    const step = (dl === 0 ? 0 : Math.min(dl, accel * dt));
    if (dl > 0) {
      this.vx += (dvx / dl) * step;
      this.vy += (dvy / dl) * step;
    }
    this.moving = Math.hypot(this.vx, this.vy) > 6;

    // integrate with axis-separated collision
    const nx = this.x + this.vx * dt;
    if (!this.hits(nx, this.y, colliders, bounds)) this.x = nx;
    else this.vx = 0;
    const ny = this.y + this.vy * dt;
    if (!this.hits(this.x, ny, colliders, bounds)) this.y = ny;
    else this.vy = 0;

    if (this.moving) {
      if (Math.abs(this.vx) > Math.abs(this.vy)) this.dir = this.vx > 0 ? 'e' : 'w';
      else this.dir = this.vy > 0 ? 's' : 'n';
      this.animT += Math.max(0, dt) * (running ? 11 : 8);
    }
  }

  private hits(x: number, y: number, colliders: Rect[], bounds: Rect): boolean {
    const r = this.radius;
    if (x - r < bounds.x || x + r > bounds.x + bounds.w || y - r < bounds.y || y + r > bounds.y + bounds.h) return true;
    for (const c of colliders) {
      if (x + r > c.x && x - r < c.x + c.w && y + r > c.y && y - r < c.y + c.h) return true;
    }
    return false;
  }

  get phase(): number {
    return this.moving ? stridePhase(this.animT) : 0;
  }

  draw(s: PixelSurface, camX: number, camY: number, t: number, castShadow = true): void {
    const f = this.frames.frames[this.dir][this.phase];
    const bob = this.moving ? 0 : breathe(t);
    const sx = Math.round(this.x - camX) - this.frames.ax;
    const sy = Math.round(this.y - camY) - this.frames.ay + bob;
    // cast shadow (quality-gated) + always-on contact shadow
    if (castShadow) {
      s.castShadow(f, sx, sy + f.height - 1, SUN.dirX * 0.7, SUN.dirY * 0.7, 0.34, packRGBA(30, 17, 15, 120), 0.8);
    }
    s.contactShadow(Math.round(this.x - camX), Math.round(this.y - camY), 5, 2, packRGBA(25, 14, 12, 110), 0.9);
    s.blit(f, sx, sy);
  }

  /** tiny visor glint used by the light pass */
  get visorGlow(): { x: number; y: number } {
    return { x: this.x, y: this.y - 22 };
  }
}

export { withAlpha };
