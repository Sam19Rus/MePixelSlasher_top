import { PixelSurface } from '../rendering/PixelSurface';
import { buildRobot, type RobotFrames } from '../assets/robot';
import { packRGBA, withAlpha } from '../rendering/color';
import { SUN } from '../data/config';
import { cyan } from '../data/palette';
import { blink, cycle, hoverBob } from '../animation/Animator';

/**
 * Patrol drone. Hovers on a slow waypoint loop, bobs, sweeps its lens, and
 * turns to look at the player when they get close — small ambient life that
 * makes the outpost feel occupied.
 */
export class Robot {
  x: number;
  y: number;
  private waypoints: { x: number; y: number }[];
  private wp = 0;
  private frames: RobotFrames;
  private t = 0;
  facing: 1 | -1 = 1;
  alert = 0;

  constructor(waypoints: { x: number; y: number }[]) {
    this.waypoints = waypoints;
    this.x = waypoints[0].x;
    this.y = waypoints[0].y;
    this.frames = buildRobot();
  }

  get lens(): { x: number; y: number } {
    return { x: this.x + this.facing * 1, y: this.y - 11 };
  }
  get thruster(): { x: number; y: number } {
    return { x: this.x, y: this.y + 1 };
  }

  update(dt: number, player: { x: number; y: number }): void {
    this.t += Math.max(0, dt);
    const target = this.waypoints[this.wp];
    const dx = target.x - this.x;
    const dy = target.y - this.y;
    const d = Math.hypot(dx, dy);
    const near = Math.hypot(player.x - this.x, player.y - this.y);
    this.alert = near < 56 ? 1 : 0;

    if (this.alert === 0) {
      if (d < 4) this.wp = (this.wp + 1) % this.waypoints.length;
      else {
        const sp = 14;
        this.x += (dx / d) * sp * dt;
        this.y += (dy / d) * sp * dt;
        if (Math.abs(dx) > 2) this.facing = dx > 0 ? 1 : -1;
      }
    } else {
      // hold position, turn toward the player
      this.facing = player.x > this.x ? 1 : -1;
    }
  }

  draw(s: PixelSurface, camX: number, camY: number, castShadow = true): void {
    const bob = hoverBob(this.t);
    const f = this.frames.frames[cycle(this.t, 6, 4)];
    const sx = Math.round(this.x - camX) - this.frames.ax;
    const sy = Math.round(this.y - camY) - this.frames.ay + bob;
    // hover shadow shrinks as the drone rises
    const shr = 6 - bob;
    s.contactShadow(Math.round(this.x - camX) + 3, Math.round(this.y - camY) + 2, shr, Math.max(2, shr >> 1), packRGBA(25, 14, 12, 100), 0.85);
    if (castShadow) s.castShadow(f, sx, sy + f.height - 1, SUN.dirX * 0.5, SUN.dirY * 0.5, 0.2, packRGBA(28, 16, 14, 70), 0.9);
    s.blit(f, sx, sy, { flipX: this.facing === -1 });
    // thruster wash on the ground
    s.blend(Math.round(this.x - camX), Math.round(this.y - camY) + 3, withAlpha(cyan.c2, blink(this.t, 0.5, 0.6) ? 46 : 30));
  }
}
