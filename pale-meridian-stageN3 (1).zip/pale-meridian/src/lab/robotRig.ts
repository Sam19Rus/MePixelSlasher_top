import { mix, withAlpha } from '../rendering/color';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, metal, rust, signal, warm } from '../data/palette';
import { cycle } from '../animation/Animator';

/**
 * THE LAB DRONE — composite: chassis + sensor head + tool arm + thruster,
 * each with its own anchor and its own micro-animation (lens sweep, arm rise,
 * thruster flicker). Side view, mirrored for the other heading.
 */

const CHASSIS = [
  '...HHHHHH...',
  '..HhhhhhhH..',
  '.HHaaaaaaHH.',
  '.HaaaaaaaaH.',
  'HHooaxxxaaH.',
  'HooaxvVvxaaH',
  'HaaaxvvvxaaH',
  'HHaaaxxxaaHH',
  '.HaaaaaaaaH.',
  '.HHbbbbbbHH.',
  '..HHbbbbHH..',
  '...HHHHHH...',
];
const HEAD = [
  '.HHHH.',
  'HhhhhH',
  'Hgvvvh',
  'Hgvvvh',
  'GGggGG',
];
const ARM_DOWN = [
  'H.',
  'H.',
  '.H',
  '.H',
  '.K',
];
const ARM_RAISED = [
  '.H',
  'H.',
  'H.',
  'K.',
  'K.',
];
const TOOL = [
  'HHH.',
  'HaaH',
  'HaaHx',
  'HHHy',
];

const C: Record<string, number> = {
  H: metal.m4,
  h: metal.m7,
  a: metal.m5,
  b: metal.m3,
  x: warm.w0,
  v: cyan.c2,
  V: cyan.c5,
  o: amber.a3,
  K: warm.w2,
  g: metal.m3,
  G: metal.m2,
  y: cyan.c4,
};

function draw(map: string[], s: PixelSurface, x: number, y: number, flip: boolean): void {
  const w = Math.max(...map.map((r) => r.length));
  for (let ry = 0; ry < map.length; ry++) {
    for (let rx = 0; rx < map[ry].length; rx++) {
      const c = C[map[ry][rx]];
      if (c === undefined) continue;
      s.set(x + (flip ? w - 1 - rx : rx), y + ry, c);
    }
  }
}

export interface RobotPose {
  t: number;
  flip: boolean;
  alert: boolean;
}

/** feet (hover point) centred at (x, y) */
export function drawRobotRig(s: PixelSurface, x: number, y: number, pose: RobotPose): void {
  const bob = Math.round(Math.sin(pose.t * 2.6) * 1.5);
  const f = pose.flip;
  const cy = y - 14 + bob;
  // thruster glow under the chassis
  const th = [3, 4, 3, 2][cycle(pose.t, 6, 4)];
  for (let i = 0; i < th; i++) {
    const wdt = i === 0 ? 4 : i === 1 ? 3 : i === 2 ? 2 : 1;
    s.hline(x - Math.floor(wdt / 2), y - 2 + bob + i, wdt, i === 0 ? cyan.c6 : i === 1 ? cyan.c4 : cyan.c2);
  }
  s.set(x - 1, y - 2 + bob, cyan.c7);
  s.set(x, y - 2 + bob, cyan.c7);
  // chassis
  draw(CHASSIS, s, x - 6, cy, f);
  // sensor head: sweeps unless alert (then locks on)
  const sweep = pose.alert ? 0 : [0, 1, 0, -1][cycle(pose.t, 1.5, 4)];
  draw(HEAD, s, x - 3 + (f ? -sweep : sweep), cy - 4, f);
  s.set(x - 1 + (f ? -sweep : sweep), cy - 2, cyan.c6);
  // tool arm: raises when alert
  const arm = pose.alert ? ARM_RAISED : ARM_DOWN;
  draw(arm, s, x + (f ? -8 : 6), cy + 6, f);
  draw(TOOL, s, x + (f ? -11 : 7), cy + (pose.alert ? 4 : 8), f);
  // cable from chassis to arm
  for (let i = 0; i < 4; i++) {
    s.set(x + (f ? -6 + -i * 0 : 5) + (f ? -i : i), cy + 5 + Math.round(Math.sin(i) * 1), warm.w0);
  }
  // beacon
  const on = cycle(pose.t, 0.9, 2) === 0;
  s.set(x + (f ? -4 : 4), cy - 5, on ? signal.s4 : signal.s1);
  // weathering
  s.set(x - 4, cy + 7, rust.x3);
  s.set(x + 3, cy + 8, rust.x2);
}

export function robotShadow(s: PixelSurface, x: number, y: number, bob: number): void {
  const r = 6 - bob;
  s.contactShadow(x + 2, y + 1, r, Math.max(2, r >> 1), withAlpha(mix(warm.w0, metal.m0, 0.5), 100), 0.85);
}
