import { Color, mix, packRGBA, withAlpha } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { fbm, makeRng, valueNoise } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, dust, grime, hazard, metal, olive, rock, rust, slate, teal, warm } from '../data/palette';
import { drawText } from '../rendering/text';
import { Proj, type FaceQuad } from './profiles';
import { faceLine, faceOutline, facePx, faceRampV, faceRect, fillFace } from './facePaint';

/**
 * PROJECTION LAB asset kit.
 *
 * One design, baked through `Proj` per projection profile: terrain, the
 * outpost building (walls / roof / tower / entrance), its interior furniture,
 * the utility vehicle, containers, rocks, plants, generator and lamp. Nothing
 * here knows which projection it ends up in — every spatial decision goes
 * through the profile, which is what makes the six-panel comparison honest.
 */

export interface LabObject {
  sprite: PixelSurface;
  x: number;
  y: number;
  key: number;
  group: 'wall' | 'wallStub' | 'roof' | 'interior' | 'prop' | 'vehicle';
  name: string;
}

export interface LabLight {
  x: number;
  y: number;
  r: number;
  c: [number, number, number];
  i: number;
  flicker?: number;
  blink?: number;
  interiorOnly?: boolean;
  exteriorOnly?: boolean;
}

export interface LabBake {
  width: number;
  height: number;
  ox: number;
  oy: number;
  ground: PixelSurface;
  shadow: PixelSurface;
  /** shadow layer without the hall roof/tower (used by the cutaway) */
  shadowCut: PixelSurface;
  objects: LabObject[];
  lights: LabLight[];
  interiorRect: { x: number; y: number; w: number; h: number };
  doorWorld: { x: number; y: number };
  focus: { x: number; y: number };
}

// ------------------------------------------------------------------ layout
export const LAB_WORLD = { w: 230, h: 180 };
export const LAB_BUILDING = {
  hall: { x: 70, y: 40, w: 58, d: 52, h: 26 },
  side: { x: 128, y: 46, w: 22, d: 40, h: 18 },
  garage: { x: 48, y: 52, w: 22, d: 36, h: 14 },
  tower: { x: 88, y: 56, w: 24, d: 20, h: 36 },
  door: { x: 92, y: 92, w: 12 },
};
const WALL_T = 3;
/** door offset in the south wall's face-local u */
const DOOR_U = LAB_BUILDING.door.x - LAB_BUILDING.hall.x;
export const LAB_INTERIOR = { x: LAB_BUILDING.hall.x + WALL_T, y: LAB_BUILDING.hall.y + WALL_T, w: LAB_BUILDING.hall.w - WALL_T * 2, h: LAB_BUILDING.hall.d - WALL_T * 2 };

export const LAB_LAYOUT = {
  vehicle: { x: 152, y: 120 },
  robot: { x: 122, y: 110 },
  character: { x: 98, y: 128 },
  containers: [
    { x: 178, y: 58 },
    { x: 186, y: 74 },
  ],
  rocks: [
    { x: 34, y: 132, r: 9 },
    { x: 196, y: 132, r: 7 },
    { x: 26, y: 34, r: 8 },
  ],
  plants: [
    { x: 60, y: 142 },
    { x: 168, y: 142 },
    { x: 44, y: 104 },
    { x: 202, y: 96 },
  ],
  generator: { x: 56, y: 106 },
  lamp: { x: 84, y: 140 },
  crates: [
    { x: 138, y: 134 },
    { x: 146, y: 140 },
  ],
  focus: { x: 108, y: 96 },
};

// ------------------------------------------------------------------ materials
export interface Mat {
  top: [Color, Color];
  front: [Color, Color, Color];
  east: [Color, Color];
  rim: Color;
  edge: Color;
}
export const CREAM: Mat = {
  top: [mix(metal.m9, dust.d8, 0.3), mix(metal.m7, dust.d7, 0.35)],
  front: [metal.m7, metal.m5, metal.m3],
  east: [metal.m3, metal.m2],
  rim: mix(metal.mA, amber.a7, 0.25),
  edge: metal.m1,
};
export const RUSTY: Mat = {
  top: [mix(rust.x7, dust.d7, 0.3), mix(rust.x5, dust.d6, 0.35)],
  front: [rust.x5, rust.x4, rust.x2],
  east: [rust.x2, rust.x1],
  rim: mix(rust.x8, amber.a6, 0.2),
  edge: rust.x0,
};
export const DARK: Mat = {
  top: [metal.m5, metal.m4],
  front: [metal.m4, metal.m3, metal.m2],
  east: [metal.m1, metal.m0],
  rim: metal.m6,
  edge: metal.m0,
};
const SLATE_MAT: Mat = {
  top: [slate.s5, slate.s4],
  front: [slate.s5, slate.s4, slate.s3],
  east: [slate.s2, slate.s1],
  rim: slate.s6,
  edge: slate.s1,
};

/** Proj wrapper that bakes into a local surface with a pixel offset. */
export class LocalProj extends Proj {
  constructor(base: Proj, public lx: number, public ly: number) {
    super(base.p);
  }
  override g(x: number, y: number): [number, number] {
    const [sx, sy] = super.g(x, y);
    return [sx + this.lx, sy + this.ly];
  }
  override inv(sx: number, sy: number): [number, number] {
    return super.inv(sx - this.lx, sy - this.ly);
  }
}

export function paintBox(
  s: PixelSurface,
  pr: Proj,
  x: number,
  y: number,
  w: number,
  d: number,
  h: number,
  m: Mat,
  detail?: (f: { top: FaceQuad; front: FaceQuad; east: FaceQuad }) => void,
): { top: FaceQuad; front: FaceQuad; east: FaceQuad } {
  const b = pr.box(x, y, w, d, h);
  if (pr.p.mode === 'tilted') {
    // back-facing west wall: draw as a dark grounded band so masses sit
    // correctly from every camera side
    fillFace(s, b.west, mix(m.east[0], m.east[1], 0.4));
    faceRampV(s, b.west, mix(m.east[0], m.east[1], 0.5), m.east[1], 3);
  }
  fillFace(s, b.top, m.top[0]);
  faceRampV(s, b.top, m.top[0], m.top[1], 3);
  fillFace(s, b.front, m.front[1]);
  faceRampV(s, b.front, m.front[0], m.front[2], 4);
  fillFace(s, b.east, m.east[0]);
  faceRampV(s, b.east, m.east[0], m.east[1], 3);
  if (pr.p.mode === 'axon') {
    // the second visible wall (west slot holds the east-face shading variant)
    faceRampV(s, b.east, mix(m.east[0], m.front[1], 0.35), m.east[1], 3);
  }
  faceOutline(s, b.top, m.edge);
  faceOutline(s, b.front, m.edge);
  faceOutline(s, b.east, m.edge);
  faceLine(s, b.top, 0, 0, b.top.uw, 0, m.rim);
  if (detail) detail(b);
  return b;
}

export function windowOnFace(s: PixelSurface, f: FaceQuad, u: number, v: number, w: number, h: number, glow: boolean): void {
  faceRect(s, f, u - 1, v - 1, w + 2, h + 2, metal.m2);
  for (let j = 0; j < h; j++) {
    for (let i = 0; i < w; i++) {
      const t = j / Math.max(1, h - 1);
      let c = mix(teal.t0, teal.t2, t);
      if ((i + j * 2) % 9 === 3) c = mix(c, teal.t4, 0.5);
      if (glow && j > h - 3 && bayer4(i, j) > 0.4) c = mix(c, cyan.c1, 0.5);
      facePx(s, f, u + i, v + j, c);
    }
  }
  faceLine(s, f, u - 1, v - 1, u + w, v - 1, metal.m6);
  faceLine(s, f, u - 1, v + h, u + w, v + h, metal.m1);
}

/** bbox of a footprint incl. height, in projected screen space */
function massBounds(pr: Proj, x: number, y: number, w: number, d: number, h: number, pad = 6) {
  const cs = [pr.g(x, y), pr.g(x + w, y), pr.g(x + w, y + d), pr.g(x, y + d)];
  const xs = cs.map((c) => c[0]);
  const ys = cs.map((c) => c[1]);
  const minX = Math.floor(Math.min(...xs)) - pad;
  const maxX = Math.ceil(Math.max(...xs)) + Math.ceil(Math.abs(pr.p.kx) * d) + pad;
  const minY = Math.floor(Math.min(...ys)) - pr.lift(h) - Math.ceil(pr.p.ky * d) - pad;
  const maxY = Math.ceil(Math.max(...ys)) + pad;
  return { minX, minY, w: maxX - minX, h: maxY - minY };
}

interface Baked {
  sprite: PixelSurface;
  /** local anchor: screen point of world (ax, ay) inside the sprite */
  ax: number;
  ay: number;
}

function bakeMass(
  pr: Proj,
  r: { x: number; y: number; w: number; d: number; h: number },
  m: Mat,
  anchor: { x: number; y: number },
  detail?: (s: PixelSurface, f: { top: FaceQuad; front: FaceQuad; east: FaceQuad }) => void,
): Baked {
  const b = massBounds(pr, r.x, r.y, r.w, r.d, r.h);
  const s = new PixelSurface(b.w, b.h);
  const lp = new LocalProj(pr, -b.minX, -b.minY);
  const faces = paintBox(s, lp, r.x, r.y, r.w, r.d, r.h, m, (f) => detail?.(s, f));
  void faces;
  const [gx, gy] = pr.g(anchor.x, anchor.y);
  return { sprite: s, ax: Math.round(gx - b.minX), ay: Math.round(gy - b.minY) };
}

// ------------------------------------------------------------------ ground
function bakeGround(pr: Proj, W: number, H: number, ox: number, oy: number): PixelSurface {
  const s = new PixelSurface(W, H);
  /** footprint quad in bake pixels (groundQuad works in raw projected space) */
  const gq = (x: number, y: number, w: number, d: number, c: number) =>
    s.polygon(
      pr.quad(x, y, w, d).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]),
      c,
    );
  for (let py = 0; py < H; py++) {
    for (let px = 0; px < W; px++) {
      const [wx, wy] = pr.inv(px - ox, py - oy);
      const form = fbm(wx / 120, wy / 80, 3, 11);
      const grain = fbm(wx / 12, wy / 10, 3, 41);
      let v = grain * 0.6 + form * 0.3 + 0.15;
      v = Math.max(0, Math.min(0.999, v));
      const ramp = [dust.d2, dust.d3, dust.d4, dust.d5, dust.d6];
      const t = v * (ramp.length - 1);
      const i = Math.floor(t);
      const c = bayer4(px, py) < t - i ? ramp[i + 1] : ramp[i];
      const out = mix(c, form > 0.55 ? dust.d8 : dust.d1, Math.min(0.18, Math.abs(form - 0.5) * 0.36));
      s.setRaw(px, py, packRGBA(out & 0xff, (out >>> 8) & 0xff, (out >>> 16) & 0xff));
    }
  }
  const rnd = makeRng(88);
  for (let i = 0; i < 2400; i++) {
    const wx = rnd.range(-20, LAB_WORLD.w + 30);
    const wy = rnd.range(-20, LAB_WORLD.h + 30);
    const [px, py] = pr.g(wx, wy);
    const sx = Math.round(px + ox);
    const sy = Math.round(py + oy);
    if (sx < 0 || sy < 0 || sx >= W || sy >= H) continue;
    s.set(sx, sy, rnd.chance(0.5) ? dust.d7 : dust.d2);
  }
  // work pad
  const pad = { x: 56, y: 96, w: 112, h: 48 };
  gq(pad.x, pad.y, pad.w, pad.h, mix(dust.d5, dust.d6, 0.55));
  gq(pad.x + 3, pad.y + 3, pad.w - 6, pad.h - 6, mix(dust.d6, dust.d7, 0.5));
  for (let i = 0; i < 6; i++) {
    const cx = rnd.range(pad.x + 10, pad.x + pad.w - 10);
    const cy = rnd.range(pad.y + 8, pad.y + pad.h - 8);
    const [px, py] = pr.g(cx, cy);
    s.contactShadow(Math.round(px + ox), Math.round(py + oy), rnd.int(3, 6), rnd.int(2, 4), withAlpha(grime.g2, 80), 0.7);
  }
  // tyre tracks
  for (const side of [-4, 4]) {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 22; t++) {
      const wx = 96 + side + Math.sin(t / 5) * 3;
      const wy = 176 - t * 1.7;
      const [px, py] = pr.g(wx, wy);
      const cur: [number, number] = [Math.round(px + ox), Math.round(py + oy)];
      if (prev) s.line(prev[0], prev[1], cur[0], cur[1], mix(dust.d2, grime.g2, 0.4));
      prev = cur;
    }
  }
  const [mx, my] = pr.g(pad.x + 12, pad.y + pad.h - 6);
  drawText(s, Math.round(mx + ox), Math.round(my + oy), 'LAB-06', mix(metal.m6, dust.d6, 0.5), { worn: 0.45, seed: 2 });

  // interior floor plate + grating + cables (visible when the roof is cut away)
  const ir = LAB_INTERIOR;
  gq(ir.x, ir.y, ir.w, ir.h, slate.s5);
  gq(ir.x + 1, ir.y + 1, ir.w - 2, ir.h - 2, slate.s4);
  for (let i = 0; i < ir.w - 8; i += 2) {
    const a = pr.g(ir.x + 4 + i, ir.y + ir.h / 2 - 3);
    const b = pr.g(ir.x + 4 + i, ir.y + ir.h / 2 + 3);
    s.line(Math.round(a[0] + ox), Math.round(a[1] + oy), Math.round(b[0] + ox), Math.round(b[1] + oy), i % 4 === 0 ? slate.s5 : slate.s2);
  }
  let prevC: [number, number] | null = null;
  for (let t = 0; t <= 12; t++) {
    const p = pr.g(ir.x + 6 + t * 3, ir.y + ir.h - 6 + Math.sin(t) * 2);
    const cur: [number, number] = [Math.round(p[0] + ox), Math.round(p[1] + oy)];
    if (prevC) s.line(prevC[0], prevC[1], cur[0], cur[1], slate.s1);
    prevC = cur;
  }
  const [dx, dy] = pr.g(ir.x + ir.w / 2 - 6, ir.y + ir.h - 5);
  s.polygon(
    [pr.g(ir.x + ir.w / 2 - 7, ir.y + ir.h - 4), pr.g(ir.x + ir.w / 2 + 7, ir.y + ir.h - 4), pr.g(ir.x + ir.w / 2 + 7, ir.y + ir.h - 1), pr.g(ir.x + ir.w / 2 - 7, ir.y + ir.h - 1)].map((p) => [
      Math.round(p[0] + ox),
      Math.round(p[1] + oy),
    ]),
    mix(hazard.h2, slate.s3, 0.4),
  );
  void dx;
  void dy;
  return s;
}

// ------------------------------------------------------------------ shadows
function bakeShadows(pr: Proj, W: number, H: number, ox: number, oy: number, masses: { x: number; y: number; w: number; d: number; h: number }[]): PixelSurface {
  const s = new PixelSurface(W, H);
  const L = pr.p.shadow;
  for (const m of masses) {
    const dx = L.x * m.h;
    const dy = L.y * m.h;
    const base = [
      pr.g(m.x, m.y),
      pr.g(m.x + m.w, m.y),
      pr.g(m.x + m.w, m.y + m.d),
      pr.g(m.x, m.y + m.d),
    ];
    const far = base.map((p) => [p[0] + dx, p[1] + dy]);
    const poly = (pts: number[][]) =>
      s.polygon(
        pts.map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]),
        packRGBA(38, 22, 20, 110),
      );
    poly([base[0], base[1], far[1], far[0]]);
    poly([base[1], base[2], far[2], far[1]]);
    poly(base);
  }
  // dither the outer edge
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      if ((s.data[i] >>> 24) === 0) continue;
      let outside = false;
      for (const o of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const nx = x + o[0];
        const ny = y + o[1];
        if (nx < 0 || ny < 0 || nx >= W || ny >= H || (s.data[ny * W + nx] >>> 24) === 0) outside = true;
      }
      if (outside && bayer8(x, y) < 0.6) s.data[i] = 0;
    }
  }
  return s;
}

// ------------------------------------------------------------------ props
function bakeRock(_pr: Proj, r: number, seed: number): Baked {
  const s = new PixelSurface(r * 2 + 6, r + 8);
  const rnd = makeRng(seed);
  const cx = r + 3;
  const cy = r + 2;
  const ry = Math.max(3, Math.round(r * 0.62));
  for (let y = -ry - 1; y <= ry; y++) {
    for (let x = -r - 1; x <= r + 1; x++) {
      const wob = 0.78 + valueNoise((cx + x) / 4, (cy + y) / 4, seed) * 0.44;
      const d = Math.sqrt((x * x) / (r * r) + (y * y) / (ry * ry)) / wob;
      if (d > 1) continue;
      const nl = (-x / r) * 0.5 + (-y / ry) * 0.8;
      let v = 0.34 + nl * 0.32 + (valueNoise((cx + x) / 3, (cy + y) / 3, seed + 1) - 0.5) * 0.4;
      v = Math.max(0, Math.min(0.999, v));
      const ramp = [rock.r1, rock.r2, rock.r3, rock.r4, rock.r5];
      const t = v * 4;
      const c = bayer4(x, y) < t - Math.floor(t) ? ramp[Math.min(4, Math.floor(t) + 1)] : ramp[Math.floor(t)];
      s.set(cx + x, cy + y, c);
    }
  }
  for (let i = 0; i < 4; i++) s.set(cx - r + 2 + rnd.int(0, r * 2 - 4), cy - 2 + rnd.int(0, 4), rock.r2);
  return { sprite: s, ax: cx, ay: cy + ry - 1 };
}

function bakePlant(_pr: Proj, seed: number): Baked {
  const s = new PixelSurface(12, 12);
  const rnd = makeRng(seed);
  const cx = 6;
  const cy = 10;
  const blades = 4 + rnd.int(0, 3);
  for (let i = 0; i < blades; i++) {
    const h = 3 + rnd.int(0, 5);
    const lean = (rnd() - 0.5) * 4;
    for (let k = 0; k < h; k++) {
      const t = k / h;
      const px = Math.round(cx + lean * t * t + (i - blades / 2) * 0.8);
      const py = cy - k;
      const c = k === h - 1 ? mix(olive.o5, rust.x5, 0.4) : t > 0.5 ? mix(olive.o3, rust.x3, 0.25) : olive.o2;
      s.set(px, py, c);
    }
  }
  s.set(cx, cy, olive.o1);
  return { sprite: s, ax: cx, ay: cy };
}

function bakeContainer(pr: Proj, seed: number): Baked {
  const r = { x: 0, y: 0, w: 20, d: 10, h: 10 };
  const baked = bakeMass(pr, r, { top: [mix(teal.t5, dust.d7, 0.35), mix(teal.t4, dust.d6, 0.35)], front: [teal.t4, teal.t3, teal.t1], east: [teal.t1, teal.t0], rim: mix(teal.t6, dust.d8, 0.3), edge: teal.t0 }, { x: 10, y: 5 }, (s, f) => {
    for (let u = 2; u < f.front.uw - 2; u += 3) faceLine(s, f.front, u, 1, u, f.front.vh - 2, teal.t2);
    faceLine(s, f.front, 0, 1, f.front.uw, 1, teal.t5);
    drawText(s, 0, 0, '', 0);
    void s;
  });
  void seed;
  return baked;
}

function bakeCrate(pr: Proj, seed: number): Baked {
  const m: Mat = seed % 2 === 0
    ? { top: [mix(metal.m7, olive.o5, 0.3), mix(metal.m5, olive.o4, 0.3)], front: [mix(metal.m6, olive.o4, 0.35), mix(metal.m4, olive.o3, 0.35), mix(metal.m2, olive.o2, 0.4)], east: [mix(metal.m2, olive.o2, 0.4), mix(metal.m1, olive.o1, 0.4)], rim: mix(metal.m8, olive.o6, 0.3), edge: metal.m1 }
    : { top: [mix(rust.x6, dust.d7, 0.25), rust.x4], front: [rust.x5, rust.x4, rust.x2], east: [rust.x2, rust.x1], rim: rust.x7, edge: rust.x0 };
  return bakeMass(pr, { x: 0, y: 0, w: 9, d: 7, h: 7 }, m, { x: 4, y: 3 });
}

function bakeGenerator(pr: Proj): Baked {
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 16, d: 10, h: 10 },
    { top: [mix(metal.m7, dust.d7, 0.3), mix(metal.m5, dust.d6, 0.3)], front: [mix(metal.m6, warm.w5, 0.4), mix(metal.m4, warm.w4, 0.4), mix(metal.m2, warm.w2, 0.4)], east: [warm.w2, warm.w1], rim: mix(metal.m8, amber.a6, 0.2), edge: warm.w0 },
    { x: 8, y: 5 },
    (s, f) => {
      // louvred intake + emissive vent
      for (let j = 2; j < 7; j += 2) faceLine(s, f.front, 2, j, 7, j, warm.w1);
      faceRect(s, f.front, 9, 2, 5, 4, warm.w1);
      faceLine(s, f.front, 10, 3, 13, 3, amber.a5);
      faceLine(s, f.front, 10, 4, 13, 4, amber.a3);
      facePx(s, f.front, 12, 7, cyan.c4);
    },
  );
}

function bakeLamp(_pr: Proj): Baked {
  const s = new PixelSurface(10, 26);
  const bx = 4;
  const by = 24;
  s.vline(bx, 6, by - 6, metal.m3);
  s.vline(bx + 1, 6, by - 6, metal.m5);
  s.rect(bx - 3, by - 2, 7, 3, metal.m2);
  s.rect(bx - 3, 3, 8, 4, metal.m3);
  s.hline(bx - 3, 3, 8, metal.m6);
  s.rect(bx - 2, 6, 6, 2, amber.a4);
  s.hline(bx - 2, 6, 6, amber.a6);
  return { sprite: s, ax: bx, ay: by };
}

function bakeVehicle(pr: Proj): Baked {
  // chassis + cabin + bed + tracks, all through the profile
  const b = massBounds(pr, -14, -8, 28, 16, 12, 8);
  const s = new PixelSurface(b.w, b.h);
  const lp = new LocalProj(pr, -b.minX, -b.minY);
  // tracks / wheels: two low masses along the sides
  paintBox(s, lp, -13, -8, 26, 4, 4, DARK);
  paintBox(s, lp, -13, 4, 26, 4, 4, DARK);
  // chassis
  paintBox(s, lp, -12, -6, 24, 12, 7, { top: [mix(metal.m6, olive.o5, 0.3), mix(metal.m5, olive.o4, 0.3)], front: [mix(metal.m6, olive.o4, 0.3), mix(metal.m4, olive.o3, 0.3), mix(metal.m2, olive.o2, 0.4)], east: [mix(metal.m2, olive.o2, 0.4), metal.m1], rim: mix(metal.m8, olive.o6, 0.3), edge: metal.m1 }, (f) => {
    faceLine(s, f.front, 1, f.front.vh - 2, f.front.uw - 1, f.front.vh - 2, mix(hazard.h2, olive.o2, 0.4));
  });
  // cabin (front-east part) with teal glass
  paintBox(s, lp, 2, -5, 9, 10, 12, { top: [mix(metal.m8, dust.d7, 0.3), mix(metal.m6, dust.d6, 0.3)], front: [metal.m7, metal.m5, metal.m3], east: [metal.m2, metal.m1], rim: mix(metal.m9, amber.a6, 0.2), edge: metal.m1 }, (f) => {
    windowOnFace(s, f.front, 2, 2, 5, 4, false);
    if (pr.p.mode === 'axon') windowOnFace(s, f.east, 2, 2, 5, 4, false);
  });
  // cargo bed rails
  paintBox(s, lp, -11, -5, 12, 10, 9, { top: [metal.m5, metal.m4], front: [metal.m5, metal.m4, metal.m2], east: [metal.m2, metal.m1], rim: metal.m7, edge: metal.m1 });
  // engine block at the rear + exhaust
  paintBox(s, lp, -13, -3, 3, 6, 10, RUSTY);
  // headlight + tail emissive pixels
  const hl = lp.g(12, 0);
  s.set(Math.round(hl[0]), Math.round(hl[1]) - 4, amber.a6);
  s.set(Math.round(hl[0]), Math.round(hl[1]) - 3, amber.a4);
  const tl = lp.g(-12, 0);
  s.set(Math.round(tl[0]), Math.round(tl[1]) - 4, signalRed());
  // antenna
  const an = lp.g(4, -5);
  s.vline(Math.round(an[0]), Math.round(an[1]) - 20, 8, metal.m4);
  s.set(Math.round(an[0]), Math.round(an[1]) - 21, signalRed());
  const [gx, gy] = pr.g(0, 0);
  return { sprite: s, ax: Math.round(gx - b.minX), ay: Math.round(gy - b.minY) };
}
function signalRed(): Color {
  return mix(rust.x5, amber.a3, 0.2);
}

// ------------------------------------------------------------------ full bake
export function bakeLab(pr: Proj): LabBake {
  const objects: LabObject[] = [];
  const lights: LabLight[] = [];
  const B = LAB_BUILDING;

  // panel bounds from the world extent
  const cs = [pr.g(-30, -30), pr.g(LAB_WORLD.w + 40, -30), pr.g(LAB_WORLD.w + 40, LAB_WORLD.h + 40), pr.g(-30, LAB_WORLD.h + 40)];
  const xs = cs.map((c) => c[0]);
  const ys = cs.map((c) => c[1]);
  const minX = Math.floor(Math.min(...xs)) - 20;
  const maxX = Math.ceil(Math.max(...xs)) + 30;
  const minY = Math.floor(Math.min(...ys)) - 70;
  const maxY = Math.ceil(Math.max(...ys)) + 20;
  const W = maxX - minX;
  const H = maxY - minY;
  const ox = -minX;
  const oy = -minY;

  const ground = bakeGround(pr, W, H, ox, oy);

  const vehMass = { x: LAB_LAYOUT.vehicle.x - 13, y: LAB_LAYOUT.vehicle.y - 7, w: 26, h: 8, d: 14 };
  const shadow = bakeShadows(pr, W, H, ox, oy, [B.hall, B.side, B.garage, B.tower, vehMass]);
  const shadowCut = bakeShadows(pr, W, H, ox, oy, [B.side, B.garage, vehMass]);

  const push = (bk: Baked, wx: number, wy: number, key: number, group: LabObject['group'], name: string) => {
    const [sx, sy] = pr.g(wx, wy);
    objects.push({ sprite: bk.sprite, x: Math.round(sx + ox) - bk.ax, y: Math.round(sy + oy) - bk.ay, key, group, name });
  };

  // ---- walls: N & W always full; S & E full outside, stubs inside
  const wallMat = CREAM;
  const wn = bakeMass(pr, { x: B.hall.x, y: B.hall.y, w: B.hall.w, d: WALL_T, h: B.hall.h }, wallMat, { x: B.hall.x + B.hall.w / 2, y: B.hall.y + WALL_T }, (s, f) => {
    // inner-face consoles glow through windows on the south (inner) face
    windowOnFace(s, f.front, 8, 6, 8, 6, true);
    windowOnFace(s, f.front, 30, 6, 8, 6, true);
  });
  push(wn, B.hall.x + B.hall.w / 2, B.hall.y + WALL_T, pr.depthKey(B.hall.x, B.hall.y) + 0.2, 'wall', 'wallN');
  const ww = bakeMass(pr, { x: B.hall.x, y: B.hall.y, w: WALL_T, d: B.hall.d, h: B.hall.h }, wallMat, { x: B.hall.x + WALL_T, y: B.hall.y + B.hall.d / 2 });
  push(ww, B.hall.x + WALL_T, B.hall.y + B.hall.d / 2, pr.depthKey(B.hall.x, B.hall.y) + 1.0, 'wall', 'wallW');
  const wsFull = bakeMass(pr, { x: B.hall.x, y: B.hall.y + B.hall.d - WALL_T, w: B.hall.w, d: WALL_T, h: B.hall.h }, wallMat, { x: B.hall.x + B.hall.w / 2, y: B.hall.y + B.hall.d }, (s, f) => {
    // entrance door + windows on the outer south face
    faceRect(s, f.front, DOOR_U, 4, 12, f.front.vh - 4, slate.s1);
    faceRect(s, f.front, DOOR_U + 1, 5, 10, f.front.vh - 5, metal.m3);
    faceLine(s, f.front, DOOR_U + 6, 5, DOOR_U + 6, f.front.vh - 1, amber.a4);
    windowOnFace(s, f.front, 8, 6, 8, 6, true);
    windowOnFace(s, f.front, 40, 6, 8, 6, true);
    faceLine(s, f.front, 0, f.front.vh - 3, f.front.uw, f.front.vh - 3, mix(hazard.h2, metal.m3, 0.5));
    void s;
  });
  push(wsFull, B.hall.x + B.hall.w / 2, B.hall.y + B.hall.d, pr.depthKey(B.hall.x + B.hall.w / 2, B.hall.y + B.hall.d) + 0.6, 'wall', 'wallS');
  const weFull = bakeMass(pr, { x: B.hall.x + B.hall.w - WALL_T, y: B.hall.y, w: WALL_T, d: B.hall.d, h: B.hall.h }, wallMat, { x: B.hall.x + B.hall.w, y: B.hall.y + B.hall.d / 2 });
  push(weFull, B.hall.x + B.hall.w, B.hall.y + B.hall.d / 2, pr.depthKey(B.hall.x, B.hall.y) + 2.0, 'wall', 'wallE');
  const wsStub = bakeMass(pr, { x: B.hall.x, y: B.hall.y + B.hall.d - WALL_T, w: B.hall.w, d: WALL_T, h: 3 }, wallMat, { x: B.hall.x + B.hall.w / 2, y: B.hall.y + B.hall.d });
  push(wsStub, B.hall.x + B.hall.w / 2, B.hall.y + B.hall.d, pr.depthKey(B.hall.x + B.hall.w / 2, B.hall.y + B.hall.d) + 0.6, 'wallStub', 'wallS-stub');
  const weStub = bakeMass(pr, { x: B.hall.x + B.hall.w - WALL_T, y: B.hall.y, w: WALL_T, d: B.hall.d, h: 3 }, wallMat, { x: B.hall.x + B.hall.w, y: B.hall.y + B.hall.d / 2 });
  push(weStub, B.hall.x + B.hall.w, B.hall.y + B.hall.d / 2, pr.depthKey(B.hall.x, B.hall.y) + 2.0, 'wallStub', 'wallE-stub');

  // ---- side section + garage (always visible, they are outside the hall)
  const side = bakeMass(pr, B.side, CREAM, { x: B.side.x + B.side.w / 2, y: B.side.y + B.side.d }, (s, f) => {
    ventOnFace(s, f);
  });
  push(side, B.side.x + B.side.w / 2, B.side.y + B.side.d, pr.depthKey(B.side.x + B.side.w, B.side.y + B.side.d) + 0.4, 'wall', 'side');
  const garage = bakeMass(pr, B.garage, CREAM, { x: B.garage.x + B.garage.w / 2, y: B.garage.y + B.garage.d }, (s, f) => {
    // shutter
    faceRect(s, f.front, 4, 3, 14, f.front.vh - 4, metal.m3);
    for (let j = 4; j < f.front.vh - 2; j += 2) faceLine(s, f.front, 4, j, 18, j, metal.m4);
    faceLine(s, f.front, 4, f.front.vh - 3, 18, f.front.vh - 3, hazard.h2);
    void s;
  });
  push(garage, B.garage.x + B.garage.w / 2, B.garage.y + B.garage.d, pr.depthKey(B.garage.x + B.garage.w, B.garage.y + B.garage.d) + 0.3, 'wall', 'garage');

  // ---- tower (top tech module) — part of the roof group
  const tower = bakeMass(pr, B.tower, RUSTY, { x: B.tower.x + B.tower.w / 2, y: B.tower.y + B.tower.d }, (s, f) => {
    for (let u = 3; u < f.front.uw - 2; u += 4) faceLine(s, f.front, u, 2, u, f.front.vh - 2, mix(rust.x3, rust.x2, 0.5));
    faceRect(s, f.front, 6, 8, 12, 5, rust.x2);
    drawTextAt(s, f, 7, 9, 'LAB', mix(rust.x7, metal.m8, 0.35));
    facePx(s, f.front, 18, 16, cyan.c4);
    void s;
  });
  push(tower, B.tower.x + B.tower.w / 2, B.tower.y + B.tower.d, 501, 'roof', 'tower');

  // ---- roof slab of the hall (+ side/garage tops come with their masses)
  const roof = bakeMass(pr, { x: B.hall.x - 1, y: B.hall.y - 1, w: B.hall.w + 2, d: B.hall.d + 2, h: B.hall.h + 1 }, { top: [mix(metal.m8, dust.d7, 0.4), mix(metal.m6, dust.d6, 0.45)], front: [metal.m6, metal.m5, metal.m3], east: [metal.m2, metal.m1], rim: mix(metal.m9, amber.a6, 0.2), edge: metal.m1 }, { x: B.hall.x + B.hall.w / 2, y: B.hall.y + B.hall.d }, (s, f) => {
    // roof furniture: vents, hatch, pipe run, dust
    faceRect(s, f.top, 6, 6, 8, 6, metal.m4);
    faceRect(s, f.top, 7, 7, 6, 4, metal.m2);
    faceRect(s, f.top, 40, 10, 10, 8, metal.m5);
    faceLine(s, f.top, 20, 4, 20, f.top.vh - 4, metal.m5);
    faceLine(s, f.top, 21, 4, 21, f.top.vh - 4, metal.m3);
    for (let u = 4; u < f.top.uw - 4; u += 9) facePx(s, f.top, u, f.top.vh - 3, dust.d6);
    void s;
  });
  push(roof, B.hall.x + B.hall.w / 2, B.hall.y + B.hall.d, 500, 'roof', 'roof');

  // ---- interior furniture (always in the world; roof hides it outside)
  const ir = LAB_INTERIOR;
  const console1 = bakeMass(pr, { x: ir.x + 4, y: ir.y + 2, w: 14, d: 5, h: 8 }, SLATE_MAT, { x: ir.x + 11, y: ir.y + 7 }, (s, f) => {
    faceRect(s, f.front, 2, 1, 10, 4, cyan.c0);
    faceLine(s, f.front, 3, 2, 9, 2, cyan.c3);
    faceLine(s, f.front, 3, 4, 7, 4, cyan.c2);
    void s;
  });
  push(console1, ir.x + 11, ir.y + 7, pr.depthKey(ir.x + 11, ir.y + 7), 'interior', 'console1');
  const console2 = bakeMass(pr, { x: ir.x + 24, y: ir.y + 2, w: 14, d: 5, h: 8 }, SLATE_MAT, { x: ir.x + 31, y: ir.y + 7 }, (s, f) => {
    faceRect(s, f.front, 2, 1, 10, 4, cyan.c0);
    faceLine(s, f.front, 3, 3, 10, 3, cyan.c2);
    void s;
  });
  push(console2, ir.x + 31, ir.y + 7, pr.depthKey(ir.x + 31, ir.y + 7), 'interior', 'console2');
  const table = bakeMass(pr, { x: ir.x + 18, y: ir.y + 18, w: 14, d: 9, h: 6 }, SLATE_MAT, { x: ir.x + 25, y: ir.y + 27 }, (s, f) => {
    faceRect(s, f.top, 3, 2, 8, 5, cyan.c0);
    facePx(s, f.top, 6, 4, cyan.c5);
    void s;
  });
  push(table, ir.x + 25, ir.y + 27, pr.depthKey(ir.x + 25, ir.y + 27), 'interior', 'table');
  const cabinet = bakeMass(pr, { x: ir.x + 2, y: ir.y + 16, w: 5, d: 12, h: 11 }, SLATE_MAT, { x: ir.x + 7, y: ir.y + 28 });
  push(cabinet, ir.x + 7, ir.y + 28, pr.depthKey(ir.x + 7, ir.y + 28), 'interior', 'cabinet');
  const icrate = bakeMass(pr, { x: ir.x + ir.w - 9, y: ir.y + 12, w: 6, d: 6, h: 6 }, RUSTY, { x: ir.x + ir.w - 6, y: ir.y + 18 });
  push(icrate, ir.x + ir.w - 6, ir.y + 18, pr.depthKey(ir.x + ir.w - 6, ir.y + 18), 'interior', 'icrate');
  const icrate2 = bakeMass(pr, { x: ir.x + ir.w - 9, y: ir.y + 20, w: 6, d: 6, h: 8 }, { top: [mix(metal.m7, olive.o5, 0.3), mix(metal.m5, olive.o4, 0.3)], front: [mix(metal.m6, olive.o4, 0.35), mix(metal.m4, olive.o3, 0.35), mix(metal.m2, olive.o2, 0.4)], east: [mix(metal.m2, olive.o2, 0.4), metal.m1], rim: metal.m8, edge: metal.m1 }, { x: ir.x + ir.w - 6, y: ir.y + 26 });
  push(icrate2, ir.x + ir.w - 6, ir.y + 26, pr.depthKey(ir.x + ir.w - 6, ir.y + 26), 'interior', 'icrate2');

  // ---- props
  for (const c of LAB_LAYOUT.containers) {
    const bk = bakeContainer(pr, c.x);
    push(bk, c.x, c.y, pr.depthKey(c.x, c.y), 'prop', 'container');
  }
  for (const c of LAB_LAYOUT.crates) {
    const bk = bakeCrate(pr, c.x + c.y);
    push(bk, c.x, c.y, pr.depthKey(c.x, c.y), 'prop', 'crate');
  }
  for (const r of LAB_LAYOUT.rocks) {
    const bk = bakeRock(pr, r.r, r.x);
    push(bk, r.x, r.y, pr.depthKey(r.x, r.y), 'prop', 'rock');
  }
  for (const p of LAB_LAYOUT.plants) {
    const bk = bakePlant(pr, p.x);
    push(bk, p.x, p.y, pr.depthKey(p.x, p.y), 'prop', 'plant');
  }
  const gen = bakeGenerator(pr);
  push(gen, LAB_LAYOUT.generator.x, LAB_LAYOUT.generator.y, pr.depthKey(LAB_LAYOUT.generator.x, LAB_LAYOUT.generator.y), 'prop', 'generator');
  const lamp = bakeLamp(pr);
  push(lamp, LAB_LAYOUT.lamp.x, LAB_LAYOUT.lamp.y, pr.depthKey(LAB_LAYOUT.lamp.x, LAB_LAYOUT.lamp.y) + 0.1, 'prop', 'lamp');
  const veh = bakeVehicle(pr);
  push(veh, LAB_LAYOUT.vehicle.x, LAB_LAYOUT.vehicle.y, pr.depthKey(LAB_LAYOUT.vehicle.x, LAB_LAYOUT.vehicle.y), 'vehicle', 'vehicle');

  // ---- lights
  lights.push({ x: B.door.x + 6, y: B.hall.y + B.hall.d + 2, r: 16, c: [1, 0.66, 0.34], i: 0.6, exteriorOnly: true });
  lights.push({ x: B.hall.x + 12, y: B.hall.y + B.hall.d + 2, r: 10, c: [0.2, 0.8, 0.9], i: 0.35, exteriorOnly: true });
  lights.push({ x: B.tower.x + 12, y: B.tower.y, r: 9, c: [1, 0.22, 0.18], i: 0.5, blink: 2.2 });
  lights.push({ x: LAB_LAYOUT.lamp.x, y: LAB_LAYOUT.lamp.y - 18, r: 22, c: [1, 0.72, 0.4], i: 0.55 });
  lights.push({ x: LAB_LAYOUT.generator.x, y: LAB_LAYOUT.generator.y - 6, r: 12, c: [1, 0.5, 0.2], i: 0.45, flicker: 0.25 });
  lights.push({ x: LAB_LAYOUT.vehicle.x + 12, y: LAB_LAYOUT.vehicle.y, r: 14, c: [1, 0.75, 0.45], i: 0.4 });
  lights.push({ x: ir.x + 26, y: ir.y + 20, r: 44, c: [1, 0.84, 0.6], i: 1.15, interiorOnly: true });
  lights.push({ x: ir.x + 14, y: ir.y + 34, r: 30, c: [1, 0.8, 0.55], i: 0.7, interiorOnly: true });
  lights.push({ x: ir.x + 11, y: ir.y + 6, r: 12, c: [0.25, 0.85, 0.9], i: 0.4, interiorOnly: true });
  lights.push({ x: ir.x + 31, y: ir.y + 6, r: 12, c: [0.25, 0.85, 0.9], i: 0.4, interiorOnly: true });
  lights.push({ x: ir.x + 25, y: ir.y + 24, r: 14, c: [0.2, 0.9, 1], i: 0.45, interiorOnly: true });

  return { width: W, height: H, ox, oy, ground, shadow, shadowCut, objects, lights, interiorRect: ir, doorWorld: { x: B.door.x + 6, y: B.hall.y + B.hall.d }, focus: LAB_LAYOUT.focus };
}

function ventOnFace(s: PixelSurface, f: { top: FaceQuad; front: FaceQuad; east: FaceQuad }): void {
  for (let j = 3; j < 8; j += 2) faceLine(s, f.front, 4, j, 12, j, metal.m2);
  faceLine(s, f.front, 4, 2, 12, 2, metal.m6);
  facePx(s, f.front, 16, 6, cyan.c3);
  void s;
}

function drawTextAt(s: PixelSurface, f: { front: FaceQuad }, u: number, v: number, text: string, c: Color): void {
  const fq = f.front;
  const [x, y] = [Math.round(fq.origin[0] + fq.u[0] * u + fq.v[0] * v), Math.round(fq.origin[1] + fq.u[1] * u + fq.v[1] * v)];
  drawText(s, x, y, text, c, { worn: 0.2 });
}

