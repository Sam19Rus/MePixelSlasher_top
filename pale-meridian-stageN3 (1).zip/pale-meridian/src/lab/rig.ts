import { Color, mix, withAlpha } from '../rendering/color';
import { PixelSurface } from '../rendering/PixelSurface';
import { cyan, metal, olive, signal, slate, warm, amber } from '../data/palette';

/**
 * THE LAB MERCENARY — a part-based rig.
 *
 * head / torso / left arm / right arm / left leg / right leg / backpack /
 * weapon are separate pixel parts with their own anchors. Poses reposition
 * parts; the torso compensates (bob / lean), the weapon follows the hands,
 * the pack follows the torso. Orientations: side (e, mirrored w), front (s),
 * back (n).
 */

export type Orient = 'e' | 'w' | 's' | 'n';
export type RigState = 'idle' | 'walk' | 'aim' | 'turn';

const P: Record<string, Color> = {
  H: metal.m6,
  h: metal.m8,
  g: metal.m4,
  G: metal.m3,
  v: cyan.c2,
  V: cyan.c5,
  s: slate.s3,
  S: slate.s5,
  t: slate.s7,
  a: metal.m8,
  A: metal.m6,
  b: metal.m4,
  w: olive.o3,
  W: olive.o1,
  p: olive.o2,
  P: olive.o4,
  k: warm.w1,
  K: warm.w3,
  r: signal.s3,
  q: warm.w2,
  Q: warm.w4,
  x: warm.w0,
  y: cyan.c3,
  m: warm.w1,
  o: amber.a3,
};

// ---------------------------------------------------------------- part maps
const HEAD_SIDE = [
  '..hhhh..',
  '.HhhhhH.',
  '.HggvvH.',
  '.HggvvH.',
  '.GGggGG.',
  '..ssss..',
];
const HEAD_FRONT = [
  '..hhhh..',
  '.HhhhhH.',
  '.HgvvvG.',
  '.HgVVVG.',
  '.GGggGG.',
  '..ssss..',
];
const HEAD_BACK = [
  '..hhhh..',
  '.HhhhhH.',
  '.HgHHgH.',
  '.HggggH.',
  '.GGggGG.',
  '..ssss..',
];
const TORSO_SIDE = [
  '..aaa...',
  '.AaSSA..',
  '.AbSSSA.',
  '.SbSSSS.',
  '.SSwSSS.',
  '.SSWWWS.',
  '..S..S..',
];
const TORSO_FRONT = [
  '.aa..aa.',
  'AaSSSSaA',
  'AbScScbA',
  'SbSSSSbS',
  'SSwSSwSS',
  'SSWWWWSS',
  '.S....S.',
];
const TORSO_BACK = [
  '.aa..aa.',
  'AappppaA',
  'AbpPPpbA',
  'SbpPPpbS',
  'SSpwwpSS',
  'SSWWWWSS',
  '.S....S.',
];
const PACK_SIDE = [
  'ppP.',
  'pPp.',
  'ppp.',
  'pWp.',
  'ppp.',
];
const ARM_SIDE_DOWN = [
  'S.',
  'S.',
  'S.',
  'S.',
  'K.',
  'K.',
];
const ARM_SIDE_SWING_A = [
  'S.',
  'S.',
  '.S',
  '.S',
  '.K',
  '.K',
];
const ARM_SIDE_SWING_B = [
  '.S',
  '.S',
  'S.',
  'S.',
  'K.',
  'K.',
];
const ARM_SIDE_AIM = [
  '......',
  'SSKKK.',
  '......',
  '......',
];
const ARM_FRONT_DOWN = [
  'S.',
  'S.',
  'S.',
  'S.',
  'K.',
];
const ARM_FRONT_SWING_A = [
  'S.',
  '.S',
  '.S',
  '.K',
  '.K',
];
const ARM_FRONT_SWING_B = [
  '.S',
  '.S',
  'S.',
  'K.',
  'K.',
];
const ARM_FRONT_AIM = [
  'KK..KK',
  'KK..KK',
];
const LEG_SIDE_STAND = [
  'SS.',
  'SS.',
  'SS.',
  'bb.',
  'SS.',
  'SS.',
  'KKk',
  'kkk',
];
const LEG_SIDE_W0 = [
  'SS.',
  'SS.',
  '.SS',
  '.bb',
  '.SS',
  '.SS',
  '.KKk',
  '.kkk',
];
const LEG_SIDE_W1 = [
  'SS.',
  'SS.',
  'SS.',
  'bb.',
  '.SS',
  '.KKk',
  '.kk.',
];
const LEG_SIDE_W2 = [
  '.SS',
  '.SS',
  'SS.',
  'bb.',
  'SS.',
  'SS.',
  'KKk',
  'kkk',
];
const LEG_FRONT_STAND = [
  'SS.',
  'SS.',
  'SS.',
  'bb.',
  'SS.',
  'SS.',
  'KKk',
  'kkk',
];
const LEG_FRONT_W0 = [
  'SS.',
  'SS.',
  'SS.',
  'bb.',
  '.SS',
  '.SS',
  '.KKk',
  '.kkk',
];
const LEG_FRONT_W1 = [
  'SS.',
  'SS.',
  'SS.',
  'bb.',
  'SS.',
  'KKk',
  'kk.',
];
const WEAPON_SIDE = [
  '..QQQQQ.....',
  'xxqqqqqqqqx.',
  'xKqqqqqqqqQy',
  '..q.mm......',
];
const WEAPON_FRONT = [
  '.QQQQQQQQ.',
  'KqqqqqqqqK',
  '..mm..mm..',
];

function part(map: string[]): { w: number; h: number; draw: (s: PixelSurface, x: number, y: number, flip: boolean) => void } {
  const w = Math.max(...map.map((r) => r.length));
  const h = map.length;
  return {
    w,
    h,
    draw: (s, x, y, flip) => {
      for (let ry = 0; ry < h; ry++) {
        const row = map[ry];
        for (let rx = 0; rx < row.length; rx++) {
          const c = P[row[rx]];
          if (c === undefined) continue;
          s.set(x + (flip ? w - 1 - rx : rx), y + ry, c);
        }
      }
    },
  };
}

const PARTS = {
  headS: part(HEAD_SIDE),
  headF: part(HEAD_FRONT),
  headB: part(HEAD_BACK),
  torsoS: part(TORSO_SIDE),
  torsoF: part(TORSO_FRONT),
  torsoB: part(TORSO_BACK),
  packS: part(PACK_SIDE),
  armSD: part(ARM_SIDE_DOWN),
  armSA: part(ARM_SIDE_SWING_A),
  armSB: part(ARM_SIDE_SWING_A),
  armSB2: part(ARM_SIDE_SWING_B),
  armSAim: part(ARM_SIDE_AIM),
  armFD: part(ARM_FRONT_DOWN),
  armFA: part(ARM_FRONT_SWING_A),
  armFB: part(ARM_FRONT_SWING_B),
  armFAim: part(ARM_FRONT_AIM),
  legSS: part(LEG_SIDE_STAND),
  legS0: part(LEG_SIDE_W0),
  legS1: part(LEG_SIDE_W1),
  legS2: part(LEG_SIDE_W2),
  legFS: part(LEG_FRONT_STAND),
  legF0: part(LEG_FRONT_W0),
  legF1: part(LEG_FRONT_W1),
  wpnS: part(WEAPON_SIDE),
  wpnF: part(WEAPON_FRONT),
};

export interface RigPose {
  state: RigState;
  phase: number; // 0..3 walk phase
  orient: Orient;
  breath: number; // 0|1
  look: number; // -1|0|1 head offset
}

/**
 * Draw the rig with feet centred at (x, y). Parts are composited back-to-front
 * per orientation so overlaps read correctly.
 */
export function drawRig(s: PixelSurface, x: number, y: number, pose: RigPose): void {
  const flip = pose.orient === 'w';
  const side = pose.orient === 'e' || pose.orient === 'w';
  const back = pose.orient === 'n';
  const bob = pose.state === 'walk' ? (pose.phase === 1 || pose.phase === 3 ? 0 : 1) : pose.breath;
  const lean = pose.state === 'aim' ? (flip ? -1 : 1) : 0;
  const hipY = y - 12 + bob;
  const torsoY = hipY - 7;
  const headY = torsoY - 6 + (pose.state === 'aim' ? 1 : 0);

  // ---- legs
  const walk = pose.state === 'walk';
  const ph = pose.phase;
  if (side) {
    const backLeg = walk ? [PARTS.legS2, PARTS.legS1, PARTS.legS0, PARTS.legS1][ph] : PARTS.legSS;
    const frontLeg = walk ? [PARTS.legS0, PARTS.legS1, PARTS.legS2, PARTS.legS1][ph] : PARTS.legSS;
    backLeg.draw(s, x - 2 + (flip ? 1 : 0), hipY, flip);
    frontLeg.draw(s, x - 1 + (flip ? -1 : 1), hipY, flip);
  } else {
    const legL = walk ? [PARTS.legF0, PARTS.legF1, PARTS.legFS, PARTS.legF1][ph] : PARTS.legFS;
    const legR = walk ? [PARTS.legFS, PARTS.legF1, PARTS.legF0, PARTS.legF1][ph] : PARTS.legFS;
    legL.draw(s, x - 4, hipY, false);
    legR.draw(s, x + 1, hipY, false);
  }

  // ---- backpack (behind torso)
  if (side) PARTS.packS.draw(s, x + (flip ? 2 : -6) + lean, torsoY + 1, flip);

  // ---- arms behind torso (back arm)
  if (side) {
    const arm = pose.state === 'walk' ? [PARTS.armSA, PARTS.armSD, PARTS.armSB2, PARTS.armSD][ph] : pose.state === 'aim' ? PARTS.armSAim : PARTS.armSD;
    if (pose.state !== 'aim') arm.draw(s, x - 1 + (flip ? 2 : -1), torsoY + 1, flip);
  }

  // ---- torso
  const torso = side ? PARTS.torsoS : back ? PARTS.torsoB : PARTS.torsoF;
  torso.draw(s, x - Math.floor(torso.w / 2) + lean, torsoY, flip);

  // ---- front arm + weapon
  if (side) {
    if (pose.state === 'aim') {
      PARTS.armSAim.draw(s, x - 1 + (flip ? -4 : 0) + lean, torsoY + 2, flip);
      const wx = flip ? x - 12 : x - 1;
      PARTS.wpnS.draw(s, wx + lean, torsoY + 1, flip);
    } else {
      const arm = pose.state === 'walk' ? [PARTS.armSB2, PARTS.armSD, PARTS.armSA, PARTS.armSD][ph] : PARTS.armSD;
      arm.draw(s, x + (flip ? -2 : 1) + lean, torsoY + 1, flip);
      // weapon slung low across the body
      const wx = flip ? x - 9 : x - 3;
      PARTS.wpnS.draw(s, wx + lean, hipY - 3, flip);
    }
  } else {
    if (pose.state === 'aim') {
      PARTS.armFAim.draw(s, x - 3 + lean, torsoY + 3, false);
      PARTS.wpnF.draw(s, x - 5 + lean, torsoY + 3, false);
    } else {
      const armL = pose.state === 'walk' ? [PARTS.armFA, PARTS.armFD, PARTS.armFB, PARTS.armFD][ph] : PARTS.armFD;
      const armR = pose.state === 'walk' ? [PARTS.armFB, PARTS.armFD, PARTS.armFA, PARTS.armFD][ph] : PARTS.armFD;
      armL.draw(s, x - 5, torsoY + 1, false);
      armR.draw(s, x + 3, torsoY + 1, false);
      PARTS.wpnF.draw(s, x - 5 + lean, hipY - 3, false);
    }
  }

  // ---- head
  const head = side ? PARTS.headS : back ? PARTS.headB : PARTS.headF;
  head.draw(s, x - Math.floor(head.w / 2) + lean + (side ? (flip ? -pose.look : pose.look) : 0), headY, flip);

  // ---- scarf accent
  s.set(x + (flip ? 3 : -3) + lean, torsoY + 1, signal.s3);
  s.set(x + (flip ? 4 : -4) + lean, torsoY + 2, signal.s2);
}

/** contact + cast shadow helper for the rig (keeps panels consistent) */
export function rigShadow(s: PixelSurface, x: number, y: number, dirX: number, dirY: number): void {
  s.contactShadow(x, y, 5, 2, withAlpha(mix(slate.s0, warm.w0, 0.4), 110), 0.9);
  for (let i = 0; i < 8; i++) {
    const t = i / 8;
    if (((i * 7) % 4) < 2) continue;
    s.set(x + Math.round(dirX * 6 * t) + (i % 3) - 1, y + Math.round(dirY * 4 * t), withAlpha(mix(slate.s0, warm.w0, 0.4), 70));
  }
}

export { amber };
