import { LAB_LAYOUT } from './kit';
import type { Orient, RigPose, RigState } from './rig';

/**
 * PROJECTION LAB scene state.
 *
 * One shared world timeline drives the character and the drone in ALL six
 * panels, so every projection shows the identical pose at the identical world
 * position at any moment — the only difference between panels is the
 * projection itself.
 */

export const LAB_T = 12; // loop length, seconds

interface Segment {
  t0: number;
  t1: number;
  state: RigState;
  orient: Orient;
  x0: number;
  x1: number;
}

const CHAR_Y = LAB_LAYOUT.character.y;
const SEGMENTS: Segment[] = [
  { t0: 0, t1: 2, state: 'idle', orient: 'e', x0: 88, x1: 88 },
  { t0: 2, t1: 4.5, state: 'walk', orient: 'e', x0: 88, x1: 112 },
  { t0: 4.5, t1: 5.0, state: 'turn', orient: 's', x0: 112, x1: 112 },
  { t0: 5.0, t1: 5.4, state: 'turn', orient: 'w', x0: 112, x1: 112 },
  { t0: 5.4, t1: 7.4, state: 'walk', orient: 'w', x0: 112, x1: 92 },
  { t0: 7.4, t1: 7.9, state: 'turn', orient: 's', x0: 92, x1: 92 },
  { t0: 7.9, t1: 8.3, state: 'turn', orient: 'e', x0: 92, x1: 92 },
  { t0: 8.3, t1: 10.3, state: 'aim', orient: 'e', x0: 92, x1: 92 },
  { t0: 10.3, t1: 12, state: 'idle', orient: 'e', x0: 92, x1: 92 },
];

export interface CharState {
  pose: RigPose;
  x: number;
  y: number;
}

export function charStateAt(t: number): CharState {
  const tt = ((t % LAB_T) + LAB_T) % LAB_T;
  let seg = SEGMENTS[SEGMENTS.length - 1];
  for (const s of SEGMENTS) {
    if (tt >= s.t0 && tt < s.t1) {
      seg = s;
      break;
    }
  }
  const u = (tt - seg.t0) / (seg.t1 - seg.t0);
  const x = seg.x0 + (seg.x1 - seg.x0) * u;
  const phase = seg.state === 'walk' ? Math.floor(u * 8) % 4 : 0;
  const breath = Math.sin(tt * 2.4) > 0.5 ? 1 : 0;
  const look = seg.state === 'idle' && Math.sin(tt * 0.9) > 0.6 ? 1 : 0;
  return {
    x,
    y: CHAR_Y,
    pose: { state: seg.state, phase, orient: seg.orient, breath, look },
  };
}

export interface RobotState {
  x: number;
  y: number;
  flip: boolean;
  alert: boolean;
}

export function robotStateAt(t: number, charX: number): RobotState {
  const period = 7;
  const u = ((t % period) + period) % period / period;
  const tri = u < 0.5 ? u * 2 : 2 - u * 2;
  const x = 116 + tri * 20;
  const flip = u < 0.5 ? false : true;
  const alert = Math.abs(charX - x) < 18;
  return { x, y: LAB_LAYOUT.robot.y, flip: alert ? charX < x : flip, alert };
}

export interface PanelState {
  interior: boolean;
}

export function newPanelStates(): PanelState[] {
  return [0, 1, 2, 3, 4, 5].map(() => ({ interior: false }));
}
