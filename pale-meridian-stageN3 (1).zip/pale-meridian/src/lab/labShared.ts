import { LabGame } from './LabGame';

/** the six bakes are the expensive part; share one instance across mounts */
let shared: LabGame | null = null;
export function getSharedLab(): LabGame {
  if (!shared) shared = new LabGame();
  return shared;
}
