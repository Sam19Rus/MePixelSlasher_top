import { PixelSurface } from '../rendering/PixelSurface';
import { LightingSystem } from '../lighting/LightingSystem';
import { PROFILES, PROFILE_ORDER, Proj, type LabProjectionId } from './profiles';
import { bakeLab, type LabBake } from './kit';
import { charStateAt, robotStateAt, type PanelState } from './LabScene';
import { drawRig, rigShadow } from './rig';
import { drawRobotRig, robotShadow } from './robotRig';
import { drawText, textWidth } from '../rendering/text';
import { metal, cyan, amber, slate } from '../data/palette';
import { mix, packRGBA, withAlpha } from '../rendering/color';

/**
 * PROJECTION LAB renderer: six independent previews of ONE world, differing
 * only by ProjectionProfile. Also draws the dev chrome (labels, parameter
 * readout, hover focus zoom).
 */

export const LAB_W = 960;
export const LAB_H = 540;
export const PW = 320;
export const PH = 270;

export interface LabFrameInput {
  time: number;
  panels: PanelState[];
  hover: number; // -1 none
  showLabels: boolean;
  showParams: boolean;
  lighting: boolean;
}

export class LabRenderer {
  readonly surface = new PixelSurface(LAB_W, LAB_H);
  readonly lighting = new LightingSystem();
  bakes: Record<LabProjectionId, LabBake>;
  private cams: Record<LabProjectionId, { x: number; y: number }> = {} as Record<LabProjectionId, { x: number; y: number }>;
  private pbuf: PixelSurface[] = [0, 1, 2, 3, 4, 5].map(() => new PixelSurface(PW, PH));

  constructor() {
    this.lighting.resize(LAB_W, LAB_H);
    this.bakes = {} as Record<LabProjectionId, LabBake>;
    for (const id of PROFILE_ORDER) this.bakes[id] = bakeLab(new Proj(PROFILES[id]));
  }

  panelRect(i: number): { x: number; y: number } {
    return { x: (i % 3) * PW, y: Math.floor(i / 3) * PH };
  }

  render(inp: LabFrameInput): PixelSurface {
    const s = this.surface;
    s.fill(packRGBA(10, 11, 13));
    this.lighting.enabled = inp.lighting;
    this.lighting.begin();

    const char = charStateAt(inp.time);
    for (let i = 0; i < 6; i++) {
      const id = PROFILE_ORDER[i];
      const pb = this.pbuf[i];
      this.renderPanel(id, i, inp, char, pb);
      const r = this.panelRect(i);
      s.blit(pb, r.x, r.y);
    }
    for (let i = 0; i < 6; i++) {
      const r = this.panelRect(i);
      this.lighting.apply(s, true, { x0: r.x, y0: r.y, x1: r.x + PW - 1, y1: r.y + PH - 1 });
    }

    // panel separators
    for (let i = 0; i < 6; i++) {
      const r = this.panelRect(i);
      s.strokeRect(r.x, r.y, PW, PH, packRGBA(28, 32, 38));
    }

    if (inp.showLabels) this.labels(s, inp);
    if (inp.hover >= 0) this.focus(s, inp);
    else if (inp.showParams) this.params(s, 0);
    return s;
  }

  private renderPanel(id: LabProjectionId, i: number, inp: LabFrameInput, char: ReturnType<typeof charStateAt>, s: PixelSurface): void {
    const pr = new Proj(PROFILES[id]);
    const bake = this.bakes[id];
    const state = inp.panels[i];
    const r = this.panelRect(i);

    // camera centred on the outpost focus
    const [fx, fy] = pr.g(bake.focus.x, bake.focus.y);
    let camX = Math.round(fx + bake.ox - PW / 2);
    let camY = Math.round(fy + bake.oy - PH / 2 + 14);
    camX = Math.max(0, Math.min(bake.width - PW, camX));
    camY = Math.max(0, Math.min(bake.height - PH, camY));
    this.cams[id] = { x: camX, y: camY };

    // ground
    for (let y = 0; y < PH; y++) {
      const sy = camY + y;
      const row = y * PW;
      if (sy < 0 || sy >= bake.height) continue;
      const srcRow = sy * bake.width;
      s.data.set(bake.ground.data.subarray(srcRow + camX, srcRow + camX + PW), row);
    }
    // baked sun shadows (cutaway uses the roof-less layer)
    const shadowLayer = state.interior ? bake.shadowCut : bake.shadow;
    for (let y = 0; y < PH; y++) {
      const sy = camY + y;
      if (sy < 0 || sy >= bake.height) continue;
      const srcRow = sy * bake.width;
      for (let x = 0; x < PW; x++) {
        const c = shadowLayer.data[srcRow + camX + x];
        if (((c >>> 24) & 0xff) === 0) continue;
        const i2 = y * PW + x;
        s.data[i2] = blendOver(s.data[i2], c);
      }
    }

    // objects with cutaway groups
    const objs = bake.objects.filter((o) => {
      if (o.group === 'roof') return !state.interior;
      if (o.group === 'wallStub') return state.interior;
      if (o.group === 'wall') {
        if (state.interior && (o.name === 'wallS' || o.name === 'wallE')) return false;
        return true;
      }
      return true;
    });
    objs.sort((a, b) => a.key - b.key);
    for (const o of objs) {
      s.blit(o.sprite, o.x - camX, o.y - camY);
    }

    // drone + merc (billboards). In cutaway panels the actors stand INSIDE the
    // room so every projection shows them in interior space too.
    const charX = state.interior ? 99 : char.x;
    const charY = state.interior ? 76 : char.y;
    const rob = robotStateAt(inp.time, charX);
    const robX = state.interior ? 112 : rob.x;
    const robY = state.interior ? 62 : rob.y;
    const [rsx, rsy] = pr.g(robX, robY);
    const rbx = Math.round(rsx + bake.ox) - camX;
    const rby = Math.round(rsy + bake.oy) - camY;
    robotShadow(s, rbx, rby, Math.round(Math.sin(inp.time * 2.6) * 1.5));
    drawRobotRig(s, rbx, rby, { t: inp.time, flip: rob.flip, alert: rob.alert });

    const [csx, csy] = pr.g(charX, charY);
    const cbx = Math.round(csx + bake.ox) - camX;
    const cby = Math.round(csy + bake.oy) - camY;
    rigShadow(s, cbx, cby, pr.p.shadow.x, pr.p.shadow.y);
    drawRig(s, cbx, cby, char.pose);

    // lights in frame space, clipped to this panel
    this.lighting.setClip(r.x, r.y, r.x + PW - 1, r.y + PH - 1);
    for (const l of bake.lights) {
      if (l.interiorOnly && !state.interior) continue;
      if (l.exteriorOnly && state.interior) continue;
      const [lx, ly] = pr.g(l.x, l.y);
      this.lighting.addLight(
        { x: lx + bake.ox - camX + r.x, y: ly + bake.oy - camY + r.y, radius: l.r, r: l.c[0], g: l.c[1], b: l.c[2], intensity: l.i, flicker: l.flicker, blink: l.blink },
        inp.time,
        [],
        0,
        0,
      );
    }
    // drone lens + visor glints
    this.lighting.addLight({ x: rbx + r.x, y: rby - 8 + r.y, radius: 10, r: 0.25, g: 0.9, b: 1, intensity: 0.4 }, inp.time, [], 0, 0);
    this.lighting.addLight({ x: cbx + r.x, y: cby - 22 + r.y, radius: 6, r: 0.2, g: 0.8, b: 0.9, intensity: 0.18 }, inp.time, [], 0, 0);
    this.lighting.clearClip();
  }

  private labels(s: PixelSurface, inp: LabFrameInput): void {
    for (let i = 0; i < 6; i++) {
      const id = PROFILE_ORDER[i];
      const r = this.panelRect(i);
      s.rect(r.x + 1, r.y + 1, PW - 2, 11, withAlpha(packRGBA(8, 9, 11), 190));
      drawText(s, r.x + 4, r.y + 4, `${id} - ${PROFILES[id].label}`, metal.m8, {});
      const mode = inp.panels[i].interior ? 'INT' : 'EXT';
      const mw = textWidth(mode);
      drawText(s, r.x + PW - 6 - mw, r.y + 4, mode, inp.panels[i].interior ? cyan.c4 : amber.a4, {});
    }
  }

  private params(s: PixelSurface, i: number): void {
    const id = PROFILE_ORDER[i];
    const p = PROFILES[id];
    const r = this.panelRect(i);
    const bx = r.x + 4;
    const by = r.y + PH - 62;
    s.rect(bx, by, 150, 58, withAlpha(packRGBA(8, 9, 11), 205));
    s.strokeRect(bx, by, 150, 58, withAlpha(slate.s5, 200));
    drawText(s, bx + 4, by + 3, `PROJECTION ${id}`, cyan.c4, {});
    const rows: [string, string][] = [
      ['ANGLE', p.readout.angle],
      ['DEPTH', p.readout.depth],
      ['V-HEIGHT', p.readout.vheight],
      ['ROOF VIS', p.readout.roof],
      ['WALL VIS', p.readout.wall],
    ];
    rows.forEach(([k, v], ri) => {
      drawText(s, bx + 4, by + 11 + ri * 9, k, slate.s6, {});
      drawText(s, bx + 62, by + 11 + ri * 9, v, metal.m8, {});
    });
    drawText(s, bx + 96, by + 11, p.mode.toUpperCase(), amber.a4, {});
  }

  /** hover: 2x nearest-neighbour zoom of the hovered panel + its parameters */
  private focus(s: PixelSurface, inp: LabFrameInput): void {
    const i = inp.hover;
    const ow = PW * 2;
    const oh = PH * 2;
    const ox = Math.floor((LAB_W - ow) / 2);
    const oy = Math.floor((LAB_H - oh) / 2);
    // dim everything outside the overlay
    for (let y = 0; y < LAB_H; y++) {
      for (let x = 0; x < LAB_W; x++) {
        if (x >= ox && x < ox + ow && y >= oy && y < oy + oh) continue;
        s.data[y * LAB_W + x] = mix(s.data[y * LAB_W + x], packRGBA(6, 7, 8), 0.78);
      }
    }
    // 2x nearest zoom of the hovered panel buffer
    const pb = this.pbuf[i];
    for (let y = 0; y < oh; y++) {
      const srow = (y >> 1) * PW;
      const drow = (oy + y) * LAB_W + ox;
      for (let x = 0; x < ow; x++) {
        s.data[drow + x] = pb.data[srow + (x >> 1)];
      }
    }
    s.strokeRect(ox - 1, oy - 1, ow + 2, oh + 2, packRGBA(60, 70, 80));
    s.strokeRect(ox - 2, oy - 2, ow + 4, oh + 4, packRGBA(20, 24, 28));
    // caption
    const id = PROFILE_ORDER[i];
    s.rect(ox, oy + oh - 14, ow, 14, withAlpha(packRGBA(8, 9, 11), 220));
    drawText(s, ox + 6, oy + oh - 10, `${id} - ${PROFILES[id].label}  ·  ${PROFILES[id].note}`, metal.m9, {});
    const p = PROFILES[id];
    drawText(
      s,
      ox + ow - 250,
      oy + oh - 10,
      `ANG ${p.readout.angle}  DEP ${p.readout.depth}  VH ${p.readout.vheight}  ROOF ${p.readout.roof}  WALL ${p.readout.wall}`,
      cyan.c4,
      {},
    );
  }
}

function blendOver(dst: number, src: number): number {
  const sa = (src >>> 24) & 0xff;
  if (sa === 255) return src;
  const isa = 255 - sa;
  const r = ((src & 0xff) * sa + (dst & 0xff) * isa) >> 8;
  const g = (((src >>> 8) & 0xff) * sa + ((dst >>> 8) & 0xff) * isa) >> 8;
  const b = (((src >>> 16) & 0xff) * sa + ((dst >>> 16) & 0xff) * isa) >> 8;
  return (0xff << 24) | (b << 16) | (g << 8) | r;
}
