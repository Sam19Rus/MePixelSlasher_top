/**
 * PROJECTION SYSTEM — one math model, several profiles.
 *
 * Every asset in every scene is baked through `Proj`, so scenes differ only
 * by their ProjectionProfile, never by assets.
 *
 * axis   — oblique 3/4 (scene 1 family): ground identity, top faces sheared.
 * axon   — 2:1 axonometric: ground lattice rotated 45°, two visible walls,
 *          diamond roof planes.
 * tilted — TILTED ORTHOGRAPHIC TOP-DOWN: verticals stay pixel-vertical; the
 *          roof is exactly the ground quad lifted by the wall height; every
 *          wall shares its edges with roof and ground, so masses are closed
 *          coherent boxes. groundShear expresses camera yaw, groundSquash the
 *          pitch foreshortening, hz = sin(tilt) gives wall screen height.
 */

export type ProjectionId = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'SCENE2_AXON' | 'SCENE3_TILTED';
export type LabProjectionId = 'A' | 'B' | 'C' | 'D' | 'E' | 'F';

export interface ProjectionProfile {
  id: ProjectionId;
  label: string;
  mode: 'axis' | 'axon' | 'tilted';
  /** axis mode: depth skew per depth unit (top faces lean) */
  kx: number;
  /** axis mode: depth compression per depth unit (roof visibility) */
  ky: number;
  /** vertical extrusion: px per height unit (tilted: sin of camera tilt) */
  hz: number;
  /** axis mode: east/side face reveal 0..1 */
  side: number;
  /** legacy/lab fields kept for readout continuity */
  wallScale: number;
  groundShear: number;
  groundSquash: number;
  /** ground-plane shadow direction per height unit */
  shadow: { x: number; y: number };
  readout: { angle: string; depth: string; vheight: string; roof: string; wall: string };
  note: string;
}

export const PROFILES: Record<LabProjectionId, ProjectionProfile> = {
  A: {
    id: 'A', label: 'PURE TOP-DOWN', mode: 'axis', kx: 0, ky: 1, hz: 0.14, side: 0.06,
    wallScale: 0.14, groundShear: 0, groundSquash: 1, shadow: { x: 0.22, y: 0.3 },
    readout: { angle: '90°', depth: '0.00', vheight: '0.14', roof: '1.00', wall: '0.06' },
    note: 'control variant: plan, roofs, ground reading',
  },
  B: {
    id: 'B', label: 'LIGHT OBLIQUE', mode: 'axis', kx: 0.1, ky: 0.84, hz: 0.38, side: 0.26,
    wallScale: 0.38, groundShear: 0, groundSquash: 1, shadow: { x: 0.42, y: 0.34 },
    readout: { angle: '78°', depth: '0.10', vheight: '0.38', roof: '0.84', wall: '0.26' },
    note: 'top-down read with a hint of wall height',
  },
  C: {
    id: 'C', label: 'STRONG 3/4', mode: 'axis', kx: 0.3, ky: 0.58, hz: 0.8, side: 0.6,
    wallScale: 0.8, groundShear: 0, groundSquash: 1, shadow: { x: 0.72, y: 0.36 },
    readout: { angle: '58°', depth: '0.30', vheight: '0.80', roof: '0.58', wall: '0.60' },
    note: 'roof + facade + side wall together (scene-1 family)',
  },
  D: {
    id: 'D', label: 'ISOMETRIC / AXON', mode: 'axon', kx: 1, ky: 0.5, hz: 1, side: 1,
    wallScale: 1, groundShear: 0, groundSquash: 1, shadow: { x: 1.1, y: 0.25 },
    readout: { angle: '45°/30°', depth: '2:1', vheight: '1.00', roof: '0.50', wall: '1.00' },
    note: 'classic 2:1 axonometric, two visible walls',
  },
  E: {
    id: 'E', label: 'FREE 2.5D', mode: 'axis', kx: 0.16, ky: 0.5, hz: 1.15, side: 0.8,
    wallScale: 1.15, groundShear: 0, groundSquash: 1, shadow: { x: 0.6, y: 0.4 },
    readout: { angle: '64°', depth: '0.16', vheight: '1.15', roof: '0.50', wall: '0.80' },
    note: 'gameplay-flat ground, tall independent volumes',
  },
  F: {
    id: 'F', label: 'DEEP 2.5D', mode: 'axis', kx: 0.42, ky: 0.42, hz: 1.5, side: 1,
    wallScale: 1.5, groundShear: 0, groundSquash: 1, shadow: { x: 0.9, y: 0.42 },
    readout: { angle: '52°', depth: '0.42', vheight: '1.50', roof: '0.42', wall: '1.00' },
    note: 'bold: strong facades, objects sit inside space',
  },
};

export const PROFILE_ORDER: LabProjectionId[] = ['A', 'B', 'C', 'D', 'E', 'F'];

/**
 * The two shipping projections chosen after the Projection Lab review.
 */
export const SCENE_PROFILES: Record<'scene2' | 'scene3', ProjectionProfile> = {
  scene2: {
    id: 'SCENE2_AXON', label: 'ISOMETRIC / AXONOMETRIC', mode: 'axon',
    kx: 1, ky: 0.5, hz: 1, side: 1, wallScale: 1, groundShear: 0, groundSquash: 1,
    shadow: { x: 1.1, y: 0.25 },
    readout: { angle: '45°/30°', depth: '2:1', vheight: '1.00', roof: '0.50', wall: '1.00' },
    note: 'two visible walls, diamond roofs, classic axonometric volume',
  },
  scene3: {
    id: 'SCENE3_TILTED', label: 'TILTED ORTHOGRAPHIC TOP-DOWN', mode: 'tilted',
    kx: 0.16, ky: 0.88, hz: 0.55, side: 1, wallScale: 1,
    groundShear: 0.16, groundSquash: 0.88,
    shadow: { x: 0.62, y: 0.42 },
    readout: { angle: 'pitch ~33° / yaw ~9°', depth: '0.16', vheight: '0.55', roof: '0.88', wall: '1.00' },
    note: 'closed coherent boxes: roof + real walls sharing edges',
  },
};

export interface FaceQuad {
  pts: number[][];
  origin: [number, number];
  u: [number, number];
  v: [number, number];
  uw: number;
  vh: number;
}

export class Proj {
  constructor(public p: ProjectionProfile) {}

  get id(): ProjectionId {
    return this.p.id;
  }

  /** world ground point -> screen point */
  g(x: number, y: number): [number, number] {
    if (this.p.mode === 'axon') return [x - y, (x + y) * 0.5];
    if (this.p.mode === 'tilted') return [x + this.p.groundShear * y, this.p.groundSquash * y];
    return [x, y];
  }

  /** inverse of g() (for terrain baking) */
  inv(sx: number, sy: number): [number, number] {
    if (this.p.mode === 'axon') return [sy + sx / 2, sy - sx / 2];
    if (this.p.mode === 'tilted') {
      const y = sy / this.p.groundSquash;
      return [sx - this.p.groundShear * y, y];
    }
    return [sx, sy];
  }

  /** screen height of a world height (walls, extrusions) */
  lift(h: number): number {
    return Math.round(h * this.p.hz);
  }

  /**
   * Centralised depth key: view-direction coordinate of a ground anchor.
   * Everything (masses, furniture, props, actors) sorts through this single
   * function plus baseZ/group biases — no per-object pixel offsets.
   */
  depthKey(x: number, y: number): number {
    if (this.p.mode === 'axon') return x + y;
    if (this.p.mode === 'tilted') return y + x * this.p.groundShear * 0.5;
    return y;
  }

  /** full depth of a renderable: anchor depth + base height + group bias */
  depth(x: number, y: number, baseZ = 0, bias = 0): number {
    return this.depthKey(x, y) + baseZ * 0.02 + bias;
  }

  /**
   * The visible faces of an axis-aligned box.
   * Footprint: front-left corner (x, y), width w (east), depth d (north),
   * height h (world units).
   */
  box(x: number, y: number, w: number, d: number, h: number): { top: FaceQuad; front: FaceQuad; east: FaceQuad; west: FaceQuad } {
    if (this.p.mode === 'tilted') return this.tiltedBox(x, y, w, d, h);
    if (this.p.mode === 'axon') return this.axonBox(x, y, w, d, this.lift(h));
    // axis / oblique
    const H = this.lift(h);
    const kx = this.p.kx;
    const ky = this.p.ky;
    const sd = this.p.side;
    const ex = kx * d * sd;
    const ey = ky * d;
    const [ox, oy] = this.g(x, y);
    const front: FaceQuad = {
      pts: [
        [ox, oy],
        [ox + w, oy],
        [ox + w, oy - H],
        [ox, oy - H],
      ],
      origin: [ox, oy - H],
      u: [1, 0],
      v: [0, 1],
      uw: w,
      vh: H,
    };
    const top: FaceQuad = {
      pts: [
        [ox, oy - H],
        [ox + w, oy - H],
        [ox + w + kx * d, oy - H - ky * d],
        [ox + kx * d, oy - H - ky * d],
      ],
      origin: [ox, oy - H],
      u: [1, 0],
      v: [kx, -ky],
      uw: w,
      vh: d,
    };
    const east: FaceQuad = {
      pts: [
        [ox + w, oy],
        [ox + w + ex, oy - ey],
        [ox + w + ex, oy - ey - H],
        [ox + w, oy - H],
      ],
      origin: [ox + w, oy],
      u: [ex / Math.max(1, d), -ey / Math.max(1, d)],
      v: [0, -1],
      uw: d,
      vh: H,
    };
    const west: FaceQuad = {
      pts: [
        [ox, oy],
        [ox + ex, oy - ey],
        [ox + ex, oy - ey - H],
        [ox, oy - H],
      ],
      origin: [ox, oy],
      u: [ex / Math.max(1, d), -ey / Math.max(1, d)],
      v: [0, -1],
      uw: d,
      vh: H,
    };
    return { top, front, east, west };
  }

  /**
   * Tilted orthographic box: verticals vertical; roof = ground quad lifted by
   * H; south/east/west walls are exact parallelograms sharing edges with the
   * roof and the ground plane => always a closed, coherent volume.
   */
  private tiltedBox(x: number, y: number, w: number, d: number, h: number): { top: FaceQuad; front: FaceQuad; east: FaceQuad; west: FaceQuad } {
    const H = this.lift(h);
    const G = (gx: number, gy: number, up = 0): [number, number] => {
      const p = this.g(gx, gy);
      return [p[0], p[1] - up];
    };
    const nw = G(x, y);
    const ne = G(x + w, y);
    const se = G(x + w, y + d);
    const sw = G(x, y + d);
    const top: FaceQuad = {
      pts: [G(x, y, H), G(x + w, y, H), G(x + w, y + d, H), G(x, y + d, H)],
      origin: G(x, y, H),
      u: [1, 0],
      v: [this.p.groundShear, this.p.groundSquash],
      uw: w,
      vh: d,
    };
    const front: FaceQuad = {
      pts: [
        [sw[0], sw[1] - H],
        [se[0], se[1] - H],
        [se[0], se[1]],
        [sw[0], sw[1]],
      ],
      origin: [sw[0], sw[1] - H],
      u: [1, 0],
      v: [0, 1],
      uw: w,
      vh: H,
    };
    const east: FaceQuad = {
      pts: [
        [se[0], se[1]],
        [ne[0], ne[1]],
        [ne[0], ne[1] - H],
        [se[0], se[1] - H],
      ],
      origin: [ne[0], ne[1] - H],
      u: [this.p.groundShear, this.p.groundSquash],
      v: [0, 1],
      uw: d,
      vh: H,
    };
    const west: FaceQuad = {
      pts: [
        [sw[0], sw[1]],
        [nw[0], nw[1]],
        [nw[0], nw[1] - H],
        [sw[0], sw[1] - H],
      ],
      origin: [nw[0], nw[1] - H],
      u: [this.p.groundShear, this.p.groundSquash],
      v: [0, 1],
      uw: d,
      vh: H,
    };
    return { top, front, east, west };
  }

  /** 2:1 axonometric box: south + east walls visible, diamond top. */
  private axonBox(x: number, y: number, w: number, d: number, H: number): { top: FaceQuad; front: FaceQuad; east: FaceQuad; west: FaceQuad } {
    const A = this.g(x, y + d); // screen-left corner (south-west)
    const Bc = this.g(x + w, y + d); // screen-bottom corner (south-east)
    const C = this.g(x + w, y); // screen-right corner (north-east)
    const Dd = this.g(x, y); // screen-top corner (north-west)
    const front: FaceQuad = {
      pts: [
        [A[0], A[1]],
        [Bc[0], Bc[1]],
        [Bc[0], Bc[1] - H],
        [A[0], A[1] - H],
      ],
      origin: [A[0], A[1] - H],
      u: [(Bc[0] - A[0]) / w, (Bc[1] - A[1]) / w],
      v: [0, 1],
      uw: w,
      vh: H,
    };
    const east: FaceQuad = {
      pts: [
        [Bc[0], Bc[1]],
        [C[0], C[1]],
        [C[0], C[1] - H],
        [Bc[0], Bc[1] - H],
      ],
      origin: [Bc[0], Bc[1] - H],
      u: [(C[0] - Bc[0]) / d, (C[1] - Bc[1]) / d],
      v: [0, 1],
      uw: d,
      vh: H,
    };
    const top: FaceQuad = {
      pts: [
        [A[0], A[1] - H],
        [Bc[0], Bc[1] - H],
        [C[0], C[1] - H],
        [Dd[0], Dd[1] - H],
      ],
      origin: [A[0], A[1] - H],
      u: [(Bc[0] - A[0]) / w, (Bc[1] - A[1]) / w],
      v: [(Dd[0] - A[0]) / d, (Dd[1] - A[1]) / d],
      uw: w,
      vh: d,
    };
    return { top, front, east, west: east };
  }

  /** map a face-local (u, v) in [0..uw, 0..vh] to screen */
  fpx(f: FaceQuad, u: number, v: number): [number, number] {
    return [Math.round(f.origin[0] + f.u[0] * u + f.v[0] * v), Math.round(f.origin[1] + f.u[1] * u + f.v[1] * v)];
  }

  /** ground quad of a footprint (for decals, pads, shadows) */
  quad(x: number, y: number, w: number, d: number): number[][] {
    return [this.g(x, y), this.g(x + w, y), this.g(x + w, y + d), this.g(x, y + d)];
  }
}
