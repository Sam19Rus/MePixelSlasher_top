import { Input } from '../input/Input';
import { LabRenderer } from './LabRenderer';
import { newPanelStates } from './LabScene';

/**
 * PROJECTION LAB orchestrator: shared clock, per-panel exterior/interior
 * state, hover selection and the review keys.
 *
 *   F1  labels on/off (clean comparison)
 *   F2  lighting on/off
 *   F3  exterior/interior for the hovered (or last clicked) panel
 *   F4  projection parameter readout
 *   1-6 toggle exterior/interior of panel A-F
 *   mouse hover = focus zoom · click = toggle that panel
 */
export class LabGame {
  readonly renderer = new LabRenderer();
  readonly input = new Input();
  time = 0;
  panels = newPanelStates();
  hover = -1;
  selected = 2; // panel C by default
  showLabels = true;
  showParams = false;
  lighting = true;

  update(dt: number): void {
    this.time += dt;
    if (this.input.consume('F1')) this.showLabels = !this.showLabels;
    if (this.input.consume('F2')) this.lighting = !this.lighting;
    if (this.input.consume('F3')) {
      const i = this.hover >= 0 ? this.hover : this.selected;
      this.panels[i].interior = !this.panels[i].interior;
      this.selected = i;
    }
    if (this.input.consume('F4')) this.showParams = !this.showParams;
    const digits = ['Digit1', 'Digit2', 'Digit3', 'Digit4', 'Digit5', 'Digit6'];
    digits.forEach((d, i) => {
      if (this.input.consume(d)) {
        this.panels[i].interior = !this.panels[i].interior;
        this.selected = i;
      }
    });
    this.input.endFrame();
  }

  render() {
    return this.renderer.render({
      time: this.time,
      panels: this.panels,
      hover: this.hover,
      showLabels: this.showLabels,
      showParams: this.showParams,
      lighting: this.lighting,
    });
  }
}
