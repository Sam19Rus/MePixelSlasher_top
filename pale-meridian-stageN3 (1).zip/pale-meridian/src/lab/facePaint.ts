import { Color, mix } from '../rendering/color';
import { bayer4 } from '../rendering/dither';
import { PixelSurface } from '../rendering/PixelSurface';
import type { FaceQuad } from './profiles';
import { Proj } from './profiles';

/**
 * Face-local painting: every detail (seams, windows, vents, stencils) is drawn
 * in a face's own (u, v) lattice and mapped to screen integers. That is what
 * lets one asset description serve all six projections without resampling.
 */

export function fillFace(s: PixelSurface, f: FaceQuad, c: Color): void {
  s.polygon(f.pts, c);
}

/** dithered ramp along the face's v axis (top->bottom or front->back) */
export function faceRampV(s: PixelSurface, f: FaceQuad, from: Color, to: Color, steps = 4): void {
  for (let i = 0; i < f.vh; i++) {
    const t = f.vh === 1 ? 0 : i / (f.vh - 1);
    const q = Math.round(t * (steps - 1)) / (steps - 1);
    const c = mix(from, to, q);
    const [x0, y0] = [f.origin[0] + f.v[0] * i, f.origin[1] + f.v[1] * i];
    const [x1, y1] = [x0 + f.u[0] * f.uw, y0 + f.u[1] * f.uw];
    s.line(Math.round(x0), Math.round(y0), Math.round(x1), Math.round(y1), c);
  }
}

/** rectangle inside a face, in face-local coords */
export function faceRect(s: PixelSurface, f: FaceQuad, u0: number, v0: number, uw: number, vh: number, c: Color): void {
  const p = (u: number, v: number): [number, number] => [
    Math.round(f.origin[0] + f.u[0] * u + f.v[0] * v),
    Math.round(f.origin[1] + f.u[1] * u + f.v[1] * v),
  ];
  const a = p(u0, v0);
  const b = p(u0 + uw, v0);
  const c2 = p(u0 + uw, v0 + vh);
  const d = p(u0, v0 + vh);
  s.polygon([a, b, c2, d], c);
}

export function faceLine(s: PixelSurface, f: FaceQuad, u0: number, v0: number, u1: number, v1: number, c: Color): void {
  const a: [number, number] = [
    Math.round(f.origin[0] + f.u[0] * u0 + f.v[0] * v0),
    Math.round(f.origin[1] + f.u[1] * u0 + f.v[1] * v0),
  ];
  const b: [number, number] = [
    Math.round(f.origin[0] + f.u[0] * u1 + f.v[0] * v1),
    Math.round(f.origin[1] + f.u[1] * u1 + f.v[1] * v1),
  ];
  s.line(a[0], a[1], b[0], b[1], c);
}

export function facePx(s: PixelSurface, f: FaceQuad, u: number, v: number, c: Color): void {
  const x = Math.round(f.origin[0] + f.u[0] * u + f.v[0] * v);
  const y = Math.round(f.origin[1] + f.u[1] * u + f.v[1] * v);
  s.set(x, y, c);
}

/** dithered shade over a face (AO / light falloff), amount 0..1 */
export function faceShade(s: PixelSurface, f: FaceQuad, c: Color, amount: number): void {
  for (let v = 0; v < f.vh; v++) {
    for (let u = 0; u < f.uw; u++) {
      if (bayer4(u, v) > amount) continue;
      facePx(s, f, u, v, c);
    }
  }
}

/** outline a face quad with a 1px contour */
export function faceOutline(s: PixelSurface, f: FaceQuad, c: Color): void {
  for (let i = 0; i < f.pts.length; i++) {
    const a = f.pts[i];
    const b = f.pts[(i + 1) % f.pts.length];
    s.line(Math.round(a[0]), Math.round(a[1]), Math.round(b[0]), Math.round(b[1]), c);
  }
}

/** ground decal quad through the projection */
export function groundQuad(s: PixelSurface, pr: Proj, x: number, y: number, w: number, d: number, c: Color): void {
  s.polygon(pr.quad(x, y, w, d), c);
}
