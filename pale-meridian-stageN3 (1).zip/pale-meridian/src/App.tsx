import { useEffect, useState } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { N2View } from './components/N2View';
import { N3View } from './components/N3View';

/**
 * PALE MERIDIAN working flow (Stage N3):
 *   1 = Scene 1 (stage-1 approved benchmark)
 *   2 = N2 — Scene 1 world in the tilted-orthographic projection
 *   3 = N3 — FINAL CAMERA benchmark (CrossCode/UNSIGHTED-style top-down
 *       with a subtle RimWorld wall lean)
 *   TAB cycles. Older stage views remain in git history & archives.
 */
type Mode = 'scene1' | 'n2' | 'n3';
const ORDER: Mode[] = ['scene1', 'n2', 'n3'];

export default function App() {
  const [mode, setMode] = useState<Mode>('scene1');

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Tab') {
        e.preventDefault();
        setMode((m) => ORDER[(ORDER.indexOf(m) + 1) % ORDER.length]);
      }
      if (e.code === 'Digit1') setMode('scene1');
      if (e.code === 'Digit2') setMode('n2');
      if (e.code === 'Digit3') setMode('n3');
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div style={{ width: '100%', height: '100%' }}>
      {mode === 'scene1' ? <GameCanvas /> : mode === 'n2' ? <N2View /> : <N3View />}
    </div>
  );
}
