import { useEffect, useRef, useState } from 'react';
import { CameraLab, INTERNAL_RES } from '../lab3d/CameraLab';
import { PRESET_ORDER } from '../lab3d/cameraRig';
import type { PostSettings } from '../lab3d/post';

interface LabHud {
  camText: string;
  preset: string;
  res: string;
  tod: string;
  settings: PostSettings;
  shadows: boolean;
  highQuality: boolean;
  cutaway: boolean;
  showHud: boolean;
}

/**
 * Scene 4 host: real 3D scene, free camera, pixel-art output.
 * Mouse: drag orbit · wheel zoom · middle/shift+drag pan.
 * Keys: P preset · R reset · C copy config · V ortho/persp · arrows orbit ·
 * -/= zoom · WASD pan · F1 hud · F2 shadows · F3 time of day · F4 outline ·
 * F5 internal res · F6 dither · F7 posterize · F8 light quality · K sheet.
 */
export function CameraLabView() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const labRef = useRef<CameraLab | null>(null);
  const stateRef = useRef({
    settings: { dither: true, posterize: 8, outline: true, vignette: true } as PostSettings,
    shadows: true,
    highQuality: true,
    tod: 'dusk' as 'day' | 'dusk' | 'night',
    resKey: 'PIXEL480' as keyof typeof INTERNAL_RES,
    showHud: true,
  });
  const [hud, setHud] = useState<LabHud | null>(null);

  useEffect(() => {
    const lab = new CameraLab(canvasRef.current!);
    labRef.current = lab;
    lab.setTOD('dusk');
    lab.resizeCanvas();

    const fit = () => {
      const res = INTERNAL_RES[stateRef.current.resKey];
      const f = Math.max(1, Math.floor(Math.min(window.innerWidth / res[0], window.innerHeight / res[1])));
      const c = canvasRef.current!;
      c.style.width = `${res[0] * f}px`;
      c.style.height = `${res[1] * f}px`;
    };
    fit();
    window.addEventListener('resize', fit);

    // ---- mouse
    const canvas = canvasRef.current!;
    let dragging: 'orbit' | 'pan' | null = null;
    let lx = 0;
    let ly = 0;
    const down = (e: MouseEvent) => {
      if (e.button === 1 || (e.button === 0 && e.shiftKey)) dragging = 'pan';
      else if (e.button === 0) dragging = 'orbit';
      lx = e.clientX;
      ly = e.clientY;
      e.preventDefault();
    };
    const move = (e: MouseEvent) => {
      if (!dragging) return;
      const dx = e.clientX - lx;
      const dy = e.clientY - ly;
      lx = e.clientX;
      ly = e.clientY;
      if (dragging === 'orbit') lab.rig.orbit(-dx * 0.4, dy * 0.3);
      else lab.rig.pan(-dx * 0.02, dy * 0.02);
    };
    const up = () => {
      dragging = null;
    };
    const wheel = (e: WheelEvent) => {
      lab.rig.zoom(e.deltaY > 0 ? 1.5 : -1.5);
      e.preventDefault();
    };
    canvas.addEventListener('mousedown', down);
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    canvas.addEventListener('wheel', wheel, { passive: false });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    // ---- keys
    const keys = new Set<string>();
    const kd = (e: KeyboardEvent) => {
      const st = stateRef.current;
      switch (e.code) {
        case 'KeyP': {
          const i = PRESET_ORDER.indexOf(lab.rig.presetName);
          lab.rig.applyPreset(PRESET_ORDER[(i + 1) % PRESET_ORDER.length]);
          break;
        }
        case 'KeyR':
          lab.rig.reset();
          break;
        case 'KeyV':
          lab.rig.toggleMode();
          break;
        case 'KeyC': {
          const txt = lab.rig.format();
          navigator.clipboard?.writeText(txt).catch(() => undefined);
          (window as unknown as { __camCopy?: string }).__camCopy = txt;
          break;
        }
        case 'KeyK': {
          const sheet = lab.captureSheet(st.settings);
          (window as unknown as { __labSheet?: string }).__labSheet = sheet.toDataURL('image/png');
          const a = document.createElement('a');
          a.href = sheet.toDataURL('image/png');
          a.download = 'pale-meridian-camera-sheet.png';
          a.click();
          break;
        }
        case 'F1':
          st.showHud = !st.showHud;
          e.preventDefault();
          break;
        case 'F2':
          st.shadows = !st.shadows;
          lab.outpost.setShadows(st.shadows);
          e.preventDefault();
          break;
        case 'F3':
          st.tod = st.tod === 'dusk' ? 'night' : st.tod === 'night' ? 'day' : 'dusk';
          lab.setTOD(st.tod);
          e.preventDefault();
          break;
        case 'F4':
          st.settings.outline = !st.settings.outline;
          e.preventDefault();
          break;
        case 'F5': {
          const order: (keyof typeof INTERNAL_RES)[] = ['PIXEL480', 'PIXEL320', 'PIXEL240'];
          st.resKey = order[(order.indexOf(st.resKey) + 1) % 3];
          lab.setInternalRes(INTERNAL_RES[st.resKey]);
          lab.resizeCanvas();
          fit();
          e.preventDefault();
          break;
        }
        case 'F6':
          st.settings.dither = !st.settings.dither;
          e.preventDefault();
          break;
        case 'F7':
          st.settings.posterize = st.settings.posterize === 8 ? 0 : st.settings.posterize === 16 ? 8 : st.settings.posterize + 4;
          e.preventDefault();
          break;
        case 'F8':
          st.highQuality = !st.highQuality;
          lab.outpost.setLightQuality(st.highQuality);
          e.preventDefault();
          break;
        case 'KeyH':
          lab.toggleCutaway();
          break;
        case 'Minus':
          lab.rig.zoom(1.5);
          break;
        case 'Equal':
          lab.rig.zoom(-1.5);
          break;
        default:
          keys.add(e.code);
      }
    };
    const ku = (e: KeyboardEvent) => keys.delete(e.code);
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);

    // ---- tooling hook for headless screenshots
    (window as unknown as { __camLab?: CameraLab }).__camLab = lab;
    (window as unknown as { __labShots?: () => Record<string, string> }).__labShots = () => {
      const out: Record<string, string> = {};
      const views = ['TOP-DOWN', 'TILTED ORTHO', 'STRONG 3/4', 'SHALLOW 3/4', 'LOW'];
      views.forEach((v, i) => {
        lab.rig.applyPreset(v);
        lab.frame(0, stateRef.current.settings);
        out[String.fromCharCode(65 + i)] = lab.renderer.domElement.toDataURL('image/png');
      });
      out.SHEET = lab.captureSheet(stateRef.current.settings).toDataURL('image/png');
      return out;
    };

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      // keyboard camera fallback
      if (keys.has('ArrowLeft')) lab.rig.orbit(-60 * dt, 0);
      if (keys.has('ArrowRight')) lab.rig.orbit(60 * dt, 0);
      if (keys.has('ArrowUp')) lab.rig.orbit(0, 40 * dt);
      if (keys.has('ArrowDown')) lab.rig.orbit(0, -40 * dt);
      if (keys.has('KeyW')) lab.rig.pan(0, -8 * dt);
      if (keys.has('KeyS')) lab.rig.pan(0, 8 * dt);
      if (keys.has('KeyA')) lab.rig.pan(-8 * dt, 0);
      if (keys.has('KeyD')) lab.rig.pan(8 * dt, 0);
      lab.frame(dt, stateRef.current.settings);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const sync = window.setInterval(() => {
      const st = stateRef.current;
      setHud({
        camText: lab.rig.format(),
        preset: lab.rig.presetName,
        res: `${INTERNAL_RES[st.resKey][0]}x${INTERNAL_RES[st.resKey][1]}`,
        tod: st.tod,
        settings: { ...st.settings },
        shadows: st.shadows,
        highQuality: st.highQuality,
        cutaway: lab.cutaway,
        showHud: st.showHud,
      });
    }, 150);

    return () => {
      cancelAnimationFrame(raf);
      clearInterval(sync);
      window.removeEventListener('resize', fit);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      canvas.removeEventListener('mousedown', down);
      canvas.removeEventListener('wheel', wheel);
      lab.renderer.dispose();
    };
  }, []);

  const mono: React.CSSProperties = {
    fontFamily: 'ui-monospace, Menlo, Consolas, monospace',
    fontSize: 11,
    lineHeight: '15px',
    letterSpacing: 0.3,
  };

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#07080a' }}>
      <canvas ref={canvasRef} style={{ imageRendering: 'pixelated' }} />
      {hud?.showHud && (
        <div
          style={{
            ...mono,
            position: 'absolute',
            left: 12,
            top: 12,
            padding: '8px 10px',
            background: 'rgba(10,12,14,0.85)',
            border: '1px solid #232a31',
            borderLeft: '2px solid #25aebc',
            color: '#9aa5ad',
            whiteSpace: 'pre',
            userSelect: 'none',
          }}
        >
          {`SCENE 4 · 3D PIXEL ART CAMERA LAB
preset: ${hud.preset}
${hud.camText}

PIXEL
res: ${hud.res} (F5)
dither: ${hud.settings.dither ? 'on' : 'off'} (F6)
posterize: ${hud.settings.posterize || 'off'} (F7)
outline: ${hud.settings.outline ? 'on' : 'off'} (F4)
shadows: ${hud.shadows ? 'on' : 'off'} (F2)
cutaway: ${hud.cutaway ? 'on' : 'off'} (H)
light q: ${hud.highQuality ? 'high' : 'low'} (F8)
time: ${hud.tod.toUpperCase()} (F3)

MOUSE drag orbit · wheel zoom · shift+drag pan
KEYS P preset · R reset · V mode · C copy · K sheet
1-3 scenes · 5 showcase · TAB cycle`}
        </div>
      )}
    </div>
  );
}
