import { useEffect, useRef, useState } from 'react';
import { N3Scene } from '../n3/N3Scene';
import { VIEW_H, VIEW_W } from '../data/config';
import { Input } from '../input/Input';

/** N3 host: software pixel render + integer upscale + minimal HUD. */
export function N3View() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const sceneRef = useRef<N3Scene | null>(null);
  if (!sceneRef.current) sceneRef.current = new N3Scene();
  const [hud, setHud] = useState({ show: true, tod: 'dusk', lighting: true, zone: 'ext' as 'ext' | 'int', cam: 'TARGET 42°' });

  useEffect(() => {
    const scene = sceneRef.current!;
    const input = new Input();
    input.attach(window);
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const off = document.createElement('canvas');
    off.width = VIEW_W;
    off.height = VIEW_H;
    const offCtx = off.getContext('2d')!;
    const img = offCtx.createImageData(VIEW_W, VIEW_H);
    const img32 = new Uint32Array(img.data.buffer);

    const resize = () => {
      const f = Math.max(1, Math.floor(Math.min(window.innerWidth / VIEW_W, window.innerHeight / VIEW_H)));
      canvas.width = VIEW_W * f;
      canvas.height = VIEW_H * f;
      canvas.style.width = `${VIEW_W * f}px`;
      canvas.style.height = `${VIEW_H * f}px`;
      ctx.imageSmoothingEnabled = false;
    };
    resize();
    window.addEventListener('resize', resize);

    const kd = (e: KeyboardEvent) => {
      if (e.code === 'F1') {
        setHud((h) => ({ ...h, show: !h.show }));
        e.preventDefault();
      }
      if (e.code === 'F2') {
        scene.review.lighting = !scene.review.lighting;
        e.preventDefault();
      }
      if (e.code === 'F3') {
        scene.review.timeOfDay = scene.review.timeOfDay === 'dusk' ? 'night' : scene.review.timeOfDay === 'night' ? 'day' : 'dusk';
        e.preventDefault();
      }
    };
    window.addEventListener('keydown', kd);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.max(0, Math.min(0.05, (now - last) / 1000));
      last = now;
      scene.update(dt, input);
      const frame = scene.render();
      img32.set(frame.data);
      offCtx.putImageData(img, 0, 0);
      ctx.drawImage(off, 0, 0, canvas.width, canvas.height);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const sync = window.setInterval(() => {
      setHud((h) => ({ ...h, tod: scene.review.timeOfDay, lighting: scene.review.lighting, zone: scene.zone, cam: scene.camLabel }));
    }, 200);
    return () => {
      cancelAnimationFrame(raf);
      clearInterval(sync);
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', kd);
      input.detach(window);
    };
  }, []);

  const mono: React.CSSProperties = { fontFamily: 'ui-monospace, Menlo, Consolas, monospace', fontSize: 11, lineHeight: '15px', letterSpacing: 0.3 };
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#07080a' }}>
      <canvas ref={canvasRef} style={{ imageRendering: 'pixelated' }} />
      {hud.show && (
        <div style={{ ...mono, position: 'absolute', left: 12, top: 12, padding: '8px 10px', background: 'rgba(10,12,14,0.85)', border: '1px solid #232a31', borderLeft: '2px solid #25aebc', color: '#9aa5ad', whiteSpace: 'pre', userSelect: 'none' }}>
          {`N3 · FINAL CAMERA BENCHMARK
view: ${hud.zone === 'int' ? 'CUTAWAY INTERIOR' : 'EXTERIOR'}
camera: ${hud.cam} · wall lean 2°
time: ${hud.tod.toUpperCase()} · lighting: ${hud.lighting ? 'on' : 'off'}

E cutaway · [ ] camera pitch
F1 hud · F2 lighting · F3 time
1 = Scene 1 · 2 = N2 · 3 = N3 · TAB cycle`}
        </div>
      )}
    </div>
  );
}
