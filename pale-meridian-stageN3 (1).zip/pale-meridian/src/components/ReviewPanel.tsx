export interface HudQuality {
  preset: string;
  lightShadows: boolean;
  sunShadows: boolean;
  entityShadows: boolean;
  ambientFx: boolean;
  atmosphere: boolean;
  budget: string;
}

export interface HudState {
  showUi: boolean;
  lighting: boolean;
  tod: string;
  debug: boolean;
  fps: number;
  zone: 'ext' | 'int';
  q: HudQuality;
}

const mono: React.CSSProperties = {
  fontFamily: 'ui-monospace, "SF Mono", Menlo, Consolas, monospace',
  fontSize: 11,
  lineHeight: '16px',
  letterSpacing: 0.4,
};

/**
 * STYLE REVIEW overlay.
 *
 * A review tool, not game UI: it exists so the art direction can be judged
 * quickly — hide all chrome, kill the light pass, flip time of day, or look at
 * collision/light radii. F1..F4 work with the panel hidden too.
 */
export function ReviewPanel({ hud }: { hud: HudState }) {
  if (!hud.showUi) {
    return (
      <div style={{ ...mono, position: 'absolute', right: 10, bottom: 8, color: '#5b6672', opacity: 0.75, userSelect: 'none' }}>
        F1 — show review panel
      </div>
    );
  }
  const row = (k: string, v: string, on: boolean) => (
    <div key={k} style={{ display: 'flex', gap: 8, justifyContent: 'space-between' }}>
      <span style={{ color: on ? '#8ceeee' : '#5b6672' }}>{k}</span>
      <span style={{ color: on ? '#d8dee2' : '#5b6672' }}>{v}</span>
    </div>
  );
  return (
    <div
      style={{
        ...mono,
        position: 'absolute',
        left: 12,
        top: 12,
        padding: '10px 12px',
        background: 'rgba(10,12,14,0.82)',
        border: '1px solid #232a31',
        borderLeft: '2px solid #25aebc',
        color: '#9aa5ad',
        minWidth: 232,
        userSelect: 'none',
        backdropFilter: 'blur(2px)',
      }}
    >
      <div style={{ color: '#e6e3d4', fontSize: 12, marginBottom: 2, letterSpacing: 1.4 }}>PALE MERIDIAN</div>
      <div style={{ color: '#5b6672', marginBottom: 8 }}>visual benchmark · stage 1 · frontier outpost</div>
      <div style={{ borderTop: '1px solid #232a31', paddingTop: 6, marginBottom: 6, color: '#7d8a90' }}>
        <div>WASD / arrows — move · Shift — run</div>
        <div>E — enter / leave the module</div>
      </div>
      <div style={{ borderTop: '1px solid #232a31', paddingTop: 6 }}>
        <div style={{ color: '#7d8a90', marginBottom: 4 }}>STYLE REVIEW</div>
        {row('F1', hud.showUi ? 'hud: on' : 'hud: off', true)}
        {row('F2', hud.lighting ? 'lighting: on' : 'lighting: OFF', hud.lighting)}
        {row('F3', `time: ${hud.tod.toUpperCase()}`, hud.tod !== 'day')}
        {row('F4', hud.debug ? 'debug: on' : 'debug: off', hud.debug)}
      </div>
      <div style={{ borderTop: '1px solid #232a31', paddingTop: 6, marginTop: 6 }}>
        <div style={{ color: '#7d8a90', marginBottom: 4 }}>
          QUALITY · <span style={{ color: hud.q.preset === 'performance' ? '#fbc45c' : hud.q.preset === 'cinematic' ? '#8ceeee' : '#d8dee2' }}>{hud.q.preset.toUpperCase()}</span>
        </div>
        {row('F5', 'preset cycle', true)}
        {row('1', `lamp shadows: ${hud.q.lightShadows ? 'on' : 'off'}`, hud.q.lightShadows)}
        {row('2', `sun shadows: ${hud.q.sunShadows ? 'on' : 'off'}`, hud.q.sunShadows)}
        {row('3', `entity shadows: ${hud.q.entityShadows ? 'on' : 'off'}`, hud.q.entityShadows)}
        {row('4', `ambient fx: ${hud.q.ambientFx ? 'on' : 'off'}`, hud.q.ambientFx)}
        {row('5', `atmosphere: ${hud.q.atmosphere ? 'on' : 'off'}`, hud.q.atmosphere)}
        {row('6', `light budget: ${hud.q.budget}`, hud.q.budget !== '8')}
      </div>
      <div style={{ borderTop: '1px solid #232a31', marginTop: 6, paddingTop: 6, display: 'flex', justifyContent: 'space-between', color: '#5b6672' }}>
        <span>{hud.zone === 'ext' ? 'EXT · pad 02' : 'INT · module 07'}</span>
        <span>{hud.fps} fps</span>
      </div>
    </div>
  );
}
