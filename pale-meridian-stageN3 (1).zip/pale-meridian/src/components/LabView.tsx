import { useEffect, useRef, useState } from 'react';
import { LabGame } from '../lab/LabGame';
import { LAB_H, LAB_W, PH, PW } from '../lab/LabRenderer';
import { getSharedLab } from '../lab/labShared';

/**
 * PROJECTION LAB view: integer-scaled 960x540 software frame + mouse
 * hover/click mapping onto the six panels.
 */
export function LabView() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const gameRef = useRef<LabGame | null>(null);
  if (!gameRef.current) gameRef.current = getSharedLab();
  const [hint, setHint] = useState(true);

  useEffect(() => {
    const game = gameRef.current!;
    game.input.attach(window);
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const off = document.createElement('canvas');
    off.width = LAB_W;
    off.height = LAB_H;
    const offCtx = off.getContext('2d')!;
    const img = offCtx.createImageData(LAB_W, LAB_H);
    const img32 = new Uint32Array(img.data.buffer);

    const resize = () => {
      const f = Math.max(1, Math.floor(Math.min(window.innerWidth / LAB_W, window.innerHeight / LAB_H)));
      canvas.width = LAB_W * f;
      canvas.height = LAB_H * f;
      canvas.style.width = `${LAB_W * f}px`;
      canvas.style.height = `${LAB_H * f}px`;
      ctx.imageSmoothingEnabled = false;
    };
    resize();
    window.addEventListener('resize', resize);

    const toPanel = (e: MouseEvent): number => {
      const rect = canvas.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * LAB_W;
      const y = ((e.clientY - rect.top) / rect.height) * LAB_H;
      if (x < 0 || y < 0 || x >= LAB_W || y >= LAB_H) return -1;
      const col = Math.min(2, Math.floor(x / PW));
      const row = Math.min(1, Math.floor(y / PH));
      return row * 3 + col;
    };
    const onMove = (e: MouseEvent) => {
      game.hover = toPanel(e);
    };
    const onClick = (e: MouseEvent) => {
      const i = toPanel(e);
      if (i >= 0) {
        game.panels[i].interior = !game.panels[i].interior;
        game.selected = i;
      }
    };
    canvas.addEventListener('mousemove', onMove);
    canvas.addEventListener('click', onClick);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.max(0, Math.min(0.05, (now - last) / 1000));
      last = now;
      game.update(dt);
      const frame = game.render();
      img32.set(frame.data);
      offCtx.putImageData(img, 0, 0);
      ctx.drawImage(off, 0, 0, canvas.width, canvas.height);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const t = window.setTimeout(() => setHint(false), 6000);

    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(t);
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousemove', onMove);
      canvas.removeEventListener('click', onClick);
      game.input.detach(window);
    };
  }, []);

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#07080a' }}>
      <canvas ref={canvasRef} style={{ imageRendering: 'pixelated', boxShadow: '0 0 0 1px #1a1d22, 0 24px 80px rgba(0,0,0,0.7)' }} />
      {hint && (
        <div
          style={{
            position: 'absolute',
            left: '50%',
            transform: 'translateX(-50%)',
            bottom: 10,
            fontFamily: 'ui-monospace, Menlo, Consolas, monospace',
            fontSize: 11,
            color: '#9aa5ad',
            background: 'rgba(10,12,14,0.85)',
            border: '1px solid #232a31',
            padding: '6px 10px',
            letterSpacing: 0.4,
          }}
        >
          PROJECTION LAB · hover = focus zoom · click / 1-6 = EXT↔INT · F1 labels · F2 lighting · F3 int for selected · F4 params · TAB = scene 1
        </div>
      )}
    </div>
  );
}
