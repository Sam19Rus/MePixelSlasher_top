import { useEffect, useRef, useState } from 'react';
import { getOutpost, SCENE_TITLES } from '../scenes/registry';
import { VIEW_H, VIEW_W } from '../data/config';
import { TIME_OF_DAY } from '../lighting/LightingSystem';
import { sharedInput } from '../input/sharedInput';
/**
 * Full-screen host for scenes 2/3: integer-scaled 480x270 software frame,
 * review keys (F1..F4) and a minimal HUD that reads as game chrome, not as a
 * test tool.
 */
export function PlayView({ sceneKey }: { sceneKey: 'scene2' | 'scene3' }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const sceneRef = useRef(getOutpost(sceneKey));
  const [hud, setHud] = useState({ show: true, lighting: true, tod: 'dusk', debug: false, zone: 'ext' });

  useEffect(() => {
    const scene = sceneRef.current;
    sharedInput.attach(window);
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const off = document.createElement('canvas');
    off.width = VIEW_W;
    off.height = VIEW_H;
    const offCtx = off.getContext('2d')!;
    const img = offCtx.createImageData(VIEW_W, VIEW_H);
    const img32 = new Uint32Array(img.data.buffer);

    const resize = () => {
      const f = Math.max(1, Math.floor(Math.min(window.innerWidth / VIEW_W, window.innerHeight / VIEW_H)));
      canvas.width = VIEW_W * f;
      canvas.height = VIEW_H * f;
      canvas.style.width = `${VIEW_W * f}px`;
      canvas.style.height = `${VIEW_H * f}px`;
      ctx.imageSmoothingEnabled = false;
    };
    resize();
    window.addEventListener('resize', resize);

    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'F1') scene.reviewShow = !scene.reviewShow;
      if (e.code === 'F2') scene.review.lighting = !scene.review.lighting;
      if (e.code === 'F3') {
        const order = ['dusk', 'night', 'day'] as const;
        scene.review.timeOfDay = order[(order.indexOf(scene.review.timeOfDay) + 1) % 3];
      }
      if (e.code === 'F4') scene.review.debug = !scene.review.debug;
    };
    window.addEventListener('keydown', onKey);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.max(0, Math.min(0.05, (now - last) / 1000));
      last = now;
      scene.update(dt, sharedInput);
      const frame = scene.render();
      img32.set(frame.data);
      offCtx.putImageData(img, 0, 0);
      ctx.drawImage(off, 0, 0, canvas.width, canvas.height);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const sync = window.setInterval(() => {
      setHud({ show: scene.reviewShow, lighting: scene.review.lighting, tod: scene.review.timeOfDay, debug: scene.review.debug, zone: scene.zone });
    }, 200);
    return () => {
      cancelAnimationFrame(raf);
      clearInterval(sync);
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', onKey);
      sharedInput.detach(window);
    };
  }, []);

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#07080a' }}>
      <canvas ref={canvasRef} style={{ imageRendering: 'pixelated', boxShadow: '0 0 0 1px #1a1d22, 0 24px 80px rgba(0,0,0,0.7)' }} />
      {hud.show && (
        <div
          style={{
            position: 'absolute',
            left: 12,
            top: 12,
            padding: '8px 10px',
            background: 'rgba(10,12,14,0.82)',
            border: '1px solid #232a31',
            borderLeft: '2px solid #25aebc',
            fontFamily: 'ui-monospace, Menlo, Consolas, monospace',
            fontSize: 11,
            lineHeight: '16px',
            color: '#9aa5ad',
            letterSpacing: 0.4,
            userSelect: 'none',
          }}
        >
          <div style={{ color: '#e6e3d4', fontSize: 12, letterSpacing: 1.2 }}>{SCENE_TITLES[sceneKey]}</div>
          <div style={{ color: '#5b6672' }}>WASD move · Shift run · Space aim · E enter/exit · 1/2/3 or TAB scene</div>
          <div style={{ color: '#5b6672' }}>
            F1 hud · F2 lighting:{hud.lighting ? 'on' : 'OFF'} · F3 {TIME_OF_DAY[hud.tod as keyof typeof TIME_OF_DAY].label} · F4 debug:{hud.debug ? 'on' : 'off'}
          </div>
          <div style={{ color: hud.zone === 'int' ? '#8ceeee' : '#fbc45c' }}>{hud.zone === 'int' ? 'INTERIOR · cutaway' : 'EXTERIOR'}</div>
        </div>
      )}
    </div>
  );
}
