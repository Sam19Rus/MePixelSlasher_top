import { useEffect, useRef } from 'react';
import { ShowcaseScene } from '../scenes/showcase';
import { VIEW_H, VIEW_W } from '../data/config';
import { Input } from '../input/Input';

/** Dedicated review page for the composite character rig (3x scale). */
export function ShowcaseView() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const sceneRef = useRef<ShowcaseScene | null>(null);
  if (!sceneRef.current) sceneRef.current = new ShowcaseScene();

  useEffect(() => {
    const scene = sceneRef.current!;
    const input = new Input();
    input.attach(window);
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const off = document.createElement('canvas');
    off.width = VIEW_W;
    off.height = VIEW_H;
    const offCtx = off.getContext('2d')!;
    const img = offCtx.createImageData(VIEW_W, VIEW_H);
    const img32 = new Uint32Array(img.data.buffer);

    const resize = () => {
      const f = Math.max(1, Math.floor(Math.min(window.innerWidth / VIEW_W, window.innerHeight / VIEW_H)));
      canvas.width = VIEW_W * f;
      canvas.height = VIEW_H * f;
      canvas.style.width = `${VIEW_W * f}px`;
      canvas.style.height = `${VIEW_H * f}px`;
      ctx.imageSmoothingEnabled = false;
    };
    resize();
    window.addEventListener('resize', resize);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.max(0, Math.min(0.05, (now - last) / 1000));
      last = now;
      scene.update(dt, input);
      const frame = scene.render();
      img32.set(frame.data);
      offCtx.putImageData(img, 0, 0);
      ctx.drawImage(off, 0, 0, canvas.width, canvas.height);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      input.detach(window);
    };
  }, []);

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#07080a' }}>
      <canvas ref={canvasRef} style={{ imageRendering: 'pixelated', boxShadow: '0 0 0 1px #1a1d22, 0 24px 80px rgba(0,0,0,0.7)' }} />
    </div>
  );
}
