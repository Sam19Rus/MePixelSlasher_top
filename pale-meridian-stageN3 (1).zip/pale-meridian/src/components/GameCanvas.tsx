import { useEffect, useRef, useState } from 'react';
import { Game, getSharedGame } from '../game/Game';
import { VIEW_H, VIEW_W } from '../data/config';
import { ReviewPanel, type HudQuality } from './ReviewPanel';
import { presetOf } from '../data/quality';

/**
 * The only DOM-aware part of the project: a nearest-neighbour upscale of the
 * 480x270 software-rendered frame. No CSS scaling of game art, no smoothing —
 * the pixel grid is preserved exactly at any window size.
 */
export function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const gameRef = useRef<Game | null>(null);
  if (!gameRef.current) gameRef.current = getSharedGame();
  const [hud, setHud] = useState({
    showUi: true,
    lighting: true,
    tod: 'dusk',
    debug: false,
    fps: 0,
    zone: 'ext' as 'ext' | 'int',
    q: { preset: 'cinematic', lightShadows: true, sunShadows: true, entityShadows: true, ambientFx: true, atmosphere: true, budget: 'all' } as HudQuality,
  });

  useEffect(() => {
    const game = gameRef.current!;
    game.input.attach(window);
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const off = document.createElement('canvas');
    off.width = VIEW_W;
    off.height = VIEW_H;
    const offCtx = off.getContext('2d')!;
    const img = offCtx.createImageData(VIEW_W, VIEW_H);
    const img32 = new Uint32Array(img.data.buffer);

    const resize = () => {
      const f = Math.max(1, Math.floor(Math.min(window.innerWidth / VIEW_W, window.innerHeight / VIEW_H)));
      canvas.width = VIEW_W * f;
      canvas.height = VIEW_H * f;
      canvas.style.width = `${VIEW_W * f}px`;
      canvas.style.height = `${VIEW_H * f}px`;
      ctx.imageSmoothingEnabled = false;
    };
    resize();
    window.addEventListener('resize', resize);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      // rAF timestamps can precede the performance.now() captured at mount
      // (and StrictMode mounts twice), so the first delta may be negative
      const dt = Math.max(0, Math.min(0.05, (now - last) / 1000));
      last = now;
      game.update(dt);
      const frame = game.render();
      if (game.review.debug) game.drawDebug(frame);
      img32.set(frame.data);
      offCtx.putImageData(img, 0, 0);
      ctx.drawImage(off, 0, 0, canvas.width, canvas.height);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const sync = window.setInterval(() => {
      setHud({
        showUi: game.review.showUi,
        lighting: game.review.lighting,
        tod: game.review.timeOfDay,
        debug: game.review.debug,
        fps: game.fps,
        zone: game.zone,
        q: {
          preset: presetOf(game.quality),
          lightShadows: game.quality.lightShadows,
          sunShadows: game.quality.sunShadows,
          entityShadows: game.quality.entityShadows,
          ambientFx: game.quality.ambientFx,
          atmosphere: game.quality.atmosphere,
          budget: game.quality.lightBudget === Infinity ? 'all' : String(game.quality.lightBudget),
        },
      });
    }, 200);

    return () => {
      cancelAnimationFrame(raf);
      clearInterval(sync);
      window.removeEventListener('resize', resize);
      game.input.detach(window);
    };
  }, []);

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#07080a' }}>
      <canvas ref={canvasRef} style={{ imageRendering: 'pixelated', boxShadow: '0 0 0 1px #1a1d22, 0 24px 80px rgba(0,0,0,0.7)' }} />
      <ReviewPanel hud={hud} />
    </div>
  );
}
