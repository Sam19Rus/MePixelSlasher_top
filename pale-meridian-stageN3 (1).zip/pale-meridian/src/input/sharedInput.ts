import { Input } from './Input';

/**
 * One keyboard state shared by every scene, so switching scenes never drops
 * held keys and only one set of window listeners exists per mounted view.
 */
export const sharedInput = new Input();
