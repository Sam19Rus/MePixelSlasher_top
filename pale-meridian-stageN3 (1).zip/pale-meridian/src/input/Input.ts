/** Keyboard input, edge-triggered actions included. */
export class Input {
  private down = new Set<string>();
  private pressed = new Set<string>();

  private onDown: ((e: KeyboardEvent) => void) | null = null;
  private onUp: ((e: KeyboardEvent) => void) | null = null;
  private onBlur: (() => void) | null = null;

  attach(target: Window): void {
    this.detach(target);
    this.onDown = (e) => {
      if (e.repeat) return;
      const k = this.norm(e.code);
      this.down.add(k);
      this.pressed.add(k);
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
    };
    this.onUp = (e) => {
      this.down.delete(this.norm(e.code));
    };
    this.onBlur = () => {
      this.down.clear();
    };
    target.addEventListener('keydown', this.onDown);
    target.addEventListener('keyup', this.onUp);
    target.addEventListener('blur', this.onBlur);
  }

  detach(target: Window): void {
    if (this.onDown) target.removeEventListener('keydown', this.onDown);
    if (this.onUp) target.removeEventListener('keyup', this.onUp);
    if (this.onBlur) target.removeEventListener('blur', this.onBlur);
    this.onDown = this.onUp = this.onBlur = null;
    this.down.clear();
    this.pressed.clear();
  }

  private norm(code: string): string {
    return code;
  }

  isDown(...codes: string[]): boolean {
    return codes.some((c) => this.down.has(c));
  }

  /** true only on the frame the key went down */
  consume(...codes: string[]): boolean {
    for (const c of codes) {
      if (this.pressed.has(c)) {
        this.pressed.delete(c);
        return true;
      }
    }
    return false;
  }

  endFrame(): void {
    this.pressed.clear();
  }

  /** test / tooling hook: synthetic key down (also registers an edge) */
  press(code: string): void {
    this.down.add(code);
    this.pressed.add(code);
  }

  /** test / tooling hook: synthetic key up */
  release(code: string): void {
    this.down.delete(code);
  }

  axis(): { x: number; y: number } {
    let x = 0;
    let y = 0;
    if (this.isDown('KeyA', 'ArrowLeft')) x -= 1;
    if (this.isDown('KeyD', 'ArrowRight')) x += 1;
    if (this.isDown('KeyW', 'ArrowUp')) y -= 1;
    if (this.isDown('KeyS', 'ArrowDown')) y += 1;
    if (x !== 0 && y !== 0) {
      x *= 0.7071;
      y *= 0.7071;
    }
    return { x, y };
  }

  get running(): boolean {
    return this.isDown('ShiftLeft', 'ShiftRight');
  }
}
