import { PixelSurface } from '../rendering/PixelSurface';
import { bakeExteriorGround } from '../assets/terrain';
import { bakeBuilding, buildingShadow } from '../assets/architecture';
import * as props from '../assets/props';
import { mix, packRGBA, withAlpha } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { makeRng } from '../rendering/noise';
import { SUN, WORLD_H, WORLD_W } from '../data/config';
import { B, COLLIDERS, L } from '../data/layout';
import { amber, cyan, dust, metal, signal } from '../data/palette';
import type { LightDef } from '../lighting/LightingSystem';

/**
 * EXTERIOR SCENE ASSEMBLY.
 *
 * Bakes the ground, the building and every static prop into buffers, pre-
 * computes their sun shadows into a separate layer, and exposes the light
 * list + dynamic overlays (steam, fan, screens, beacon) for the renderer.
 */

export interface StaticSprite {
  sprite: PixelSurface;
  /** top-left in world space */
  x: number;
  y: number;
  /** ground-anchor y, used for depth sorting */
  gy: number;
  /** extra sort bias (tall thin things should not occlude wrongly) */
  bias?: number;
}

export interface DynamicOverlay {
  /** 'cheap' overlays survive the performance preset; 'full' ones are FX */
  cost?: 'cheap' | 'full';
  draw: (s: PixelSurface, t: number, camX: number, camY: number) => void;
}

export interface ExteriorScene {
  ground: PixelSurface;
  shadow: PixelSurface;
  statics: StaticSprite[];
  colliders: typeof COLLIDERS;
  lights: (t: number) => LightDef[];
  dynamics: DynamicOverlay[];
  doorZone: typeof L.doorZone;
  doorReturn: typeof L.doorReturn;
  playerSpawn: typeof L.playerSpawn;
  robotPatrol: { x: number; y: number }[];
}

export function buildExterior(): ExteriorScene {
  const { ground, shadow } = bakeExteriorGround();
  const statics: StaticSprite[] = [];
  const rnd = makeRng(2024);

  // building + its sun shadow
  const b = bakeBuilding();
  const bsh = buildingShadow();
  shadow.blit(bsh.surface, bsh.origin.x, bsh.origin.y);
  statics.push({ sprite: b.sprite, x: b.origin.x, y: b.origin.y, gy: B.hall.y + 2, bias: -6 });

  // ---- props
  const place = (p: props.Prop, x: number, y: number, castShadow = true, bias = 0) => {
    const tx = x - p.ax;
    const ty = y - p.ay;
    statics.push({ sprite: p.sprite, x: tx, y: ty, gy: y, bias });
    if (castShadow) {
      shadow.castShadow(p.sprite, tx, ty + p.sprite.height - 1, SUN.dirX, SUN.dirY, SUN.heightScale * 0.8, packRGBA(40, 23, 20, 96), 0.85);
    }
    return p;
  };

  const gen = place(props.generator(), L.generator.x, L.generator.y);
  const cont = place(props.container(), L.container.x, L.container.y);
  const mastP = place(props.mast(), L.mast.x, L.mast.y, true, -30);
  const flood = place(props.floodPole(), L.floodPole.x, L.floodPole.y, true, -30);
  place(props.cart(), L.cart.x, L.cart.y);
  place(props.scrapPile(), L.scrapPile.x, L.scrapPile.y);
  place(props.barrier(), L.barrier.x, L.barrier.y);
  place(props.targetDummy(), L.dummy.x, L.dummy.y);
  place(props.cableSpool(), 508, 428);
  place(props.ventUnit(), 470, 372);
  place(props.pipeSupport(), 560, 356);
  place(props.groundLamp(), 306, 386);
  place(props.groundLamp(), 396, 386);
  place(props.groundLamp(), 512, 404);
  const crates = [props.crate('lg', 0), props.crate('md', 1), props.crate('sm', 2)];
  place(crates[0], L.crates[0].x, L.crates[0].y);
  place(crates[1], L.crates[1].x, L.crates[1].y);
  place(crates[2], L.crates[2].x, L.crates[2].y);
  const drums = [props.drum(0), props.drum(1), props.drum(2)];
  place(drums[0], L.drums[0].x, L.drums[0].y);
  place(drums[1], L.drums[1].x, L.drums[1].y);
  place(drums[2], L.drums[2].x, L.drums[2].y);

  // a few extra authored beats: pipes from the generator into the building
  const pipe = props.pipeSupport();
  place(pipe, 500, 372);

  // foreground framing: a big dark boulder + a cable run at the south edge
  place(props.boulder(), 168, 552, true, 4);
  place(props.boulder(), 606, 566, true, 4);

  // contact shadows for small things that don't cast long ones
  for (const st of statics) {
    shadow.contactShadow(st.x + st.sprite.width / 2, st.gy, Math.min(10, st.sprite.width / 3), 3, packRGBA(35, 20, 18, 90), 0.8);
  }

  // ------------------------------------------------------------ lights
  const lights = (t: number): LightDef[] => {
    void t;
    return [
      // porch + door
      { x: B.porch.x + 25, y: B.porch.y - 16, radius: 46, r: 1, g: 0.68, b: 0.34, intensity: 0.6, flicker: 0.05, castShadows: true },
      { x: B.door.x + 11, y: B.door.y - 14, radius: 18, r: 1, g: 0.62, b: 0.32, intensity: 0.42 },
      // hall walkway lamp
      { x: B.hall.x + 68, y: B.hall.y - 20, radius: 26, r: 1, g: 0.68, b: 0.34, intensity: 0.5, flicker: 0.12 },
      // module status screen
      { x: B.module.x + 50, y: B.module.y - 25, radius: 15, r: 0.22, g: 0.85, b: 0.95, intensity: 0.45, flicker: 0.2 },
      // beacon
      { x: B.module.x + 12, y: B.module.y - B.module.h - 31, radius: 12, r: 1, g: 0.2, b: 0.16, intensity: 0.6, blink: 2.2 },
      // generator
      { x: L.generator.x + 4, y: L.generator.y - 20, radius: 26, r: 1, g: 0.5, b: 0.2, intensity: 0.6, flicker: 0.25 },
      // flood light
      { x: L.floodPole.x + 1, y: L.floodPole.y - 33, radius: 52, r: 1, g: 0.74, b: 0.42, intensity: 0.6, flicker: 0.03, castShadows: true },
      // ground lamps
      { x: 306, y: 380, radius: 22, r: 1, g: 0.7, b: 0.36, intensity: 0.5 },
      { x: 396, y: 380, radius: 22, r: 1, g: 0.7, b: 0.36, intensity: 0.5 },
      { x: 512, y: 398, radius: 20, r: 1, g: 0.7, b: 0.36, intensity: 0.45 },
      // mast beacon
      { x: L.mast.x, y: L.mast.y - 65, radius: 10, r: 1, g: 0.22, b: 0.18, intensity: 0.5, blink: 3.1 },
      // crate LED + container reflection
      { x: L.crates[0].x + 8, y: L.crates[0].y - 10, radius: 8, r: 0.2, g: 0.9, b: 1, intensity: 0.35, pulse: 1.7 },
    ];
  };

  // ------------------------------------------------------------ dynamics
  const dynamics: DynamicOverlay[] = [];

  // steam from the hall exhaust stack
  dynamics.push({
    cost: 'full',
    draw: (s, t, camX, camY) => {
      const vx = B.hall.x + 99;
      const vy = B.hall.y - B.hall.h - 24;
      for (let i = 0; i < 3; i++) {
        const p = (t * 0.32 + i / 3) % 1;
        const px = Math.round(vx + Math.sin((p * 4 + i) * 2) * 2 - camX);
        const py = Math.round(vy - p * 16 - camY);
        const a = 1 - p;
        const w = 1 + Math.round(p * 3);
        for (let dy = 0; dy < w; dy++) {
          for (let dx = -w; dx <= w; dx++) {
            const d = Math.hypot(dx / w, dy / w);
            if (d > 1) continue;
            if (bayer8(px + dx, py + dy) > a * 0.8 - d * 0.3) continue;
            s.blend(px + dx, py + dy, withAlpha(mix(dust.d8, metal.m8, 0.4), 120));
          }
        }
      }
    },
  });

  // garage roof fan: 2-frame rotation
  dynamics.push({
    cost: 'cheap',
    draw: (s, t, camX, camY) => {
      const fx = B.garage.x + 17;
      const fy = B.garage.y - B.garage.h - 12;
      const frame = Math.floor(t * 6) % 2;
      const x = Math.round(fx - camX);
      const y = Math.round(fy - camY);
      s.ellipse(x, y, 6, 3, metal.m1);
      if (frame === 0) {
        s.hline(x - 5, y, 11, metal.m5);
        s.set(x, y - 1, metal.m4);
        s.set(x, y + 1, metal.m4);
      } else {
        s.line(x - 4, y - 2, x + 4, y + 2, metal.m5);
        s.line(x - 4, y + 2, x + 4, y - 2, metal.m5);
      }
      s.set(x, y, metal.m7);
    },
  });

  // module screen flicker
  dynamics.push({
    cost: 'cheap',
    draw: (s, t, camX, camY) => {
      const x = Math.round(B.module.x + 45 - camX);
      const y = Math.round(B.module.y - 29 - camY);
      const scan = Math.floor(t * 8) % 8;
      s.hline(x, y + scan, 11, withAlpha(cyan.c4, 90));
      if (Math.floor(t * 2) % 7 === 3) s.rect(x + 2, y + 2, 5, 1, withAlpha(cyan.c5, 160));
    },
  });

  // beacon blink sprite pixels
  dynamics.push({
    cost: 'cheap',
    draw: (s, t, camX, camY) => {
      const on = t % 2.2 < 0.35;
      const x = Math.round(B.module.x + 12 - camX);
      const y = Math.round(B.module.y - B.module.h - 31 - camY);
      s.set(x, y, on ? signal.s4 : signal.s1);
      if (on) {
        s.set(x - 1, y, withAlpha(signal.s3, 160));
        s.set(x + 1, y, withAlpha(signal.s3, 160));
        s.set(x, y - 1, withAlpha(signal.s3, 160));
      }
      const on2 = t % 3.1 < 0.4;
      const mx = Math.round(L.mast.x - camX);
      const my = Math.round(L.mast.y - 65 - camY);
      s.set(mx, my, on2 ? signal.s4 : signal.s1);
    },
  });

  // generator heat shimmer + vent pulse
  dynamics.push({
    cost: 'cheap',
    draw: (s, t, camX, camY) => {
      const x = Math.round(L.generator.x + 4 - camX);
      const y = Math.round(L.generator.y - 20 - camY);
      const p = (Math.sin(t * 5) + 1) / 2;
      s.hline(x - 5, y - 1 + Math.round(p), 10, withAlpha(amber.a5, 60 + Math.round(p * 60)));
      s.hline(x - 4, y + 1, 8, withAlpha(amber.a3, 90));
    },
  });

  // dust motes drifting in the light (very sparse, 1px)
  dynamics.push({
    cost: 'full',
    draw: (s, t, camX, camY) => {
      for (let i = 0; i < 26; i++) {
        const seed = i * 97.13;
        const px = Math.round((Math.sin(seed) * 0.5 + 0.5) * WORLD_W + t * (4 + (i % 5))) % WORLD_W;
        const py = Math.round((Math.cos(seed * 1.7) * 0.5 + 0.5) * WORLD_H + Math.sin(t * 0.6 + i) * 6);
        const sx = Math.round(px - camX);
        const sy = Math.round(py - camY);
        if (sx < 0 || sy < 0 || sx >= s.width || sy >= s.height) continue;
        if (bayer4(i, Math.floor(t * 2)) < 0.5) continue;
        s.blend(sx, sy, withAlpha(dust.d9, 70));
      }
    },
  });

  void rnd;
  void cont;
  void mastP;
  void flood;
  void gen;

  return {
    ground,
    shadow,
    statics,
    colliders: COLLIDERS,
    lights,
    dynamics,
    doorZone: L.doorZone,
    doorReturn: L.doorReturn,
    playerSpawn: L.playerSpawn,
    robotPatrol: L.robotPatrol.map((p) => ({ x: p.x, y: p.y })),
  };
}

