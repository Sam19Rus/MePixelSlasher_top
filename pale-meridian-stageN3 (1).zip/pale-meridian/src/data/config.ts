/**
 * Global constants for the benchmark scene.
 */

/** Logical (pixel-art) resolution of one frame. */
export const VIEW_W = 480;
export const VIEW_H = 270;

/** Exterior world size in logical pixels — deliberately small and dense. */
export const WORLD_W = 780;
export const WORLD_H = 580;

/** Interior room footprint. */
export const ROOM_W = 480;
export const ROOM_H = 270;

/**
 * Oblique 3/4 projection.
 *
 * The ground plane is the world plane (movement, collision and the baked
 * terrain all live in it). Anything with *height* is extruded straight up on
 * screen, and anything with *depth* (a roof, a floor plate, a ground decal)
 * is sheared along this vector. That is what produces visible top faces and
 * visible east faces without ever becoming strict isometric.
 */
export const PROJ = {
  /** horizontal shift per unit of depth */
  kx: 0.34,
  /** vertical compression per unit of depth */
  ky: 0.6,
} as const;

/** Sun: high and to the north-west, so shadows fall south-east. */
export const SUN = {
  /** ground-plane direction the shadow travels, per pixel of object height */
  dirX: 0.82,
  dirY: 0.44,
  /** how "tall" a sprite pixel counts as when projecting its shadow */
  heightScale: 0.72,
} as const;

/** Player tuning. */
export const PLAYER = {
  walkSpeed: 52, // logical px / second
  runSpeed: 84,
  accel: 620,
  friction: 520,
  radius: 4.5,
} as const;

/** Camera tuning. */
export const CAMERA = {
  follow: 7.5, // exponential smoothing rate
  maxDelta: 90,
} as const;

export const DOOR_PROMPT_DISTANCE = 26;
