import { Color, hex } from '../rendering/color';

/**
 * MASTER PALETTE — "Pale Meridian", frontier outpost on a dusty world.
 *
 * One curated, deliberately small set of ramps is shared by terrain,
 * architecture, props, characters and UI. Every sprite in the project picks
 * its colours from here, which is what keeps the whole scene reading as a
 * single hand-painted world instead of a pile of unrelated assets.
 *
 * Direction: warm ochre dust + muted industrial metals + dark teal glass,
 * with small, high-value cyan / amber emissive accents doing the storytelling.
 */

/** Alien dust / soil. */
export const dust = {
  void: hex('#1a120e'),
  d0: hex('#2b1e17'),
  d1: hex('#3d2b1f'),
  d2: hex('#54392a'),
  d3: hex('#6e4c34'),
  d4: hex('#8a6242'),
  d5: hex('#a3794f'),
  d6: hex('#bd9362'),
  d7: hex('#d3ad78'),
  d8: hex('#e6c894'),
  d9: hex('#f4ddb2'),
} as const;

/** Cool rock / boulders (reads as "not dirt", gives the ground variety). */
export const rock = {
  r0: hex('#171417'),
  r1: hex('#2a2528'),
  r2: hex('#3f383a'),
  r3: hex('#574d4c'),
  r4: hex('#71645c'),
  r5: hex('#8c7d6c'),
  r6: hex('#a6967f'),
  r7: hex('#bfae94'),
} as const;

/** Distant haze bands — atmospheric depth at the horizon. */
export const haze = {
  h0: hex('#3b2e30'),
  h1: hex('#574243'),
  h2: hex('#75584f'),
  h3: hex('#94705c'),
  h4: hex('#b18c6c'),
} as const;

/** Off-white / dusty cream structural metal (main building shell). */
export const metal = {
  m0: hex('#14161a'),
  m1: hex('#23272d'),
  m2: hex('#343a42'),
  m3: hex('#484f59'),
  m4: hex('#616a74'),
  m5: hex('#7d868e'),
  m6: hex('#9aa1a4'),
  m7: hex('#b6b8b0'),
  m8: hex('#cfd0c4'),
  m9: hex('#e6e3d4'),
  mA: hex('#f6f2e4'),
} as const;

/** Rusty red / dark red technical module + corrosion. */
export const rust = {
  x0: hex('#1a0d0b'),
  x1: hex('#331712'),
  x2: hex('#52251a'),
  x3: hex('#733520'),
  x4: hex('#934727'),
  x5: hex('#b05f31'),
  x6: hex('#c97b41'),
  x7: hex('#dd9c60'),
  x8: hex('#ecbc85'),
} as const;

/** Dark teal glass, seals and trim. */
export const teal = {
  t0: hex('#06141a'),
  t1: hex('#0d2831'),
  t2: hex('#143d4a'),
  t3: hex('#1c5665'),
  t4: hex('#267280'),
  t5: hex('#3b939c'),
  t6: hex('#63b3b6'),
} as const;

/** Cyan emissive (screens, sensors, coolant, holo). */
export const cyan = {
  c0: hex('#08303a'),
  c1: hex('#0f5663'),
  c2: hex('#17818f'),
  c3: hex('#25aebc'),
  c4: hex('#4fd4dc'),
  c5: hex('#8ceeee'),
  c6: hex('#ccfbff'),
  c7: hex('#f0ffff'),
} as const;

/** Warm emissive (sodium lamps, warning beacons, exhaust). */
export const amber = {
  a0: hex('#3d1e07'),
  a1: hex('#6d360c'),
  a2: hex('#9d5312'),
  a3: hex('#c9781c'),
  a4: hex('#e9a02c'),
  a5: hex('#fbc45c'),
  a6: hex('#ffdf94'),
  a7: hex('#fff2c8'),
} as const;

/** Warm gunmetal — ground-level scrap, deck plates, machinery in dust light. */
export const warm = {
  w0: hex('#171312'),
  w1: hex('#282220'),
  w2: hex('#3b332e'),
  w3: hex('#514740'),
  w4: hex('#6a5d52'),
  w5: hex('#867765'),
  w6: hex('#a2937c'),
  w7: hex('#bdb094'),
} as const;

/** Interior slate / gunmetal. */
export const slate = {
  s0: hex('#0d1013'),
  s1: hex('#161b20'),
  s2: hex('#20272d'),
  s3: hex('#2b343b'),
  s4: hex('#3a454d'),
  s5: hex('#4c5962'),
  s6: hex('#63707a'),
  s7: hex('#7d8a90'),
  s8: hex('#9aa5a6'),
} as const;

/** Muted hazard / industrial stripe. */
export const hazard = {
  h0: hex('#45340e'),
  h1: hex('#6d5415'),
  h2: hex('#98761e'),
  h3: hex('#bd972b'),
  h4: hex('#dcb646'),
  h5: hex('#efd477'),
} as const;

/** Olive-drab fabric / webbing / undersuit. */
export const olive = {
  o0: hex('#151a12'),
  o1: hex('#232b1c'),
  o2: hex('#354028'),
  o3: hex('#4a5636'),
  o4: hex('#616d47'),
  o5: hex('#7b875c'),
  o6: hex('#96a074'),
} as const;

/** Skin (only ever a few pixels — face under the helmet). */
export const skin = {
  k0: hex('#4a2c22'),
  k1: hex('#6d4433'),
  k2: hex('#8d5d43'),
  k3: hex('#ab7954'),
} as const;

/** Oil, grime, burnt residue. */
export const grime = {
  g0: hex('#0e0c0c'),
  g1: hex('#1a1614'),
  g2: hex('#262019'),
  g3: hex('#332a20'),
} as const;

/** Faction accent — a dull signal red used on banners and markings. */
export const signal = {
  s0: hex('#2a0f12'),
  s1: hex('#4d1a1c'),
  s2: hex('#77282a'),
  s3: hex('#a03a35'),
  s4: hex('#c25b45'),
} as const;

/** Pure reference points. */
export const base = {
  black: hex('#000000'),
  white: hex('#ffffff'),
  outline: hex('#100d0e'),
  shadow: hex('#1b1210'),
} as const;

/** Flat list of every palette entry — used by the palette preview tool. */
export const ALL_RAMPS: Record<string, Record<string, Color>> = {
  dust,
  rock,
  haze,
  metal,
  rust,
  teal,
  cyan,
  amber,
  slate,
  warm,
  hazard,
  olive,
  skin,
  grime,
  signal,
};

/** Convenience: the four-step "shadow / mid / light / rim" set for dust. */
export const dustRamp: Color[] = [dust.d1, dust.d3, dust.d5, dust.d7, dust.d8];
export const metalRamp: Color[] = [metal.m1, metal.m3, metal.m5, metal.m7, metal.m9];
export const slateRamp: Color[] = [slate.s1, slate.s3, slate.s5, slate.s7];
