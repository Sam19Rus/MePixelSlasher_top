/**
 * Authored layout of the benchmark scene — the single source of truth for
 * where everything sits in the exterior world. Terrain baking, architecture,
 * props, collision and lighting all read from here so the composition stays
 * exactly as designed.
 */

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Main building masses. `y` is always the ground line of the front face. */
export const B = {
  /** low west wing (crew block) */
  westWing: { x: 216, y: 334, w: 46, h: 40, d: 36 },
  /** main hall (cream panels) */
  hall: { x: 258, y: 336, w: 148, h: 58, d: 46 },
  /** central rusty tech module, protrudes forward, carries the entrance */
  module: { x: 306, y: 342, w: 62, h: 88, d: 30 },
  /** east garage / store */
  garage: { x: 402, y: 336, w: 74, h: 44, d: 40 },
  /** entrance porch canopy */
  porch: { x: 312, y: 342, w: 50, h: 26, d: 14 },
  /** door opening in the module front face */
  door: { x: 326, y: 342, w: 22, h: 26 },
} as const;

/** Walkable-world furniture (exterior). */
export const L = {
  /** compacted landing / work pad in front of the entrance */
  pad: { x: 246, y: 356, w: 268, h: 128 } as Rect,
  /** steps in front of the door */
  steps: { x: 322, y: 344, w: 30, h: 10 } as Rect,
  /** interact zone that triggers the interior */
  doorZone: { x: 320, y: 330, w: 34, h: 26 } as Rect,
  /** where the player returns to when leaving the interior */
  doorReturn: { x: 337, y: 372 },

  generator: { x: 536, y: 398 },
  generatorPad: { x: 522, y: 380, w: 52, h: 34 } as Rect,
  crates: [
    { x: 232, y: 402 },
    { x: 252, y: 416 },
    { x: 240, y: 386 },
  ],
  drums: [
    { x: 588, y: 430 },
    { x: 602, y: 436 },
    { x: 596, y: 420 },
  ],
  container: { x: 618, y: 322 },
  mast: { x: 196, y: 312 },
  floodPole: { x: 486, y: 440 },
  ventStack: { x: 288, y: 292 },
  tank: { x: 452, y: 318 },
  cart: { x: 148, y: 402 },
  scrapPile: { x: 118, y: 348 },
  barrier: { x: 470, y: 470 },
  dish: { x: 210, y: 268 },

  /** player + robot spawns */
  playerSpawn: { x: 352, y: 428 },
  robotPatrol: [
    { x: 452, y: 402 },
    { x: 500, y: 372 },
    { x: 470, y: 352 },
    { x: 420, y: 368 },
  ],
  /** training dummy for scale reading */
  dummy: { x: 262, y: 462 },
} as const;

/** Collision boxes (exterior), world space. */
export const COLLIDERS: Rect[] = [
  // building footprint (front faces + wings)
  { x: 216, y: 292, w: 260, h: 52 },
  // porch steps block
  { x: 318, y: 344, w: 38, h: 6 },
  // generator
  { x: 524, y: 376, w: 46, h: 24 },
  // container
  { x: 618, y: 300, w: 84, h: 30 },
  // crates
  { x: 230, y: 384, w: 40, h: 34 },
  // drums
  { x: 586, y: 416, w: 26, h: 24 },
  // cart
  { x: 138, y: 386, w: 52, h: 26 },
  // scrap pile
  { x: 106, y: 336, w: 44, h: 22 },
  // mast base
  { x: 190, y: 304, w: 14, h: 10 },
  // tank
  { x: 446, y: 306, w: 26, h: 18 },
  // barrier
  { x: 466, y: 462, w: 62, h: 12 },
  // big rocks
  { x: 60, y: 396, w: 40, h: 18 },
  { x: 726, y: 396, w: 38, h: 18 },
  { x: 108, y: 478, w: 44, h: 18 },
  { x: 646, y: 492, w: 38, h: 16 },
];

/** The strip of world above this line is the far badlands (not walkable). */
export const WALK_MIN_Y = 150;
export const WALK_MAX_Y = 566;
export const WALK_MIN_X = 16;
export const WALK_MAX_X = 764;
