/**
 * QUALITY / PERFORMANCE settings.
 *
 * The frame is rendered in software, so every pass has a measurable CPU cost.
 * This module exposes the passes that matter as independent toggles plus three
 * curated presets, so the quality/perf balance can be tuned precisely from the
 * style-review panel (and measured with `npm run bench`).
 *
 * Cost notes (480x270 software pipeline):
 *  - lightShadows   ray-marched occlusion per shadow-casting lamp (per frame)
 *  - sunShadows     blit of the baked sun-shadow layer (per pixel, dithered)
 *  - entityShadows  per-frame cast-shadow masks for merc + drone
 *  - ambientFx      steam / dust motes / holo shimmer / screen scanlines
 *  - atmosphere     vignette + dust haze (cached surface, blended per pixel)
 *  - lightBudget    caps how many additive lamps are evaluated
 */

export interface QualitySettings {
  /** ray-marched shadows for shadow-casting lamps */
  lightShadows: boolean;
  /** baked sun-shadow layer (building / rocks / props) */
  sunShadows: boolean;
  /** per-frame cast shadows under the merc and the drone */
  entityShadows: boolean;
  /** steam, dust motes, holo shimmer, screen scanlines */
  ambientFx: boolean;
  /** vignette + atmospheric haze */
  atmosphere: boolean;
  /** max additive lights evaluated per frame (Infinity = all) */
  lightBudget: number;
}

export type QualityPreset = 'cinematic' | 'balanced' | 'performance' | 'custom';

export const QUALITY_PRESETS: Record<Exclude<QualityPreset, 'custom'>, QualitySettings> = {
  cinematic: {
    lightShadows: true,
    sunShadows: true,
    entityShadows: true,
    ambientFx: true,
    atmosphere: true,
    lightBudget: Infinity,
  },
  balanced: {
    lightShadows: true,
    sunShadows: true,
    entityShadows: true,
    ambientFx: false,
    atmosphere: true,
    lightBudget: 14,
  },
  performance: {
    lightShadows: false,
    sunShadows: false,
    entityShadows: false,
    ambientFx: false,
    atmosphere: false,
    lightBudget: 8,
  },
};

export function cloneQuality(q: QualitySettings): QualitySettings {
  return { ...q };
}

export function presetOf(q: QualitySettings): QualityPreset {
  for (const key of ['cinematic', 'balanced', 'performance'] as const) {
    const p = QUALITY_PRESETS[key];
    if (
      p.lightShadows === q.lightShadows &&
      p.sunShadows === q.sunShadows &&
      p.entityShadows === q.entityShadows &&
      p.ambientFx === q.ambientFx &&
      p.atmosphere === q.atmosphere &&
      p.lightBudget === q.lightBudget
    ) {
      return key;
    }
  }
  return 'custom';
}
