import { PixelSurface } from '../rendering/PixelSurface';
import { LightingSystem, type TimeOfDay } from '../lighting/LightingSystem';
import { VIEW_H, VIEW_W } from '../data/config';
import { bayer4 } from '../rendering/dither';
import { mix, packRGBA, withAlpha } from '../rendering/color';
import { dust, metal } from '../data/palette';
import { CAM_PRESETS, DEFAULT_CAM, N3Projection, type CamPreset } from './projection';
import { bakeN3World, type N3World } from './worldN3';
import { Mercenary } from '../entities/Mercenary';
import type { Input } from '../input/Input';

/**
 * N3 SCENE — the FINAL-CAMERA visual benchmark.
 *
 * One substantial frontier building presented through the N3 tilted
 * orthographic top-down camera (CrossCode / UNSIGHTED family, subtle
 * RimWorld-style wall lean). Static composition: one merc beside the
 * building, one working inside; E switches the cutaway (roof + south
 * facade hide, the interior stays in the same world coordinates);
 * [ / ] cycle the camera pitch candidates used for the final choice.
 */

interface Puff {
  wx: number;
  wy: number;
  wz: number;
  age: number;
  life: number;
  seed: number;
}

export class N3Scene {
  readonly lighting = new LightingSystem();
  proj: N3Projection;
  camKey: CamPreset['key'];
  world: N3World;
  zone: 'ext' | 'int' = 'ext';
  time = 0;
  review = { lighting: true, timeOfDay: 'dusk' as TimeOfDay, debug: false };

  readonly mercExt: Mercenary;
  readonly mercInt: Mercenary;

  private camX = 0;
  private camY = 0;
  private atmo: PixelSurface | null = null;
  private fade = 0;
  private pending: 'ext' | 'int' | null = null;
  private puffs: Puff[] = [];
  private steamClock = 0;

  constructor(camKey: CamPreset['key'] = DEFAULT_CAM) {
    this.camKey = camKey;
    this.proj = N3Projection.fromPreset(camKey);
    this.world = bakeN3World(this.proj);
    this.lighting.resize(VIEW_W, VIEW_H);
    this.mercExt = new Mercenary(this.world.mercExt.x, this.world.mercExt.y);
    this.mercExt.dir = this.world.mercExt.dir;
    this.mercInt = new Mercenary(this.world.mercInt.x, this.world.mercInt.y);
    this.mercInt.dir = this.world.mercInt.dir;
    this.snapCam();
  }

  /** re-bake the whole world through another camera pitch candidate */
  setCamera(key: CamPreset['key']): void {
    if (key === this.camKey && this.world) return;
    this.camKey = key;
    this.proj = N3Projection.fromPreset(key);
    this.world = bakeN3World(this.proj);
    this.snapCam();
  }

  cycleCamera(dir: number): void {
    const i = CAM_PRESETS.findIndex((c) => c.key === this.camKey);
    const n = CAM_PRESETS.length;
    this.setCamera(CAM_PRESETS[((i + dir) % n + n) % n].key);
  }

  get camLabel(): string {
    return CAM_PRESETS.find((c) => c.key === this.camKey)?.label ?? this.camKey;
  }

  private toScreen(wx: number, wy: number, wz = 0): [number, number] {
    const [sx, sy] = this.proj.projectPoint(wx, wy, wz);
    return [sx + this.world.ox, sy + this.world.oy];
  }

  private clamp(v: number, max: number): number {
    if (max <= 0) return Math.round(max / 2);
    return Math.round(Math.max(0, Math.min(max, v)));
  }

  private snapCam(): void {
    const f = this.zone === 'ext' ? this.world.focus.ext : this.world.focus.int;
    const [gx, gy] = this.toScreen(f[0], f[1]);
    const lookUp = this.zone === 'ext' ? 26 : 16;
    this.camX = this.clamp(gx - VIEW_W / 2, this.world.width - VIEW_W);
    this.camY = this.clamp(gy - lookUp - VIEW_H / 2, this.world.height - VIEW_H);
  }

  toggleZone(): void {
    if (this.pending) return;
    this.pending = this.zone === 'ext' ? 'int' : 'ext';
  }

  update(dt: number, input: Input): void {
    this.time += dt;

    if (input.consume('KeyE', 'Enter')) this.toggleZone();
    if (input.consume('BracketLeft')) this.cycleCamera(-1);
    if (input.consume('BracketRight')) this.cycleCamera(1);

    if (this.pending) {
      this.fade = Math.min(1, this.fade + dt * 5);
      if (this.fade >= 1) {
        this.zone = this.pending;
        this.pending = null;
        this.snapCam();
      }
    } else if (this.fade > 0) this.fade = Math.max(0, this.fade - dt * 4);

    // steam puffs from the roof stacks
    this.steamClock += dt;
    if (this.steamClock > 0.55) {
      this.steamClock = 0;
      const em = this.world.steam[(Math.floor(this.time / 0.55) | 0) % this.world.steam.length];
      this.puffs.push({ wx: em.x + (Math.random() - 0.5) * 2, wy: em.y, wz: em.z + 2, age: 0, life: 2.4, seed: Math.random() * 10 });
    }
    for (const p of this.puffs) {
      p.age += dt;
      p.wz += dt * 7;
      p.wx += dt * 2.4;
      p.wy -= dt * 0.8;
    }
    this.puffs = this.puffs.filter((p) => p.age < p.life);

    input.endFrame();
  }

  render(): PixelSurface {
    const s = new PixelSurface(VIEW_W, VIEW_H);
    const w = this.world;
    const camX = Math.round(this.camX);
    const camY = Math.round(this.camY);

    // ground
    for (let y = 0; y < VIEW_H; y++) {
      const sy = camY + y;
      const row = y * VIEW_W;
      if (sy < 0 || sy >= w.height) {
        s.data.fill(0xff0d0b0a, row, row + VIEW_W);
        continue;
      }
      const srcRow = sy * w.width;
      if (camX >= 0 && camX + VIEW_W <= w.width) s.data.set(w.ground.data.subarray(srcRow + camX, srcRow + camX + VIEW_W), row);
      else {
        for (let x = 0; x < VIEW_W; x++) {
          const sx = camX + x;
          s.data[row + x] = sx >= 0 && sx < w.width ? w.ground.data[srcRow + sx] : 0xff0d0b0a;
        }
      }
    }
    // baked sun shadows
    const sh = this.zone === 'ext' ? w.shadow : w.shadowCut;
    const shScale = this.review.lighting ? 1 : 0.6;
    for (let y = 0; y < VIEW_H; y++) {
      const sy = camY + y;
      if (sy < 0 || sy >= w.height) continue;
      const srcRow = sy * w.width;
      for (let x = 0; x < VIEW_W; x++) {
        const sx = camX + x;
        if (sx < 0 || sx >= w.width) continue;
        const c = sh.data[srcRow + sx];
        const sa0 = (c >>> 24) & 0xff;
        if (sa0 === 0) continue;
        if (bayer4(x, y) > 0.9) continue;
        const sa = Math.round(sa0 * shScale);
        const i = y * VIEW_W + x;
        const isa = 255 - sa;
        const d0 = s.data[i];
        s.data[i] = packRGBA(
          (((c & 0xff) * sa + (d0 & 0xff) * isa) / 255) | 0,
          ((((c >>> 8) & 0xff) * sa + ((d0 >>> 8) & 0xff) * isa) / 255) | 0,
          ((((c >>> 16) & 0xff) * sa + ((d0 >>> 16) & 0xff) * isa) / 255) | 0,
          255,
        );
      }
    }
    // depth-sorted renderables
    const list = w.renderables.filter((o) => o.mode === 'both' || (o.mode === 'ext') === (this.zone === 'ext'));
    list.sort((a, b) => a.depth - b.depth);
    for (const o of list) s.blit(o.sprite, o.x - camX, o.y - camY);

    // steam puffs (over the building, under the light pass)
    for (const p of this.puffs) {
      if (this.zone === 'int') continue;
      const t = p.age / p.life;
      const [px, py] = this.toScreen(p.wx, p.wy, p.wz);
      const x = Math.round(px - camX);
      const y = Math.round(py - camY);
      const r = 1 + Math.floor(t * 3 + p.seed * 0.4);
      const a = Math.round(85 * (1 - t) * (0.4 + t));
      const col = withAlpha(mix(0x00000000, mix(dust.d7, metal.m8, 0.5), 1), a);
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          const d = Math.sqrt(dx * dx + dy * dy * 1.6);
          if (d > r) continue;
          if (bayer4(x + dx + Math.floor(p.seed), y + dy) < 0.25 + t * 0.5) continue;
          s.blend(x + dx, y + dy, col);
        }
      }
    }

    // mercenaries (world-space positions, screen-space draw)
    const merc = this.zone === 'ext' ? this.mercExt : this.mercInt;
    const [mx, my] = this.toScreen(merc.x, merc.y);
    const mox = merc.x;
    const moy = merc.y;
    merc.x = mx;
    merc.y = my;
    merc.draw(s, camX, camY, this.time, false);
    merc.x = mox;
    merc.y = moy;

    // lights
    this.lighting.timeOfDay = this.review.timeOfDay;
    this.lighting.enabled = this.review.lighting;
    this.lighting.begin();
    for (const l of w.lights) {
      if (l.mode !== 'both' && (l.mode === 'int') !== (this.zone === 'int')) continue;
      const [lx, ly] = this.toScreen(l.x, l.y, l.z);
      this.lighting.addLight(
        { x: lx - camX, y: ly - camY, radius: l.r, r: l.c[0], g: l.c[1], b: l.c[2], intensity: l.i, flicker: l.flicker, blink: l.blink, pulse: l.pulse },
        this.time,
        [],
        0,
        0,
      );
    }
    // antenna beacon (red blink)
    {
      const b = w.beacon;
      const [bx, by] = this.toScreen(b.x, b.y, b.z);
      this.lighting.addLight({ x: bx - camX, y: by - camY, radius: 30, r: 1, g: 0.22, b: 0.18, intensity: 0.8, blink: 1.15 }, this.time, [], 0, 0);
    }
    // visor glints
    this.lighting.addLight({ x: mx - camX, y: my - camY - 22, radius: 9, r: 0.25, g: 0.85, b: 0.95, intensity: 0.16 }, this.time, [], 0, 0);
    this.lighting.apply(s);

    // atmosphere
    if (!this.atmo) this.atmo = this.bakeAtmo();
    for (let i = 0; i < this.atmo.data.length; i++) {
      const c = this.atmo.data[i];
      if (((c >>> 24) & 0xff) === 0) continue;
      s.data[i] = blendOver(s.data[i], c);
    }

    if (this.fade > 0.01) {
      for (let y = 0; y < VIEW_H; y++) for (let x = 0; x < VIEW_W; x++) if (bayer4(x, y) < this.fade) s.data[y * VIEW_W + x] = 0xff080708;
    }
    return s;
  }

  private bakeAtmo(): PixelSurface {
    const a = new PixelSurface(VIEW_W, VIEW_H);
    for (let y = 0; y < VIEW_H; y++) {
      for (let x = 0; x < VIEW_W; x++) {
        const dx = (x - VIEW_W / 2) / (VIEW_W / 2);
        const dy = (y - VIEW_H / 2) / (VIEW_H / 2);
        const d = Math.sqrt(dx * dx * 0.8 + dy * dy * 1.15);
        if (y < 56) {
          const ht = (1 - y / 56) * 0.34;
          if (bayer4(x, y) <= ht) a.data[y * VIEW_W + x] = withAlpha(mix(0x00000000, 0x2a2019, 1), Math.round(ht * 230));
        }
        if (d < 0.8) continue;
        const t = Math.min(1, (d - 0.8) / 0.45) * 0.3;
        if (bayer4(x, y) <= t) a.data[y * VIEW_W + x] = withAlpha(mix(0x00000000, 0x0c0a09, 1), Math.round(t * 255));
      }
    }
    return a;
  }
}

function blendOver(dst: number, src: number): number {
  const sa = (src >>> 24) & 0xff;
  if (sa === 255) return src;
  const isa = 255 - sa;
  const da = (dst >>> 24) & 0xff;
  const oa = sa + ((da * isa) >> 8);
  if (oa === 0) return 0;
  const r = (((src & 0xff) * sa + ((dst & 0xff) * da * isa) / 255) / oa) | 0;
  const g = ((((src >>> 8) & 0xff) * sa + (((dst >>> 8) & 0xff) * da * isa) / 255) / oa) | 0;
  const b = ((((src >>> 16) & 0xff) * sa + (((dst >>> 16) & 0xff) * da * isa) / 255) / oa) | 0;
  return packRGBA(r, g, b, oa);
}
