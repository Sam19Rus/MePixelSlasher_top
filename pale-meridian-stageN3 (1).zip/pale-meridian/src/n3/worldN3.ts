import { mix, packRGBA, withAlpha } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { fbm, hash2, makeRng, valueNoise } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, dust, grime, hazard, metal, olive, rock, rust, signal, slate, teal, warm } from '../data/palette';
import { drawText, stencilPlate } from '../rendering/text';
import {
  bolts,
  cable,
  dustDrift,
  grimePatch,
  hazardStripes,
  lamp,
  panelSeams,
  pipeRun,
  rustRun,
  screenFill,
  scratches,
  techBox,
  ventGrille,
  weatherSpeckle,
} from '../rendering/detail';
import type { N3Projection } from './projection';

/**
 * N3 WORLD — the FINAL-CAMERA benchmark scene.
 *
 * One substantial frontier building (main hall + taller west tower + east
 * garage bay + canopy porch + north service module) baked from scratch
 * through the N3 tilted-orthographic lattice: zero shear, roofs and south
 * faces visible, every wall face a subtle RimWorld-style trapezoid (2° lean).
 *
 * The cutaway interior is the SAME physical space: same projection, same
 * world coordinates, roof + south facade simply switch off.
 */

export interface N3Renderable {
  sprite: PixelSurface;
  x: number;
  y: number;
  depth: number;
  mode: 'both' | 'ext' | 'int';
  name: string;
}

export interface N3Light {
  x: number;
  y: number;
  z: number;
  r: number;
  c: [number, number, number];
  i: number;
  flicker?: number;
  blink?: number;
  pulse?: number;
  mode: 'both' | 'ext' | 'int';
}

export interface N3World {
  width: number;
  height: number;
  ox: number;
  oy: number;
  ground: PixelSurface;
  shadow: PixelSurface;
  shadowCut: PixelSurface;
  renderables: N3Renderable[];
  lights: N3Light[];
  steam: { x: number; y: number; z: number }[];
  beacon: { x: number; y: number; z: number };
  focus: { ext: [number, number]; int: [number, number] };
  mercExt: { x: number; y: number; dir: 's' | 'n' | 'e' | 'w' };
  mercInt: { x: number; y: number; dir: 's' | 'n' | 'e' | 'w' };
  worldW: number;
  worldH: number;
  pitchDeg: number;
}

const WW = 760;
const WH = 600;

/** mass convention: (x, y) = FRONT (south) ground line, body extends −y by d */
const HALL = { x: 252, y: 340, w: 200, d: 120, h: 58 };
const TOWER = { x: 188, y: 356, w: 64, d: 96, h: 84 };
const GARAGE = { x: 452, y: 352, w: 88, d: 92, h: 42 };
const PORCH = { x: 330, y: 356, w: 52, d: 16, h: 30 };
const MODULE = { x: 286, y: 220, w: 76, d: 44, h: 44 };
/** interior floor of the hall (world rect, y = north edge) */
const INT = { x: 256, y: 224, w: 192, h: 112 };

interface Baked {
  sprite: PixelSurface;
  ax: number;
  ay: number;
}

export interface BoxColors {
  front: [number, number, number]; // top, mid, bottom of the south face ramp
  top: [number, number]; // lit, shaded of the top cap
  edge: number;
  rim: number;
}

const CREAM: BoxColors = {
  front: [mix(metal.m8, dust.d8, 0.35), mix(metal.m6, dust.d7, 0.35), mix(metal.m4, dust.d5, 0.4)],
  top: [mix(metal.m8, dust.d8, 0.3), mix(metal.m6, dust.d6, 0.35)],
  edge: metal.m1,
  rim: mix(metal.m9, dust.d8, 0.4),
};
const OLIVE: BoxColors = {
  front: [mix(olive.o4, metal.m5, 0.35), mix(olive.o3, metal.m4, 0.3), mix(olive.o1, metal.m2, 0.4)],
  top: [mix(olive.o5, metal.m6, 0.3), mix(olive.o3, metal.m4, 0.35)],
  edge: mix(olive.o0, metal.m0, 0.5),
  rim: mix(olive.o6, metal.m8, 0.3),
};
const RUSTM: BoxColors = {
  front: [rust.x5, rust.x4, rust.x2],
  top: [mix(rust.x6, dust.d7, 0.3), rust.x4],
  edge: rust.x0,
  rim: rust.x7,
};
const SLATE: BoxColors = {
  front: [slate.s5, slate.s4, slate.s2],
  top: [slate.s6, slate.s5],
  edge: slate.s0,
  rim: slate.s7,
};
const WARM: BoxColors = {
  front: [warm.w5, warm.w4, warm.w2],
  top: [warm.w6, warm.w5],
  edge: warm.w0,
  rim: warm.w7,
};

/**
 * Generic axis-aligned box for the N3 camera (top cap + south face).
 * (x, yBase) is the sprite-local position of the front-bottom edge;
 * dVs = depth in screen px (d·vs), hS = height in screen px (h·hs).
 */
export function drawBoxN3(
  s: PixelSurface,
  x: number,
  yBase: number,
  w: number,
  dVs: number,
  hS: number,
  C: BoxColors,
  paint?: { face?: (fx: number, fy: number, fw: number, fh: number) => void; top?: (tx: number, ty: number, tw: number, th: number) => void },
): void {
  const fy = yBase - hS;
  const ty = fy - dVs;
  // top cap
  if (dVs > 0) {
    s.rect(x, ty, w, dVs, C.top[1]);
    s.rect(x, ty, w, Math.max(1, dVs - 1), C.top[0]);
    s.hline(x, ty + dVs - 1, w, mix(C.top[1], C.edge, 0.5)); // crease before the face
    s.hline(x, ty, w, C.rim);
    if (paint?.top) paint.top(x, ty, w, dVs);
  }
  // south face
  s.rect(x, fy, w, hS, C.front[1]);
  s.rect(x, fy, w, Math.max(1, Math.round(hS * 0.34)), C.front[0]);
  s.rect(x, fy + hS - Math.max(1, Math.round(hS * 0.28)), w, Math.max(1, Math.round(hS * 0.28)), C.front[2]);
  if (paint?.face) paint.face(x, fy, w, hS);
  // silhouette edges
  s.vline(x - 1, fy, hS + dVs, C.edge);
  s.vline(x + w, fy, hS + dVs, C.edge);
  s.hline(x - 1, ty, w + 2, mix(C.edge, C.rim, 0.25));
  s.hline(x, fy + hS, w, mix(C.edge, 0x00000000, 0.2));
}

/** Vertical cylinder (tanks, drums, stacks) for the N3 camera. */
export function drawCylN3(
  s: PixelSurface,
  cx: number,
  yBase: number,
  r: number,
  hS: number,
  ry: number,
  base: [number, number, number],
  cap: [number, number],
  edge: number,
  bandFn?: (y: number) => void,
): void {
  const top = yBase - hS;
  for (let x = -r; x <= r; x++) {
    const t = (x + r) / (2 * r);
    // sun from the west: lit at the left
    const litv = 1 - Math.abs(t - 0.34) * 1.7;
    let c: number;
    if (litv > 0.55) c = mix(base[0], base[1], (0.9 - litv) * 2.2);
    else if (litv > 0.1) c = mix(base[1], base[2], (0.55 - litv) * 2.2);
    else c = mix(base[2], edge, Math.min(1, (0.1 - litv) * 2.4));
    s.vline(cx + x, top, hS, c);
    if (x === -r || x === r) s.vline(cx + x, top, hS, edge);
  }
  s.ellipse(cx, top, r, Math.max(1, ry), cap[1]);
  s.ellipse(cx, top, r - 1, Math.max(1, ry - 1), cap[0]);
  s.ellipseOutline(cx, top, r, Math.max(1, ry), edge);
  if (bandFn) bandFn(top);
  // footing shadow
  s.ellipse(cx, yBase, r + 1, Math.max(1, ry), withAlpha(packRGBA(20, 12, 10), 90));
}

/** paste a wall texture as a trapezoid: top edge inset by L px per side */
function pasteWall(dst: PixelSurface, tex: PixelSurface, x0: number, yTop: number, L: number): void {
  const H = tex.height;
  const w = tex.width;
  for (let v = 0; v < H; v++) {
    const ins = H === 1 ? 0 : Math.round((L * (H - 1 - v)) / (H - 1));
    const span = w - 2 * ins;
    if (span <= 0) continue;
    const src = v * w + ins;
    const drow = (yTop + v) * dst.width + x0 + ins;
    dst.data.set(tex.data.subarray(src, src + span), drow);
  }
}

interface MassGeom {
  s: PixelSurface;
  w: number;
  H: number;
  L: number;
  x0: number; // sprite-local screen x of the west face at ground
  yBase: number; // sprite-local screen y of the front ground line
  roofX: number;
  roofY: number;
  roofW: number;
  roofH: number;
  S: (wx: number, wy: number, wz?: number) => [number, number];
}

function bakeMass(pr: N3Projection, m: { x: number; y: number; w: number; d: number; h: number }, extraTop: number, paint: (g: MassGeom) => void): Baked {
  const H = pr.projectHeight(m.h);
  const L = pr.leanPx(m.h);
  const E = pr.p.eave;
  const rs = pr.roofSlab(m.x, m.y, m.w, m.d, m.h);
  const minX = Math.floor(m.x - E - 4);
  const maxX = Math.ceil(m.x + m.w + E + 4);
  const topSy = Math.min((rs.y) * pr.vs - H, (m.y - m.d) * pr.vs - pr.projectHeight(m.h + extraTop)) - 6;
  const botSy = m.y * pr.vs + 6;
  const lx = -minX;
  const ly = -topSy;
  const s = new PixelSurface(maxX - minX, Math.ceil(botSy - topSy));
  const S = (wx: number, wy: number, wz = 0): [number, number] => [Math.round(wx + lx), Math.round(wy * pr.vs - pr.projectHeight(wz) + ly)];
  const [roofX, roofYn] = S(rs.x, rs.y, m.h);
  const [, roofYs] = S(rs.x, rs.y + rs.d, m.h);
  const g: MassGeom = {
    s,
    w: m.w,
    H,
    L,
    x0: S(m.x, m.y)[0],
    yBase: S(m.x, m.y)[1],
    roofX,
    roofY: roofYn,
    roofW: rs.w,
    roofH: Math.max(1, roofYs - roofYn),
    S,
  };
  paint(g);
  return { sprite: s, ax: g.x0, ay: g.yBase };
}

/** paint the wall texture, then paste it as the leaning trapezoid */
function wall(g: MassGeom, painter: (tex: PixelSurface, w: number, H: number) => void): void {
  const tex = new PixelSurface(g.w, g.H);
  painter(tex, g.w, g.H);
  pasteWall(g.s, tex, g.x0, g.yBase - g.H, g.L);
}

/** cornice: slab edge painted over the top rows of the pasted wall */
function cornice(g: MassGeom, dark = true): void {
  const yT = g.yBase - g.H;
  for (let v = 0; v < 3; v++) {
    const ins = Math.round((g.L * (g.H - 1 - v)) / Math.max(1, g.H - 1));
    const x = g.x0 + ins;
    const w = g.w - 2 * ins;
    if (v === 0) g.s.hline(x - 1, yT + v, w + 2, mix(metal.m8, dust.d7, 0.35));
    else if (v === 1) g.s.hline(x, yT + v, w, mix(metal.m5, dust.d5, 0.4));
    else g.s.hline(x, yT + v, w, dark ? mix(metal.m1, grime.g2, 0.4) : mix(metal.m3, dust.d3, 0.4));
  }
}

/** parapet rim around a roof rect + corner posts */
function parapet(g: MassGeom, c1: number, c2: number, posts = true): void {
  const { s, roofX, roofY, roofW, roofH } = g;
  s.hline(roofX, roofY, roofW, c1);
  s.hline(roofX, roofY + 1, roofW, c2);
  s.hline(roofX, roofY + roofH - 1, roofW, c2);
  s.hline(roofX, roofY + roofH - 2, roofW, mix(c2, c1, 0.5));
  s.vline(roofX, roofY, roofH, c2);
  s.vline(roofX + 1, roofY, roofH, mix(c1, c2, 0.5));
  s.vline(roofX + roofW - 1, roofY, roofH, c2);
  s.vline(roofX + roofW - 2, roofY, roofH, mix(c1, c2, 0.4));
  if (posts) {
    for (let u = 10; u < roofW - 6; u += 26) {
      s.rect(roofX + u, roofY - 2, 2, 3, c2);
      s.set(roofX + u, roofY - 2, c1);
    }
  }
}

/** dusty industrial roof membrane inside a rect (panels, patches, wear) */
function roofMembrane(g: MassGeom, rnd: () => number, dustAmt = 1): void {
  const { s, roofX, roofY, roofW, roofH } = g;
  const baseA = mix(metal.m4, dust.d4, 0.34);
  const baseB = mix(metal.m3, dust.d3, 0.38);
  s.rect(roofX, roofY, roofW, roofH, baseB);
  s.ditherRect(roofX, roofY, roofW, roofH, baseB, baseA, 0.5);
  // panel grid with an irregular rhythm (authored, not wallpaper)
  const seam = mix(metal.m2, grime.g2, 0.45);
  const bevel = mix(metal.m5, dust.d6, 0.3);
  let u = 14;
  let ui = 0;
  for (const step of [17, 21, 15, 19, 23, 17]) {
    u += step;
    if (u >= roofW - 4) break;
    s.vline(roofX + u, roofY + 2, roofH - 4, seam);
    s.vline(roofX + u + 1, roofY + 2, roofH - 4, ui % 2 === 0 ? bevel : mix(bevel, baseA, 0.5));
    ui++;
  }
  let v = 10;
  for (const step of [13, 16, 12, 15]) {
    v += step;
    if (v >= roofH - 3) break;
    s.hline(roofX + 2, roofY + v, roofW - 4, seam);
    s.hline(roofX + 2, roofY + v + 1, roofW - 4, bevel);
  }
  // patch plates (repaired sections, slightly different metal)
  const patches: [number, number, number, number][] = [
    [roofW * 0.18, roofH * 0.24, 22, 14],
    [roofW * 0.62, roofH * 0.55, 26, 12],
    [roofW * 0.4, roofH * 0.1, 16, 10],
  ];
  for (const [px, py, pw, ph] of patches) {
    const x = roofX + Math.round(px);
    const y = roofY + Math.round(py);
    s.rect(x, y, pw, ph, mix(metal.m4, dust.d5, 0.3));
    s.strokeRect(x, y, pw, ph, mix(metal.m2, grime.g2, 0.4));
    s.hline(x + 1, y + 1, pw - 2, mix(metal.m6, dust.d6, 0.35));
    for (let rx = x + 2; rx < x + pw - 1; rx += 4) {
      s.set(rx, y + 1, metal.m2);
      s.set(rx, y + ph - 2, metal.m2);
    }
  }
  // rust blooms + grime + dust drift along the parapet
  for (let i = 0; i < 7; i++) {
    grimePatch(s, roofX + 6 + Math.floor(rnd() * (roofW - 12)), roofY + 5 + Math.floor(rnd() * (roofH - 10)), 3 + rnd() * 5, [mix(rust.x2, dust.d2, 0.5), mix(rust.x3, dust.d3, 0.55)], rnd, 0.6);
  }
  for (let i = 0; i < 5; i++) {
    grimePatch(s, roofX + 6 + Math.floor(rnd() * (roofW - 12)), roofY + 5 + Math.floor(rnd() * (roofH - 10)), 4 + rnd() * 7, [grime.g2, grime.g1], rnd, 0.5);
  }
  for (let u = 3; u < roofW - 8; u += 9 + Math.floor(rnd() * 7)) {
    dustDrift(s, roofX + u, roofY + 3, 5 + Math.floor(rnd() * 8), [dust.d5, dust.d4, dust.d3], rnd, 0.8 * dustAmt);
    dustDrift(s, roofX + u + 3, roofY + roofH - 2, 4 + Math.floor(rnd() * 7), [dust.d5, dust.d4], rnd, 0.7 * dustAmt);
  }
  weatherSpeckle(s, roofX + 2, roofY + 2, roofW - 4, roofH - 4, [dust.d6, dust.d3, warm.w2, mix(rust.x3, dust.d3, 0.5)], 0.02, rnd);
  // a few hairline scratches
  scratches(s, roofX + 4, roofY + 4, roofW - 8, roofH - 8, mix(warm.w6, dust.d7, 0.4), warm.w1, 6, rnd);
}

/** gravel bed strip (roof sections covered in ballast gravel) */
function gravelBed(g: MassGeom, x: number, y: number, w: number, h: number, rnd: () => number): void {
  const { s } = g;
  s.rect(x, y, w, h, mix(warm.w2, rock.r2, 0.5));
  for (let i = 0; i < w * h * 0.5; i++) {
    const px = x + Math.floor(rnd() * w);
    const py = y + Math.floor(rnd() * h);
    s.set(px, py, rnd() < 0.5 ? mix(rock.r3, warm.w4, 0.4) : rnd() < 0.5 ? rock.r2 : mix(dust.d4, rock.r3, 0.5));
  }
  s.strokeRect(x, y, w, h, mix(warm.w1, grime.g1, 0.5));
}

// ---------------------------------------------------------------------------

export function bakeN3World(pr: N3Projection): N3World {
  const rnd = makeRng(7331);
  const renderables: N3Renderable[] = [];
  const lights: N3Light[] = [];

  // ---------------------------------------------------------- screen bounds
  const cs = [pr.projectPoint(-40, -40), pr.projectPoint(WW + 40, -40), pr.projectPoint(WW + 40, WH + 40), pr.projectPoint(-40, WH + 40)];
  const minX = Math.floor(Math.min(...cs.map((c) => c[0])));
  const maxX = Math.ceil(Math.max(...cs.map((c) => c[0])));
  const minY = Math.floor(Math.min(...cs.map((c) => c[1]))) - pr.projectHeight(120);
  const maxY = Math.ceil(Math.max(...cs.map((c) => c[1])));
  const W = maxX - minX;
  const H = maxY - minY;
  const ox = -minX;
  const oy = -minY;
  const gp = (wx: number, wy: number, wz = 0): [number, number] => {
    const [sx, sy] = pr.projectPoint(wx, wy, wz);
    return [Math.round(sx + ox), Math.round(sy + oy)];
  };

  // --------------------------------------------------------------- terrain
  const ground = new PixelSurface(W, H);
  const field = new Float32Array(W * H);
  for (let py = 0; py < H; py++) {
    for (let px = 0; px < W; px++) {
      const [wx, wy] = pr.invPoint(px - ox, py - oy);
      field[py * W + px] = fbm(wx / 150, wy / 96, 3, 11);
    }
  }
  const F = (px: number, py: number) => field[Math.max(0, Math.min(H - 1, py)) * W + Math.max(0, Math.min(W - 1, px))];
  const CRUST = [dust.d0, dust.d1, dust.d2];
  const RUSTY = [dust.d1, mix(rust.x1, dust.d1, 0.55), mix(rust.x2, dust.d2, 0.55), mix(rust.x3, dust.d3, 0.6), mix(rust.x4, dust.d4, 0.7)];
  const OCHRE = [dust.d1, dust.d2, dust.d3, dust.d4, dust.d5];
  const PALE = [dust.d3, dust.d4, dust.d5, dust.d6, dust.d7];
  for (let py = 0; py < H; py++) {
    for (let px = 0; px < W; px++) {
      const [wx, wy] = pr.invPoint(px - ox, py - oy);
      const form = F(px, py);
      const sx = F(px + 4, py) - F(px - 4, py);
      const sy = F(px, py + 4) - F(px, py - 4);
      let lit = -sx * 5.2 - sy * 6.4;
      lit = Math.max(-1, Math.min(1, lit));
      const q = Math.round(lit * 2) / 2;
      const litT = bayer4(px, py) < Math.abs(lit * 2) - Math.round(Math.abs(lit * 2)) + 0.5 ? Math.abs(q) + 0.25 : Math.abs(q);
      const grain = fbm(wx / 13, wy / 10, 3, 41);
      const micro = valueNoise(wx / 3.4, wy / 3.4, 77);
      const biome = fbm(wx / 82, wy / 70, 3, 5) * 0.85 + form * 0.15;
      let v = grain * 0.62 + form * 0.28 + (micro - 0.5) * 0.08 + 0.12;
      // jitter the ramp threshold so flat ground never turns into a
      // perfect 1px checkerboard (breaks the dither into organic grain)
      v += (valueNoise(wx / 9, wy / 9, 91) - 0.5) * 0.09;
      v = Math.max(0, Math.min(0.999, v));
      const bEdge = bayer8(px, py) * 0.1 - 0.05;
      // ordered-dither threshold blended with high-frequency noise:
      // keeps banding-free ramps but never a visible periodic dot grid
      const thr = bayer4(px, py) * 0.22 + hash2(px, py, 55) * 0.78;
      let c: number;
      if (biome + bEdge < 0.31) c = thr < ((v * 2.7) % 1) ? CRUST[Math.min(2, Math.floor(v * 2.7) + 1)] : CRUST[Math.floor(v * 2.7)];
      else if (biome + bEdge < 0.45) {
        const t = v * 4;
        c = thr < t - Math.floor(t) ? RUSTY[Math.min(4, Math.floor(t) + 1)] : RUSTY[Math.floor(t)];
      } else if (biome + bEdge < 0.78) {
        const t = v * 4;
        c = thr < t - Math.floor(t) ? OCHRE[Math.min(4, Math.floor(t) + 1)] : OCHRE[Math.floor(t)];
      } else {
        const t = v * 4;
        c = thr < t - Math.floor(t) ? PALE[Math.min(4, Math.floor(t) + 1)] : PALE[Math.floor(t)];
      }
      if (q > 0) c = mix(c, dust.d8, Math.min(0.16, litT * 0.2));
      else c = mix(c, dust.d0, Math.min(0.2, litT * 0.24));
      ground.setRaw(px, py, packRGBA(c & 0xff, (c >>> 8) & 0xff, (c >>> 16) & 0xff));
    }
  }
  // speckle field
  for (let i = 0; i < 8000; i++) {
    const wx = rnd.range(0, WW);
    const wy = rnd.range(40, WH);
    if (valueNoise(wx / 30, wy / 30, 3) < 0.68) continue;
    const [px, py] = gp(wx, wy);
    ground.set(px, py, rnd.chance(0.5) ? dust.d7 : dust.d2);
  }
  // cracks
  for (let i = 0; i < 14; i++) {
    let wx = rnd.range(60, WW - 60);
    let wy = rnd.range(180, WH - 30);
    if (wx > 170 && wx < 560 && wy > 160 && wy < 460) {
      wx = rnd.range(580, 720);
    }
    let ang = rnd() * Math.PI * 2;
    for (let k = 0; k < 36; k++) {
      ang += (rnd() - 0.5) * 0.5;
      wx += Math.cos(ang) * 1.6;
      wy += Math.sin(ang) * 1.1;
      const [px, py] = gp(wx, wy);
      ground.set(px, py, mix(dust.d0, dust.d1, 0.4));
      if (rnd() < 0.2) ground.set(px, py + 1, dust.d5);
    }
  }

  // concrete apron in front of the garage (world rect: x, yFront, w, d)
  const apron = (ax0: number, ayFront: number, aw: number, ad: number, cA: number, cB: number) => {
    const q = pr.groundQuad(ax0, ayFront - ad, aw, ad).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
    ground.polygon(q, cA);
    const q2 = pr.groundQuad(ax0 + 2, ayFront - ad + 2, aw - 4, ad - 4).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
    ground.polygon(q2, cB);
    // expansion joints
    for (let u = 18; u < aw - 6; u += 22) {
      const a = gp(ax0 + u, ayFront - ad + 3);
      const b = gp(ax0 + u, ayFront - 3);
      ground.line(a[0], a[1], b[0], b[1], mix(warm.w2, dust.d2, 0.4));
    }
    for (let v = 14; v < ad - 4; v += 16) {
      const a = gp(ax0 + 3, ayFront - v);
      const b = gp(ax0 + aw - 3, ayFront - v);
      ground.line(a[0], a[1], b[0], b[1], mix(warm.w2, dust.d2, 0.45));
    }
    return q;
  };
  const aprC = mix(dust.d5, warm.w4, 0.35);
  apron(444, 430, 120, 74, mix(dust.d4, warm.w3, 0.4), aprC);
  apron(316, 396, 88, 34, mix(dust.d4, warm.w3, 0.3), mix(dust.d5, warm.w4, 0.3));
  // apron wear + oil
  for (let i = 0; i < 16; i++) {
    const p = gp(rnd.range(448, 560), rnd.range(362, 428));
    grimePatch(ground, p[0], p[1], 3 + rnd() * 6, [mix(dust.d3, warm.w3, 0.5), mix(dust.d4, warm.w4, 0.4)], () => rnd(), 0.5);
  }
  {
    const p = gp(505, 396);
    grimePatch(ground, p[0], p[1], 9, [grime.g2, grime.g1, mix(grime.g0, dust.d1, 0.4)], () => rnd(), 0.55);
    const p2 = gp(512, 402);
    grimePatch(ground, p2[0], p2[1], 5, [grime.g1, grime.g0], () => rnd(), 0.5);
  }
  // wheel tracks from the south into the garage bay
  for (const side of [-13, 13]) {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 34; t++) {
      const wx = 498 + side + Math.sin(t / 9) * 4;
      const wy = WH + 6 - t * 5.2;
      const p = gp(wx, wy);
      if (prev) {
        ground.line(prev[0], prev[1], p[0], p[1], mix(dust.d2, grime.g2, 0.45));
        ground.line(prev[0] + 2, prev[1], p[0] + 2, p[1], mix(dust.d3, dust.d2, 0.5));
      }
      prev = p;
    }
  }
  // gravel path porch -> south, with footprints
  {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 26; t++) {
      const wx = 356 + Math.sin(t / 6) * 5;
      const wy = 366 + t * 6.5;
      const p = gp(wx, wy);
      if (prev) {
        ground.line(prev[0], prev[1], p[0], p[1], mix(dust.d4, rock.r3, 0.4));
        ground.line(prev[0] + 1, prev[1], p[0] + 1, p[1], mix(dust.d5, rock.r3, 0.3));
        ground.line(prev[0] - 1, prev[1], p[0] - 1, p[1], mix(dust.d3, dust.d2, 0.4));
      }
      prev = p;
    }
    for (let i = 0; i < 22; i++) {
      const wx = 356 + (i % 2 === 0 ? -3 : 3) + Math.sin(i / 6) * 5;
      const wy = 372 + i * 5.4;
      const [px, py] = gp(wx, wy);
      ground.set(px, py, mix(dust.d2, dust.d3, 0.5));
      ground.set(px + 1, py, mix(dust.d1, dust.d2, 0.5));
    }
  }
  // buried cable trench: west yard generator -> hall west wall
  {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 30; t++) {
      const wx = 196 + t * 2.6;
      const wy = 388 - Math.max(0, t - 22) * 4.2;
      const p = gp(wx, wy);
      if (prev) {
        ground.line(prev[0], prev[1], p[0], p[1], warm.w2);
        ground.line(prev[0], prev[1] - 1, p[0], p[1] - 1, warm.w4);
      }
      prev = p;
    }
  }
  // surface cable snaking across the yard
  {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 40; t++) {
      const wx = 420 + t * 3.2;
      const wy = 404 + Math.sin(t / 4) * 5;
      const p = gp(wx, wy);
      if (prev) {
        ground.line(prev[0], prev[1], p[0], p[1], grime.g1);
        ground.set(p[0], p[1] - 1, mix(warm.w3, grime.g2, 0.4));
      }
      prev = p;
    }
  }
  // stencil on the apron
  {
    const st = gp(452, 420);
    drawText(ground, st[0], st[1], 'BAY 03  K-7', mix(metal.m5, dust.d6, 0.45), { worn: 0.5, seed: 9 });
  }

  // ---------------------------------------------------------- baked shadows
  const shadow = new PixelSurface(W, H);
  const shadowCut = new PixelSurface(W, H);
  const castBox = (target: PixelSurface, m: { x: number; y: number; w: number; d: number; h: number }) => {
    const [dx, dy] = pr.shadowOffset(m.h);
    const q = pr.groundQuad(m.x, m.y - m.d, m.w, m.d).map((p) => [p[0] + ox, p[1] + oy]);
    const far = q.map((p) => [p[0] + dx, p[1] + dy]);
    target.polygon([q[0], q[1], far[1], far[0]], packRGBA(34, 19, 16, 132));
    target.polygon([q[1], q[2], far[2], far[1]], packRGBA(34, 19, 16, 132));
    target.polygon(q, packRGBA(34, 19, 16, 132));
  };
  const SH_MASSES = [HALL, TOWER, GARAGE, PORCH, MODULE];
  for (const m of SH_MASSES) castBox(shadow, m);
  castBox(shadowCut, MODULE);
  castBox(shadowCut, TOWER);
  castBox(shadowCut, GARAGE);
  // contact darkening along the front bases
  for (const m of [HALL, TOWER, GARAGE]) {
    const q = pr.groundQuad(m.x + 1, m.y - 2, m.w - 2, 3).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
    ground.polygon(q, mix(dust.d1, dust.d0, 0.45));
  }
  for (const target of [shadow, shadowCut]) {
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = y * W + x;
        if ((target.data[i] >>> 24) === 0) continue;
        let outside = false;
        for (const o of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ]) {
          const nx = x + o[0];
          const ny = y + o[1];
          if (nx < 0 || ny < 0 || nx >= W || ny >= H || (target.data[ny * W + nx] >>> 24) === 0) outside = true;
        }
        if (outside && bayer8(x, y) < 0.6) target.data[i] = 0;
      }
    }
  }

  const push = (bk: Baked, wx: number, wy: number, depth: number, mode: N3Renderable['mode'], name: string) => {
    const [sx, sy] = pr.projectPoint(wx, wy);
    renderables.push({ sprite: bk.sprite, x: Math.round(sx + ox) - bk.ax, y: Math.round(sy + oy) - bk.ay, depth, mode, name });
  };

  // =========================================================== HALL (main)
  const hallBk = bakeMass(pr, HALL, 34, (g) => {
    const { s } = g;
    // ---- south wall texture (u = 0..200 from west, v = 0..H from top)
    wall(g, (tex, w, H) => {
      tex.rect(0, 0, w, H, CREAM.front[1]);
      tex.gradientDither(0, 0, w, H, [CREAM.front[0], CREAM.front[1], CREAM.front[2]]);
      // plinth
      tex.rect(0, H - 5, w, 5, mix(warm.w2, dust.d2, 0.35));
      tex.hline(0, H - 5, w, mix(warm.w4, dust.d4, 0.4));
      tex.hline(0, H - 1, w, mix(warm.w1, grime.g1, 0.4));
      // panel seams
      panelSeams(tex, 0, 0, w, H - 5, mix(metal.m2, grime.g2, 0.4), mix(metal.m7, dust.d7, 0.35), [26, 54, 80, 122, 150, 176], [Math.round(H * 0.42)]);
      // pilasters (shallow buttresses for rhythm + structure)
      for (const px of [46, 100, 152]) {
        tex.rect(px, 3, 6, H - 8, mix(metal.m5, dust.d6, 0.3));
        tex.vline(px, 3, H - 8, mix(metal.m7, dust.d8, 0.35));
        tex.vline(px + 5, 3, H - 8, mix(metal.m2, grime.g2, 0.5));
        tex.rect(px - 1, 2, 8, 2, mix(metal.m6, dust.d7, 0.3));
        tex.hline(px - 1, 2, 8, mix(metal.m8, dust.d8, 0.4));
      }
      // windows: two triples (lab cyan west, quarters amber east)
      const windowUnit = (u0: number, warmGlass: boolean) => {
        for (let k = 0; k < 3; k++) {
          const u = u0 + k * 15;
          const v0 = 8;
          const ww = 12;
          const wh = 11;
          tex.rect(u - 2, v0 - 2, ww + 4, wh + 5, mix(metal.m1, grime.g1, 0.3));
          tex.rect(u - 1, v0 - 1, ww + 2, wh + 3, mix(metal.m2, slate.s2, 0.4));
          const gl = warmGlass ? [mix(amber.a2, teal.t1, 0.2), mix(amber.a1, teal.t0, 0.25)] : [teal.t3, teal.t2];
          tex.rect(u, v0, ww, wh, gl[1]);
          tex.rect(u, v0, ww, Math.round(wh * 0.4), gl[0]);
          for (let vy = 0; vy < wh; vy += 2) tex.hline(u, v0 + vy, ww, mix(gl[1], 0x00000000, 0.25));
          tex.line(u + 1, v0 + wh - 2, u + ww - 3, v0 + 1, warmGlass ? mix(amber.a5, teal.t3, 0.3) : teal.t5);
          tex.set(u + 2, v0 + wh - 3, warmGlass ? amber.a6 : teal.t6);
          tex.vline(u + Math.floor(ww / 2), v0, wh, mix(metal.m3, slate.s3, 0.5));
          tex.strokeRect(u - 1, v0 - 1, ww + 2, wh + 2, metal.m1);
          tex.rect(u - 2, v0 + wh + 2, ww + 4, 1, mix(metal.m6, dust.d7, 0.3));
          tex.rect(u - 2, v0 + wh + 3, ww + 4, 1, mix(metal.m2, grime.g2, 0.4));
          tex.hline(u - 2, v0 - 3, ww + 4, mix(metal.m5, dust.d6, 0.35));
          rustRun(tex, u + 2, v0 + wh + 4, 6, [rust.x2, rust.x3, mix(rust.x3, dust.d2, 0.5)], 2, u);
        }
      };
      windowUnit(28, false);
      windowUnit(128, true);
      // main door (behind the porch): recessed double airlock
      {
        const u0 = 90;
        const v0 = H - 5 - 26;
        tex.rect(u0 - 3, v0 - 3, 32, 29 + 3, mix(metal.m1, grime.g1, 0.25));
        tex.rect(u0 - 2, v0 - 2, 30, 28 + 2, mix(metal.m2, slate.s1, 0.4));
        tex.rect(u0, v0, 26, 26, mix(metal.m4, olive.o2, 0.35));
        tex.gradientDither(u0, v0, 26, 26, [mix(metal.m5, olive.o3, 0.3), mix(metal.m3, olive.o1, 0.4)]);
        tex.vline(u0 + 13, v0, 26, mix(metal.m1, grime.g1, 0.5));
        tex.strokeRect(u0, v0, 26, 26, metal.m1);
        tex.rect(u0 + 3, v0 + 4, 8, 7, teal.t2);
        tex.rect(u0 + 16, v0 + 4, 8, 7, teal.t2);
        tex.hline(u0 + 3, v0 + 4, 8, teal.t4);
        tex.hline(u0 + 16, v0 + 4, 8, teal.t4);
        tex.strokeRect(u0 + 3, v0 + 4, 8, 7, metal.m1);
        tex.strokeRect(u0 + 16, v0 + 4, 8, 7, metal.m1);
        tex.rect(u0 + 10, v0 + 14, 2, 5, metal.m6);
        tex.rect(u0 + 14, v0 + 14, 2, 5, metal.m6);
        tex.rect(u0 + 1, v0 + 21, 11, 4, mix(metal.m3, grime.g2, 0.5));
        tex.rect(u0 + 14, v0 + 21, 11, 4, mix(metal.m3, grime.g2, 0.5));
        scratches(tex, u0 + 1, v0 + 12, 24, 12, mix(metal.m6, dust.d7, 0.3), metal.m2, 5, () => rnd());
        hazardStripes(tex, u0 - 3, H - 5, 32, 2, hazard.h1, hazard.h3, 6);
        drawText(tex, u0 - 1, v0 - 9, 'K-7 AIRLOCK', mix(metal.m3, dust.d4, 0.4), { worn: 0.45, seed: 4 });
        lamp(tex, u0 + 13, v0 - 5, amber.a6, amber.a3, withAlpha(amber.a2, 160));
        tex.rect(u0 + 11, v0 - 7, 5, 2, metal.m2);
      }
      // vents
      ventGrille(tex, 6, 7, 16, 10, mix(metal.m1, grime.g1, 0.4), mix(metal.m5, dust.d6, 0.3));
      rustRun(tex, 9, 18, 10, [rust.x2, rust.x3, mix(rust.x4, dust.d3, 0.5)], 2, 11);
      ventGrille(tex, 182, 9, 14, 8, mix(metal.m1, grime.g1, 0.4), mix(metal.m5, dust.d6, 0.3));
      rustRun(tex, 186, 18, 8, [rust.x2, rust.x3], 2, 21);
      // crew door (east end)
      {
        const u0 = 160;
        const v0 = H - 5 - 24;
        tex.rect(u0 - 2, v0 - 2, 18, 26 + 2, mix(metal.m2, slate.s1, 0.4));
        tex.rect(u0, v0, 14, 24, mix(rust.x3, warm.w3, 0.35));
        tex.gradientDither(u0, v0, 14, 24, [mix(rust.x4, warm.w4, 0.3), mix(rust.x2, warm.w2, 0.4)]);
        tex.strokeRect(u0, v0, 14, 24, metal.m1);
        tex.rect(u0 + 3, v0 + 3, 8, 5, teal.t2);
        tex.hline(u0 + 3, v0 + 3, 8, teal.t4);
        tex.strokeRect(u0 + 3, v0 + 3, 8, 5, metal.m1);
        tex.set(u0 + 11, v0 + 13, metal.m7);
        tex.set(u0 + 11, v0 + 14, metal.m5);
        scratches(tex, u0 + 1, v0 + 12, 12, 10, mix(rust.x5, dust.d6, 0.3), rust.x1, 4, () => rnd());
      }
      // horizontal pipe split around the door + conduit jumpers
      pipeRun(tex, [[0, 24], [86, 24]], 3, mix(metal.m1, warm.w1, 0.4), mix(warm.w4, metal.m4, 0.35), mix(warm.w6, metal.m6, 0.3), mix(metal.m3, warm.w2, 0.4));
      pipeRun(tex, [[126, 24], [w, 24]], 3, mix(metal.m1, warm.w1, 0.4), mix(warm.w4, metal.m4, 0.35), mix(warm.w6, metal.m6, 0.3), mix(metal.m3, warm.w2, 0.4));
      for (const cx of [34, 74, 140, 168]) {
        tex.rect(cx, 22, 3, 7, mix(metal.m2, grime.g2, 0.4));
        tex.hline(cx, 22, 3, mix(metal.m5, dust.d6, 0.3));
      }
      cable(tex, 8, 30, 74, 32, 3, grime.g1, mix(warm.w3, grime.g2, 0.5));
      cable(tex, 140, 32, 196, 29, 3, grime.g1, mix(warm.w3, grime.g2, 0.5));
      techBox(tex, 76, 27, 8, 7, mix(metal.m3, slate.s3, 0.4), mix(metal.m6, slate.s6, 0.4), mix(metal.m1, slate.s1, 0.4), metal.m1);
      lamp(tex, 79, 30, cyan.c5, cyan.c2, withAlpha(cyan.c1, 150));
      techBox(tex, 128, 27, 8, 7, mix(metal.m3, slate.s3, 0.4), mix(metal.m6, slate.s6, 0.4), mix(metal.m1, slate.s1, 0.4), metal.m1);
      // big faded stencil + faction marking
      drawText(tex, 130, 2, 'MERIDIAN LINE', mix(metal.m4, dust.d5, 0.45), { worn: 0.6, seed: 6 });
      tex.rect(76, 6, 10, 12, mix(signal.s2, dust.d3, 0.35));
      tex.strokeRect(76, 6, 10, 12, mix(signal.s1, grime.g1, 0.4));
      tex.line(78, 14, 84, 8, mix(signal.s4, dust.d6, 0.4));
      // weathering
      for (let i = 0; i < 7; i++) grimePatch(tex, 6 + Math.floor(rnd() * (w - 12)), H - 8, 3 + rnd() * 5, [grime.g2, grime.g1], () => rnd(), 0.7);
      dustDrift(tex, 0, H - 5, w, [mix(dust.d5, CREAM.front[2], 0.4), mix(dust.d4, CREAM.front[2], 0.5)], () => rnd(), 1.1);
      weatherSpeckle(tex, 0, 0, w, H, [dust.d5, mix(metal.m6, dust.d7, 0.4), rust.x2, grime.g2], 0.03, () => rnd());
      for (const sx of [26, 80, 150]) rustRun(tex, sx + 1, 5, Math.round(H * 0.5), [rust.x1, rust.x2, mix(rust.x3, dust.d2, 0.6)], 1, sx);
    });
    cornice(g);
    // ---- roof
    roofMembrane(g, () => rnd());
    const { roofX, roofY, roofW, roofH } = g;
    parapet(g, mix(metal.m7, dust.d8, 0.3), mix(metal.m4, dust.d5, 0.35));
    // gravel beds
    gravelBed(g, roofX + 8, roofY + roofH - 20, 46, 14, () => rnd());
    gravelBed(g, roofX + roofW - 62, roofY + 6, 54, 12, () => rnd());
    // roof unit painter in sprite-local coords
    const dVs = (d: number) => Math.round(d * pr.vs);
    const hS = (h: number) => pr.projectHeight(h);
    const boxAt = (wx: number, wyFront: number, bw: number, bd: number, bh: number, C: BoxColors, paint?: Parameters<typeof drawBoxN3>[7]) => {
      const [bx, by] = g.S(wx, wyFront, HALL.h);
      drawBoxN3(s, bx, by, bw, dVs(bd), hS(bh), C, paint);
    };
    // HVAC units
    boxAt(276, 268, 30, 20, 12, SLATE, {
      face: (fx, fy, fw, fh) => {
        ventGrille(s, fx + 3, fy + 3, fw - 6, fh - 6, slate.s1, slate.s5);
        lamp(s, fx + fw - 3, fy + 2, amber.a5, amber.a2, withAlpha(amber.a1, 140));
      },
      top: (tx, ty, tw, th) => {
        // fan grille
        const cx = tx + Math.round(tw / 2);
        const cy = ty + Math.round(th / 2);
        s.ellipse(cx, cy, 8, Math.max(2, Math.round(th / 2) - 1), slate.s2);
        s.ellipseOutline(cx, cy, 8, Math.max(2, Math.round(th / 2) - 1), slate.s5);
        s.line(cx - 6, cy, cx + 6, cy, slate.s4);
        s.line(cx, cy - 2, cx, cy + 2, slate.s4);
        s.set(cx, cy, metal.m6);
      },
    });
    boxAt(400, 300, 26, 18, 10, WARM, {
      face: (fx, fy, fw, fh) => {
        ventGrille(s, fx + 2, fy + 2, fw - 4, fh - 4, warm.w1, warm.w5);
        rustRun(s, fx + 5, fy + fh - 2, 5, [rust.x2, rust.x3], 2, 5);
      },
      top: (tx, ty, tw, th) => {
        s.rect(tx + 3, ty + 2, tw - 6, Math.max(1, th - 4), mix(warm.w3, grime.g2, 0.5));
        bolts(s, tx + 2, ty + 1, warm.w1, warm.w6);
        bolts(s, tx + tw - 3, ty + 1, warm.w1, warm.w6);
      },
    });
    // central vent housing with two fans
    boxAt(340, 262, 38, 24, 13, {
      front: [mix(metal.m5, dust.d6, 0.3), mix(metal.m4, dust.d5, 0.3), mix(metal.m2, dust.d3, 0.35)],
      top: [mix(metal.m6, dust.d7, 0.3), mix(metal.m4, dust.d5, 0.35)],
      edge: metal.m1,
      rim: mix(metal.m8, dust.d8, 0.35),
    }, {
      face: (fx, fy, fw, fh) => {
        panelSeams(s, fx, fy, fw, fh, metal.m2, mix(metal.m7, dust.d7, 0.3), [Math.round(fw / 2)], []);
        techBox(s, fx + 4, fy + 3, 10, 7, slate.s3, slate.s5, slate.s1, metal.m1);
        lamp(s, fx + 8, fy + 6, cyan.c5, cyan.c2, withAlpha(cyan.c1, 130));
        rustRun(s, fx + fw - 8, fy + 2, fh - 3, [rust.x2, rust.x3, mix(rust.x3, dust.d2, 0.5)], 2, 9);
      },
      top: (tx, ty, _tw, th) => {
        for (const cxx of [tx + 10, tx + 26]) {
          const cyy = ty + Math.round(th / 2);
          s.ellipse(cxx, cyy, 7, Math.max(2, Math.round(th / 2) - 2), slate.s2);
          s.ellipseOutline(cxx, cyy, 7, Math.max(2, Math.round(th / 2) - 2), mix(metal.m6, dust.d6, 0.3));
          s.line(cxx - 5, cyy, cxx + 5, cyy, slate.s4);
          s.set(cxx, cyy, metal.m7);
        }
      },
    });
    // pipe run across the roof + drop over the south face
    pipeRun(s, [[g.S(268, 288, HALL.h)[0], g.S(268, 288, HALL.h)[1] - 2], [g.S(336, 288, HALL.h)[0], g.S(336, 288, HALL.h)[1] - 2]], 3, warm.w1, warm.w4, warm.w6, warm.w2);
    {
      const [dxp, dyp] = g.S(336, 340, HALL.h);
      pipeRun(s, [[dxp, dyp - 2], [dxp, dyp + 14]], 3, warm.w1, warm.w3, warm.w5, warm.w2);
    }
    // cable tray west->east with junction boxes and a droop over the parapet
    {
      const [tx0, ty0] = g.S(262, 310, HALL.h);
      const [tx1] = g.S(446, 310, HALL.h);
      s.rect(tx0, ty0 - 4, tx1 - tx0, 4, mix(slate.s2, grime.g1, 0.4));
      s.hline(tx0, ty0 - 4, tx1 - tx0, mix(slate.s5, dust.d5, 0.3));
      for (let u = tx0 + 3; u < tx1 - 2; u += 7) s.vline(u, ty0 - 3, 2, slate.s1);
      cable(s, tx0 + 6, ty0 - 4, tx0 + 90, ty0 - 5, 2, grime.g0, mix(warm.w2, grime.g2, 0.4));
      cable(s, tx0 + 100, ty0 - 5, tx1 - 8, ty0 - 4, 2, grime.g0, mix(warm.w2, grime.g2, 0.4));
      techBox(s, tx0 + 40, ty0 - 8, 9, 6, slate.s3, slate.s5, slate.s0, metal.m1);
      lamp(s, tx0 + 44, ty0 - 5, cyan.c5, cyan.c2, withAlpha(cyan.c1, 120));
      // droop down the wall
      const [wxp, wyp] = g.S(420, 340, HALL.h);
      cable(s, wxp - 14, ty0 - 4, wxp, wyp - 6, 8, grime.g0, mix(warm.w2, grime.g2, 0.4), 2);
      cable(s, wxp, wyp - 6, wxp + 2, wyp + 16, 3, grime.g0, mix(warm.w2, grime.g2, 0.4), 2);
    }
    // maintenance hatches
    const hatch = (hx: number, hy: number, hw: number, hd: number) => {
      const [x, y] = g.S(hx, hy + hd, HALL.h);
      const dh = Math.round(hd * pr.vs);
      s.rect(x, y, hw, dh, mix(metal.m4, dust.d5, 0.35));
      s.strokeRect(x, y, hw, dh, mix(metal.m2, grime.g2, 0.4));
      s.hline(x + 1, y + 1, hw - 2, mix(metal.m6, dust.d7, 0.35));
      s.rect(x + 3, y + Math.round(dh / 2) - 1, hw - 6, 2, mix(metal.m3, warm.w3, 0.4));
      s.set(x + Math.round(hw / 2), y + Math.round(dh / 2), metal.m7);
      hazardStripes(s, x, y + dh - 2, hw, 2, hazard.h1, hazard.h3, 5);
    };
    hatch(268, 296, 20, 13);
    hatch(420, 246, 18, 12);
    // skylights (glow at night)
    for (const [skx, sky] of [[308, 300], [338, 300]] as [number, number][]) {
      const [x, y] = g.S(skx, sky + 12, HALL.h);
      const dh = Math.round(12 * pr.vs);
      s.rect(x - 1, y - 1, 26, dh + 2, mix(metal.m3, dust.d4, 0.4));
      s.rect(x, y, 24, dh, teal.t1);
      s.rect(x, y, 24, Math.round(dh * 0.5), mix(teal.t2, cyan.c0, 0.5));
      s.line(x + 2, y + dh - 2, x + 20, y + 2, teal.t4);
      s.set(x + 4, y + dh - 3, teal.t5);
      s.strokeRect(x - 1, y - 1, 26, dh + 2, mix(metal.m1, grime.g1, 0.4));
      grimePatch(s, x + 18, y + dh - 3, 3, [grime.g2, grime.g1], () => rnd(), 0.6);
    }
    // walkway grating between hatch and central unit
    {
      const [x0, y0] = g.S(292, 300, HALL.h);
      const [x1] = g.S(340, 300, HALL.h);
      s.rect(x0, y0 - 8, x1 - x0, 8, mix(slate.s2, grime.g1, 0.5));
      for (let u = x0 + 2; u < x1 - 1; u += 4) s.vline(u, y0 - 7, 6, mix(slate.s4, warm.w3, 0.4));
      s.hline(x0, y0 - 8, x1 - x0, mix(slate.s5, dust.d5, 0.3));
      s.strokeRect(x0, y0 - 8, x1 - x0, 8, mix(slate.s1, grime.g0, 0.5));
    }
    // roof storytelling: faded painted zone, ghost of a removed unit,
    // walked maintenance path hatch -> central unit -> ladder
    {
      const [zx, zy] = g.S(300, 322, HALL.h);
      s.rect(zx, zy - 10, 56, 10, withAlpha(mix(signal.s2, dust.d4, 0.55), 60));
      drawText(s, zx + 8, zy - 8, 'K-7', withAlpha(mix(signal.s3, dust.d5, 0.5), 85), { worn: 0.7, seed: 8 });
      const [ox2, oy2] = g.S(380, 268, HALL.h);
      s.strokeRect(ox2, oy2, 26, 14, mix(grime.g2, warm.w2, 0.5));
      grimePatch(s, ox2 + 13, oy2 + 7, 6, [grime.g2, mix(grime.g1, warm.w2, 0.4)], () => rnd(), 0.5);
      bolts(s, ox2 + 2, oy2 + 2, grime.g1, warm.w5);
      bolts(s, ox2 + 22, oy2 + 10, grime.g1, warm.w5);
      let prev: [number, number] | null = null;
      for (let t = 0; t <= 26; t++) {
        const wxp = 288 + t * 6;
        const wyp = 304 - Math.max(0, t - 14) * 1.4;
        const p2 = g.S(wxp, wyp, HALL.h);
        if (prev) {
          s.line(prev[0], prev[1], p2[0], p2[1], withAlpha(mix(dust.d5, warm.w4, 0.4), 110));
          if (t % 3 === 0) s.set(p2[0], p2[1] + 1, withAlpha(dust.d6, 80));
        }
        prev = p2;
      }
    }
    // ladder down the east face (roof access)
    {
      const [lx, ly] = g.S(448, 340, HALL.h);
      s.rect(lx - 4, ly - 2, 2, H + 2, metal.m2);
      s.rect(lx + 2, ly - 2, 2, H + 2, metal.m2);
      for (let v = 0; v < H; v += 4) s.hline(lx - 4, ly + v, 8, mix(metal.m5, dust.d6, 0.3));
      s.vline(lx - 5, ly - 2, H + 2, mix(metal.m1, grime.g1, 0.4));
    }
    // roof edge shadows (AO under the parapet)
    for (let v = 0; v < 3; v++) {
      s.hline(roofX + 2, roofY + 2 + v, roofW - 4, withAlpha(mix(grime.g1, 0x00000000, 0), 70 - v * 22));
    }
  });
  push(hallBk, HALL.x, HALL.y, pr.depth(0, HALL.y, 0, 0.5), 'ext', 'hall');

  // =========================================================== NORTH MODULE
  const moduleBk = bakeMass(pr, MODULE, 34, (g) => {
    const { s } = g;
    wall(g, (tex, w, H) => {
      tex.rect(0, 0, w, H, mix(metal.m4, dust.d5, 0.3));
      tex.gradientDither(0, 0, w, H, [mix(metal.m5, dust.d6, 0.3), mix(metal.m3, dust.d4, 0.35)]);
      panelSeams(tex, 0, 0, w, H, mix(metal.m2, grime.g2, 0.4), mix(metal.m6, dust.d7, 0.3), [24, 50], [Math.round(H / 2)]);
      weatherSpeckle(tex, 0, 0, w, H, [dust.d5, rust.x2, metal.m5], 0.03, () => rnd());
    });
    cornice(g);
    roofMembrane(g, () => rnd(), 1.3);
    parapet(g, mix(metal.m6, dust.d7, 0.3), mix(metal.m3, dust.d4, 0.4), false);
    const dVs = (d: number) => Math.round(d * pr.vs);
    // cooling tank (cylinder)
    {
      const [cx, cy] = g.S(312, 212, MODULE.h);
      drawCylN3(s, cx, cy, 11, pr.projectHeight(18), Math.round(11 * pr.vs), [mix(metal.m6, dust.d7, 0.25), mix(metal.m4, dust.d5, 0.3), mix(metal.m2, dust.d3, 0.35)], [mix(metal.m7, dust.d8, 0.3), mix(metal.m5, dust.d6, 0.3)], metal.m1, (top) => {
        s.hline(cx - 10, top + 8, 20, mix(rust.x3, metal.m3, 0.5));
        s.hline(cx - 10, top + 16, 20, mix(metal.m2, grime.g2, 0.5));
        // ladder
        s.vline(cx + 8, top + 2, pr.projectHeight(18) - 2, metal.m3);
        s.vline(cx + 11, top + 2, pr.projectHeight(18) - 2, metal.m3);
        for (let v = top + 4; v < cy - 2; v += 3) s.hline(cx + 8, v, 4, mix(metal.m5, dust.d6, 0.3));
        grimePatch(s, cx - 4, top + 4, 4, [grime.g2, grime.g1], () => rnd(), 0.5);
      });
      rustRun(s, cx - 6, cy - pr.projectHeight(18) + 4, 12, [rust.x2, rust.x3, mix(rust.x3, dust.d2, 0.5)], 2, 3);
    }
    // exhaust stacks (steam emitters)
    for (const [stx, sty, sth] of [[342, 202, 26], [354, 198, 30]] as [number, number, number][]) {
      const [cx, cy] = g.S(stx, sty, MODULE.h);
      drawCylN3(s, cx, cy, 4, pr.projectHeight(sth), Math.round(4 * pr.vs), [warm.w5, warm.w3, warm.w1], [mix(warm.w6, metal.m6, 0.3), warm.w4], grime.g0, (top) => {
        s.ellipse(cx, top, 4, Math.max(1, Math.round(4 * pr.vs)), grime.g1);
        s.ellipseOutline(cx, top, 3, Math.max(1, Math.round(3 * pr.vs)), mix(grime.g0, warm.w1, 0.4));
      });
      // soot above the cap on the sprite? soot stains on the side
      rustRun(s, cx - 2, cy - pr.projectHeight(sth) + 2, 8, [grime.g1, grime.g2], 2, stx);
      // support collar
      const [, cyy] = g.S(stx, sty, MODULE.h + 3);
      s.rect(cx - 5, cyy, 10, 2, mix(metal.m3, warm.w2, 0.4));
    }
    // small vent box + gravel
    {
      const [bx, by] = g.S(294, 200, MODULE.h);
      drawBoxN3(s, bx, by, 14, dVs(10), pr.projectHeight(7), SLATE, {
        face: (fx, fy, fw, fh) => ventGrille(s, fx + 2, fy + 2, fw - 4, fh - 3, slate.s1, slate.s5),
      });
    }
    gravelBed(g, g.roofX + 6, g.roofY + 4, 30, g.roofH - 10, () => rnd());
    // conduit from tank south over the hall roof edge
    {
      const [px0, py0] = g.S(322, 220, MODULE.h);
      pipeRun(s, [[px0, py0 - 2], [px0 + 16, py0 - 2], [px0 + 16, py0 + 8]], 2, warm.w1, warm.w3, warm.w5, warm.w2);
    }
  });
  push(moduleBk, MODULE.x, MODULE.y, pr.depth(0, HALL.y - HALL.d, 0, -1), 'both', 'module');

  // =========================================================== WEST TOWER
  const towerBk = bakeMass(pr, TOWER, 40, (g) => {
    const { s } = g;
    wall(g, (tex, w, H) => {
      tex.rect(0, 0, w, H, OLIVE.front[1]);
      tex.gradientDither(0, 0, w, H, [OLIVE.front[0], OLIVE.front[1], OLIVE.front[2]]);
      // plinth
      tex.rect(0, H - 5, w, 5, mix(warm.w2, dust.d2, 0.35));
      tex.hline(0, H - 5, w, mix(warm.w4, dust.d4, 0.4));
      // floor slab band (2 storeys)
      const slab = Math.round(H * 0.52);
      tex.rect(0, slab, w, 3, mix(metal.m2, grime.g2, 0.4));
      tex.hline(0, slab, w, mix(metal.m6, dust.d7, 0.3));
      tex.hline(0, slab + 3, w, mix(metal.m1, grime.g1, 0.4));
      panelSeams(tex, 0, 0, w, H - 5, mix(olive.o1, metal.m1, 0.5), mix(olive.o5, metal.m6, 0.25), [22, 44], []);
      // tall windows: two per floor
      const towerWin = (u0: number, v0: number, lit: boolean) => {
        tex.rect(u0 - 2, v0 - 2, 13, 16, mix(metal.m1, grime.g1, 0.3));
        tex.rect(u0, v0, 9, 12, lit ? mix(teal.t2, cyan.c0, 0.4) : teal.t1);
        tex.rect(u0, v0, 9, 5, lit ? teal.t3 : teal.t2);
        tex.line(u0 + 1, v0 + 10, u0 + 7, v0 + 2, lit ? teal.t5 : teal.t4);
        tex.set(u0 + 2, v0 + 9, lit ? teal.t6 : teal.t5);
        tex.hline(u0, v0 + 6, 9, mix(metal.m2, slate.s2, 0.4));
        tex.strokeRect(u0 - 1, v0 - 1, 11, 14, metal.m1);
        tex.rect(u0 - 2, v0 + 13, 13, 1, mix(metal.m6, dust.d7, 0.3));
        tex.rect(u0 - 2, v0 + 14, 13, 1, mix(metal.m2, grime.g2, 0.4));
        rustRun(tex, u0 + 1, v0 + 15, 6, [rust.x2, mix(rust.x3, olive.o2, 0.4)], 1, u0);
      };
      towerWin(9, 6, true);
      towerWin(42, 6, false);
      towerWin(9, slab + 6, true);
      towerWin(42, slab + 6, true);
      // floor numbers
      drawText(tex, 29, 10, '02', mix(metal.m6, dust.d6, 0.4), { worn: 0.4, seed: 2 });
      drawText(tex, 29, slab + 10, '01', mix(metal.m6, dust.d6, 0.4), { worn: 0.4, seed: 3 });
      // ground door
      {
        const u0 = 26;
        const v0 = H - 5 - 18;
        tex.rect(u0 - 2, v0 - 2, 17, 20 + 2, mix(metal.m1, grime.g1, 0.3));
        tex.rect(u0, v0, 13, 18, mix(metal.m4, olive.o2, 0.35));
        tex.gradientDither(u0, v0, 13, 18, [mix(metal.m5, olive.o3, 0.3), mix(metal.m3, olive.o1, 0.4)]);
        tex.strokeRect(u0, v0, 13, 18, metal.m1);
        tex.rect(u0 + 3, v0 + 3, 7, 4, teal.t2);
        tex.hline(u0 + 3, v0 + 3, 7, teal.t4);
        tex.set(u0 + 10, v0 + 10, metal.m7);
        lamp(tex, u0 + 6, v0 - 4, amber.a6, amber.a3, withAlpha(amber.a2, 150));
        tex.rect(u0 + 4, v0 - 6, 5, 2, metal.m2);
      }
      // vertical pipe + cable on the east side
      pipeRun(tex, [[56, 4], [56, H - 5]], 3, mix(metal.m1, warm.w1, 0.4), mix(warm.w4, metal.m4, 0.3), mix(warm.w6, metal.m6, 0.3), warm.w2);
      cable(tex, 60, 6, 62, H - 8, 2, grime.g1, mix(warm.w3, grime.g2, 0.4));
      // vent on 2nd floor
      ventGrille(tex, 6, 22, 10, 7, mix(metal.m1, grime.g1, 0.4), mix(metal.m5, olive.o4, 0.3));
      // weathering
      for (let i = 0; i < 5; i++) grimePatch(tex, 4 + Math.floor(rnd() * (w - 8)), H - 8, 3 + rnd() * 4, [grime.g2, grime.g1], () => rnd(), 0.7);
      dustDrift(tex, 0, H - 5, w, [mix(dust.d5, OLIVE.front[2], 0.4), mix(dust.d4, olive.o2, 0.5)], () => rnd(), 1);
      weatherSpeckle(tex, 0, 0, w, H, [dust.d5, mix(olive.o5, metal.m6, 0.3), rust.x2, grime.g2], 0.03, () => rnd());
      rustRun(tex, 23, 4, Math.round(H * 0.55), [rust.x1, rust.x2, mix(rust.x3, olive.o1, 0.5)], 1, 7);
      rustRun(tex, 45, slab + 4, 16, [rust.x2, mix(rust.x3, olive.o1, 0.5)], 1, 13);
    });
    cornice(g);
    cornice(g);
    roofMembrane(g, () => rnd(), 0.9);
    parapet(g, mix(olive.o5, metal.m6, 0.3), mix(olive.o2, metal.m3, 0.4));
    // safety railing around the tower roof
    {
      const { roofX, roofY, roofW, roofH } = g;
      const rail = mix(metal.m5, dust.d6, 0.25);
      for (let u = 4; u < roofW - 2; u += 8) {
        s.vline(roofX + u, roofY - 6, 5, mix(metal.m3, grime.g2, 0.4));
        s.vline(roofX + u, roofY - 6, 4, rail);
      }
      s.hline(roofX + 2, roofY - 6, roofW - 4, rail);
      s.hline(roofX + 2, roofY - 4, roofW - 4, mix(metal.m3, grime.g2, 0.4));
      for (let v = 4; v < roofH - 2; v += 8) {
        s.vline(roofX + 1, roofY + v - 4, 4, rail);
        s.vline(roofX + roofW - 2, roofY + v - 4, 4, rail);
      }
    }
    // antenna mast (lattice) + dish + beacon
    {
      const [mx, my] = g.S(202, 274, TOWER.h);
      const mh = pr.projectHeight(30);
      s.vline(mx - 3, my - mh, mh, mix(metal.m4, grime.g2, 0.3));
      s.vline(mx + 3, my - mh, mh, mix(metal.m3, grime.g2, 0.4));
      for (let v = 0; v < mh; v += 4) {
        s.hline(mx - 3, my - mh + v, 7, mix(metal.m5, dust.d6, 0.3));
        s.line(mx - 3, my - mh + v, mx + 3, my - mh + v + 3, mix(metal.m3, warm.w3, 0.4));
      }
      // small cross-arm + dish
      s.hline(mx - 7, my - mh + 6, 15, metal.m4);
      s.ellipse(mx + 8, my - mh + 9, 5, 3, mix(metal.m6, dust.d7, 0.3));
      s.ellipseOutline(mx + 8, my - mh + 9, 5, 3, metal.m2);
      s.set(mx + 8, my - mh + 9, metal.m8);
      // beacon at the tip
      lamp(s, mx, my - mh - 2, signal.s4, signal.s2, withAlpha(signal.s1, 160));
      s.vline(mx, my - mh - 1, 2, metal.m3);
    }
    // vent box + hatch on the tower roof
    {
      const dVs = (d: number) => Math.round(d * pr.vs);
      const [bx, by] = g.S(230, 330, TOWER.h);
      drawBoxN3(s, bx, by, 14, dVs(10), pr.projectHeight(8), SLATE, {
        face: (fx, fy, fw, fh) => ventGrille(s, fx + 2, fy + 2, fw - 4, fh - 3, slate.s1, slate.s5),
      });
      const [hx, hy] = g.S(200, 340, TOWER.h);
      s.rect(hx, hy - 8, 16, 8, mix(metal.m4, dust.d5, 0.3));
      s.strokeRect(hx, hy - 8, 16, 8, mix(metal.m2, grime.g2, 0.4));
      s.hline(hx + 1, hy - 7, 14, mix(metal.m6, dust.d7, 0.3));
      s.rect(hx + 4, hy - 5, 8, 2, mix(metal.m3, warm.w3, 0.4));
    }
    gravelBed(g, g.roofX + g.roofW - 30, g.roofY + 6, 24, 16, () => rnd());
  });
  push(towerBk, TOWER.x, TOWER.y, pr.depth(0, TOWER.y, 0, 0.5), 'both', 'tower');

  // =========================================================== GARAGE
  const garageBk = bakeMass(pr, GARAGE, 20, (g) => {
    const { s } = g;
    wall(g, (tex, w, H) => {
      tex.rect(0, 0, w, H, mix(metal.m4, dust.d5, 0.3));
      tex.gradientDither(0, 0, w, H, [mix(metal.m5, dust.d6, 0.25), mix(metal.m3, dust.d4, 0.35)]);
      // ribbed siding
      for (let u = 2; u < w - 1; u += 3) {
        tex.vline(u, 3, H - 8, mix(metal.m2, grime.g2, 0.35));
        tex.vline(u + 1, 3, H - 8, mix(metal.m6, dust.d7, 0.25));
      }
      tex.rect(0, H - 5, w, 5, mix(warm.w2, dust.d2, 0.35));
      tex.hline(0, H - 5, w, mix(warm.w4, dust.d4, 0.4));
      // lintel stencil above the shutter
      stencilPlate(tex, 24, 1, 'BAY 03', mix(metal.m3, dust.d4, 0.35), metal.m1, mix(metal.m7, dust.d7, 0.3), 0.3);
      // big roll-up shutter
      {
        const u0 = 8;
        const v0 = 11;
        const sh = H - 5 - v0 - 1;
        tex.rect(u0 - 3, v0 - 3, 62, sh + 4, mix(metal.m2, grime.g2, 0.3));
        tex.rect(u0 - 2, v0 - 2, 60, sh + 3, mix(metal.m3, slate.s2, 0.4));
        tex.rect(u0, v0, 56, sh, mix(metal.m4, warm.w3, 0.3));
        for (let v = 0; v < sh; v += 2) {
          tex.hline(u0, v0 + v, 56, mix(metal.m5, dust.d6, 0.25));
          tex.hline(u0, v0 + v + 1, 56, mix(metal.m2, grime.g2, 0.45));
        }
        tex.strokeRect(u0, v0, 56, sh, metal.m1);
        hazardStripes(tex, u0, v0 + sh - 3, 56, 3, hazard.h1, hazard.h3, 6);
        tex.rect(u0 + 25, v0 + sh - 7, 7, 2, metal.m6);
        scratches(tex, u0 + 2, v0 + 4, 52, sh - 6, mix(metal.m6, dust.d7, 0.3), mix(metal.m2, grime.g2, 0.4), 7, () => rnd());
        for (const rx of [u0 + 4, u0 + 30, u0 + 48]) rustRun(tex, rx, v0 + 2, sh - 4, [rust.x2, rust.x3, mix(rust.x4, dust.d3, 0.5)], 2, rx);
      }
      // personnel door
      {
        const u0 = 72;
        const v0 = H - 5 - 18;
        tex.rect(u0 - 2, v0 - 2, 16, 20 + 2, mix(metal.m2, slate.s1, 0.4));
        tex.rect(u0, v0, 12, 18, mix(rust.x3, warm.w3, 0.3));
        tex.gradientDither(u0, v0, 12, 18, [mix(rust.x4, warm.w4, 0.3), mix(rust.x2, warm.w2, 0.4)]);
        tex.strokeRect(u0, v0, 12, 18, metal.m1);
        tex.rect(u0 + 3, v0 + 3, 6, 4, teal.t2);
        tex.set(u0 + 9, v0 + 10, metal.m7);
      }
      // wall lamp + conduit
      lamp(tex, 68, 5, amber.a6, amber.a3, withAlpha(amber.a2, 140));
      tex.rect(66, 3, 5, 2, metal.m2);
      pipeRun(tex, [[4, 3], [4, H - 6]], 2, mix(metal.m1, warm.w1, 0.4), mix(warm.w4, metal.m4, 0.3), mix(warm.w6, metal.m6, 0.3), warm.w2);
      // weathering
      dustDrift(tex, 0, H - 5, w, [mix(dust.d5, metal.m4, 0.4), mix(dust.d4, metal.m3, 0.5)], () => rnd(), 1.1);
      for (let i = 0; i < 4; i++) grimePatch(tex, 4 + Math.floor(rnd() * (w - 8)), H - 8, 3 + rnd() * 4, [grime.g2, grime.g1], () => rnd(), 0.7);
      weatherSpeckle(tex, 0, 0, w, H, [dust.d5, metal.m5, rust.x2, grime.g2], 0.03, () => rnd());
    });
    cornice(g);
    cornice(g);
    roofMembrane(g, () => rnd(), 1.1);
    parapet(g, mix(metal.m6, dust.d7, 0.3), mix(metal.m3, dust.d4, 0.4), false);
    const dVs = (d: number) => Math.round(d * pr.vs);
    // solar array (3 panels)
    for (let k = 0; k < 3; k++) {
      const [px, py] = g.S(462 + k * 26, 320, GARAGE.h);
      const pw = 22;
      const ph = dVs(26);
      s.rect(px, py - ph - 3, pw, ph, mix(teal.t1, slate.s1, 0.4));
      s.rect(px + 1, py - ph - 2, pw - 2, ph - 2, mix(teal.t2, cyan.c0, 0.55));
      for (let u = 4; u < pw - 2; u += 5) s.vline(px + u, py - ph - 2, ph - 2, mix(teal.t1, slate.s0, 0.5));
      for (let v = 3; v < ph - 2; v += 5) s.hline(px + 1, py - ph - 2 + v, pw - 2, mix(teal.t1, slate.s0, 0.5));
      s.line(px + 2, py - 4, px + pw - 3, py - ph - 1, mix(teal.t4, cyan.c2, 0.4));
      s.strokeRect(px, py - ph - 3, pw, ph, mix(metal.m2, grime.g2, 0.4));
      s.rect(px + 2, py - 3, 2, 3, metal.m3);
      s.rect(px + pw - 4, py - 3, 2, 3, metal.m3);
      grimePatch(s, px + pw - 6, py - 6, 3, [grime.g2, grime.g1], () => rnd(), 0.5);
    }
    // sat dish on a tripod
    {
      const [dx, dy] = g.S(522, 300, GARAGE.h);
      s.line(dx - 4, dy, dx, dy - 8, metal.m3);
      s.line(dx + 4, dy, dx, dy - 8, metal.m3);
      s.line(dx, dy, dx, dy - 8, metal.m4);
      s.ellipse(dx, dy - 13, 7, 5, mix(metal.m6, dust.d7, 0.3));
      s.ellipse(dx, dy - 13, 5, 3, mix(metal.m4, dust.d5, 0.35));
      s.ellipseOutline(dx, dy - 13, 7, 5, mix(metal.m2, grime.g2, 0.4));
      s.set(dx, dy - 13, metal.m8);
      s.line(dx, dy - 13, dx + 5, dy - 17, metal.m3);
      s.set(dx + 5, dy - 17, cyan.c4);
    }
    // vent pipe + gravel
    {
      const [vx, vy] = g.S(470, 286, GARAGE.h);
      drawCylN3(s, vx, vy, 3, pr.projectHeight(9), 2, [warm.w5, warm.w3, warm.w1], [warm.w6, warm.w4], grime.g0);
      s.ellipse(vx, vy - pr.projectHeight(9), 3, 2, grime.g1);
    }
    gravelBed(g, g.roofX + 4, g.roofY + g.roofH - 16, 30, 12, () => rnd());
  });
  push(garageBk, GARAGE.x, GARAGE.y, pr.depth(0, GARAGE.y, 0, 0.5), 'both', 'garage');

  // =========================================================== PORCH
  const porchBk = bakeMass(pr, PORCH, 6, (g) => {
    const { s } = g;
    // canopy slab (its own small roof) + fascia
    roofMembrane(g, () => rnd(), 0.7);
    const { roofX, roofY, roofW, roofH } = g;
    s.hline(roofX, roofY + roofH - 1, roofW, mix(metal.m7, dust.d8, 0.3));
    s.hline(roofX, roofY + roofH, roofW, mix(metal.m3, grime.g2, 0.4));
    s.hline(roofX, roofY + roofH + 1, roofW, mix(metal.m1, grime.g0, 0.5));
    s.vline(roofX, roofY, roofH + 2, mix(metal.m2, grime.g2, 0.4));
    s.vline(roofX + roofW - 1, roofY, roofH + 2, mix(metal.m2, grime.g2, 0.4));
    hazardStripes(s, roofX + 6, roofY + roofH - 1, roofW - 12, 1, hazard.h1, hazard.h3, 6);
    // warm soffit glow under the canopy
    for (let u = 6; u < roofW - 6; u++) {
      if (bayer4(u, 0) < 0.75) s.set(roofX + u, roofY + roofH + 2, withAlpha(amber.a4, 90));
    }
    // support posts
    for (const wxp of [PORCH.x + 3, PORCH.x + PORCH.w - 5]) {
      const [px, py] = g.S(wxp, PORCH.y);
      const [, ptop] = g.S(wxp, PORCH.y, PORCH.h);
      s.rect(px, ptop, 4, py - ptop, mix(metal.m4, dust.d5, 0.3));
      s.vline(px, ptop, py - ptop, mix(metal.m6, dust.d7, 0.3));
      s.vline(px + 3, ptop, py - ptop, mix(metal.m1, grime.g1, 0.4));
      s.rect(px - 1, py - 2, 6, 2, mix(metal.m3, warm.w3, 0.4)); // base plate
      bolts(s, px, py - 2, metal.m1, metal.m6);
      rustRun(s, px + 1, py - 8, 7, [rust.x2, rust.x3], 1, wxp);
    }
    // hanging lamp under the canopy
    {
      const [lxp, lyp] = g.S(PORCH.x + PORCH.w / 2, PORCH.y - 6, PORCH.h - 4);
      s.vline(lxp, lyp - 4, 4, metal.m2);
      lamp(s, lxp, lyp + 1, amber.a7, amber.a4, withAlpha(amber.a2, 170));
    }
  });
  push(porchBk, PORCH.x, PORCH.y, pr.depth(0, PORCH.y, 0, 0.2), 'ext', 'porch');

  // steps + landing (stay visible in cutaway: they are outside)
  {
    const stepSprite = new PixelSurface(72, 26);
    const dVs = (d: number) => Math.round(d * pr.vs);
    // landing slab
    const [lx, ly] = gp(PORCH.x - 4, PORCH.y + 10);
    const local = (wx: number, wy: number, wz = 0): [number, number] => {
      const [sxp, syp] = gp(wx, wy, wz);
      return [sxp - lx + 8, syp - ly + 16];
    };
    {
      const a = local(PORCH.x - 4, PORCH.y + 10);
      const dh = dVs(8);
      stepSprite.rect(a[0], a[1] - dh, 60, dh, mix(warm.w3, dust.d3, 0.35));
      stepSprite.hline(a[0], a[1] - dh, 60, mix(warm.w5, dust.d5, 0.35));
      for (let u = 6; u < 60; u += 12) stepSprite.vline(a[0] + u, a[1] - dh + 1, dh - 1, mix(warm.w2, dust.d2, 0.4));
    }
    {
      const [a] = [local(PORCH.x + 2, PORCH.y + 16)];
      const dh = dVs(6);
      stepSprite.rect(a[0], a[1] - dh, 48, dh, mix(warm.w4, dust.d4, 0.3));
      stepSprite.hline(a[0], a[1] - dh, 48, mix(warm.w6, dust.d6, 0.3));
      hazardStripes(stepSprite, a[0], a[1] - 2, 48, 2, hazard.h1, hazard.h3, 6);
    }
    push({ sprite: stepSprite, ax: 8, ay: 16 }, PORCH.x - 4, PORCH.y + 10, pr.depth(0, PORCH.y + 16), 'both', 'steps');
  }

  // =========================================================== INTERIOR
  const intBk = (() => {
    // sprite-local coords from world (floor z=0, walls to z=44)
    const pad = 8;
    const x0w = HALL.x - 4;
    const x1w = HALL.x + HALL.w + 4;
    const yTopS = Math.round((INT.y) * pr.vs) - pr.projectHeight(HALL.h) - pad;
    const yBotS = Math.round((INT.y + INT.h) * pr.vs) + pad;
    const wS = x1w - x0w + pad * 2;
    const hS = yBotS - yTopS;
    const s = new PixelSurface(wS, hS);
    const lx = -(x0w - pad);
    const ly = -yTopS;
    const S = (wx: number, wy: number, wz = 0): [number, number] => [Math.round(wx + lx), Math.round(wy * pr.vs - pr.projectHeight(wz) + ly)];
    const dVs = (d: number) => Math.round(d * pr.vs);
    const boxAt = (wx: number, wyFront: number, bw: number, bd: number, bh: number, C: BoxColors, paint?: Parameters<typeof drawBoxN3>[7]) => {
      const [bx, by] = S(wx, wyFront);
      drawBoxN3(s, bx, by, bw, dVs(bd), pr.projectHeight(bh), C, paint);
    };

    // ---- floor (deck plates)
    {
      const [fxp, fyn] = S(INT.x, INT.y);
      const [, fys] = S(INT.x, INT.y + INT.h);
      const fw = INT.w;
      const fh = fys - fyn;
      s.rect(fxp, fyn, fw, fh, mix(slate.s4, warm.w3, 0.25));
      s.ditherRect(fxp, fyn, fw, fh, mix(slate.s4, warm.w3, 0.25), mix(slate.s5, warm.w4, 0.2), 0.5);
      for (let u = 16; u < fw; u += 16) {
        s.vline(fxp + u, fyn, fh, mix(slate.s2, grime.g2, 0.5));
        s.vline(fxp + u + 1, fyn, fh, mix(slate.s5, warm.w4, 0.3));
      }
      for (let v = dVs(16); v < fh; v += dVs(16)) {
        s.hline(fxp, fyn + v, fw, mix(slate.s2, grime.g2, 0.5));
        s.hline(fxp, fyn + v + 1, fw, mix(slate.s5, warm.w4, 0.3));
      }
      // grating strip across the middle
      s.rect(fxp + 8, fyn + Math.round(fh * 0.55), fw - 16, 5, mix(slate.s2, grime.g1, 0.5));
      for (let u = fxp + 10; u < fxp + fw - 8; u += 3) s.vline(u, fyn + Math.round(fh * 0.55) + 1, 3, mix(slate.s4, warm.w3, 0.4));
      // wear + stains
      for (let i = 0; i < 10; i++) {
        grimePatch(s, fxp + 8 + Math.floor(rnd() * (fw - 16)), fyn + 6 + Math.floor(rnd() * (fh - 12)), 3 + rnd() * 6, [mix(slate.s2, grime.g2, 0.5), mix(slate.s1, grime.g1, 0.5)], () => rnd(), 0.5);
      }
      {
        const [oxp, oyp] = S(276, 268);
        grimePatch(s, oxp, oyp, 12, [grime.g1, grime.g0, mix(grime.g0, slate.s1, 0.5)], () => rnd(), 0.5);
      }
      // hazard border of the machinery bay
      hazardStripes(s, fxp + 2, fyn + 2, 48, 2, hazard.h0, hazard.h2, 6);
      hazardStripes(s, fxp + 2, fyn + 2, 2, dVs(44), hazard.h0, hazard.h2, 6);
      // painted walkway line to the door
      {
        const [wxp, wyn] = S(348, INT.y + 6);
        const [, wys] = S(348, INT.y + INT.h - 4);
        s.vline(wxp, wyn, wys - wyn, mix(hazard.h2, slate.s4, 0.45));
        s.vline(wxp + 8, wyn, wys - wyn, mix(hazard.h2, slate.s4, 0.45));
        for (let v = wyn; v < wys; v += 5) {
          s.set(wxp + 2, v, mix(hazard.h1, slate.s3, 0.5));
          s.set(wxp + 6, v + 2, mix(hazard.h1, slate.s3, 0.5));
        }
      }
      // floor cable runs
      cable(s, fxp + 60, fyn + fh - 8, fxp + 120, fyn + fh - 5, 2, grime.g0, mix(warm.w2, grime.g2, 0.5), 2);
      cable(s, fxp + 96, fyn + 30, fxp + 150, fyn + 34, 3, grime.g0, mix(warm.w2, grime.g2, 0.5), 2);
      // rug in the rest corner
      {
        const [rxp, ryn] = S(402, 306);
        const [, rys] = S(402, 324);
        s.rect(rxp, ryn, 30, rys - ryn, mix(signal.s1, dust.d2, 0.4));
        s.strokeRect(rxp, ryn, 30, rys - ryn, mix(signal.s2, dust.d3, 0.35));
        s.rect(rxp + 3, ryn + 2, 24, Math.max(1, rys - ryn - 4), mix(signal.s2, rust.x2, 0.3));
        for (let u = rxp + 5; u < rxp + 26; u += 4) s.vline(u, ryn + 3, Math.max(1, rys - ryn - 6), mix(signal.s1, dust.d1, 0.4));
      }
    }

    // ---- north inner wall face
    {
      const [wx0, wyTop] = S(INT.x, INT.y, HALL.h);
      const [, wyBot] = S(INT.x, INT.y);
      const fw = INT.w;
      const fh = wyBot - wyTop;
      s.rect(wx0, wyTop, fw, fh, mix(slate.s5, dust.d5, 0.2));
      s.gradientDither(wx0, wyTop, fw, fh, [mix(slate.s6, dust.d6, 0.25), mix(slate.s5, dust.d5, 0.2), mix(slate.s3, warm.w2, 0.3)]);
      // top bevel + skirting
      s.hline(wx0, wyTop, fw, mix(warm.w6, slate.s6, 0.4));
      s.hline(wx0, wyTop + 1, fw, mix(warm.w4, slate.s5, 0.35));
      s.rect(wx0, wyBot - 3, fw, 3, mix(slate.s2, warm.w1, 0.4));
      s.hline(wx0, wyBot - 3, fw, mix(slate.s4, warm.w3, 0.4));
      // conduit runs
      pipeRun(s, [[wx0 + 4, wyTop + 6], [wx0 + fw - 4, wyTop + 6]], 2, slate.s1, mix(slate.s4, warm.w3, 0.4), mix(slate.s6, warm.w5, 0.3), slate.s2);
      cable(s, wx0 + 40, wyTop + 8, wx0 + 90, wyTop + 9, 2, grime.g0, mix(warm.w2, grime.g2, 0.5));
      cable(s, wx0 + 120, wyTop + 8, wx0 + 170, wyTop + 10, 2, grime.g0, mix(warm.w2, grime.g2, 0.5));
      // fuse boxes
      for (const bx of [16, 150]) {
        techBox(s, wx0 + bx, wyTop + 10, 12, 10, mix(slate.s3, warm.w2, 0.3), mix(slate.s6, warm.w4, 0.3), mix(slate.s1, warm.w0, 0.4), slate.s0);
        lamp(s, wx0 + bx + 3, wyTop + 13, cyan.c5, cyan.c2, withAlpha(cyan.c1, 130));
        lamp(s, wx0 + bx + 8, wyTop + 13, amber.a5, amber.a2, withAlpha(amber.a1, 120));
        for (let v = 0; v < 3; v++) s.hline(wx0 + bx + 2, wyTop + 16 + v, 8, slate.s2);
      }
      // big map screen
      {
        const mx = wx0 + 82;
        const my = wyTop + 9;
        s.rect(mx - 2, my - 2, 40, 20, mix(slate.s2, warm.w1, 0.4));
        screenFill(s, mx, my, 36, 16, mix(teal.t0, slate.s0, 0.4), cyan.c2, cyan.c5, () => rnd());
        // coastline-ish squiggle
        s.line(mx + 4, my + 10, mx + 12, my + 5, cyan.c4);
        s.line(mx + 12, my + 5, mx + 20, my + 9, cyan.c4);
        s.line(mx + 20, my + 9, mx + 30, my + 4, cyan.c4);
        s.set(mx + 20, my + 9, amber.a5);
        s.strokeRect(mx - 2, my - 2, 40, 20, slate.s0);
        s.hline(mx - 2, my - 2, 40, mix(slate.s5, warm.w4, 0.3));
      }
      // vent grille high on the wall
      ventGrille(s, wx0 + 134, wyTop + 4, 14, 8, mix(slate.s1, grime.g1, 0.4), mix(slate.s5, warm.w4, 0.3));
      // posters + stencil
      s.rect(wx0 + 56, wyTop + 10, 9, 12, mix(dust.d6, amber.a4, 0.25));
      s.strokeRect(wx0 + 56, wyTop + 10, 9, 12, mix(grime.g2, slate.s1, 0.4));
      s.line(wx0 + 58, wyTop + 18, wx0 + 63, wyTop + 12, mix(signal.s2, dust.d3, 0.4));
      s.rect(wx0 + 68, wyTop + 11, 8, 10, mix(metal.m5, dust.d6, 0.3));
      s.strokeRect(wx0 + 68, wyTop + 11, 8, 10, mix(grime.g2, slate.s1, 0.4));
      drawText(s, wx0 + 69, wyTop + 14, 'K7', mix(slate.s2, grime.g1, 0.4));
      drawText(s, wx0 + 160, wyTop + 12, 'DECK 1', mix(slate.s7, dust.d7, 0.3), { worn: 0.5, seed: 5 });
      // wall sconces (warm)
      for (const bx of [30, 100, 168]) {
        s.rect(wx0 + bx, wyTop + 3, 4, 3, mix(warm.w2, slate.s2, 0.4));
        lamp(s, wx0 + bx + 2, wyTop + 6, amber.a6, amber.a3, withAlpha(amber.a2, 150));
      }
      weatherSpeckle(s, wx0, wyTop, fw, fh, [mix(slate.s3, warm.w2, 0.4), mix(slate.s6, dust.d6, 0.3), rust.x2], 0.02, () => rnd());
    }

    // inner ambient-occlusion ring along the walls
    {
      const [fxp, fyn] = S(INT.x, INT.y);
      const [, fys] = S(INT.x, INT.y + INT.h);
      const fw = INT.w;
      const fh = fys - fyn;
      for (let k = 0; k < 3; k++) {
        const a = withAlpha(grime.g1, 80 - k * 24);
        s.hline(fxp, fyn + k, fw, a);
        s.vline(fxp + k, fyn, fh, a);
        s.vline(fxp + fw - 1 - k, fyn, fh, a);
        s.hline(fxp, fys - 1 - k, fw, a);
      }
      // door mat at the entrance
      const [mxp, myp] = S(346, 328);
      const [, mys] = S(346, 336);
      s.rect(mxp, myp, 20, mys - myp, mix(grime.g2, slate.s2, 0.4));
      s.strokeRect(mxp, myp, 20, mys - myp, mix(grime.g1, slate.s1, 0.4));
      for (let u = mxp + 2; u < mxp + 18; u += 3) s.vline(u, myp + 1, mys - myp - 2, mix(grime.g1, slate.s1, 0.5));
      // painted direction arrow on the walkway
      const [axp, ayp] = S(350, 300);
      s.line(axp, ayp, axp, ayp - 8, mix(hazard.h2, slate.s4, 0.45));
      s.line(axp - 3, ayp - 5, axp, ayp - 8, mix(hazard.h2, slate.s4, 0.45));
      s.line(axp + 3, ayp - 5, axp, ayp - 8, mix(hazard.h2, slate.s4, 0.45));
    }
    // toolbox by the bench
    boxAt(372, 332, 10, 7, 6, {
      front: [signal.s3, signal.s2, signal.s1],
      top: [signal.s4, signal.s3],
      edge: signal.s0,
      rim: mix(signal.s4, dust.d6, 0.3),
    }, {
      face: (fx, fy, fw, fh) => {
        s.hline(fx + 1, fy + Math.round(fh / 2), fw - 2, mix(signal.s1, grime.g1, 0.4));
        s.set(fx + Math.round(fw / 2), fy + 1, metal.m6);
      },
    });
    // small trolley near storage
    boxAt(394, 320, 12, 8, 7, SLATE, {
      face: (fx, fy, fw, fh) => {
        s.hline(fx + 1, fy + 2, fw - 2, mix(slate.s6, warm.w5, 0.3));
        s.set(fx + 2, fy + fh - 1, grime.g0);
        s.set(fx + fw - 3, fy + fh - 1, grime.g0);
      },
      top: (tx, ty, tw, th) => {
        s.rect(tx + 2, ty + 1, tw - 4, Math.max(1, th - 2), mix(dust.d4, warm.w3, 0.4));
      },
    });

    // ---- cut wall stubs (wall thickness read)
    for (const side of [0, 1]) {
      const wxEdge = side === 0 ? HALL.x : HALL.x + HALL.w - 4;
      const [cxp, cyn] = S(wxEdge, INT.y, HALL.h);
      const [, cys] = S(wxEdge, INT.y + INT.h);
      const capW = 4;
      // top cap of the stub (the cut wall's "roof")
      s.rect(cxp, cyn, capW, cys - cyn, mix(CREAM.top[1], dust.d5, 0.25));
      s.vline(cxp, cyn, cys - cyn, mix(CREAM.top[0], dust.d6, 0.3));
      s.vline(cxp + capW - 1, cyn, cys - cyn, mix(metal.m2, grime.g2, 0.4));
      // layered cut face at the south end
      const [sxp, syp] = S(wxEdge, INT.y + INT.h, HALL.h);
      const [, syg] = S(wxEdge, INT.y + INT.h);
      s.rect(sxp, syp, capW, syg - syp, mix(warm.w3, dust.d3, 0.3));
      s.vline(sxp, syp, syg - syp, mix(metal.m5, dust.d6, 0.3)); // outer paint
      s.vline(sxp + 1, syp, syg - syp, mix(rust.x2, warm.w2, 0.4)); // core
      s.vline(sxp + 2, syp, syg - syp, mix(slate.s4, warm.w3, 0.3)); // core
      s.vline(sxp + 3, syp, syg - syp, mix(slate.s6, dust.d6, 0.25)); // inner paint
      s.hline(sxp, syp, capW, mix(metal.m6, dust.d7, 0.3));
    }

    // ---- furniture (back to front)
    // machinery bay generator (west)
    boxAt(262, 268, 34, 26, 22, WARM, {
      face: (fx, fy, fw, fh) => {
        ventGrille(s, fx + 3, fy + 4, 14, fh - 8, warm.w1, warm.w5);
        techBox(s, fx + 20, fy + 3, 11, 9, slate.s3, slate.s5, slate.s0, metal.m1);
        lamp(s, fx + 23, fy + 6, amber.a6, amber.a3, withAlpha(amber.a2, 150));
        lamp(s, fx + 28, fy + 6, cyan.c5, cyan.c2, withAlpha(cyan.c1, 130));
        s.ellipse(fx + 25, fy + fh - 5, 3, 3, slate.s2);
        s.ellipseOutline(fx + 25, fy + fh - 5, 3, 3, mix(slate.s6, warm.w5, 0.3));
        s.set(fx + 26, fy + fh - 6, mix(slate.s7, warm.w6, 0.3));
        rustRun(s, fx + 6, fy + fh - 4, 4, [rust.x2, rust.x3], 2, 3);
        hazardStripes(s, fx, fy + fh - 2, fw, 2, hazard.h0, hazard.h2, 5);
      },
      top: (tx, ty, tw, th) => {
        s.rect(tx + 4, ty + 2, tw - 8, Math.max(1, th - 4), mix(warm.w2, grime.g2, 0.5));
        bolts(s, tx + 2, ty + 1, warm.w1, warm.w6);
        bolts(s, tx + tw - 4, ty + th - 3, warm.w1, warm.w6);
        // exhaust pipe stub rising
        s.rect(tx + tw - 10, ty - 6, 4, 8, warm.w3);
        s.vline(tx + tw - 10, ty - 6, 8, warm.w5);
        s.hline(tx + tw - 10, ty - 6, 4, warm.w6);
      },
    });
    // pipes from generator up the west inner wall
    {
      const [pxp, pyp] = S(268, INT.y + 2, 18);
      pipeRun(s, [[pxp, pyp], [pxp, pyp - 14], [pxp + 20, pyp - 14]], 2, warm.w1, warm.w3, warm.w5, warm.w2);
    }
    // lockers (north wall, east of centre)
    for (let k = 0; k < 4; k++) {
      const lxw = 366 + k * 9;
      boxAt(lxw, 240, 8, 7, 20, k === 2 ? SLATE : OLIVE, {
        face: (fx, fy, fw, fh) => {
          s.strokeRect(fx + 1, fy + 1, fw - 2, fh - 2, mix(slate.s1, olive.o0, 0.4));
          ventGrille(s, fx + 2, fy + 2, fw - 4, 3, mix(slate.s1, olive.o0, 0.5), mix(slate.s5, olive.o4, 0.3));
          s.set(fx + fw - 2, fy + Math.round(fh / 2), metal.m6);
          s.rect(fx + 2, fy + fh - 6, 4, 3, mix(metal.m5, dust.d6, 0.3)); // name plate
          if (k === 2) s.vline(fx + fw - 2, fy + 2, fh - 4, slate.s0); // ajar
        },
      });
    }
    // terminal desk + screens + chair
    boxAt(310, 246, 46, 12, 12, SLATE, {
      face: (fx, fy, fw, fh) => {
        panelSeams(s, fx, fy, fw, fh, slate.s1, mix(slate.s6, warm.w5, 0.3), [15, 30], []);
        s.rect(fx + 4, fy + fh - 4, 8, 3, slate.s2);
        techBox(s, fx + 34, fy + 3, 9, 6, slate.s3, slate.s5, slate.s0, metal.m1);
      },
      top: (tx, ty) => {
        // keyboards + clutter on the desk top
        s.rect(tx + 6, ty + 2, 12, 4, mix(slate.s2, warm.w1, 0.4));
        for (let u = tx + 7; u < tx + 17; u += 2) s.set(u, ty + 3, mix(slate.s5, warm.w4, 0.3));
        s.rect(tx + 24, ty + 3, 8, 3, mix(dust.d4, warm.w3, 0.4)); // papers
        s.set(tx + 40, ty + 2, amber.a3); // mug
        s.set(tx + 40, ty + 3, amber.a1);
      },
    });
    for (let k = 0; k < 3; k++) {
      const scx = 314 + k * 14;
      boxAt(scx, 240, 10, 3, 9, {
        front: [mix(slate.s3, teal.t0, 0.3), slate.s2, slate.s1],
        top: [slate.s4, slate.s3],
        edge: slate.s0,
        rim: slate.s5,
      }, {
        face: (fx, fy, fw, fh) => {
          screenFill(s, fx + 1, fy + 1, fw - 2, fh - 2, mix(teal.t0, slate.s0, 0.5), cyan.c2, cyan.c5, () => rnd());
        },
      });
    }
    // chair
    boxAt(326, 258, 7, 7, 8, {
      front: [mix(olive.o3, slate.s3, 0.4), mix(olive.o2, slate.s2, 0.4), mix(olive.o1, slate.s1, 0.4)],
      top: [mix(olive.o4, slate.s4, 0.3), mix(olive.o2, slate.s2, 0.4)],
      edge: slate.s0,
      rim: mix(olive.o5, slate.s5, 0.3),
    });
    // storage shelves along the east inner wall
    for (let k = 0; k < 3; k++) {
      const sy0 = 252 + k * 22;
      boxAt(428, sy0 + 18, 16, 18, 24, WARM, {
        face: (fx, fy, fw, fh) => {
          // shelf tiers with stored junk
          for (let t = 0; t < 3; t++) {
            const ty2 = fy + 3 + t * 7;
            s.hline(fx + 1, ty2 + 5, fw - 2, mix(warm.w5, dust.d5, 0.3));
            s.hline(fx + 1, ty2 + 6, fw - 2, mix(warm.w2, grime.g2, 0.4));
            const items = [mix(rust.x3, warm.w3, 0.3), mix(slate.s4, teal.t1, 0.4), mix(dust.d5, warm.w4, 0.3), mix(olive.o3, slate.s3, 0.4)];
            for (let it = 0; it < 3; it++) {
              if (rnd() < 0.25) continue;
              const ix = fx + 2 + it * 5;
              const ih = 3 + Math.floor(rnd() * 2);
              s.rect(ix, ty2 + 5 - ih, 4, ih, items[(t * 3 + it) % items.length]);
              s.hline(ix, ty2 + 5 - ih, 4, mix(metal.m6, dust.d6, 0.25));
            }
          }
          s.vline(fx + 1, fy, fh, mix(warm.w2, grime.g2, 0.4));
          s.vline(fx + fw - 2, fy, fh, mix(warm.w2, grime.g2, 0.4));
        },
      });
    }
    // crates + drum on the floor (east)
    boxAt(402, 300, 16, 12, 14, RUSTM, {
      face: (fx, fy, fw, fh) => {
        panelSeams(s, fx, fy, fw, fh, mix(rust.x1, grime.g1, 0.4), mix(rust.x6, dust.d6, 0.3), [Math.round(fw / 2)], []);
        bolts(s, fx + 2, fy + 2, rust.x1, rust.x6);
        bolts(s, fx + fw - 4, fy + fh - 4, rust.x1, rust.x6);
      },
      top: (tx, ty, tw, th) => {
        s.line(tx + 2, ty + 2, tx + tw - 3, ty + th - 3, mix(rust.x2, grime.g2, 0.4));
        dustDrift(s, tx + 2, ty + th - 2, tw - 4, [dust.d5, dust.d4], () => rnd(), 0.6);
      },
    });
    boxAt(420, 296, 12, 10, 10, CREAM, {
      face: (fx, fy, fw, fh) => {
        drawText(s, fx + 2, fy + 3, 'K7', mix(metal.m3, dust.d4, 0.4));
        panelSeams(s, fx, fy, fw, fh, mix(metal.m2, grime.g2, 0.4), mix(metal.m7, dust.d7, 0.3), [], [Math.round(fh / 2)]);
      },
    });
    {
      const [dxk, dyk] = S(412, 314);
      drawCylN3(s, dxk, dyk, 5, pr.projectHeight(12), Math.round(5 * pr.vs), [mix(rust.x4, warm.w4, 0.3), mix(rust.x3, warm.w3, 0.3), mix(rust.x1, warm.w1, 0.4)], [mix(rust.x5, warm.w5, 0.3), mix(rust.x3, warm.w3, 0.3)], rust.x0, (top) => {
        s.ellipseOutline(dxk, top + 3, 4, Math.max(1, Math.round(4 * pr.vs)), mix(rust.x2, grime.g2, 0.4));
      });
      hazardStripes(s, dxk - 5, dyk - 6, 10, 2, hazard.h1, hazard.h3, 4);
    }
    // rest area: bunk + table + stool
    boxAt(404, 330, 26, 14, 5, {
      front: [warm.w3, warm.w2, warm.w1],
      top: [warm.w4, warm.w3],
      edge: warm.w0,
      rim: warm.w5,
    });
    {
      // mattress + pillow + blanket on the bunk top
      const [bxp, byp] = S(405, 317, 5);
      const mw = 24;
      const mh = dVs(12);
      s.rect(bxp, byp - mh, mw, mh, mix(olive.o3, slate.s3, 0.35));
      s.rect(bxp, byp - mh, mw, Math.round(mh * 0.6), mix(olive.o4, slate.s4, 0.3));
      s.rect(bxp + 1, byp - mh + 1, 7, Math.max(2, mh - 3), mix(metal.m7, dust.d8, 0.35)); // pillow
      s.rect(bxp + 10, byp - mh + 2, mw - 12, Math.max(2, mh - 4), mix(signal.s2, rust.x2, 0.35)); // folded blanket
      for (let u = bxp + 11; u < bxp + mw - 3; u += 3) s.vline(u, byp - mh + 3, Math.max(1, mh - 6), mix(signal.s1, rust.x1, 0.4));
      s.strokeRect(bxp, byp - mh, mw, mh, mix(warm.w1, olive.o0, 0.5));
    }
    boxAt(436, 322, 9, 9, 9, SLATE, {
      top: (tx, ty) => {
        s.set(tx + 3, ty + 2, amber.a2); // cup
        s.set(tx + 6, ty + 3, mix(cyan.c1, slate.s2, 0.4)); // datapad
      },
    });
    boxAt(432, 332, 5, 5, 6, WARM);
    // wall lamp over the bunk (emissive)
    {
      const [lmpx, lmpy] = S(416, INT.y + 2, 24);
      s.rect(lmpx - 2, lmpy, 5, 2, warm.w2);
      lamp(s, lmpx, lmpy + 3, amber.a7, amber.a4, withAlpha(amber.a2, 160));
    }
    // workbench + pegboard (south centre)
    boxAt(332, 318, 34, 4, 21, CREAM, {
      face: (fx, fy, fw, fh) => {
        // pegboard with hanging tools
        s.rect(fx + 1, fy + 1, fw - 2, fh - 2, mix(dust.d4, warm.w4, 0.35));
        for (let u = fx + 3; u < fx + fw - 2; u += 3) for (let v = fy + 3; v < fy + fh - 2; v += 3) s.set(u, v, mix(dust.d2, warm.w2, 0.4));
        const tools: [number, number, number, number, number][] = [
          [fx + 4, fy + 4, 2, 9, metal.m5],
          [fx + 9, fy + 5, 3, 7, warm.w4],
          [fx + 15, fy + 4, 2, 10, metal.m4],
          [fx + 20, fy + 6, 4, 5, rust.x4],
          [fx + 27, fy + 4, 2, 8, metal.m5],
        ];
        for (const [tx2, ty2, tw2, th2, tc] of tools) {
          s.rect(tx2, ty2, tw2, th2, tc);
          s.set(tx2, ty2 - 1, mix(metal.m2, grime.g2, 0.4));
          s.hline(tx2, ty2, tw2, mix(metal.m7, dust.d7, 0.3));
        }
        s.strokeRect(fx + 1, fy + 1, fw - 2, fh - 2, mix(metal.m2, grime.g2, 0.4));
      },
    });
    boxAt(330, 328, 38, 10, 12, WARM, {
      face: (fx, fy, fw, fh) => {
        panelSeams(s, fx, fy, fw, fh, warm.w1, mix(warm.w6, dust.d6, 0.3), [12, 25], []);
        s.rect(fx + 3, fy + 3, 8, 5, mix(slate.s3, warm.w2, 0.4)); // drawer
        s.set(fx + 6, fy + 5, metal.m6);
        s.rect(fx + 16, fy + 3, 8, 5, mix(slate.s3, warm.w2, 0.4));
        s.set(fx + 19, fy + 5, metal.m6);
        rustRun(s, fx + fw - 6, fy + 2, fh - 3, [rust.x2, rust.x3], 1, 4);
      },
      top: (tx, ty, _tw, th) => {
        // bench top clutter: vise, parts, solder rig
        s.rect(tx + 2, ty + 1, 6, Math.max(2, th - 2), mix(slate.s4, warm.w3, 0.4)); // vise
        s.rect(tx + 2, ty + 1, 6, 1, mix(slate.s6, warm.w5, 0.3));
        s.set(tx + 4, ty + 2, metal.m7);
        s.rect(tx + 12, ty + 2, 7, 3, mix(rust.x3, warm.w3, 0.3)); // parts tray
        s.set(tx + 13, ty + 3, metal.m6);
        s.set(tx + 16, ty + 2, cyan.c3);
        techBox(s, tx + 24, ty + 1, 7, 4, slate.s3, slate.s5, slate.s0, metal.m1);
        lamp(s, tx + 27, ty + 2, cyan.c5, cyan.c2, withAlpha(cyan.c1, 120));
        s.set(tx + 34, ty + 3, amber.a3);
      },
    });
    // bench lamp (arm + head over the bench)
    {
      const [bmx, bmy] = S(366, 322, 12);
      s.line(bmx, bmy, bmx + 4, bmy - 8, warm.w3);
      s.line(bmx + 4, bmy - 8, bmx - 2, bmy - 11, warm.w4);
      s.rect(bmx - 5, bmy - 12, 6, 3, mix(warm.w3, slate.s3, 0.4));
      lamp(s, bmx - 2, bmy - 9, amber.a7, amber.a4, withAlpha(amber.a2, 170));
    }
    // partition wall between machinery bay and the middle
    boxAt(300, 300, 7, 56, 26, CREAM, {
      face: (fx, fy, fw, fh) => {
        panelSeams(s, fx, fy, fw, fh, mix(metal.m2, grime.g2, 0.4), mix(metal.m7, dust.d7, 0.3), [], [Math.round(fh / 2)]);
        rustRun(s, fx + 2, fy + 2, 10, [rust.x1, rust.x2], 1, 2);
      },
      top: (tx, ty, tw) => {
        s.hline(tx, ty, tw, mix(metal.m8, dust.d8, 0.35));
      },
    });
    // hanging cables on the partition
    {
      const [cxp, cyp] = S(303, 268, 24);
      cable(s, cxp, cyp, cxp + 2, cyp + 16, 4, grime.g0, mix(warm.w2, grime.g2, 0.5), 2);
    }
    // extinguisher + mop corner details
    {
      const [ex0, ey0] = S(258, 330, 0);
      drawCylN3(s, ex0 + 3, ey0, 2, pr.projectHeight(7), 1, [signal.s3, signal.s2, signal.s1], [signal.s4, signal.s2], signal.s0);
      s.rect(ex0 + 2, ey0 - pr.projectHeight(7) - 2, 3, 2, slate.s3);
      s.line(ex0 + 8, ey0, ex0 + 10, ey0 - 14, warm.w4); // mop handle
      s.rect(ex0 + 6, ey0 - 3, 5, 3, mix(dust.d5, warm.w4, 0.4));
    }

    return { sprite: s, ax: pad, ay: Math.round((INT.y + INT.h) * pr.vs) + ly };
  })();
  push(intBk, HALL.x - 4, INT.y + INT.h, pr.depth(0, HALL.y - HALL.d, 0, -0.5), 'int', 'interior');

  // =========================================================== PROPS
  type PropPaint = {
    face?: (ps: PixelSurface, fx: number, fy: number, fw: number, fh: number) => void;
    top?: (ps: PixelSurface, tx: number, ty: number, tw: number, th: number) => void;
  };
  const propBox = (
    wx: number,
    wyFront: number,
    bw: number,
    bd: number,
    bh: number,
    C: BoxColors,
    paint?: PropPaint,
    name = 'prop',
  ) => {
    const pad = 6;
    const dV = Math.round(bd * pr.vs);
    const hSl = pr.projectHeight(bh);
    const ps = new PixelSurface(bw + pad * 2 + 2, dV + hSl + pad * 2 + 4);
    const yB = pad + 2 + hSl + dV;
    drawBoxN3(
      ps,
      pad,
      yB,
      bw,
      dV,
      hSl,
      C,
      paint
        ? {
            face: paint.face ? (fx, fy, fw, fh) => paint.face!(ps, fx, fy, fw, fh) : undefined,
            top: paint.top ? (tx, ty, tw, th) => paint.top!(ps, tx, ty, tw, th) : undefined,
          }
        : undefined,
    );
    const [gx, gy] = gp(wx, wyFront);
    ground.contactShadow(gx, gy, Math.max(3, Math.round(bw / 2) + 1), Math.max(2, Math.round(dV * 0.5) + 1), packRGBA(24, 14, 12, 90), 0.85);
    push({ sprite: ps, ax: pad, ay: yB }, wx, wyFront, pr.depth(wx, wyFront), 'both', name);
  };
  const propCyl = (
    wx: number,
    wyFront: number,
    r: number,
    h: number,
    body: [number, number, number],
    cap: [number, number],
    edge: number,
    band?: (ps: PixelSurface, cx: number, top: number, hS: number) => void,
    name = 'drum',
  ) => {
    const pad = 5;
    const hSl = pr.projectHeight(h);
    const ry = Math.max(1, Math.round(r * pr.vs));
    const ps = new PixelSurface(r * 2 + pad * 2 + 2, hSl + pad * 2 + ry * 2 + 4);
    const cx = pad + r + 1;
    const yB = pad + 2 + hSl + ry;
    drawCylN3(ps, cx, yB, r, hSl, ry, body, cap, edge);
    if (band) band(ps, cx, yB - hSl, hSl);
    const [gx, gy] = gp(wx, wyFront);
    ground.contactShadow(gx, gy, r + 2, Math.max(2, ry + 1), packRGBA(24, 14, 12, 95), 0.9);
    push({ sprite: ps, ax: cx, ay: yB }, wx, wyFront, pr.depth(wx, wyFront), 'both', name);
  };

  // crate cluster west of the porch
  propBox(294, 382, 18, 14, 16, CREAM, {
    face: (ps, fx, fy, fw, fh) => {
      panelSeams(ps, fx, fy, fw, fh, mix(metal.m2, grime.g2, 0.4), mix(metal.m7, dust.d7, 0.3), [Math.round(fw / 2)], []);
      bolts(ps, fx + 2, fy + 2, metal.m1, metal.m7);
      bolts(ps, fx + fw - 4, fy + 2, metal.m1, metal.m7);
      bolts(ps, fx + 2, fy + fh - 4, metal.m1, metal.m7);
      bolts(ps, fx + fw - 4, fy + fh - 4, metal.m1, metal.m7);
      drawText(ps, fx + 4, fy + 6, 'K7', mix(metal.m3, dust.d4, 0.4));
      rustRun(ps, fx + fw - 6, fy + 2, fh - 4, [rust.x2, rust.x3], 1, 5);
    },
    top: (ps, tx, ty, tw, th) => {
      ps.line(tx + 2, ty + 2, tx + tw - 3, ty + th - 2, mix(metal.m3, grime.g2, 0.4));
      dustDrift(ps, tx + 2, ty + th - 2, tw - 4, [dust.d5, dust.d4], () => rnd(), 0.7);
    },
  }, 'crate');
  propBox(312, 392, 14, 10, 12, RUSTM, {
    face: (ps, fx, fy, fw, fh) => {
      ps.line(fx + 1, fy + 1, fx + fw - 2, fy + fh - 2, mix(rust.x2, grime.g2, 0.4));
      ps.line(fx + fw - 2, fy + 1, fx + 1, fy + fh - 2, mix(rust.x2, grime.g2, 0.4));
      bolts(ps, fx + 2, fy + 2, rust.x0, rust.x6);
      bolts(ps, fx + fw - 4, fy + fh - 4, rust.x0, rust.x6);
    },
  }, 'crate');
  propBox(300, 396, 10, 8, 9, OLIVE, {
    face: (ps, fx, fy, fw, fh) => {
      panelSeams(ps, fx, fy, fw, fh, mix(olive.o1, metal.m1, 0.5), mix(olive.o5, metal.m6, 0.3), [], [Math.round(fh / 2)]);
    },
  }, 'crate');
  // drums
  propCyl(280, 392, 5, 12, [mix(rust.x4, warm.w4, 0.25), mix(rust.x3, warm.w3, 0.3), mix(rust.x1, warm.w1, 0.4)], [mix(rust.x5, warm.w5, 0.3), mix(rust.x3, warm.w3, 0.3)], rust.x0, (ps, cx, top, hS) => {
    ps.hline(cx - 4, top + 3, 9, mix(rust.x2, grime.g2, 0.4));
    hazardStripes(ps, cx - 4, top + Math.round(hS / 2), 9, 2, hazard.h1, hazard.h3, 4);
    ps.hline(cx - 4, top + hS - 3, 9, mix(rust.x2, grime.g2, 0.4));
  });
  propCyl(288, 399, 5, 12, [mix(slate.s5, warm.w4, 0.3), mix(slate.s4, warm.w3, 0.3), mix(slate.s2, warm.w1, 0.4)], [mix(slate.s6, warm.w5, 0.3), mix(slate.s4, warm.w3, 0.3)], slate.s0, (ps, cx, top, hS) => {
    ps.hline(cx - 4, top + 4, 9, mix(slate.s3, grime.g2, 0.4));
    ps.hline(cx - 4, top + hS - 4, 9, mix(slate.s3, grime.g2, 0.4));
    lamp(ps, cx, top + Math.round(hS / 2), cyan.c5, cyan.c2, withAlpha(cyan.c1, 120));
  });
  // yard generator (west, feeds the buried trench)
  propBox(184, 396, 30, 18, 16, WARM, {
    face: (ps, fx, fy, fw, fh) => {
      ventGrille(ps, fx + 3, fy + 3, 12, fh - 6, warm.w1, warm.w5);
      techBox(ps, fx + 18, fy + 2, 9, 7, slate.s3, slate.s5, slate.s0, metal.m1);
      lamp(ps, fx + 21, fy + 5, amber.a6, amber.a3, withAlpha(amber.a2, 150));
      lamp(ps, fx + 25, fy + 5, cyan.c5, cyan.c2, withAlpha(cyan.c1, 120));
      hazardStripes(ps, fx, fy + fh - 2, fw, 2, hazard.h0, hazard.h2, 5);
      rustRun(ps, fx + 8, fy + 2, fh - 4, [rust.x2, rust.x3], 1, 9);
    },
    top: (ps, tx, ty, tw, th) => {
      ps.rect(tx + 4, ty + 2, tw - 8, Math.max(1, th - 4), mix(warm.w2, grime.g2, 0.5));
      ps.rect(tx + tw - 8, ty - 4, 3, 6, warm.w3); // exhaust stub
      ps.hline(tx + tw - 8, ty - 4, 3, warm.w6);
      bolts(ps, tx + 2, ty + 1, warm.w1, warm.w6);
    },
  }, 'generator');
  // barriers at the apron edge
  for (const [bxw, byw] of [[578, 436], [602, 444]] as [number, number][]) {
    propBox(bxw, byw, 24, 8, 7, {
      front: [mix(warm.w5, dust.d6, 0.3), mix(warm.w4, dust.d5, 0.3), mix(warm.w2, dust.d3, 0.4)],
      top: [mix(warm.w6, dust.d7, 0.3), mix(warm.w5, dust.d6, 0.3)],
      edge: warm.w1,
      rim: mix(warm.w7, dust.d8, 0.3),
    }, {
      face: (ps, fx, fy, fw, fh) => {
        hazardStripes(ps, fx + 2, fy + 2, fw - 4, fh - 3, hazard.h1, hazard.h3, 6);
        grimePatch(ps, fx + Math.round(fw / 2), fy + fh - 2, 4, [grime.g2, grime.g1], () => rnd(), 0.6);
      },
    }, 'barrier');
  }
  // pallet + small crate at the garage
  propBox(460, 372, 18, 12, 3, WARM, {
    face: (ps, fx, fy, fw, fh) => {
      for (let u = fx + 2; u < fx + fw - 1; u += 4) ps.vline(u, fy, fh, mix(warm.w2, grime.g2, 0.4));
    },
  }, 'pallet');
  propBox(462, 369, 12, 9, 10, CREAM, {
    face: (ps, fx, fy, fw, fh) => {
      drawText(ps, fx + 2, fy + 3, 'PM', mix(metal.m3, dust.d4, 0.4));
      panelSeams(ps, fx, fy, fw, fh, mix(metal.m2, grime.g2, 0.4), mix(metal.m7, dust.d7, 0.3), [], [Math.round(fh / 2)]);
    },
  }, 'crate');
  propCyl(442, 390, 5, 12, [mix(slate.s5, warm.w4, 0.3), mix(slate.s4, warm.w3, 0.3), mix(slate.s2, warm.w1, 0.4)], [mix(slate.s6, warm.w5, 0.3), slate.s4], slate.s0);
  // bin near the porch
  propCyl(392, 372, 4, 9, [mix(slate.s4, warm.w3, 0.3), mix(slate.s3, warm.w2, 0.3), mix(slate.s1, warm.w0, 0.4)], [mix(slate.s5, warm.w4, 0.3), slate.s3], slate.s0, (ps, cx, top) => {
    ps.hline(cx - 4, top + 1, 9, mix(slate.s6, warm.w5, 0.3));
  }, 'bin');
  // cable spool (west yard)
  propBox(160, 370, 13, 11, 13, RUSTM, {
    face: (ps, fx, fy, fw, fh) => {
      ps.ellipse(fx + Math.round(fw / 2), fy + Math.round(fh / 2), 5, 5, mix(rust.x1, grime.g1, 0.4));
      ps.ellipseOutline(fx + Math.round(fw / 2), fy + Math.round(fh / 2), 5, 5, mix(rust.x5, dust.d5, 0.3));
      ps.set(fx + Math.round(fw / 2), fy + Math.round(fh / 2), rust.x6);
    },
    top: (ps, tx, ty, tw, th) => {
      ps.ellipse(tx + Math.round(tw / 2), ty + Math.round(th / 2), Math.round(tw / 2) - 1, Math.max(1, Math.round(th / 2) - 1), mix(rust.x2, grime.g2, 0.4));
    },
  }, 'spool');

  // flood pole (east apron)
  {
    const [gx, gy] = gp(566, 392);
    const hP = pr.projectHeight(46);
    const ps = new PixelSurface(22, hP + 14);
    const bx = 11;
    const by = hP + 8;
    drawBoxN3(ps, bx - 4, by, 8, 3, 4, SLATE);
    ps.rect(bx - 1, by - hP - 4, 3, hP + 4, mix(metal.m4, warm.w3, 0.3));
    ps.vline(bx - 1, by - hP - 4, hP + 4, mix(metal.m6, dust.d6, 0.3));
    ps.vline(bx + 1, by - hP - 4, hP + 4, mix(metal.m1, grime.g1, 0.4));
    ps.hline(bx - 7, by - hP - 5, 15, metal.m3);
    ps.hline(bx - 7, by - hP - 6, 15, mix(metal.m5, dust.d6, 0.3));
    for (const hx of [bx - 7, bx + 4]) {
      ps.rect(hx, by - hP - 9, 5, 3, mix(metal.m3, slate.s3, 0.4));
      ps.hline(hx, by - hP - 9, 5, mix(metal.m6, dust.d7, 0.3));
      ps.hline(hx, by - hP - 6, 5, amber.a6);
      ps.hline(hx, by - hP - 7, 5, mix(amber.a4, metal.m3, 0.3));
    }
    ground.contactShadow(gx, gy, 5, 2, packRGBA(24, 14, 12, 90));
    renderables.push({ sprite: ps, x: gx - bx, y: gy - by, depth: pr.depth(566, 392), mode: 'both', name: 'floodpole' });
  }
  // sign post by the path
  {
    const [gx, gy] = gp(392, 434);
    const hP = pr.projectHeight(20);
    const ps = new PixelSurface(30, hP + 14);
    const bx = 9;
    const by = hP + 8;
    ps.rect(bx, by - hP, 2, hP, warm.w3);
    ps.vline(bx, by - hP, hP, warm.w5);
    ps.vline(bx + 1, by - hP, hP, warm.w1);
    const px = bx - 6;
    const py = by - hP - 4;
    ps.rect(px, py, 24, 12, mix(metal.m4, dust.d5, 0.3));
    ps.strokeRect(px, py, 24, 12, metal.m1);
    ps.hline(px + 1, py + 1, 22, mix(metal.m6, dust.d7, 0.3));
    drawText(ps, px + 2, py + 2, 'K-7', mix(metal.m1, grime.g1, 0.5));
    drawText(ps, px + 2, py + 8, 'BAY', mix(metal.m2, dust.d3, 0.4));
    ps.line(px + 15, py + 4, px + 20, py + 4, mix(signal.s3, dust.d4, 0.3));
    ps.set(px + 20, py + 3, mix(signal.s3, dust.d4, 0.3));
    ps.set(px + 20, py + 5, mix(signal.s3, dust.d4, 0.3));
    ps.set(px + 21, py + 4, mix(signal.s3, dust.d4, 0.3));
    weatherSpeckle(ps, px, py, 24, 12, [rust.x2, mix(metal.m6, dust.d7, 0.3)], 0.05, () => rnd());
    ground.contactShadow(gx, gy, 3, 2, packRGBA(24, 14, 12, 90));
    renderables.push({ sprite: ps, x: gx - bx, y: gy - by, depth: pr.depth(392, 434), mode: 'both', name: 'sign' });
  }
  // scrap pile (west yard)
  {
    const [gx, gy] = gp(150, 344);
    const ps = new PixelSurface(42, 24);
    for (let i = 0; i < 30; i++) {
      const cx = 6 + rnd.range(0, 28);
      const cy = 17 - rnd.range(0, 10);
      const w = 3 + rnd.int(0, 6);
      const h = 2 + rnd.int(0, 3);
      const c = rnd.pick([warm.w2, warm.w3, mix(rust.x2, warm.w2, 0.5), mix(metal.m2, grime.g2, 0.4), mix(rust.x3, warm.w3, 0.4)]);
      ps.rect(Math.round(cx), Math.round(cy), w, h, c);
      ps.hline(Math.round(cx), Math.round(cy), w, mix(c, metal.m6, 0.35));
    }
    ps.line(12, 18, 20, 5, warm.w4);
    ps.line(21, 5, 27, 9, warm.w3);
    ps.set(27, 9, warm.w5);
    ps.outline(packRGBA(16, 12, 12, 255));
    ground.contactShadow(gx, gy, 14, 4, packRGBA(24, 14, 12, 90));
    renderables.push({ sprite: ps, x: gx - 21, y: gy - 19, depth: pr.depth(150, 344), mode: 'both', name: 'scrap' });
  }

  // rocks (billboard mounds, camera-independent)
  const rocks: [number, number, number, number][] = [
    [86, 300, 22, 12], [140, 240, 14, 8], [640, 280, 24, 13], [700, 340, 17, 10],
    [60, 470, 20, 11], [730, 470, 19, 11], [300, 150, 26, 12], [600, 180, 21, 11],
    [196, 470, 12, 7], [616, 410, 12, 7], [128, 540, 24, 13], [664, 548, 19, 10],
    [394, 565, 14, 8], [560, 240, 16, 9], [110, 380, 11, 7], [500, 150, 13, 8],
  ];
  for (const [rx, ry, rr, rry0] of rocks) {
    const ps = new PixelSurface(rr * 2 + 8, rry0 + 12);
    const ccx = rr + 4;
    const ccy = rry0 + 3;
    const rry = Math.max(3, Math.round(rry0 * 0.62));
    for (let y = -rry - 1; y <= rry; y++) {
      for (let x = -rr - 1; x <= rr + 1; x++) {
        const wob = 0.76 + valueNoise((ccx + x) / 4, (ccy + y) / 4, 7) * 0.46;
        const d = Math.sqrt((x * x) / (rr * rr) + (y * y) / (rry * rry)) / wob;
        if (d > 1) continue;
        const nl = (-x / rr) * 0.5 + (-y / rry) * 0.8;
        let v = 0.34 + nl * 0.33 + (valueNoise((ccx + x) / 3, (ccy + y) / 3, 8) - 0.5) * 0.4;
        v = Math.max(0, Math.min(0.999, v));
        const ramp = [rock.r1, rock.r2, rock.r3, rock.r4, rock.r5];
        const t = v * 4;
        ps.set(ccx + x, ccy + y, bayer4(x, y) < t - Math.floor(t) ? ramp[Math.min(4, Math.floor(t) + 1)] : ramp[Math.floor(t)]);
      }
    }
    const [px, py] = gp(rx, ry);
    ground.contactShadow(px, py + 1, rr + 2, Math.max(2, Math.round(rry0 * 0.4)), packRGBA(24, 14, 12, 80), 0.8);
    renderables.push({ sprite: ps, x: px - ccx, y: py - (ccy + rry - 1), depth: pr.depth(rx, ry), mode: 'both', name: 'rock' });
  }
  // dry scrub
  for (let i = 0; i < 46; i++) {
    const wx = rnd.range(20, WW - 20);
    const wy = rnd.range(180, WH - 12);
    if (wx > 170 && wx < 580 && wy > 170 && wy < 460) continue;
    if (valueNoise(wx / 44, wy / 44, 17) < 0.5) continue;
    const ps = new PixelSurface(14, 14);
    const blades = 4 + rnd.int(0, 4);
    for (let b = 0; b < blades; b++) {
      const h = 3 + rnd.int(0, 6);
      const lean = (rnd() - 0.5) * 4;
      for (let k = 0; k < h; k++) {
        const t = k / h;
        ps.set(Math.round(7 + lean * t * t + (b - blades / 2) * 0.8), 12 - k, k === h - 1 ? mix(olive.o5, rust.x5, 0.4) : t > 0.5 ? mix(olive.o3, rust.x3, 0.25) : olive.o2);
      }
    }
    const [px, py] = gp(wx, wy);
    renderables.push({ sprite: ps, x: px - 7, y: py - 12, depth: pr.depth(wx, wy), mode: 'both', name: 'scrub' });
  }
  // scattered pebbles + debris
  for (let i = 0; i < 220; i++) {
    const wx = rnd.range(30, WW - 30);
    const wy = rnd.range(200, WH - 20);
    if (wx > 200 && wx < 560 && wy > 200 && wy < 440 && rnd() < 0.75) continue;
    const [px, py] = gp(wx, wy);
    const c = rnd.pick([rock.r2, rock.r3, mix(dust.d3, rock.r2, 0.5), warm.w2]);
    ground.set(px, py, c);
    if (rnd() < 0.4) ground.set(px + 1, py, mix(c, dust.d2, 0.4));
    if (rnd() < 0.2) ground.set(px, py - 1, mix(c, dust.d6, 0.3));
  }
  // manhole on the path
  {
    const [mx, my] = gp(358, 420);
    ground.ellipse(mx, my, 6, Math.max(2, Math.round(6 * pr.vs)), mix(warm.w2, grime.g2, 0.4));
    ground.ellipseOutline(mx, my, 6, Math.max(2, Math.round(6 * pr.vs)), mix(warm.w4, dust.d4, 0.3));
    for (let u = -4; u <= 4; u += 2) ground.set(mx + u, my, mix(warm.w3, grime.g1, 0.4));
  }

  // =========================================================== LIGHTS
  lights.push(
    // exterior
    { x: 356, y: 350, z: 25, r: 46, c: [1, 0.74, 0.4], i: 0.62, flicker: 0.05, mode: 'ext' },
    { x: 356, y: 344, z: 50, r: 18, c: [1, 0.78, 0.45], i: 0.3, mode: 'ext' },
    { x: 518, y: 350, z: 34, r: 30, c: [1, 0.76, 0.42], i: 0.42, flicker: 0.06, mode: 'ext' },
    { x: 301, y: 338, z: 40, r: 24, c: [0.3, 0.85, 0.95], i: 0.32, mode: 'ext' },
    { x: 401, y: 338, z: 40, r: 22, c: [1, 0.78, 0.4], i: 0.36, mode: 'ext' },
    { x: 203, y: 354, z: 74, r: 15, c: [0.3, 0.85, 0.95], i: 0.26, mode: 'ext' },
    { x: 236, y: 354, z: 74, r: 15, c: [0.3, 0.85, 0.95], i: 0.2, mode: 'ext' },
    { x: 203, y: 354, z: 34, r: 15, c: [0.3, 0.85, 0.95], i: 0.24, mode: 'ext' },
    { x: 220, y: 354, z: 38, r: 16, c: [1, 0.75, 0.4], i: 0.34, flicker: 0.05, mode: 'ext' },
    { x: 566, y: 392, z: 46, r: 54, c: [0.78, 0.86, 1], i: 0.5, mode: 'ext' },
    { x: 356, y: 404, z: 6, r: 15, c: [1, 0.78, 0.45], i: 0.3, mode: 'ext' },
    { x: 356, y: 452, z: 6, r: 15, c: [1, 0.78, 0.45], i: 0.3, mode: 'ext' },
    { x: 320, y: 306, z: 56, r: 15, c: [0.35, 0.85, 0.95], i: 0.2, mode: 'ext' },
    { x: 344, y: 306, z: 56, r: 15, c: [0.35, 0.85, 0.95], i: 0.2, mode: 'ext' },
    // interior
    { x: 288, y: 227, z: 44, r: 50, c: [1, 0.78, 0.48], i: 0.5, mode: 'int' },
    { x: 356, y: 227, z: 44, r: 50, c: [1, 0.78, 0.48], i: 0.5, mode: 'int' },
    { x: 424, y: 227, z: 44, r: 44, c: [1, 0.78, 0.48], i: 0.44, mode: 'int' },
    { x: 330, y: 240, z: 20, r: 30, c: [0.3, 0.85, 0.95], i: 0.5, flicker: 0.12, mode: 'int' },
    { x: 356, y: 228, z: 30, r: 26, c: [0.3, 0.85, 0.95], i: 0.3, flicker: 0.06, mode: 'int' },
    { x: 364, y: 318, z: 24, r: 26, c: [1, 0.8, 0.5], i: 0.55, mode: 'int' },
    { x: 280, y: 256, z: 16, r: 18, c: [1, 0.7, 0.35], i: 0.34, pulse: 2.4, mode: 'int' },
    { x: 416, y: 228, z: 28, r: 20, c: [1, 0.76, 0.44], i: 0.4, mode: 'int' },
  );

  const steam = [
    { x: 342, y: 202, z: MODULE.h + 26 },
    { x: 354, y: 198, z: MODULE.h + 30 },
  ];
  const beacon = { x: 202, y: 274, z: TOWER.h + 30 };

  return {
    width: W,
    height: H,
    ox,
    oy,
    ground,
    shadow,
    shadowCut,
    renderables,
    lights,
    steam,
    beacon,
    focus: { ext: [368, 300], int: [352, 288] },
    mercExt: { x: 340, y: 382, dir: 's' },
    mercInt: { x: 348, y: 334, dir: 'n' },
    worldW: WW,
    worldH: WH,
    pitchDeg: pr.p.pitchDeg,
  };
}
