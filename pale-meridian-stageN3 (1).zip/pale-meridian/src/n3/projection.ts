/**
 * N3 PROJECTION — the FINAL CAMERA candidate: tilted orthographic top-down
 * in the CrossCode / UNSIGHTED family, rebuilt from scratch (NOT the N2
 * oblique system: zero shear, azimuth 0).
 *
 * Camera model — an orthographic camera looking from the south, pitched
 * down from the horizontal by `pitchDeg`:
 *
 *   sx = x                                   (no shear, no yaw)
 *   sy = y · sin(pitch) − z · cos(pitch)
 *
 *   vs = sin(pitch)  — ground/roof foreshortening ("how top-down")
 *   hs = cos(pitch)  — wall presence ("how much vertical surface reads")
 *
 * Consequences (the CrossCode read):
 *   - roofs/floors are visible, compressed but large;
 *   - south faces of every mass are fully visible;
 *   - east/west faces are edge-on (zero width) — volume is carried by
 *     overlapping masses, heights, cornices, parapets and recesses, not by
 *     a second visible side;
 *   - never isometric, never flat top-down.
 *
 * The one deliberate deviation — the RimWorld-ish wall slope:
 * every vertical face leans inward by `slopeDeg` (1–3°, default 2°).
 * The top edge of a wall of height h sits `h·tan(slope)` world-px further
 * inside the footprint, so:
 *   - wall faces are subtle trapezoids (batter), never flat strips;
 *   - the roof slab / cornice reveals a sliver more of itself;
 *   - at gameplay scale it reads as "this wall has a little more surface",
 *     not as "this wall is tilted".
 *
 * Pure math module: knows nothing about the building.
 */

export interface N3Params {
  /** camera pitch from horizontal, degrees (bigger = more top-down) */
  pitchDeg: number;
  /** wall lean from vertical, degrees (RimWorld-style, keep 1..3) */
  slopeDeg: number;
  /** roof slab overhang past the wall face, screen px (cornice read) */
  eave: number;
  /** ground-plane shadow direction per height unit (sun from the NW) */
  shadowDir: { x: number; y: number };
  /** shadow length per height unit (low dusk sun) */
  shadowLen: number;
}

export interface CamPreset {
  key: 'A' | 'B' | 'C';
  label: string;
  pitchDeg: number;
}

/** Camera candidates for the final test (section 10 of the stage spec). */
export const CAM_PRESETS: CamPreset[] = [
  { key: 'A', label: 'CANDIDATE 42°', pitchDeg: 42 },
  { key: 'B', label: 'TARGET 36° (SELECTED)', pitchDeg: 36 },
  { key: 'C', label: 'CANDIDATE 50°', pitchDeg: 50 },
];

/**
 * The camera the scene ships with, chosen from the A/B/C render test:
 * 36° keeps the roof large while walls read as real architecture
 * (wall/roof screen ratio ~0.66 — the CrossCode/UNSIGHTED family).
 */
export const DEFAULT_CAM: CamPreset['key'] = 'B';

export class N3Projection {
  readonly vs: number;
  readonly hs: number;
  readonly slopeTan: number;

  constructor(public p: N3Params) {
    const r = (p.pitchDeg * Math.PI) / 180;
    this.vs = Math.sin(r);
    this.hs = Math.cos(r);
    this.slopeTan = Math.tan((p.slopeDeg * Math.PI) / 180);
  }

  static fromPreset(key: CamPreset['key'], extra: Partial<N3Params> = {}): N3Projection {
    const preset = CAM_PRESETS.find((c) => c.key === key) ?? CAM_PRESETS[0];
    return new N3Projection({
      pitchDeg: preset.pitchDeg,
      slopeDeg: 2,
      eave: 2,
      shadowDir: { x: 0.82, y: 0.34 },
      shadowLen: 0.9,
      ...extra,
    });
  }

  /** world point (x, y ground, z height) -> screen point */
  projectPoint(x: number, y: number, z = 0): [number, number] {
    return [x, this.vs * y - this.projectHeight(z)];
  }

  project(x: number, y: number, z = 0): [number, number] {
    return this.projectPoint(x, y, z);
  }

  projectHeight(h: number): number {
    return Math.round(h * this.hs);
  }

  /** inverse of the ground lattice (screen -> world, z = 0) */
  invPoint(sx: number, sy: number): [number, number] {
    return [sx, sy / this.vs];
  }

  /** inward top-edge offset of a wall face of height h (the RimWorld lean) */
  leanPx(h: number): number {
    return Math.max(1, Math.round(h * this.slopeTan));
  }

  /** ground quad of a world footprint (floors, decals, shadows) */
  groundQuad(x: number, y: number, w: number, d: number): [number, number][] {
    return [this.projectPoint(x, y + d), this.projectPoint(x + w, y + d), this.projectPoint(x + w, y), this.projectPoint(x, y)];
  }

  /**
   * Roof slab rectangle of a mass, in WORLD coordinates: the footprint
   * shrunk by the wall lean, then grown by the cornice eave. Projected at
   * height h it is an axis-aligned screen rect (no shear).
   * Mass convention: (x, y) = front-left, body extends toward −y by d.
   */
  roofSlab(x: number, y: number, w: number, d: number, h: number): { x: number; y: number; w: number; d: number } {
    const L = this.leanPx(h);
    const E = this.p.eave;
    return { x: x + L - E, y: y - d + L - E, w: w - 2 * L + 2 * E, d: d - 2 * L + 2 * E };
  }

  /** painter depth: front ground line + bias (no x term — zero shear) */
  depth(_x: number, y: number, baseZ = 0, bias = 0): number {
    return y + baseZ * 0.02 + bias;
  }

  /** ground-plane shadow offset for an object of height h */
  shadowOffset(h: number): [number, number] {
    return [this.p.shadowDir.x * h * this.p.shadowLen, this.p.shadowDir.y * h * this.p.shadowLen];
  }
}
