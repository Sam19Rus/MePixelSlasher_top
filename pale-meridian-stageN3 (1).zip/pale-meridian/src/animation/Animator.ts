/**
 * Tiny animation helpers shared by entities and dynamic overlays.
 *
 * Everything in the benchmark animates on integer frames or dithered steps —
 * these keep the timing conventions (phase counts, blink duty cycles, hover
 * bob) in one place instead of scattered magic numbers.
 */

/** Integer cycle phase in [0, count) advancing at `fps` phases per second. */
export function cycle(t: number, fps: number, count: number, offset = 0): number {
  // safe modulo: a negative clock (first rAF timestamp can precede the
  // performance.now() taken at mount) must never yield a negative index
  return ((Math.floor(t * fps + offset) % count) + count) % count;
}

/** 0/1 square blink with a given period and on-duty (0..1). */
export function blink(t: number, period: number, duty = 0.2, offset = 0): boolean {
  return ((((t + offset) % period) + period) % period) / period < duty;
}

/** Smooth hover bob in pixels (returns a small integer offset). */
export function hoverBob(t: number, amplitude = 1.5, rate = 2.6): number {
  return Math.round(Math.sin(t * rate) * amplitude);
}

/** Walk-phase index for a stride of `phases` at a speed-scaled rate. */
export function stridePhase(animT: number, phases = 4): number {
  return ((Math.floor(animT) % phases) + phases) % phases;
}

/** Breathing offset for idle poses: 0 or 1 pixel. */
export function breathe(t: number, rate = 2.4): number {
  return Math.sin(t * rate) > 0.5 ? 1 : 0;
}

/** Normalised flicker curve (0..1) for lamps and screens. */
export function flicker(t: number, seed = 0): number {
  const a = Math.sin(t * 37.3 + seed) * 0.5 + 0.5;
  const b = Math.sin(t * 91.7 + seed * 1.7) * 0.5 + 0.5;
  return a * 0.6 + b * 0.4;
}
