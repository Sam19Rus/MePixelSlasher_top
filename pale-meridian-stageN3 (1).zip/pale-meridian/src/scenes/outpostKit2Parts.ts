import { Color, mix, packRGBA, withAlpha } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { fbm, makeRng, valueNoise } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, dust, grime, hazard, metal, olive, rock, rust, slate, teal, warm } from '../data/palette';
import { drawText } from '../rendering/text';
import { Proj, type FaceQuad } from '../lab/profiles';
import { DARK, LocalProj, RUSTY, paintBox, windowOnFace, type Mat } from '../lab/kit';
import { faceLine, facePx, faceRect } from '../lab/facePaint';
import type { SceneBake, SceneLight, SceneRenderable } from './outpostKit';

/**
 * OUTPOST v2 — the full frontier complex for Scene 2 / Scene 3.
 *
 * Same scenography in both projections; every spatial decision goes through
 * Proj. Density target = Stage 1: large/medium/small detail layers everywhere,
 * environmental storytelling, and an interior that is the SAME building
 * (crew wing | ops hall | power room | garage bay) revealed by cutaway.
 */

export const O2 = {
  hall: { x: 150, y: 96, w: 84, d: 64, h: 32 },
  wing: { x: 108, y: 106, w: 42, d: 46, h: 22 },
  tech: { x: 234, y: 104, w: 40, d: 50, h: 26 },
  garage: { x: 238, y: 154, w: 44, d: 40, h: 20 },
  tower: { x: 176, y: 110, w: 34, d: 30, h: 52 },
  doorU: 36,
  doorW: 12,
};
const WT = 3;
export const O2_ROOMS = {
  wing: { x: O2.wing.x + WT, y: O2.wing.y + WT, w: O2.wing.w - WT * 2, h: O2.wing.d - WT * 2 },
  hall: { x: O2.hall.x + WT, y: O2.hall.y + WT, w: O2.hall.w - WT * 2, h: O2.hall.d - WT * 2 },
  tech: { x: O2.tech.x + WT, y: O2.tech.y + WT, w: O2.tech.w - WT * 2, h: O2.tech.d - WT * 2 },
  garage: { x: O2.garage.x + WT, y: O2.garage.y + WT, w: O2.garage.w - WT * 2, h: O2.garage.d - WT * 2 },
};
export const O2_LAYOUT = {
  vehicle: { x: 322, y: 236 },
  robot: { x: 268, y: 214 },
  spawn: { x: 192, y: 214 },
  containers: [
    { x: 352, y: 148 },
    { x: 364, y: 166 },
  ],
  crateStack: [
    { x: 300, y: 262 },
    { x: 310, y: 270 },
    { x: 305, y: 254 },
  ],
  rocks: [
    { x: 84, y: 268, r: 11 },
    { x: 430, y: 262, r: 9 },
    { x: 62, y: 96, r: 10 },
    { x: 476, y: 128, r: 8 },
    { x: 140, y: 344, r: 9 },
    { x: 436, y: 336, r: 10 },
    { x: 250, y: 356, r: 7 },
  ],
  plants: [
    { x: 116, y: 296 },
    { x: 336, y: 300 },
    { x: 92, y: 196 },
    { x: 408, y: 208 },
    { x: 246, y: 336 },
    { x: 378, y: 326 },
    { x: 170, y: 320 },
    { x: 452, y: 240 },
  ],
  generators: [
    { x: 112, y: 232 },
    { x: 128, y: 244 },
  ],
  transformer: { x: 96, y: 210 },
  lamps: [
    { x: 176, y: 216 },
    { x: 208, y: 216 },
    { x: 262, y: 250 },
  ],
  barrier: { x: 258, y: 314 },
  bench: { x: 226, y: 246 },
  dish: { x: 132, y: 176 },
  tank: { x: 284, y: 132 },
  spool: { x: 246, y: 206 },
  sandbags: { x: 160, y: 250 },
  sign: { x: 214, y: 268 },
  cart: { x: 348, y: 210 },
  drums: [
    { x: 292, y: 186 },
    { x: 298, y: 192 },
  ],
  mesas: [
    { x: 60, y: 150 },
    { x: 150, y: 40 },
  ],
};

const BIAS = { shellNW: -0.4, partition: -0.2, shellSE: 0.4, shaft: 0.5, roof: 12, tower: 20 };

interface Baked {
  sprite: PixelSurface;
  ax: number;
  ay: number;
}

function massBounds(pr: Proj, x: number, y: number, w: number, d: number, h: number, pad = 8) {
  const cs = [pr.g(x, y), pr.g(x + w, y), pr.g(x + w, y + d), pr.g(x, y + d)];
  const xs = cs.map((c) => c[0]);
  const ys = cs.map((c) => c[1]);
  const minX = Math.floor(Math.min(...xs)) - pad;
  const maxX = Math.ceil(Math.max(...xs)) + Math.ceil(Math.abs(pr.p.kx) * d) + pad;
  const minY = Math.floor(Math.min(...ys)) - pr.lift(h) - Math.ceil(pr.p.ky * d) - pad;
  const maxY = Math.ceil(Math.max(...ys)) + pad;
  return { minX, minY, w: maxX - minX, h: maxY - minY };
}

function bakeMass(
  pr: Proj,
  r: { x: number; y: number; w: number; d: number; h: number },
  m: Mat,
  anchor: { x: number; y: number },
  baseZ = 0,
  detail?: (s: PixelSurface, f: { top: FaceQuad; front: FaceQuad; east: FaceQuad }) => void,
): Baked {
  const b = massBounds(pr, r.x, r.y, r.w, r.d, r.h);
  const s = new PixelSurface(b.w, b.h);
  const lp = new LocalProj(pr, -b.minX, -b.minY - pr.lift(baseZ));
  paintBox(s, lp, r.x, r.y, r.w, r.d, r.h, m, (f) => detail?.(s, f));
  const [gx, gy] = pr.g(anchor.x, anchor.y);
  return { sprite: s, ax: Math.round(gx - b.minX), ay: Math.round(gy - b.minY) - pr.lift(baseZ) };
}

// ------------------------------------------------------------------ terrain
export function bakeGround2(pr: Proj, W: number, H: number, ox: number, oy: number): PixelSurface {
  const s = new PixelSurface(W, H);
  const rnd = makeRng(90210);
  const gq = (x: number, y: number, w: number, d: number, c: Color) =>
    s.polygon(
      pr.quad(x, y, w, d).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]),
      c,
    );
  // slope-lit dune field
  const field = new Float32Array((W + 4) * (H + 4));
  for (let py = 0; py < H + 4; py++) {
    for (let px = 0; px < W + 4; px++) {
      const [wx, wy] = pr.inv(px - ox, py - oy);
      field[py * (W + 4) + px] = fbm(wx / 150, wy / 96, 3, 11);
    }
  }
  const F = (px: number, py: number) => field[Math.max(0, Math.min(H + 3, py)) * (W + 4) + Math.max(0, Math.min(W + 3, px))];
  for (let py = 0; py < H; py++) {
    for (let px = 0; px < W; px++) {
      const [wx, wy] = pr.inv(px - ox, py - oy);
      const form = F(px + 2, py + 2);
      const sx = F(px + 4, py + 2) - F(px, py + 2);
      const sy = F(px + 2, py + 4) - F(px + 2, py);
      let lit = -sx * 6 - sy * 7;
      lit = Math.max(-1, Math.min(1, lit));
      const grain = fbm(wx / 13, wy / 10, 3, 41);
      const micro = valueNoise(wx / 2.7, wy / 2.7, 77);
      const biome = fbm(wx / 92, wy / 70, 3, 5) * 0.8 + form * 0.2;
      let v = grain * 0.6 + form * 0.26 + (micro - 0.5) * 0.1 + 0.14;
      v = Math.max(0, Math.min(0.999, v));
      const ramp = biome < 0.4 ? [dust.d1, dust.d2, dust.d3, dust.d4] : [dust.d3, dust.d4, dust.d5, dust.d6, dust.d7];
      const t = v * (ramp.length - 1);
      const i = Math.floor(t);
      let c = bayer4(px, py) < t - i ? ramp[Math.min(ramp.length - 1, i + 1)] : ramp[i];
      if (lit > 0) c = mix(c, dust.d8, Math.min(0.2, lit * 0.22));
      else c = mix(c, dust.d1, Math.min(0.24, -lit * 0.26));
      // wind streaks (directional texture)
      const streak = valueNoise(wx / 46, wy / 5, 61);
      if (streak > 0.78 && bayer4(px, py) < 0.5) c = mix(c, dust.d7, 0.25);
      if (streak < 0.2 && bayer4(px, py) < 0.4) c = mix(c, dust.d2, 0.25);
      s.setRaw(px, py, packRGBA(c & 0xff, (c >>> 8) & 0xff, (c >>> 16) & 0xff));
    }
  }
  // speckle clusters
  for (let i = 0; i < 7000; i++) {
    const wx = rnd.range(-20, 560);
    const wy = rnd.range(-20, 420);
    if (valueNoise(wx / 30, wy / 30, 3) < 0.55) continue;
    const [px, py] = pr.g(wx, wy);
    const sx = Math.round(px + ox);
    const sy = Math.round(py + oy);
    if (sx < 0 || sy < 0 || sx >= W || sy >= H) continue;
    s.set(sx, sy, rnd.chance(0.5) ? dust.d7 : dust.d2);
    if (rnd.chance(0.2)) s.set(sx + 1, sy, dust.d5);
  }
  // cracks with lit edges
  for (let i = 0; i < 16; i++) {
    let wx = rnd.range(40, 460);
    let wy = rnd.range(140, 360);
    let ang = rnd() * Math.PI * 2;
    for (let k = 0; k < 46; k++) {
      ang += (rnd() - 0.5) * 0.5;
      wx += Math.cos(ang) * 1.7;
      wy += Math.sin(ang) * 1.3;
      const [px, py] = pr.g(wx, wy);
      const sx = Math.round(px + ox);
      const sy = Math.round(py + oy);
      if (sx < 1 || sy < 1 || sx >= W - 1 || sy >= H - 1) break;
      s.set(sx, sy, mix(dust.d0, dust.d1, 0.4));
      if (rnd() < 0.25) s.set(sx, sy + 1, dust.d5);
      if (rnd() < 0.05 && k > 8) ang += 1.2;
    }
  }
  // work pad
  const pad = { x: 140, y: 176, w: 200, h: 100 };
  gq(pad.x, pad.y, pad.w, pad.h, mix(dust.d5, dust.d6, 0.5));
  gq(pad.x + 3, pad.y + 3, pad.w - 6, pad.h - 6, mix(dust.d6, dust.d7, 0.45));
  for (let i = 0; i < 10; i++) {
    const wx = rnd.range(pad.x + 12, pad.x + pad.w - 12);
    const wy = rnd.range(pad.y + 10, pad.y + pad.h - 10);
    const [px, py] = pr.g(wx, wy);
    s.contactShadow(Math.round(px + ox), Math.round(py + oy), rnd.int(3, 8), rnd.int(2, 5), withAlpha(grime.g2, 80), 0.7);
  }
  // deck plates + bolts
  for (const [dx, dy, dw, dd] of [
    [162, 196, 28, 18],
    [244, 190, 32, 20],
    [298, 214, 26, 16],
    [196, 244, 24, 14],
  ]) {
    gq(dx, dy, dw, dd, mix(warm.w3, dust.d3, 0.45));
    const a = pr.g(dx, dy);
    const b = pr.g(dx + dw, dy);
    s.line(Math.round(a[0] + ox), Math.round(a[1] + oy), Math.round(b[0] + ox), Math.round(b[1] + oy), mix(warm.w5, dust.d5, 0.4));
    const c2 = pr.g(dx + dw, dy + dd);
    s.line(Math.round(b[0] + ox), Math.round(b[1] + oy), Math.round(c2[0] + ox), Math.round(c2[1] + oy), warm.w1);
    for (let u = 3; u < dw - 2; u += 6) {
      const bp = pr.g(dx + u, dy + 1);
      s.set(Math.round(bp[0] + ox), Math.round(bp[1] + oy), warm.w6);
    }
  }
  // vehicle tracks with berms + treads
  for (const side of [-6, 6]) {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 30; t++) {
      const wx = 205 + side + Math.sin(t / 7) * 5;
      const wy = 420 - t * 4.4;
      const [px, py] = pr.g(wx, wy);
      const cur: [number, number] = [Math.round(px + ox), Math.round(py + oy)];
      if (prev) {
        s.line(prev[0], prev[1], cur[0], cur[1], mix(dust.d2, grime.g2, 0.45));
        s.line(prev[0] + 2, prev[1], cur[0] + 2, cur[1], mix(dust.d2, grime.g2, 0.5));
        if (t % 3 === 0) s.line(prev[0], prev[1] - 1, cur[0], cur[1] - 1, dust.d6);
      }
      prev = cur;
    }
  }
  // footpaths
  for (const [ax, ay, bx, by] of [
    [192, 210, 120, 236],
    [210, 214, 262, 246],
    [262, 246, 292, 190],
  ]) {
    for (let i = 0; i < 26; i++) {
      const t = i / 25;
      const wx = ax + (bx - ax) * t + (i % 2 === 0 ? -1.5 : 1.5);
      const wy = ay + (by - ay) * t;
      const [px, py] = pr.g(wx, wy);
      s.set(Math.round(px + ox), Math.round(py + oy), mix(dust.d2, dust.d3, 0.5));
    }
  }
  // footprints to the door
  for (let i = 0; i < 18; i++) {
    const wx = 192 + (i % 2 === 0 ? -1.5 : 1.5);
    const wy = 170 + i * 2.4;
    const [px, py] = pr.g(wx, wy);
    s.set(Math.round(px + ox), Math.round(py + oy), mix(dust.d2, dust.d3, 0.5));
  }
  // pipe trench generators -> hall
  let prevP: [number, number] | null = null;
  for (let t = 0; t <= 34; t++) {
    const wx = 120 + t * 3.4;
    const wy = 218 - Math.max(0, t - 26) * 3.4;
    const [px, py] = pr.g(wx, wy);
    const cur: [number, number] = [Math.round(px + ox), Math.round(py + oy)];
    if (prevP) {
      s.line(prevP[0], prevP[1], cur[0], cur[1], warm.w2);
      s.line(prevP[0], prevP[1] - 1, cur[0], cur[1] - 1, warm.w4);
    }
    prevP = cur;
  }
  // pad stencil + arrows
  const [mx, my] = pr.g(pad.x + 8, pad.y + pad.h - 8);
  drawText(s, Math.round(mx + ox), Math.round(my + oy), 'K-7 OUTPOST', mix(metal.m6, dust.d6, 0.5), { worn: 0.45, seed: 3 });
  for (let i = 0; i < 3; i++) {
    const [axx, axy] = pr.g(pad.x + 60 + i * 30, pad.y + 12);
    s.polygon(
      [
        [Math.round(axx + ox), Math.round(axy + oy)],
        [Math.round(axx + ox) + 6, Math.round(axy + oy) + 3],
        [Math.round(axx + ox), Math.round(axy + oy) + 6],
      ],
      mix(hazard.h2, dust.d5, 0.4),
    );
  }
  // interior floors of all four rooms (revealed by cutaway)
  for (const key of ['wing', 'hall', 'tech', 'garage'] as const) {
    const r = O2_ROOMS[key];
    gq(r.x, r.y, r.w, r.h, key === 'hall' ? slate.s5 : slate.s4);
    gq(r.x + 1, r.y + 1, r.w - 2, r.h - 2, key === 'hall' ? slate.s4 : slate.s3);
    // floor panel seams
    for (let u = 6; u < r.w - 4; u += 10) {
      const a = pr.g(r.x + u, r.y + 2);
      const b = pr.g(r.x + u, r.y + r.h - 2);
      s.line(Math.round(a[0] + ox), Math.round(a[1] + oy), Math.round(b[0] + ox), Math.round(b[1] + oy), slate.s2);
    }
    for (let v = 6; v < r.h - 4; v += 10) {
      const a = pr.g(r.x + 2, r.y + v);
      const b = pr.g(r.x + r.w - 2, r.y + v);
      s.line(Math.round(a[0] + ox), Math.round(a[1] + oy), Math.round(b[0] + ox), Math.round(b[1] + oy), slate.s2);
    }
  }
  // hall grating walkway + door mat + cables
  const hr = O2_ROOMS.hall;
  for (let i = 0; i < hr.w - 16; i += 2) {
    const a = pr.g(hr.x + 8 + i, hr.y + hr.h / 2 - 4);
    const b = pr.g(hr.x + 8 + i, hr.y + hr.h / 2 + 4);
    s.line(Math.round(a[0] + ox), Math.round(a[1] + oy), Math.round(b[0] + ox), Math.round(b[1] + oy), i % 4 === 0 ? slate.s5 : slate.s3);
  }
  let prevC: [number, number] | null = null;
  for (let t = 0; t <= 16; t++) {
    const p = pr.g(hr.x + 10 + t * 3.6, hr.y + hr.h - 8 + Math.sin(t) * 2);
    const cur: [number, number] = [Math.round(p[0] + ox), Math.round(p[1] + oy)];
    if (prevC) s.line(prevC[0], prevC[1], cur[0], cur[1], slate.s2);
    prevC = cur;
  }
  // garage pit (dark recess with hazard lip)
  const gr = O2_ROOMS.garage;
  gq(gr.x + 8, gr.y + 8, gr.w - 16, gr.h - 14, grime.g1);
  const lip = [
    pr.g(gr.x + 8, gr.y + 8),
    pr.g(gr.x + gr.w - 8, gr.y + 8),
    pr.g(gr.x + gr.w - 8, gr.y + gr.h - 6),
    pr.g(gr.x + 8, gr.y + gr.h - 6),
  ].map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
  for (let i = 0; i < 4; i++) s.line(lip[i][0], lip[i][1], lip[(i + 1) % 4][0], lip[(i + 1) % 4][1], mix(hazard.h2, slate.s3, 0.4));
  return s;
}

// ------------------------------------------------------------------ mesas
export function bakeMesa2(__pr: Proj, seed: number, tall: boolean): Baked {
  const s = new PixelSurface(150, 74);
  for (let x = 0; x < 150; x++) {
    const win = Math.pow(Math.max(0, Math.sin((Math.PI * x) / 150)), 0.65);
    const n = fbm(x / 58, seed, 3, seed);
    const plateau = Math.round(n * 3 + 0.35) / 3;
    const jitter = valueNoise(x * 0.28, seed * 3, 9) * 10;
    const top = Math.round(58 - win * ((tall ? 34 : 24) + plateau * (tall ? 22 : 14) + jitter * 0.6));
    for (let y = top; y < 70; y++) {
      const depth = (y - top) / 26;
      let c = mix(mix(dust.d3, rock.r3, 0.45), dust.d1, Math.min(0.72, depth));
      if (Math.sin(y * 0.85 + x * 0.02) > 0.88) c = mix(c, rock.r2, 0.45);
      if (Math.sin(y * 0.31 + x * 0.011) > 0.93) c = mix(c, dust.d4, 0.35); // strata
      if (y === top || y === top + 1) c = mix(c, dust.d7, 0.5);
      c = mix(c, dust.d6, 0.24);
      if (y > 62 && bayer4(x, y) < (y - 62) / 8) continue;
      if (x < 7 && bayer4(x, y) < (7 - x) / 7) continue;
      if (x > 142 && bayer4(x, y) < (x - 142) / 7) continue;
      s.set(x, y, c);
    }
  }
  // distant derelict mast on the ridge
  const mxp = 96;
  const myp = 26;
  s.vline(mxp, myp, 16, mix(metal.m3, dust.d6, 0.5));
  s.hline(mxp - 3, myp + 4, 7, mix(metal.m3, dust.d6, 0.5));
  s.set(mxp, myp - 1, mix(rust.x5, dust.d6, 0.4));
  return { sprite: s, ax: 75, ay: 72 };
}

// ------------------------------------------------------------------ shadows
export function bakeShadows2(pr: Proj, W: number, H: number, ox: number, oy: number, masses: { x: number; y: number; w: number; d: number; h: number }[], alpha: number): PixelSurface {
  const s = new PixelSurface(W, H);
  const L = pr.p.shadow;
  for (const m of masses) {
    const dx = L.x * m.h;
    const dy = L.y * m.h;
    const base = [pr.g(m.x, m.y), pr.g(m.x + m.w, m.y), pr.g(m.x + m.w, m.y + m.d), pr.g(m.x, m.y + m.d)];
    const far = base.map((p) => [p[0] + dx, p[1] + dy]);
    const poly = (pts: number[][]) =>
      s.polygon(
        pts.map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]),
        packRGBA(38, 22, 20, alpha),
      );
    poly([base[0], base[1], far[1], far[0]]);
    poly([base[1], base[2], far[2], far[1]]);
    poly(base);
  }
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      if ((s.data[i] >>> 24) === 0) continue;
      let outside = false;
      for (const o of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const nx = x + o[0];
        const ny = y + o[1];
        if (nx < 0 || ny < 0 || nx >= W || ny >= H || (s.data[ny * W + nx] >>> 24) === 0) outside = true;
      }
      if (outside && bayer8(x, y) < 0.6) s.data[i] = 0;
    }
  }
  return s;
}

// ------------------------------------------------------------------ props v2
export function bakeRock2(__pr: Proj, r: number, seed: number): Baked {
  const s = new PixelSurface(r * 2 + 10, r + 12);
  const rnd = makeRng(seed);
  const cx = r + 5;
  const cy = r + 4;
  const ry = Math.max(3, Math.round(r * 0.64));
  for (let y = -ry - 2; y <= ry; y++) {
    for (let x = -r - 2; x <= r + 2; x++) {
      const wob = 0.74 + valueNoise((cx + x) / 4, (cy + y) / 4, seed) * 0.5;
      const d = Math.sqrt((x * x) / (r * r) + (y * y) / (ry * ry)) / wob;
      if (d > 1) continue;
      const nl = (-x / r) * 0.5 + (-y / ry) * 0.82;
      const facet = valueNoise((cx + x) / 3.2, (cy + y) / 3.2, seed + 5);
      let v = 0.34 + nl * 0.34 + (facet - 0.5) * 0.42 - (1 - d) * 0.05;
      v = Math.max(0, Math.min(0.999, v));
      const ramp = [rock.r1, rock.r2, rock.r3, rock.r4, rock.r5, rock.r6];
      const t = v * (ramp.length - 1);
      let c = bayer4(x, y) < t - Math.floor(t) ? ramp[Math.min(ramp.length - 1, Math.floor(t) + 1)] : ramp[Math.floor(t)];
      if (nl > 0.55 && facet > 0.6) c = mix(c, rock.r7, 0.4);
      if (d > 0.8 && y > 0) c = mix(c, dust.d4, 0.4);
      s.set(cx + x, cy + y, c);
    }
  }
  for (let i = 0; i < 5; i++) s.set(cx - r + 2 + rnd.int(0, r * 2 - 4), cy - 3 + rnd.int(0, 6), rock.r2);
  return { sprite: s, ax: cx, ay: cy + ry - 1 };
}

export function bakePlant2(__pr: Proj, seed: number): Baked {
  const s = new PixelSurface(16, 16);
  const rnd = makeRng(seed);
  const cx = 8;
  const cy = 14;
  const blades = 5 + rnd.int(0, 4);
  for (let i = 0; i < blades; i++) {
    const h = 4 + rnd.int(0, 7);
    const lean = (rnd() - 0.5) * 5;
    for (let k = 0; k < h; k++) {
      const t = k / h;
      const px = Math.round(cx + lean * t * t + (i - blades / 2) * 0.9);
      const c = k === h - 1 ? mix(olive.o5, rust.x5, 0.45) : t > 0.5 ? mix(olive.o3, rust.x3, 0.3) : olive.o2;
      s.set(px, cy - k, c);
      if (k === h - 2 && rnd.chance(0.4)) s.set(px + 1, cy - k, mix(olive.o4, rust.x4, 0.4));
    }
  }
  s.set(cx, cy, olive.o1);
  s.set(cx + 1, cy, olive.o2);
  return { sprite: s, ax: cx, ay: cy };
}

export function bakeContainer2(pr: Proj, __seed: number): Baked {
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 26, d: 13, h: 13 },
    { top: [mix(teal.t5, dust.d7, 0.35), mix(teal.t4, dust.d6, 0.35)], front: [teal.t4, teal.t3, teal.t1], east: [teal.t1, teal.t0], rim: mix(teal.t6, dust.d8, 0.3), edge: teal.t0 },
    { x: 13, y: 6 },
    0,
    (s, f) => {
      for (let u = 2; u < f.front.uw - 2; u += 3) faceLine(s, f.front, u, 1, u, f.front.vh - 2, teal.t2);
      faceLine(s, f.front, 0, 1, f.front.uw, 1, teal.t5);
      faceRect(s, f.front, 4, 3, 8, 4, mix(metal.m6, dust.d6, 0.4));
      const fx = Math.round(f.front.origin[0] + f.front.u[0] * 5 + f.front.v[0] * 4);
      const fy = Math.round(f.front.origin[1] + f.front.u[1] * 5 + f.front.v[1] * 4);
      drawText(s, fx, fy, 'FRG', teal.t1, { worn: 0.2 });
      faceLine(s, f.front, 0, f.front.vh - 3, f.front.uw, f.front.vh - 3, mix(rust.x3, teal.t2, 0.4));
      facePx(s, f.front, f.front.uw - 3, 2, rust.x4);
      void s;
    },
  );
}

export function bakeCrate2(pr: Proj, seed: number): Baked {
  const m: Mat =
    seed % 2 === 0
      ? { top: [mix(metal.m7, olive.o5, 0.3), mix(metal.m5, olive.o4, 0.3)], front: [mix(metal.m6, olive.o4, 0.35), mix(metal.m4, olive.o3, 0.35), mix(metal.m2, olive.o2, 0.4)], east: [mix(metal.m2, olive.o2, 0.4), mix(metal.m1, olive.o1, 0.4)], rim: mix(metal.m8, olive.o6, 0.3), edge: metal.m1 }
      : { top: [mix(rust.x6, dust.d7, 0.25), rust.x4], front: [rust.x5, rust.x4, rust.x2], east: [rust.x2, rust.x1], rim: rust.x7, edge: rust.x0 };
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 11, d: 9, h: 9 },
    m,
    { x: 5, y: 4 },
    0,
    (s, f) => {
      faceLine(s, f.front, 1, 2, f.front.uw - 1, 2, metal.m2);
      faceLine(s, f.front, 1, f.front.vh - 3, f.front.uw - 1, f.front.vh - 3, metal.m2);
      facePx(s, f.front, 2, 4, metal.m7);
      void s;
    },
  );
}

export function bakeGenerator2(pr: Proj): Baked {
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 20, d: 13, h: 13 },
    { top: [mix(metal.m7, dust.d7, 0.3), mix(metal.m5, dust.d6, 0.3)], front: [mix(metal.m6, warm.w5, 0.4), mix(metal.m4, warm.w4, 0.4), mix(metal.m2, warm.w2, 0.4)], east: [warm.w2, warm.w1], rim: mix(metal.m8, amber.a6, 0.2), edge: warm.w0 },
    { x: 10, y: 6 },
    0,
    (s, f) => {
      for (let j = 2; j < 9; j += 2) faceLine(s, f.front, 2, j, 9, j, warm.w1);
      faceRect(s, f.front, 11, 2, 7, 6, warm.w1);
      faceLine(s, f.front, 12, 3, 16, 3, amber.a5);
      faceLine(s, f.front, 12, 5, 16, 5, amber.a3);
      facePx(s, f.front, 16, 9, cyan.c4);
      facePx(s, f.front, 3, 10, rust.x4);
      // exhaust stack on top
      const tx = Math.round(f.top.origin[0] + f.top.u[0] * 4 + f.top.v[0] * 4);
      const ty = Math.round(f.top.origin[1] + f.top.u[1] * 4 + f.top.v[1] * 4);
      s.rect(tx, ty - 8, 3, 8, warm.w2);
      s.vline(tx, ty - 8, 8, warm.w4);
      s.rect(tx - 1, ty - 10, 5, 3, warm.w1);
      void s;
    },
  );
}

export function bakeTransformer2(pr: Proj): Baked {
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 12, d: 10, h: 16 },
    { top: [metal.m5, metal.m4], front: [metal.m4, metal.m3, metal.m2], east: [metal.m2, metal.m1], rim: metal.m6, edge: metal.m1 },
    { x: 6, y: 5 },
    0,
    (s, f) => {
      faceRect(s, f.front, 2, 3, 8, 6, metal.m2);
      for (let j = 4; j < 9; j += 2) faceLine(s, f.front, 2, j, 10, j, metal.m4);
      facePx(s, f.front, 8, 2, amber.a4);
      // insulators on top
      for (const u of [3, 6, 9]) {
        const ix = Math.round(f.top.origin[0] + f.top.u[0] * u + f.top.v[0] * 4);
        const iy = Math.round(f.top.origin[1] + f.top.u[1] * u + f.top.v[1] * 4);
        s.vline(ix, iy - 5, 5, metal.m5);
        s.set(ix, iy - 6, mix(teal.t4, metal.m5, 0.4));
        s.set(ix - 1, iy - 3, metal.m6);
        s.set(ix + 1, iy - 3, metal.m6);
      }
      void s;
    },
  );
}

export function bakeLamp2(_pr: Proj): Baked {
  const s = new PixelSurface(14, 34);
  const bx = 6;
  const by = 32;
  s.vline(bx, 8, by - 8, metal.m3);
  s.vline(bx + 1, 8, by - 8, metal.m5);
  s.vline(bx - 1, 10, by - 10, metal.m2);
  s.rect(bx - 4, by - 2, 9, 3, metal.m2);
  s.hline(bx - 4, by - 2, 9, metal.m4);
  s.rect(bx - 5, 3, 11, 5, metal.m3);
  s.hline(bx - 5, 3, 11, metal.m6);
  s.rect(bx - 4, 7, 9, 2, amber.a4);
  s.hline(bx - 4, 7, 9, amber.a6);
  s.rect(bx - 2, 1, 3, 2, metal.m2);
  s.set(bx - 4, 9, rust.x3);
  return { sprite: s, ax: bx, ay: by };
}

export function bakeBarrier2(pr: Proj): Baked {
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 34, d: 7, h: 7 },
    { top: [mix(metal.m6, dust.d6, 0.4), mix(metal.m5, dust.d5, 0.4)], front: [mix(metal.m5, dust.d5, 0.45), mix(metal.m4, dust.d4, 0.45), mix(metal.m2, dust.d3, 0.4)], east: [metal.m2, metal.m1], rim: mix(metal.m7, dust.d7, 0.3), edge: metal.m1 },
    { x: 17, y: 3 },
    0,
    (s, f) => {
      for (let u = 0; u < f.front.uw - 2; u += 7) faceRect(s, f.front, u + 1, 2, 4, f.front.vh - 3, hazard.h2);
      facePx(s, f.front, 6, f.front.vh - 2, rust.x4);
      facePx(s, f.front, 20, 3, metal.m7);
      void s;
    },
  );
}

export function bakeBench2(pr: Proj): Baked {
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 16, d: 8, h: 6 },
    { top: [warm.w5, warm.w4], front: [warm.w4, warm.w3, warm.w2], east: [warm.w1, warm.w0], rim: warm.w6, edge: warm.w0 },
    { x: 8, y: 4 },
    0,
    (s, f) => {
      // tools on top
      for (const [u, v] of [
        [3, 2],
        [6, 4],
        [10, 3],
      ]) {
        const tx = Math.round(f.top.origin[0] + f.top.u[0] * u + f.top.v[0] * v);
        const ty = Math.round(f.top.origin[1] + f.top.u[1] * u + f.top.v[1] * v);
        s.set(tx, ty, metal.m6);
        s.set(tx + 1, ty, metal.m4);
      }
      facePx(s, f.front, 3, 2, metal.m6);
      void s;
    },
  );
}

export function bakeDish2(__pr: Proj): Baked {
  const s = new PixelSurface(24, 26);
  const cx = 12;
  const cy = 22;
  s.vline(cx, cy - 10, 10, metal.m4);
  s.vline(cx + 1, cy - 10, 10, metal.m2);
  s.ellipse(cx, cy - 14, 8, 6, metal.m5);
  s.ellipse(cx, cy - 14, 6, 4, metal.m3);
  s.ellipse(cx, cy - 14, 3, 2, metal.m2);
  s.set(cx, cy - 14, metal.m8);
  s.line(cx, cy - 14, cx + 6, cy - 20, metal.m4);
  s.set(cx + 6, cy - 20, cyan.c3);
  s.rect(cx - 4, cy - 2, 9, 3, metal.m3);
  return { sprite: s, ax: cx, ay: cy };
}

export function bakeTank2(__pr: Proj): Baked {
  const s = new PixelSurface(26, 34);
  const cx = 13;
  const cy = 30;
  // legs
  for (const lx of [cx - 7, cx + 5]) {
    s.vline(lx, cy - 8, 8, metal.m3);
    s.vline(lx + 1, cy - 8, 8, metal.m2);
  }
  // cylinder body
  for (let y = -16; y <= -6; y++) {
    for (let x = -9; x <= 9; x++) {
      const d = Math.abs(x) / 9;
      if (d > 1) continue;
      const lit = 0.5 - d * 0.8;
      const c = mix(metal.m2, metal.m7, Math.max(0, Math.min(1, lit + 0.35)));
      s.set(cx + x, cy + y, bayer4(x, y) < 0.2 ? mix(c, metal.m4, 0.4) : c);
    }
  }
  s.ellipse(cx, cy - 16, 9, 3, metal.m6);
  s.ellipse(cx, cy - 16, 7, 2, metal.m4);
  s.hline(cx - 9, cy - 11, 19, metal.m3);
  s.hline(cx - 9, cy - 10, 19, metal.m5);
  s.set(cx + 6, cy - 13, rust.x4);
  s.set(cx - 6, cy - 8, rust.x3);
  // pipe down
  s.vline(cx + 8, cy - 8, 8, metal.m3);
  s.vline(cx + 9, cy - 8, 8, metal.m2);
  return { sprite: s, ax: cx, ay: cy };
}

export function bakeSpool2(_pr: Proj): Baked {
  const s = new PixelSurface(22, 20);
  const cx = 11;
  const cy = 16;
  s.ellipse(cx, cy - 6, 9, 4, warm.w2);
  for (let i = 0; i < 7; i++) s.ellipseOutline(cx, cy - 6 + (i > 3 ? 1 : 0), 9 - (i % 3), 4 - (i % 2), i % 2 ? metal.m1 : metal.m3);
  s.ellipse(cx, cy - 7, 4, 2, warm.w4);
  s.rect(cx - 9, cy - 3, 18, 5, warm.w1);
  s.hline(cx - 9, cy - 3, 18, warm.w3);
  s.set(cx + 7, cy - 5, rust.x3);
  return { sprite: s, ax: cx, ay: cy };
}

export function bakeSandbags2(_pr: Proj): Baked {
  const s = new PixelSurface(26, 14);
  const rnd = makeRng(77);
  for (let row = 0; row < 3; row++) {
    for (let i = 0; i < 5 - row; i++) {
      const bx = 2 + i * 4 + row * 2;
      const by = 11 - row * 3;
      s.rect(bx, by, 4, 3, mix(olive.o3, dust.d4, 0.3 + row * 0.1));
      s.hline(bx, by, 4, mix(olive.o5, dust.d6, 0.3));
      s.hline(bx, by + 2, 4, olive.o1);
      if (rnd.chance(0.3)) s.set(bx + 2, by + 1, dust.d5);
    }
  }
  return { sprite: s, ax: 13, ay: 13 };
}

export function bakeSign2(_pr: Proj): Baked {
  const s = new PixelSurface(18, 22);
  const bx = 8;
  const by = 20;
  s.vline(bx, by - 14, 14, metal.m3);
  s.vline(bx + 1, by - 14, 14, metal.m2);
  s.rect(bx - 7, by - 20, 15, 8, metal.m4);
  s.strokeRect(bx - 7, by - 20, 15, 8, metal.m2);
  drawText(s, bx - 5, by - 18, 'K-7', metal.m9, { worn: 0.2 });
  s.hline(bx - 7, by - 13, 15, hazard.h2);
  s.set(bx - 6, by - 19, rust.x4);
  return { sprite: s, ax: bx, ay: by };
}

export function bakeCart2(_pr: Proj): Baked {
  const s = new PixelSurface(30, 22);
  const bx = 15;
  const by = 19;
  s.rect(bx - 12, by - 8, 24, 6, metal.m4);
  s.hline(bx - 12, by - 8, 24, metal.m6);
  s.hline(bx - 12, by - 3, 24, metal.m2);
  for (const wx of [bx - 9, bx + 7]) {
    s.ellipse(wx, by - 1, 3, 2, warm.w0);
    s.ellipse(wx, by - 1, 1, 1, warm.w3);
  }
  s.vline(bx + 12, by - 14, 7, metal.m3);
  s.hline(bx + 10, by - 14, 5, metal.m5);
  s.rect(bx - 9, by - 13, 8, 5, mix(olive.o3, metal.m4, 0.4));
  s.hline(bx - 9, by - 13, 8, olive.o5);
  s.rect(bx + 1, by - 11, 6, 3, mix(rust.x4, metal.m4, 0.4));
  return { sprite: s, ax: bx, ay: by };
}

export function bakeDrum2(_pr: Proj, seed: number): Baked {
  const s = new PixelSurface(14, 20);
  const cx = 7;
  const top = 4;
  const bot = 18;
  const rx = 5;
  for (let y = top; y <= bot; y++) {
    for (let x = -rx; x <= rx; x++) {
      const d = Math.abs(x) / rx;
      const lit = 0.5 - d * 0.9 + 0.35;
      const c = seed % 2 === 0 ? mix(rust.x2, rust.x6, Math.max(0, Math.min(1, lit))) : mix(warm.w1, warm.w5, Math.max(0, Math.min(1, lit)));
      s.set(cx + x, y, bayer4(x + 2, y) < 0.2 ? mix(c, rust.x3, 0.5) : c);
    }
  }
  for (const ry of [top + 4, top + 9]) {
    for (let x = -rx; x <= rx; x++) {
      const d = Math.abs(x) / rx;
      s.set(cx + x, ry, mix(rust.x6, rust.x8, 0.4 - d * 0.4));
      s.set(cx + x, ry + 1, rust.x1);
    }
  }
  s.ellipse(cx, top, rx, 2, mix(rust.x5, dust.d6, 0.3));
  s.ellipse(cx, top, rx - 1, 1, mix(rust.x3, rust.x4, 0.5));
  s.set(cx + 2, top - 1, metal.m5);
  s.rect(cx - 3, top + 6, 6, 4, mix(hazard.h1, rust.x3, 0.4));
  s.hline(cx - 3, top + 6, 6, hazard.h3);
  return { sprite: s, ax: cx, ay: bot };
}

// ------------------------------------------------------------------ vehicle v2
export function bakeVehicle2(pr: Proj): Baked {
  const b = massBounds(pr, -18, -10, 36, 20, 16);
  const s = new PixelSurface(b.w, b.h);
  const lp = new LocalProj(pr, -b.minX, -b.minY);
  const OLIVE: Mat = { top: [mix(olive.o4, dust.d6, 0.25), mix(olive.o3, dust.d5, 0.3)], front: [olive.o4, olive.o3, olive.o2], east: [olive.o2, olive.o1], rim: mix(olive.o5, dust.d7, 0.3), edge: olive.o1 };
  const CREAMC: Mat = { top: [mix(metal.m9, dust.d8, 0.25), mix(metal.m8, dust.d7, 0.3)], front: [metal.m7, metal.m5, metal.m3], east: [metal.m3, metal.m2], rim: mix(metal.mA, amber.a7, 0.2), edge: metal.m1 };
  // tracks with hubs
  for (const ty of [-10, 5]) {
    paintBox(s, lp, -17, ty, 34, 5, 5, DARK, (f) => {
      for (let u = 3; u < f.front.uw - 2; u += 6) {
        faceRect(s, f.front, u, 1, 3, 3, metal.m2);
        facePx(s, f.front, u + 1, 2, metal.m5);
      }
      faceLine(s, f.front, 0, 0, f.front.uw, 0, metal.m4);
      void s;
    });
  }
  // chassis
  paintBox(s, lp, -16, -8, 32, 16, 8, { top: [metal.m5, metal.m4], front: [metal.m5, metal.m4, metal.m2], east: [metal.m3, metal.m2], rim: metal.m6, edge: metal.m1 });
  // cargo bed (olive) with rails + strap + crate
  paintBox(s, lp, -15, -7, 17, 14, 13, OLIVE, (f) => {
    faceLine(s, f.front, 0, 1, f.front.uw, 1, mix(olive.o5, dust.d7, 0.3));
    faceLine(s, f.front, 0, 4, f.front.uw, 4, olive.o2);
    faceLine(s, f.front, 5, 1, 5, f.front.vh - 1, mix(warm.w3, olive.o3, 0.4)); // strap
    facePx(s, f.front, 10, 3, rust.x4);
    facePx(s, f.front, 2, f.front.vh - 2, rust.x3);
    void s;
  });
  paintBox(s, lp, -12, -4, 8, 8, 17, { top: [mix(metal.m7, olive.o5, 0.3), mix(metal.m5, olive.o4, 0.3)], front: [mix(metal.m6, olive.o4, 0.35), mix(metal.m4, olive.o3, 0.35), mix(metal.m2, olive.o2, 0.4)], east: [mix(metal.m2, olive.o2, 0.4), metal.m1], rim: metal.m8, edge: metal.m1 });
  // cabin (cream) with big glass
  paintBox(s, lp, 4, -7, 11, 14, 18, CREAMC, (f) => {
    windowOnFace(s, f.front, 2, 4, 5, 4, false);
    windowOnFace(s, f.east, 3, 4, 5, 4, false);
    faceLine(s, f.front, 0, f.front.vh - 2, f.front.uw, f.front.vh - 2, metal.m2);
    faceLine(s, f.front, 2, 10, 9, 10, metal.m6);
    faceLine(s, f.front, 0, 2, f.front.uw, 2, metal.m8);
    facePx(s, f.east, f.east.uw - 2, f.east.vh - 3, amber.a6); // headlight
    facePx(s, f.east, f.east.uw - 2, f.east.vh - 5, amber.a4);
    void s;
  });
  // roof rack + strapped crate
  paintBox(s, lp, 5, -6, 9, 12, 20, { top: [metal.m4, metal.m3], front: [metal.m4, metal.m3, metal.m2], east: [metal.m2, metal.m1], rim: metal.m6, edge: metal.m1 });
  paintBox(s, lp, 6, -4, 7, 8, 26, RUSTY, (f) => {
    faceLine(s, f.front, 1, 1, f.front.uw - 1, 1, rust.x6);
    faceLine(s, f.front, 3, 1, 3, f.front.vh - 1, mix(warm.w3, rust.x3, 0.4));
    facePx(s, f.front, 5, 3, metal.m7);
    void s;
  });
  // engine block (rust) + exhaust, lower than bed
  paintBox(s, lp, -18, -5, 4, 10, 10, RUSTY, (f) => {
    faceLine(s, f.front, 1, 3, f.front.uw - 1, 3, rust.x5);
    void s;
  });
  const ex = lp.g(-16, 0);
  s.vline(Math.round(ex[0]), Math.round(ex[1]) - 16, 7, warm.w2);
  s.vline(Math.round(ex[0]) + 1, Math.round(ex[1]) - 16, 7, warm.w4);
  s.rect(Math.round(ex[0]) - 1, Math.round(ex[1]) - 18, 4, 3, warm.w1);
  // bumper + winch + antenna + tail light
  const bp = lp.g(17, 0);
  s.rect(Math.round(bp[0]) - 1, Math.round(bp[1]) - 5, 3, 4, metal.m3);
  s.set(Math.round(bp[0]), Math.round(bp[1]) - 4, metal.m6);
  const tl = lp.g(-16, 4);
  s.set(Math.round(tl[0]), Math.round(tl[1]) - 6, mix(rust.x5, amber.a3, 0.2));
  const an = lp.g(6, -7);
  s.vline(Math.round(an[0]), Math.round(an[1]) - 30, 12, metal.m4);
  s.set(Math.round(an[0]), Math.round(an[1]) - 31, mix(rust.x5, amber.a3, 0.2));
  const [gx, gy] = pr.g(0, 0);
  return { sprite: s, ax: Math.round(gx - b.minX), ay: Math.round(gy - b.minY) };
}

export { bakeMass, massBounds, BIAS, O2_ROOMS as ROOMS2 };
export type { Baked, SceneBake, SceneLight, SceneRenderable };
