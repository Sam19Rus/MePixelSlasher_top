import { Color, mix, packRGBA, withAlpha } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { fbm, makeRng, valueNoise } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, dust, grime, hazard, metal, olive, rock, rust, slate, teal, warm } from '../data/palette';
import { drawText } from '../rendering/text';
import { Proj, type FaceQuad } from '../lab/profiles';
import { CREAM, DARK, LocalProj, RUSTY, paintBox, windowOnFace, type Mat } from '../lab/kit';
import { faceLine, facePx, faceRect } from '../lab/facePaint';

/**
 * THE FRONTIER OUTPOST — one scenography, baked per projection.
 *
 * Scene 2 (axonometric) and Scene 3 (tilted orthographic) render exactly this
 * world: same terrain concept, same building, same vehicle, drone, props,
 * lights and entrance. Only the ProjectionProfile differs.
 *
 * Depth is centralised: every renderable carries `depth` computed through
 * Proj.depth(anchor, baseZ, bias). Architectural stacking (shell NW < interior
 * < shell SE < roof < tower) uses documented group biases, never per-object
 * pixel offsets.
 */

export interface SceneRenderable {
  sprite: PixelSurface;
  x: number;
  y: number;
  depth: number;
  mode: 'both' | 'ext' | 'int';
  name: string;
}

export interface SceneLight {
  x: number;
  y: number;
  r: number;
  c: [number, number, number];
  i: number;
  flicker?: number;
  blink?: number;
  mode: 'both' | 'ext' | 'int';
}

export interface SceneBake {
  width: number;
  height: number;
  ox: number;
  oy: number;
  ground: PixelSurface;
  shadow: PixelSurface;
  shadowCut: PixelSurface;
  renderables: SceneRenderable[];
  lights: SceneLight[];
  collidersExt: { x: number; y: number; w: number; h: number }[];
  collidersInt: { x: number; y: number; w: number; h: number }[];
  boundsExt: { x: number; y: number; w: number; h: number };
  boundsInt: { x: number; y: number; w: number; h: number };
  entrance: { ext: { x: number; y: number }; int: { x: number; y: number } };
  interiorRect: { x: number; y: number; w: number; h: number };
  focus: { x: number; y: number };
  worldW: number;
  worldH: number;
}

// ------------------------------------------------------------------ layout
export const OUT_WORLD = { w: 560, h: 420 };
export const OUT = {
  hall: { x: 150, y: 100, w: 80, d: 60, h: 30 },
  wing: { x: 112, y: 108, w: 38, d: 44, h: 20 },
  garage: { x: 230, y: 112, w: 48, d: 44, h: 18 },
  tower: { x: 172, y: 112, w: 32, d: 28, h: 48 },
  doorU: 34,
  doorW: 12,
};
const WALL_T = 3;
export const OUT_INTERIOR = {
  x: OUT.hall.x + WALL_T,
  y: OUT.hall.y + WALL_T,
  w: OUT.hall.w - WALL_T * 2,
  h: OUT.hall.d - WALL_T * 2,
};
export const OUT_LAYOUT = {
  vehicle: { x: 306, y: 214 },
  robot: { x: 262, y: 200 },
  spawn: { x: 210, y: 250 },
  containers: [
    { x: 336, y: 138 },
    { x: 348, y: 156 },
  ],
  crates: [
    { x: 268, y: 240 },
    { x: 278, y: 248 },
  ],
  rocks: [
    { x: 88, y: 262, r: 10 },
    { x: 424, y: 252, r: 8 },
    { x: 66, y: 92, r: 9 },
    { x: 472, y: 118, r: 7 },
    { x: 150, y: 340, r: 8 },
    { x: 430, y: 330, r: 9 },
  ],
  plants: [
    { x: 120, y: 290 },
    { x: 330, y: 292 },
    { x: 96, y: 190 },
    { x: 402, y: 200 },
    { x: 250, y: 330 },
    { x: 372, y: 320 },
  ],
  generator: { x: 118, y: 224 },
  lamps: [
    { x: 176, y: 210 },
    { x: 206, y: 210 },
  ],
  spool: { x: 252, y: 202 },
  mast: { x: 100, y: 92 },
  barrier: { x: 250, y: 306 },
  mesas: [
    { x: 60, y: 150 },
    { x: 150, y: 40 },
  ],
};

// depth group biases (documented architectural stacking)
const BIAS = {
  shellNW: -0.4,
  shellSE: 0.4,
  roof: 0.8,
  tower: 1.2,
};

interface Baked {
  sprite: PixelSurface;
  ax: number;
  ay: number;
}

function massBounds(pr: Proj, x: number, y: number, w: number, d: number, h: number, pad = 8) {
  const cs = [pr.g(x, y), pr.g(x + w, y), pr.g(x + w, y + d), pr.g(x, y + d)];
  const xs = cs.map((c) => c[0]);
  const ys = cs.map((c) => c[1]);
  const minX = Math.floor(Math.min(...xs)) - pad;
  const maxX = Math.ceil(Math.max(...xs)) + Math.ceil(Math.abs(pr.p.kx) * d) + pad;
  const minY = Math.floor(Math.min(...ys)) - pr.lift(h) - Math.ceil(pr.p.ky * d) - pad;
  const maxY = Math.ceil(Math.max(...ys)) + pad;
  return { minX, minY, w: maxX - minX, h: maxY - minY };
}

function bakeMass(
  pr: Proj,
  r: { x: number; y: number; w: number; d: number; h: number },
  m: Mat,
  anchor: { x: number; y: number },
  baseZ = 0,
  detail?: (s: PixelSurface, f: { top: FaceQuad; front: FaceQuad; east: FaceQuad }) => void,
): Baked {
  const b = massBounds(pr, r.x, r.y, r.w, r.d, r.h);
  const s = new PixelSurface(b.w, b.h);
  const lp = new LocalProj(pr, -b.minX, -b.minY - pr.lift(baseZ));
  paintBox(s, lp, r.x, r.y, r.w, r.d, r.h, m, (f) => detail?.(s, f));
  const [gx, gy] = pr.g(anchor.x, anchor.y);
  return { sprite: s, ax: Math.round(gx - b.minX), ay: Math.round(gy - b.minY) - pr.lift(baseZ) };
}

// ------------------------------------------------------------------ ground
function bakeGround(pr: Proj, W: number, H: number, ox: number, oy: number): PixelSurface {
  const s = new PixelSurface(W, H);
  const gq = (x: number, y: number, w: number, d: number, c: Color) =>
    s.polygon(
      pr.quad(x, y, w, d).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]),
      c,
    );
  for (let py = 0; py < H; py++) {
    for (let px = 0; px < W; px++) {
      const [wx, wy] = pr.inv(px - ox, py - oy);
      const form = fbm(wx / 150, wy / 100, 3, 11);
      const grain = fbm(wx / 13, wy / 10, 3, 41);
      const micro = valueNoise(wx / 2.7, wy / 2.7, 77);
      let biome = fbm(wx / 90, wy / 70, 3, 5) * 0.8 + form * 0.2;
      let v = grain * 0.62 + form * 0.28 + (micro - 0.5) * 0.1 + 0.12;
      v = Math.max(0, Math.min(0.999, v));
      const ramp = biome < 0.42 ? [dust.d1, dust.d2, dust.d3, dust.d4] : [dust.d3, dust.d4, dust.d5, dust.d6, dust.d7];
      const t = v * (ramp.length - 1);
      const i = Math.floor(t);
      let c = bayer4(px, py) < t - i ? ramp[Math.min(ramp.length - 1, i + 1)] : ramp[i];
      c = mix(c, form > 0.55 ? dust.d8 : dust.d1, Math.min(0.16, Math.abs(form - 0.5) * 0.32));
      s.setRaw(px, py, packRGBA(c & 0xff, (c >>> 8) & 0xff, (c >>> 16) & 0xff));
    }
  }
  const rnd = makeRng(4242);
  for (let i = 0; i < 5200; i++) {
    const wx = rnd.range(-20, OUT_WORLD.w + 30);
    const wy = rnd.range(-20, OUT_WORLD.h + 30);
    const [px, py] = pr.g(wx, wy);
    const sx = Math.round(px + ox);
    const sy = Math.round(py + oy);
    if (sx < 0 || sy < 0 || sx >= W || sy >= H) continue;
    if (valueNoise(wx / 30, wy / 30, 3) < 0.55) continue;
    s.set(sx, sy, rnd.chance(0.5) ? dust.d7 : dust.d2);
  }
  // cracks
  for (let i = 0; i < 10; i++) {
    let wx = rnd.range(30, OUT_WORLD.w - 30);
    let wy = rnd.range(120, OUT_WORLD.h - 20);
    let ang = rnd() * Math.PI * 2;
    for (let k = 0; k < 40; k++) {
      ang += (rnd() - 0.5) * 0.5;
      wx += Math.cos(ang) * 1.6;
      wy += Math.sin(ang) * 1.2;
      const [px, py] = pr.g(wx, wy);
      const sx = Math.round(px + ox);
      const sy = Math.round(py + oy);
      if (sx < 1 || sy < 1 || sx >= W - 1 || sy >= H - 1) break;
      s.set(sx, sy, mix(dust.d0, dust.d1, 0.4));
      if (rnd() < 0.2) s.set(sx, sy + 1, dust.d5);
    }
  }
  // work pad + inner plate
  const pad = { x: 140, y: 170, w: 190, h: 92 };
  gq(pad.x, pad.y, pad.w, pad.h, mix(dust.d5, dust.d6, 0.5));
  gq(pad.x + 3, pad.y + 3, pad.w - 6, pad.h - 6, mix(dust.d6, dust.d7, 0.45));
  // deck plates
  for (const [dx, dy, dw, dd] of [
    [160, 186, 26, 16],
    [236, 182, 30, 18],
    [286, 200, 24, 14],
  ]) {
    gq(dx, dy, dw, dd, mix(warm.w3, dust.d3, 0.45));
    const a = pr.g(dx, dy);
    const b = pr.g(dx + dw, dy);
    s.line(Math.round(a[0] + ox), Math.round(a[1] + oy), Math.round(b[0] + ox), Math.round(b[1] + oy), mix(warm.w5, dust.d5, 0.4));
  }
  // tracks from south edge to pad
  for (const side of [-5, 5]) {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 26; t++) {
      const wx = 205 + side + Math.sin(t / 6) * 4;
      const wy = OUT_WORLD.h + 10 - t * 3.4;
      const [px, py] = pr.g(wx, wy);
      const cur: [number, number] = [Math.round(px + ox), Math.round(py + oy)];
      if (prev) s.line(prev[0], prev[1], cur[0], cur[1], mix(dust.d2, grime.g2, 0.45));
      prev = cur;
    }
  }
  // footprints door -> pad
  for (let i = 0; i < 16; i++) {
    const wx = 190 + (i % 2 === 0 ? -1.5 : 1.5);
    const wy = 166 + i * 2.4;
    const [px, py] = pr.g(wx, wy);
    s.set(Math.round(px + ox), Math.round(py + oy), mix(dust.d2, dust.d3, 0.5));
  }
  // pipe trench generator -> garage
  let prevP: [number, number] | null = null;
  for (let t = 0; t <= 30; t++) {
    const wx = 124 + t * 4;
    const wy = 210 - Math.max(0, t - 22) * 3.2;
    const [px, py] = pr.g(wx, wy);
    const cur: [number, number] = [Math.round(px + ox), Math.round(py + oy)];
    if (prevP) {
      s.line(prevP[0], prevP[1], cur[0], cur[1], warm.w2);
      s.line(prevP[0], prevP[1] - 1, cur[0], cur[1] - 1, warm.w4);
    }
    prevP = cur;
  }
  // stains
  for (let i = 0; i < 8; i++) {
    const wx = rnd.range(pad.x + 10, pad.x + pad.w - 10);
    const wy = rnd.range(pad.y + 8, pad.y + pad.h - 8);
    const [px, py] = pr.g(wx, wy);
    s.contactShadow(Math.round(px + ox), Math.round(py + oy), rnd.int(3, 7), rnd.int(2, 4), withAlpha(grime.g2, 80), 0.7);
  }
  // pad stencil
  const [mx, my] = pr.g(pad.x + 10, pad.y + pad.h - 8);
  drawText(s, Math.round(mx + ox), Math.round(my + oy), 'OUTPOST K-7', mix(metal.m6, dust.d6, 0.5), { worn: 0.45, seed: 3 });

  // interior floor (same physical space, revealed by cutaway)
  const ir = OUT_INTERIOR;
  gq(ir.x, ir.y, ir.w, ir.h, slate.s5);
  gq(ir.x + 1, ir.y + 1, ir.w - 2, ir.h - 2, slate.s4);
  for (let i = 0; i < ir.w - 10; i += 2) {
    const a = pr.g(ir.x + 5 + i, ir.y + ir.h / 2 - 4);
    const b = pr.g(ir.x + 5 + i, ir.y + ir.h / 2 + 4);
    s.line(Math.round(a[0] + ox), Math.round(a[1] + oy), Math.round(b[0] + ox), Math.round(b[1] + oy), i % 4 === 0 ? slate.s5 : slate.s3);
  }
  let prevC: [number, number] | null = null;
  for (let t = 0; t <= 14; t++) {
    const p = pr.g(ir.x + 8 + t * 3.4, ir.y + ir.h - 7 + Math.sin(t) * 2);
    const cur: [number, number] = [Math.round(p[0] + ox), Math.round(p[1] + oy)];
    if (prevC) s.line(prevC[0], prevC[1], cur[0], cur[1], slate.s2);
    prevC = cur;
  }
  const hz = [pr.g(ir.x + ir.w / 2 - 8, ir.y + ir.h - 5), pr.g(ir.x + ir.w / 2 + 8, ir.y + ir.h - 5), pr.g(ir.x + ir.w / 2 + 8, ir.y + ir.h - 2), pr.g(ir.x + ir.w / 2 - 8, ir.y + ir.h - 2)];
  s.polygon(hz.map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]), mix(hazard.h2, slate.s3, 0.4));
  return s;
}

// ------------------------------------------------------------------ shadows
function bakeShadowLayer(pr: Proj, W: number, H: number, ox: number, oy: number, masses: { x: number; y: number; w: number; d: number; h: number }[], alpha = 118): PixelSurface {
  const s = new PixelSurface(W, H);
  const L = pr.p.shadow;
  for (const m of masses) {
    const dx = L.x * m.h;
    const dy = L.y * m.h;
    const base = [pr.g(m.x, m.y), pr.g(m.x + m.w, m.y), pr.g(m.x + m.w, m.y + m.d), pr.g(m.x, m.y + m.d)];
    const far = base.map((p) => [p[0] + dx, p[1] + dy]);
    const poly = (pts: number[][]) =>
      s.polygon(
        pts.map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]),
        packRGBA(38, 22, 20, alpha),
      );
    poly([base[0], base[1], far[1], far[0]]);
    poly([base[1], base[2], far[2], far[1]]);
    poly(base);
  }
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      if ((s.data[i] >>> 24) === 0) continue;
      let outside = false;
      for (const o of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const nx = x + o[0];
        const ny = y + o[1];
        if (nx < 0 || ny < 0 || nx >= W || ny >= H || (s.data[ny * W + nx] >>> 24) === 0) outside = true;
      }
      if (outside && bayer8(x, y) < 0.6) s.data[i] = 0;
    }
  }
  return s;
}

// ------------------------------------------------------------------ props
function bakeRock(_pr: Proj, r: number, seed: number): Baked {
  const s = new PixelSurface(r * 2 + 8, r + 10);
  const rnd = makeRng(seed);
  const cx = r + 4;
  const cy = r + 3;
  const ry = Math.max(3, Math.round(r * 0.62));
  for (let y = -ry - 1; y <= ry; y++) {
    for (let x = -r - 1; x <= r + 1; x++) {
      const wob = 0.78 + valueNoise((cx + x) / 4, (cy + y) / 4, seed) * 0.44;
      const d = Math.sqrt((x * x) / (r * r) + (y * y) / (ry * ry)) / wob;
      if (d > 1) continue;
      const nl = (-x / r) * 0.5 + (-y / ry) * 0.8;
      let v = 0.34 + nl * 0.32 + (valueNoise((cx + x) / 3, (cy + y) / 3, seed + 1) - 0.5) * 0.4;
      v = Math.max(0, Math.min(0.999, v));
      const ramp = [rock.r1, rock.r2, rock.r3, rock.r4, rock.r5];
      const t = v * 4;
      s.set(cx + x, cy + y, bayer4(x, y) < t - Math.floor(t) ? ramp[Math.min(4, Math.floor(t) + 1)] : ramp[Math.floor(t)]);
    }
  }
  for (let i = 0; i < 4; i++) s.set(cx - r + 2 + rnd.int(0, r * 2 - 4), cy - 2 + rnd.int(0, 4), rock.r2);
  return { sprite: s, ax: cx, ay: cy + ry - 1 };
}

function bakePlant(_pr: Proj, seed: number): Baked {
  const s = new PixelSurface(14, 14);
  const rnd = makeRng(seed);
  const cx = 7;
  const cy = 12;
  const blades = 4 + rnd.int(0, 4);
  for (let i = 0; i < blades; i++) {
    const h = 3 + rnd.int(0, 6);
    const lean = (rnd() - 0.5) * 4;
    for (let k = 0; k < h; k++) {
      const t = k / h;
      const px = Math.round(cx + lean * t * t + (i - blades / 2) * 0.8);
      s.set(px, cy - k, k === h - 1 ? mix(olive.o5, rust.x5, 0.4) : t > 0.5 ? mix(olive.o3, rust.x3, 0.25) : olive.o2);
    }
  }
  s.set(cx, cy, olive.o1);
  return { sprite: s, ax: cx, ay: cy };
}

function bakeContainer(pr: Proj, _seed: number): Baked {
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 24, d: 12, h: 12 },
    { top: [mix(teal.t5, dust.d7, 0.35), mix(teal.t4, dust.d6, 0.35)], front: [teal.t4, teal.t3, teal.t1], east: [teal.t1, teal.t0], rim: mix(teal.t6, dust.d8, 0.3), edge: teal.t0 },
    { x: 12, y: 6 },
    0,
    (s, f) => {
      for (let u = 2; u < f.front.uw - 2; u += 3) faceLine(s, f.front, u, 1, u, f.front.vh - 2, teal.t2);
      faceLine(s, f.front, 0, 1, f.front.uw, 1, teal.t5);
      drawText(s, 0, 0, '', 0);
      void s;
    },
  );
}

function bakeCrate(pr: Proj, seed: number): Baked {
  const m: Mat =
    seed % 2 === 0
      ? { top: [mix(metal.m7, olive.o5, 0.3), mix(metal.m5, olive.o4, 0.3)], front: [mix(metal.m6, olive.o4, 0.35), mix(metal.m4, olive.o3, 0.35), mix(metal.m2, olive.o2, 0.4)], east: [mix(metal.m2, olive.o2, 0.4), mix(metal.m1, olive.o1, 0.4)], rim: mix(metal.m8, olive.o6, 0.3), edge: metal.m1 }
      : { top: [mix(rust.x6, dust.d7, 0.25), rust.x4], front: [rust.x5, rust.x4, rust.x2], east: [rust.x2, rust.x1], rim: rust.x7, edge: rust.x0 };
  return bakeMass(pr, { x: 0, y: 0, w: 10, d: 8, h: 8 }, m, { x: 5, y: 4 });
}

function bakeGenerator(pr: Proj): Baked {
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 18, d: 12, h: 12 },
    { top: [mix(metal.m7, dust.d7, 0.3), mix(metal.m5, dust.d6, 0.3)], front: [mix(metal.m6, warm.w5, 0.4), mix(metal.m4, warm.w4, 0.4), mix(metal.m2, warm.w2, 0.4)], east: [warm.w2, warm.w1], rim: mix(metal.m8, amber.a6, 0.2), edge: warm.w0 },
    { x: 9, y: 6 },
    0,
    (s, f) => {
      for (let j = 2; j < 8; j += 2) faceLine(s, f.front, 2, j, 8, j, warm.w1);
      faceRect(s, f.front, 10, 2, 6, 5, warm.w1);
      faceLine(s, f.front, 11, 3, 14, 3, amber.a5);
      faceLine(s, f.front, 11, 5, 14, 5, amber.a3);
      facePx(s, f.front, 14, 9, cyan.c4);
    },
  );
}

function bakeLamp(_pr: Proj): Baked {
  const s = new PixelSurface(12, 30);
  const bx = 5;
  const by = 28;
  s.vline(bx, 7, by - 7, metal.m3);
  s.vline(bx + 1, 7, by - 7, metal.m5);
  s.rect(bx - 3, by - 2, 8, 3, metal.m2);
  s.rect(bx - 4, 3, 10, 5, metal.m3);
  s.hline(bx - 4, 3, 10, metal.m6);
  s.rect(bx - 3, 7, 8, 2, amber.a4);
  s.hline(bx - 3, 7, 8, amber.a6);
  return { sprite: s, ax: bx, ay: by };
}

function bakeMast(_pr: Proj): Baked {
  const s = new PixelSurface(26, 64);
  const bx = 12;
  const by = 60;
  for (let y = by; y > 8; y--) {
    const wdt = y > by - 18 ? 3 : 2;
    s.set(bx - wdt, y, metal.m4);
    s.set(bx + wdt, y, metal.m2);
    if ((by - y) % 5 === 0) {
      s.hline(bx - wdt, y, wdt * 2 + 1, metal.m3);
      s.line(bx - wdt, y, bx + wdt, y - 4, metal.m2);
      s.line(bx + wdt, y, bx - wdt, y - 4, metal.m2);
    }
  }
  s.rect(bx - 5, by - 2, 11, 4, metal.m3);
  s.hline(bx - 5, by - 2, 11, metal.m6);
  s.hline(bx - 7, 14, 15, metal.m3);
  s.ellipse(bx + 6, 10, 5, 4, metal.m5);
  s.ellipse(bx + 6, 10, 3, 2, metal.m2);
  s.set(bx + 6, 10, metal.m8);
  s.vline(bx, 4, 8, metal.m4);
  s.set(bx, 3, mix(rust.x5, amber.a3, 0.2));
  s.line(bx, 8, bx - 9, by - 2, withAlpha(metal.m5, 150));
  s.line(bx, 8, bx + 9, by - 2, withAlpha(metal.m4, 150));
  return { sprite: s, ax: bx, ay: by };
}

function bakeVehicle(pr: Proj): Baked {
  const b = massBounds(pr, -16, -9, 32, 18, 14);
  const s = new PixelSurface(b.w, b.h);
  const lp = new LocalProj(pr, -b.minX, -b.minY);
  paintBox(s, lp, -15, -9, 30, 5, 5, DARK);
  paintBox(s, lp, -15, 4, 30, 5, 5, DARK);
  paintBox(
    s,
    lp,
    -14,
    -7,
    28,
    14,
    8,
    { top: [mix(metal.m6, olive.o5, 0.3), mix(metal.m5, olive.o4, 0.3)], front: [mix(metal.m6, olive.o4, 0.3), mix(metal.m4, olive.o3, 0.3), mix(metal.m2, olive.o2, 0.4)], east: [mix(metal.m2, olive.o2, 0.4), metal.m1], rim: mix(metal.m8, olive.o6, 0.3), edge: metal.m1 },
    (f) => {
      faceLine(s, f.front, 1, f.front.vh - 2, f.front.uw - 1, f.front.vh - 2, mix(hazard.h2, olive.o2, 0.4));
    },
  );
  paintBox(
    s,
    lp,
    3,
    -6,
    10,
    12,
    17,
    { top: [mix(metal.m9, dust.d8, 0.25), mix(metal.m8, dust.d7, 0.3)], front: [metal.m7, metal.m5, metal.m3], east: [metal.m2, metal.m1], rim: mix(metal.mA, amber.a7, 0.2), edge: metal.m1 },
    (f) => {
      windowOnFace(s, f.front, 2, 3, 7, 6, false);
      windowOnFace(s, f.east, 2, 3, 7, 6, false);
      faceLine(s, f.front, 0, f.front.vh - 2, f.front.uw, f.front.vh - 2, metal.m2);
    },
  );
  paintBox(
    s,
    lp,
    -13,
    -6,
    14,
    12,
    11,
    { top: [metal.m4, metal.m3], front: [metal.m4, metal.m3, metal.m2], east: [metal.m2, metal.m1], rim: metal.m6, edge: metal.m1 },
    (f) => {
      // cargo bed rails
      faceLine(s, f.front, 0, 1, f.front.uw, 1, metal.m6);
      faceLine(s, f.front, 0, 4, f.front.uw, 4, metal.m3);
      faceRect(s, f.front, 3, 5, 8, 4, mix(rust.x3, metal.m3, 0.4));
    },
  );
  paintBox(s, lp, -16, -4, 4, 8, 12, RUSTY);
  const hl = lp.g(14, 0);
  s.set(Math.round(hl[0]), Math.round(hl[1]) - 5, amber.a6);
  s.set(Math.round(hl[0]), Math.round(hl[1]) - 4, amber.a4);
  const tl = lp.g(-14, 0);
  s.set(Math.round(tl[0]), Math.round(tl[1]) - 5, mix(rust.x5, amber.a3, 0.2));
  const an = lp.g(5, -6);
  s.vline(Math.round(an[0]), Math.round(an[1]) - 24, 10, metal.m4);
  s.set(Math.round(an[0]), Math.round(an[1]) - 25, mix(rust.x5, amber.a3, 0.2));
  const [gx, gy] = pr.g(0, 0);
  return { sprite: s, ax: Math.round(gx - b.minX), ay: Math.round(gy - b.minY) };
}

function bakeSpool(_pr: Proj): Baked {
  const s = new PixelSurface(20, 18);
  const cx = 10;
  const cy = 14;
  s.ellipse(cx, cy - 5, 8, 4, warm.w2);
  for (let i = 0; i < 6; i++) s.ellipseOutline(cx, cy - 5 + (i > 2 ? 1 : 0), 8 - (i % 3), 4 - (i % 2), i % 2 ? metal.m1 : metal.m3);
  s.ellipse(cx, cy - 6, 4, 2, warm.w4);
  s.rect(cx - 8, cy - 3, 16, 5, warm.w1);
  s.hline(cx - 8, cy - 3, 16, warm.w3);
  return { sprite: s, ax: cx, ay: cy };
}

function bakeBarrier(pr: Proj): Baked {
  return bakeMass(
    pr,
    { x: 0, y: 0, w: 30, d: 6, h: 6 },
    { top: [mix(metal.m6, dust.d6, 0.4), mix(metal.m5, dust.d5, 0.4)], front: [mix(metal.m5, dust.d5, 0.45), mix(metal.m4, dust.d4, 0.45), mix(metal.m2, dust.d3, 0.4)], east: [metal.m2, metal.m1], rim: mix(metal.m7, dust.d7, 0.3), edge: metal.m1 },
    { x: 15, y: 3 },
    0,
    (s, f) => {
      for (let u = 0; u < f.front.uw - 2; u += 6) {
        faceRect(s, f.front, u + 1, 2, 3, f.front.vh - 3, hazard.h2);
      }
      void s;
    },
  );
}

function bakeMesa(_pr: Proj, seed: number): Baked {
  const s = new PixelSurface(120, 60);
  for (let x = 0; x < 120; x++) {
    const n = fbm(x / 34, seed, 3, seed);
    const plateau = Math.round(n * 4 + 0.4) / 4;
    const jitter = valueNoise(x * 0.35, seed * 3, 9) * 5;
    const top = Math.round(34 - plateau * 24 - jitter);
    for (let y = top; y < 58; y++) {
      const depth = (y - top) / 26;
      let c = mix(mix(dust.d3, rock.r3, 0.45), dust.d1, Math.min(0.7, depth));
      if (Math.sin(y * 0.9 + x * 0.02) > 0.9) c = mix(c, rock.r2, 0.45);
      if (y === top || y === top + 1) c = mix(c, dust.d7, 0.5); // sun rim on the ridge
      c = mix(c, dust.d6, 0.22); // haze
      if (y > 48 && bayer4(x, y) < (y - 48) / 10) continue; // fade into terrain
      if (x < 6 && bayer4(x, y) < (6 - x) / 6) continue; // fade side edges
      if (x > 113 && bayer4(x, y) < (x - 113) / 6) continue;
      s.set(x, y, c);
    }

  }
  return { sprite: s, ax: 60, ay: 58 };
}

// ------------------------------------------------------------------ full bake
export function bakeOutpost(pr: Proj): SceneBake {
  const renderables: SceneRenderable[] = [];
  const lights: SceneLight[] = [];
  const B = OUT;

  const cs = [pr.g(-40, -40), pr.g(OUT_WORLD.w + 50, -40), pr.g(OUT_WORLD.w + 50, OUT_WORLD.h + 50), pr.g(-40, OUT_WORLD.h + 50)];
  const xs = cs.map((c) => c[0]);
  const ys = cs.map((c) => c[1]);
  const minX = Math.floor(Math.min(...xs)) - 30;
  const maxX = Math.ceil(Math.max(...xs)) + 40;
  const minY = Math.floor(Math.min(...ys)) - 90;
  const maxY = Math.ceil(Math.max(...ys)) + 30;
  const W = maxX - minX;
  const H = maxY - minY;
  const ox = -minX;
  const oy = -minY;

  const ground = bakeGround(pr, W, H, ox, oy);
  const vehMass = { x: OUT_LAYOUT.vehicle.x - 15, y: OUT_LAYOUT.vehicle.y - 8, w: 30, h: 9, d: 16 };
  const shadowAlpha = pr.p.mode === 'tilted' ? 92 : 118;
  const shadow = bakeShadowLayer(pr, W, H, ox, oy, [B.hall, B.wing, B.garage, vehMass], shadowAlpha);
  const shadowCut = bakeShadowLayer(pr, W, H, ox, oy, [B.wing, B.garage, vehMass], shadowAlpha);

  const push = (bk: Baked, wx: number, wy: number, depth: number, mode: SceneRenderable['mode'], name: string) => {
    const [sx, sy] = pr.g(wx, wy);
    renderables.push({ sprite: bk.sprite, x: Math.round(sx + ox) - bk.ax, y: Math.round(sy + oy) - bk.ay, depth, mode, name });
  };

  // ---- background mesas
  for (const m of OUT_LAYOUT.mesas) {
    const bk = bakeMesa(pr, m.x);
    push(bk, m.x, m.y, pr.depth(m.x, m.y) - 40, 'both', 'mesa');
  }

  // ---- building shells
  const hallN = { x: B.hall.x, y: B.hall.y, w: B.hall.w, d: WALL_T, h: B.hall.h };
  const hallW = { x: B.hall.x, y: B.hall.y, w: WALL_T, d: B.hall.d, h: B.hall.h };
  const hallS = { x: B.hall.x, y: B.hall.y + B.hall.d - WALL_T, w: B.hall.w, d: WALL_T, h: B.hall.h };
  const hallE = { x: B.hall.x + B.hall.w - WALL_T, y: B.hall.y, w: WALL_T, d: B.hall.d, h: B.hall.h };

  // NW shell: north + west walls baked together (inner faces read in cutaway)
  {
    const bN = massBounds(pr, hallN.x, hallN.y, hallN.w, hallN.d, hallN.h);
    const bW = massBounds(pr, hallW.x, hallW.y, hallW.w, hallW.d, hallW.h);
    const mnx = Math.min(bN.minX, bW.minX);
    const mny = Math.min(bN.minY, bW.minY);
    const mxx = Math.max(bN.minX + bN.w, bW.minX + bW.w);
    const mxy = Math.max(bN.minY + bN.h, bW.minY + bW.h);
    const s = new PixelSurface(mxx - mnx, mxy - mny);
    const lp = new LocalProj(pr, -mnx, -mny);
    paintBox(s, lp, hallN.x, hallN.y, hallN.w, hallN.d, hallN.h, CREAM, (f) => {
      windowOnFace(s, f.front, 12, 7, 12, 8, true);
      windowOnFace(s, f.front, 44, 7, 12, 8, true);
      faceLine(s, f.front, 0, f.front.vh - 4, f.front.uw, f.front.vh - 4, mix(signalStripe(), metal.m3, 0.5));
    });
    paintBox(s, lp, hallW.x, hallW.y, hallW.w, hallW.d, hallW.h, CREAM, (f) => {
      windowOnFace(s, f.east, 10, 7, 8, 8, true);
      windowOnFace(s, f.east, 26, 7, 8, 8, true);
    });
    const anchor = { x: B.hall.x, y: B.hall.y + B.hall.d };
    const [gx, gy] = pr.g(anchor.x, anchor.y);
    push({ sprite: s, ax: Math.round(gx - mnx), ay: Math.round(gy - mny) }, anchor.x, anchor.y, pr.depth(B.hall.x + 6, B.hall.y + 6, 0, BIAS.shellNW), 'ext', 'hallNW');
  }
  // cutaway variant of the NW shell: walls cut at 60% height so the room reads
  {
    const hCut = Math.round(B.hall.h * 0.6);
    const bN = massBounds(pr, hallN.x, hallN.y, hallN.w, hallN.d, hCut);
    const bW = massBounds(pr, hallW.x, hallW.y, hallW.w, hallW.d, hCut);
    const mnx = Math.min(bN.minX, bW.minX);
    const mny = Math.min(bN.minY, bW.minY);
    const mxx = Math.max(bN.minX + bN.w, bW.minX + bW.w);
    const mxy = Math.max(bN.minY + bN.h, bW.minY + bW.h);
    const s = new PixelSurface(mxx - mnx, mxy - mny);
    const lp = new LocalProj(pr, -mnx, -mny);
    paintBox(s, lp, hallN.x, hallN.y, hallN.w, hallN.d, hCut, CREAM, (f) => {
      windowOnFace(s, f.front, 12, 4, 12, 6, true);
      windowOnFace(s, f.front, 44, 4, 12, 6, true);
    });
    paintBox(s, lp, hallW.x, hallW.y, hallW.w, hallW.d, hCut, { ...CREAM, east: [metal.m3, metal.m2], rim: metal.m6 }, (f) => {
      windowOnFace(s, f.east, 10, 4, 8, 6, true);
      windowOnFace(s, f.east, 26, 4, 8, 6, true);
    });
    // cut edge highlight
    const anchor = { x: B.hall.x, y: B.hall.y + B.hall.d };
    const [gx, gy] = pr.g(anchor.x, anchor.y);
    push({ sprite: s, ax: Math.round(gx - mnx), ay: Math.round(gy - mny) }, anchor.x, anchor.y, pr.depth(B.hall.x + 6, B.hall.y + 6, 0, BIAS.shellNW), 'int', 'hallNW-cut');
  }
  // SE shell: south + east walls + canopy + stairs + door
  {
    const bS = massBounds(pr, hallS.x, hallS.y, hallS.w, hallS.d, hallS.h);
    const bE = massBounds(pr, hallE.x, hallE.y, hallE.w, hallE.d, hallE.h);
    const mnx = Math.min(bS.minX, bE.minX);
    const mny = Math.min(bS.minY, bE.minY) - 10;
    const mxx = Math.max(bS.minX + bS.w, bE.minX + bE.w);
    const mxy = Math.max(bS.minY + bS.h, bE.minY + bE.h) + 10;
    const s = new PixelSurface(mxx - mnx, mxy - mny);
    const lp = new LocalProj(pr, -mnx, -mny);
    paintBox(s, lp, hallS.x, hallS.y, hallS.w, hallS.d, hallS.h, CREAM, (f) => {
      // blast door in the wall
      faceRect(s, f.front, B.doorU - 1, 4, B.doorW + 2, f.front.vh - 4, rust.x1);
      faceRect(s, f.front, B.doorU, 5, B.doorW, f.front.vh - 5, metal.m3);
      faceLine(s, f.front, B.doorU + B.doorW / 2, 5, B.doorU + B.doorW / 2, f.front.vh - 1, amber.a5);
      faceRect(s, f.front, B.doorU + 2, 7, 3, 4, teal.t1);
      faceRect(s, f.front, B.doorU + B.doorW - 5, 7, 3, 4, teal.t1);
      // windows + hazard base
      windowOnFace(s, f.front, 10, 7, 12, 8, true);
      windowOnFace(s, f.front, 56, 7, 12, 8, true);
      faceLine(s, f.front, 0, f.front.vh - 3, f.front.uw, f.front.vh - 3, mix(hazard.h2, metal.m3, 0.5));
      // door lamp
      facePx(s, f.front, B.doorU + B.doorW / 2, 1, amber.a5);
    });
    paintBox(s, lp, hallE.x, hallE.y, hallE.w, hallE.d, hallE.h, CREAM, (f) => {
      faceRect(s, f.front, 8, 6, 10, 8, teal.t1);
      faceLine(s, f.front, 8, 5, 18, 5, metal.m6);
    });
    // canopy: elevated slab on two posts (world-space, part of SE shell)
    {
      const lp2 = new LocalProj(pr, -mnx, -mny - pr.lift(20));
      paintBox(s, lp2, B.hall.x + B.doorU - 6, B.hall.y + B.hall.d - 2, B.doorW + 12, 6, 3, {
        top: [mix(metal.m7, dust.d7, 0.3), mix(metal.m6, dust.d6, 0.3)],
        front: [metal.m5, metal.m4, metal.m2],
        east: [metal.m2, metal.m1],
        rim: mix(metal.m8, amber.a6, 0.2),
        edge: metal.m1,
      }, (f) => {
        faceLine(s, f.front, 0, 1, f.front.uw, 1, mix(hazard.h2, metal.m3, 0.5));
      });
      // posts down to the steps
      for (const pu of [B.doorU - 4, B.doorU + B.doorW + 3]) {
        const a = lp2.g(B.hall.x + pu, B.hall.y + B.hall.d + 2);
        s.vline(Math.round(a[0]), Math.round(a[1]) - 2, 20, metal.m4);
        s.vline(Math.round(a[0]) + 1, Math.round(a[1]) - 2, 20, metal.m2);
      }
      // under-canopy light bar
      const lb = lp2.g(B.hall.x + B.doorU + B.doorW / 2, B.hall.y + B.hall.d + 3);
      s.hline(Math.round(lb[0]) - 4, Math.round(lb[1]) + 2, 9, amber.a5);
    }
    // stairs + rails in front of the door (world-space, part of SE shell)
    for (let i = 0; i < 3; i++) {
      const sw = B.doorW + 6 + i * 4;
      const sx0 = B.hall.x + B.doorU + B.doorW / 2 - sw / 2;
      const sy0 = B.hall.y + B.hall.d + 1 + i * 2;
      const q = [pr.g(sx0, sy0), pr.g(sx0 + sw, sy0), pr.g(sx0 + sw, sy0 + 2), pr.g(sx0, sy0 + 2)].map((p) => [Math.round(p[0] - mnx), Math.round(p[1] - mny - pr.lift(2 - i))]);
      s.polygon(q, mix(metal.m4, dust.d4, 0.35 + i * 0.15));
      s.line(q[0][0], q[0][1], q[1][0], q[1][1], mix(metal.m6, dust.d6, 0.3 + i * 0.2));
    }
    const anchor = { x: B.hall.x + B.hall.w, y: B.hall.y + B.hall.d };
    const [gx, gy] = pr.g(anchor.x, anchor.y);
    push({ sprite: s, ax: Math.round(gx - mnx), ay: Math.round(gy - mny) }, anchor.x, anchor.y, pr.depth(B.hall.x + B.hall.w - 6, B.hall.y + B.hall.d - 6, 0, BIAS.shellSE), 'ext', 'hallSE');
    // cutaway stubs (interior mode): low cut walls on S and E
    const stubS = bakeMass(pr, { ...hallS, h: 3 }, CREAM, { x: hallS.x + hallS.w / 2, y: hallS.y + hallS.d });
    push(stubS, hallS.x + hallS.w / 2, hallS.y + hallS.d, pr.depth(B.hall.x + B.hall.w - 6, B.hall.y + B.hall.d - 6, 0, BIAS.shellSE), 'int', 'hallS-stub');
    const stubE = bakeMass(pr, { ...hallE, h: 3 }, CREAM, { x: hallE.x + hallE.w, y: hallE.y + hallE.d / 2 });
    push(stubE, hallE.x + hallE.w, hallE.y + hallE.d / 2, pr.depth(B.hall.x + B.hall.w - 6, B.hall.y + B.hall.d - 6, 0, BIAS.shellSE), 'int', 'hallE-stub');
  }
  // roof slab + roof furniture
  {
    const r = { x: B.hall.x - 1, y: B.hall.y - 1, w: B.hall.w + 2, d: B.hall.d + 2, h: B.hall.h + 1 };
    const roof = bakeMass(pr, r, { top: [mix(metal.m8, dust.d7, 0.4), mix(metal.m6, dust.d6, 0.45)], front: [metal.m6, metal.m5, metal.m3], east: [metal.m2, metal.m1], rim: mix(metal.m9, amber.a6, 0.2), edge: metal.m1 }, { x: B.hall.x + B.hall.w / 2, y: B.hall.y + B.hall.d }, 0, (s, f) => {
      faceRect(s, f.top, 8, 8, 12, 9, metal.m4);
      faceRect(s, f.top, 9, 9, 10, 7, metal.m2);
      faceRect(s, f.top, 52, 14, 14, 11, metal.m5);
      faceLine(s, f.top, 53, 15, 64, 15, metal.m7);
      faceLine(s, f.top, 30, 6, 30, f.top.vh - 6, metal.m5);
      faceLine(s, f.top, 31, 6, 31, f.top.vh - 6, metal.m3);
      for (let u = 6; u < f.top.uw - 6; u += 11) facePx(s, f.top, u, f.top.vh - 4, dust.d6);
    });
    // roof sorts after the NW shell (overhang) but before anything standing on it
    push(roof, B.hall.x + B.hall.w / 2, B.hall.y + B.hall.d, pr.depth(B.hall.x, B.hall.y, 0, 12), 'ext', 'roof');
  }
  // tower (elevated mass penetrating the roof)
  {
    const tower = bakeMass(
      pr,
      { x: B.tower.x, y: B.tower.y, w: B.tower.w, d: B.tower.d, h: 26 },
      RUSTY,
      { x: B.tower.x + B.tower.w / 2, y: B.tower.y + B.tower.d },
      B.hall.h,
      (s, f) => {
        for (let u = 3; u < f.front.uw - 2; u += 4) faceLine(s, f.front, u, 2, u, f.front.vh - 2, mix(rust.x3, rust.x2, 0.5));
        faceRect(s, f.front, 5, 6, 14, 5, rust.x2);
        const fx = Math.round(f.front.origin[0] + f.front.u[0] * 6 + f.front.v[0] * 7);
        const fy = Math.round(f.front.origin[1] + f.front.u[1] * 6 + f.front.v[1] * 7);
        drawText(s, fx, fy, 'K-7', mix(rust.x7, metal.m8, 0.35), { worn: 0.15 });
        facePx(s, f.front, 24, 12, cyan.c4);
        // antenna on tower top
        const ax = Math.round(f.top.origin[0] + f.top.u[0] * 6 + f.top.v[0] * 6);
        const ay = Math.round(f.top.origin[1] + f.top.u[1] * 6 + f.top.v[1] * 6);
        s.vline(ax, ay - 16, 16, metal.m4);
        s.vline(ax + 1, ay - 16, 16, metal.m2);
        s.hline(ax - 3, ay - 12, 7, metal.m3);
        s.set(ax, ay - 17, mix(rust.x5, amber.a3, 0.2));
      },
    );
    push(tower, B.tower.x + B.tower.w / 2, B.tower.y + B.tower.d, pr.depth(B.tower.x + B.tower.w / 2, B.tower.y + B.tower.d / 2, B.hall.h, 20), 'ext', 'tower');
  }
  // wing + garage (complete masses, walls+roof in one sprite)
  const wing = bakeMass(pr, B.wing, CREAM, { x: B.wing.x + B.wing.w / 2, y: B.wing.y + B.wing.d }, 0, (s, f) => {
    windowOnFace(s, f.front, 6, 5, 8, 6, true);
    windowOnFace(s, f.front, 22, 5, 8, 6, true);
    faceRect(s, f.top, 6, 6, 10, 8, teal.t1);
    faceLine(s, f.top, 7, 8, 14, 8, teal.t3);
    faceLine(s, f.top, 7, 11, 14, 11, teal.t3);
  });
  push(wing, B.wing.x + B.wing.w / 2, B.wing.y + B.wing.d, pr.depth(B.wing.x + B.wing.w - 4, B.wing.y + B.wing.d - 4), 'both', 'wing');
  const garage = bakeMass(pr, B.garage, CREAM, { x: B.garage.x + B.garage.w / 2, y: B.garage.y + B.garage.d }, 0, (s, f) => {
    faceRect(s, f.front, 8, 4, 26, f.front.vh - 5, metal.m3);
    for (let j = 5; j < f.front.vh - 3; j += 2) faceLine(s, f.front, 8, j, 34, j, metal.m4);
    faceLine(s, f.front, 8, f.front.vh - 4, 34, f.front.vh - 4, hazard.h2);
    faceRect(s, f.front, 38, 6, 6, 6, teal.t1);
  });
  push(garage, B.garage.x + B.garage.w / 2, B.garage.y + B.garage.d, pr.depth(B.garage.x + B.garage.w - 4, B.garage.y + B.garage.d - 4), 'both', 'garage');

  // ---- interior furniture (interior mode only)
  const ir = OUT_INTERIOR;
  const furn: { r: { x: number; y: number; w: number; d: number; h: number }; m: Mat; name: string; detail?: (s: PixelSurface, f: { top: FaceQuad; front: FaceQuad; east: FaceQuad }) => void }[] = [
    { r: { x: ir.x + 6, y: ir.y + 2, w: 16, d: 6, h: 9 }, m: SLATE_MAT(), name: 'console1', detail: (s, f) => { faceRect(s, f.front, 2, 1, 12, 5, cyan.c0); faceLine(s, f.front, 3, 2, 11, 2, cyan.c3); faceLine(s, f.front, 3, 4, 8, 4, cyan.c2); } },
    { r: { x: ir.x + 30, y: ir.y + 2, w: 16, d: 6, h: 9 }, m: SLATE_MAT(), name: 'console2', detail: (s, f) => { faceRect(s, f.front, 2, 1, 12, 5, cyan.c0); faceLine(s, f.front, 3, 3, 12, 3, cyan.c2); } },
    { r: { x: ir.x + 22, y: ir.y + 24, w: 16, d: 10, h: 7 }, m: SLATE_MAT(), name: 'holotable', detail: (s, f) => { faceRect(s, f.top, 3, 2, 10, 6, cyan.c0); facePx(s, f.top, 7, 4, cyan.c5); } },
    { r: { x: ir.x + 2, y: ir.y + 20, w: 6, d: 14, h: 12 }, m: SLATE_MAT(), name: 'cabinet' },
    { r: { x: ir.x + ir.w - 10, y: ir.y + 14, w: 8, d: 8, h: 7 }, m: RUSTY, name: 'icrate1' },
    { r: { x: ir.x + ir.w - 10, y: ir.y + 24, w: 8, d: 8, h: 9 }, m: { top: [mix(metal.m7, olive.o5, 0.3), mix(metal.m5, olive.o4, 0.3)], front: [mix(metal.m6, olive.o4, 0.35), mix(metal.m4, olive.o3, 0.35), mix(metal.m2, olive.o2, 0.4)], east: [mix(metal.m2, olive.o2, 0.4), metal.m1], rim: metal.m8, edge: metal.m1 }, name: 'icrate2' },
    { r: { x: ir.x + 8, y: ir.y + 38, w: 14, d: 7, h: 8 }, m: { top: [warm.w5, warm.w4], front: [warm.w4, warm.w3, warm.w2], east: [warm.w1, warm.w0], rim: warm.w6, edge: warm.w0 }, name: 'workbench' },
  ];
  for (const f of furn) {
    const bk = bakeMass(pr, f.r, f.m, { x: f.r.x + f.r.w / 2, y: f.r.y + f.r.d }, 0, f.detail);
    push(bk, f.r.x + f.r.w / 2, f.r.y + f.r.d, pr.depth(f.r.x + f.r.w / 2, f.r.y + f.r.d), 'int', f.name);
  }

  // ---- props
  for (const c of OUT_LAYOUT.containers) push(bakeContainer(pr, c.x), c.x, c.y, pr.depth(c.x, c.y), 'both', 'container');
  for (const c of OUT_LAYOUT.crates) push(bakeCrate(pr, c.x + c.y), c.x, c.y, pr.depth(c.x, c.y), 'both', 'crate');
  for (const r of OUT_LAYOUT.rocks) push(bakeRock(pr, r.r, r.x), r.x, r.y, pr.depth(r.x, r.y), 'both', 'rock');
  for (const p of OUT_LAYOUT.plants) push(bakePlant(pr, p.x), p.x, p.y, pr.depth(p.x, p.y), 'both', 'plant');
  push(bakeGenerator(pr), OUT_LAYOUT.generator.x, OUT_LAYOUT.generator.y, pr.depth(OUT_LAYOUT.generator.x, OUT_LAYOUT.generator.y), 'both', 'generator');
  for (const l of OUT_LAYOUT.lamps) push(bakeLamp(pr), l.x, l.y, pr.depth(l.x, l.y) + 0.1, 'both', 'lamp');
  push(bakeSpool(pr), OUT_LAYOUT.spool.x, OUT_LAYOUT.spool.y, pr.depth(OUT_LAYOUT.spool.x, OUT_LAYOUT.spool.y), 'both', 'spool');
  push(bakeMast(pr), OUT_LAYOUT.mast.x, OUT_LAYOUT.mast.y, pr.depth(OUT_LAYOUT.mast.x, OUT_LAYOUT.mast.y) + 0.1, 'both', 'mast');
  push(bakeBarrier(pr), OUT_LAYOUT.barrier.x, OUT_LAYOUT.barrier.y, pr.depth(OUT_LAYOUT.barrier.x, OUT_LAYOUT.barrier.y), 'both', 'barrier');
  push(bakeVehicle(pr), OUT_LAYOUT.vehicle.x, OUT_LAYOUT.vehicle.y, pr.depth(OUT_LAYOUT.vehicle.x, OUT_LAYOUT.vehicle.y), 'both', 'vehicle');

  // ---- lights (world space)
  lights.push({ x: B.hall.x + B.doorU + B.doorW / 2, y: B.hall.y + B.hall.d + 3, r: 24, c: [1, 0.66, 0.34], i: 0.8, mode: 'ext' });
  lights.push({ x: B.hall.x + 16, y: B.hall.y + B.hall.d + 2, r: 10, c: [0.2, 0.8, 0.9], i: 0.35, mode: 'ext' });
  lights.push({ x: B.hall.x + 62, y: B.hall.y + B.hall.d + 2, r: 10, c: [0.2, 0.8, 0.9], i: 0.35, mode: 'ext' });
  lights.push({ x: B.tower.x + 16, y: B.tower.y - 2, r: 9, c: [1, 0.22, 0.18], i: 0.5, blink: 2.2, mode: 'ext' });
  for (const l of OUT_LAYOUT.lamps) lights.push({ x: l.x, y: l.y - 20, r: 24, c: [1, 0.72, 0.4], i: 0.55, mode: 'both' });
  lights.push({ x: OUT_LAYOUT.generator.x, y: OUT_LAYOUT.generator.y - 7, r: 13, c: [1, 0.5, 0.2], i: 0.45, flicker: 0.25, mode: 'both' });
  lights.push({ x: OUT_LAYOUT.vehicle.x + 14, y: OUT_LAYOUT.vehicle.y, r: 15, c: [1, 0.75, 0.45], i: 0.4, mode: 'both' });
  lights.push({ x: ir.x + ir.w / 2, y: ir.y + ir.h / 2, r: 46, c: [1, 0.84, 0.6], i: 1.1, mode: 'int' });
  lights.push({ x: ir.x + 14, y: ir.y + 6, r: 14, c: [0.25, 0.85, 0.9], i: 0.45, mode: 'int' });
  lights.push({ x: ir.x + 38, y: ir.y + 6, r: 14, c: [0.25, 0.85, 0.9], i: 0.45, mode: 'int' });
  lights.push({ x: ir.x + 30, y: ir.y + 28, r: 16, c: [0.2, 0.9, 1], i: 0.5, mode: 'int' });

  // ---- colliders
  const collidersExt = [
    { x: B.hall.x, y: B.hall.y, w: B.hall.w, d: 0, h: 0 },
  ];
  void collidersExt;
  const ce = [
    { x: B.wing.x, y: B.wing.y, w: B.garage.x + B.garage.w - B.wing.x, h: B.hall.d + B.hall.y - B.wing.y + 4 },
    { x: B.hall.x + B.doorU - 2, y: B.hall.y + B.hall.d, w: B.doorW + 4, h: 7 },
    { x: OUT_LAYOUT.vehicle.x - 15, y: OUT_LAYOUT.vehicle.y - 8, w: 30, h: 16 },
    { x: OUT_LAYOUT.containers[0].x - 12, y: OUT_LAYOUT.containers[0].y - 6, w: 24, h: 12 },
    { x: OUT_LAYOUT.containers[1].x - 12, y: OUT_LAYOUT.containers[1].y - 6, w: 24, h: 12 },
    { x: OUT_LAYOUT.crates[0].x - 5, y: OUT_LAYOUT.crates[0].y - 4, w: 20, h: 14 },
    { x: OUT_LAYOUT.generator.x - 9, y: OUT_LAYOUT.generator.y - 6, w: 18, h: 12 },
    { x: OUT_LAYOUT.barrier.x - 15, y: OUT_LAYOUT.barrier.y - 3, w: 30, h: 8 },
    { x: OUT_LAYOUT.rocks[0].x - 9, y: OUT_LAYOUT.rocks[0].y - 5, w: 18, h: 10 },
    { x: OUT_LAYOUT.rocks[1].x - 7, y: OUT_LAYOUT.rocks[1].y - 4, w: 14, h: 8 },
    { x: OUT_LAYOUT.rocks[4].x - 7, y: OUT_LAYOUT.rocks[4].y - 4, w: 14, h: 8 },
    { x: OUT_LAYOUT.rocks[5].x - 8, y: OUT_LAYOUT.rocks[5].y - 5, w: 16, h: 9 },
  ];
  const ci = [
    { x: 0, y: 0, w: 0, h: 0 },
  ];
  void ci;
  const ciReal = [
    // inner wall bands
    { x: ir.x - WALL_T, y: ir.y - WALL_T, w: ir.w + WALL_T * 2, h: WALL_T },
    { x: ir.x - WALL_T, y: ir.y, w: WALL_T, h: ir.h },
    { x: ir.x + ir.w, y: ir.y, w: WALL_T, h: ir.h },
    { x: ir.x, y: ir.y + ir.h, w: ir.w, h: WALL_T },
    // furniture
    { x: ir.x + 6, y: ir.y + 2, w: 16, h: 6 },
    { x: ir.x + 30, y: ir.y + 2, w: 16, h: 6 },
    { x: ir.x + 22, y: ir.y + 24, w: 16, h: 10 },
    { x: ir.x + 2, y: ir.y + 20, w: 6, h: 14 },
    { x: ir.x + ir.w - 10, y: ir.y + 14, w: 8, h: 16 },
    { x: ir.x + 8, y: ir.y + 38, w: 14, h: 7 },
  ];

  return {
    width: W,
    height: H,
    ox,
    oy,
    ground,
    shadow,
    shadowCut,
    renderables,
    lights,
    collidersExt: ce,
    collidersInt: ciReal,
    boundsExt: { x: 30, y: 60, w: OUT_WORLD.w - 60, h: OUT_WORLD.h - 90 },
    boundsInt: { x: ir.x + 1, y: ir.y + 1, w: ir.w - 2, h: ir.h - 2 },
    entrance: { ext: { x: B.hall.x + B.doorU + B.doorW / 2, y: B.hall.y + B.hall.d + 8 }, int: { x: B.hall.x + B.doorU + B.doorW / 2, y: B.hall.y + B.hall.d - 6 } },
    interiorRect: ir,
    focus: { x: B.hall.x + B.hall.w / 2, y: B.hall.y + B.hall.d / 2 + 26 },
    worldW: OUT_WORLD.w,
    worldH: OUT_WORLD.h,
  };
}

function SLATE_MAT(): Mat {
  return { top: [slate.s5, slate.s4], front: [slate.s5, slate.s4, slate.s3], east: [slate.s2, slate.s1], rim: slate.s6, edge: slate.s1 };
}
function signalStripe(): Color {
  return mix(rust.x4, hazard.h2, 0.3);
}
