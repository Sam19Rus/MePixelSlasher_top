import { mix, packRGBA, withAlpha } from '../rendering/color';
import { bayer4 } from '../rendering/dither';
import { makeRng } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, dust, hazard, metal, rust, slate, teal, warm } from '../data/palette';
import { drawText } from '../rendering/text';
import { Proj, type FaceQuad } from '../lab/profiles';
import { CREAM, DARK, LocalProj, RUSTY, paintBox, windowOnFace, type Mat } from '../lab/kit';
import { faceLine, facePx, faceRect } from '../lab/facePaint';
import type { SceneBake, SceneLight, SceneRenderable } from './outpostKit';
import {
  BIAS,
  O2,
  O2_LAYOUT as L2,
  O2_ROOMS as R2,
  bakeBarrier2,
  bakeBench2,
  bakeCart2,
  bakeContainer2,
  bakeCrate2,
  bakeDish2,
  bakeDrum2,
  bakeGenerator2,
  bakeGround2,
  bakeLamp2,
  bakeMass,
  bakeMesa2,
  bakePlant2,
  bakeRock2,
  bakeSandbags2,
  bakeShadows2,
  bakeSign2,
  bakeSpool2,
  bakeTank2,
  bakeTransformer2,
  bakeVehicle2,
  massBounds,
} from './outpostKit2Parts';

/**
 * OUTPOST K-7 assembler (Stage 5 geometry correction).
 *
 * Exterior masses are CLOSED coherent boxes: one sprite per mass containing
 * its roof plane + real south/east walls sharing edges with roof and ground
 * (see Proj.tiltedBox / axonBox). Nothing of the interior exists in exterior
 * mode. The cutaway swaps each closed mass for an open variant (north + west
 * walls only, full height, inner-face detail) so the same physical building
 * reads correctly from inside, in the same world.
 */

const TECH_MAT: Mat = {
  top: [mix(metal.m8, dust.d7, 0.35), mix(metal.m6, dust.d6, 0.4)],
  front: [metal.m6, metal.m4, metal.m2],
  east: [metal.m3, metal.m2],
  rim: mix(metal.m9, amber.a6, 0.2),
  edge: metal.m1,
};
const GARAGE_MAT: Mat = {
  top: [mix(metal.m7, dust.d7, 0.4), mix(metal.m5, dust.d6, 0.45)],
  front: [metal.m5, metal.m4, metal.m2],
  east: [metal.m3, metal.m2],
  rim: mix(metal.m8, dust.d8, 0.2),
  edge: metal.m1,
};
const TOWER_MAT: Mat = {
  top: [mix(rust.x7, dust.d7, 0.3), mix(rust.x5, dust.d6, 0.3)],
  front: [rust.x6, rust.x5, rust.x3],
  east: [rust.x3, rust.x2],
  rim: mix(rust.x8, amber.a6, 0.2),
  edge: rust.x0,
};
const INNER_MAT: Mat = {
  top: [metal.m6, metal.m5],
  front: [slate.s6, slate.s5, slate.s4],
  east: [slate.s5, slate.s4],
  rim: metal.m7,
  edge: slate.s2,
};

interface Baked {
  sprite: PixelSurface;
  ax: number;
  ay: number;
}

type Faces = { top: FaceQuad; front: FaceQuad; east: FaceQuad };

export function bakeOutpost2(pr: Proj): SceneBake {
  const renderables: SceneRenderable[] = [];
  const lights: SceneLight[] = [];
  const rnd = makeRng(5150);
  const B = O2;
  const tilted = pr.p.mode === 'tilted';

  const cs = [pr.g(-50, -50), pr.g(560, -50), pr.g(560, 430), pr.g(-50, 430)];
  const xs = cs.map((c) => c[0]);
  const ys = cs.map((c) => c[1]);
  const minX = Math.floor(Math.min(...xs)) - 40;
  const maxX = Math.ceil(Math.max(...xs)) + 50;
  const minY = Math.floor(Math.min(...ys)) - 110;
  const maxY = Math.ceil(Math.max(...ys)) + 40;
  const W = maxX - minX;
  const H = maxY - minY;
  const ox = -minX;
  const oy = -minY;

  const ground = bakeGround2(pr, W, H, ox, oy);
  const shadowAlpha = tilted ? 96 : 118;
  const shadow = bakeShadows2(pr, W, H, ox, oy, [B.hall, B.wing, B.tech, B.garage, { x: L2.vehicle.x - 17, y: L2.vehicle.y - 9, w: 34, h: 10, d: 18 }], shadowAlpha);
  const shadowCut = bakeShadows2(pr, W, H, ox, oy, [B.wing, B.tech, B.garage, { x: L2.vehicle.x - 17, y: L2.vehicle.y - 9, w: 34, h: 10, d: 18 }], shadowAlpha);

  const push = (bk: Baked, wx: number, wy: number, depth: number, mode: SceneRenderable['mode'], name: string) => {
    const [sx, sy] = pr.g(wx, wy);
    renderables.push({ sprite: bk.sprite, x: Math.round(sx + ox) - bk.ax, y: Math.round(sy + oy) - bk.ay, depth, mode, name });
  };

  // ------------------------------------------------------------ background
  for (const m of L2.mesas) {
    const bk = bakeMesa2(pr, m.x, m.x === 150);
    push(bk, m.x, m.y, pr.depth(m.x, m.y) - 40, 'both', 'mesa');
  }

  // ------------------------------------------------------------ mass bakers
  /** closed exterior mass: roof + real walls in one sprite */
  const closedMass = (
    mass: { x: number; y: number; w: number; d: number; h: number },
    mat: Mat,
    anchor: { x: number; y: number },
    depth: number,
    name: string,
    detail?: (s: PixelSurface, f: Faces) => void,
  ) => {
    const bk = bakeMass(pr, mass, mat, anchor, 0, detail);
    push(bk, anchor.x, anchor.y, depth, 'ext', name);
    return bk;
  };
  /** open (cutaway) mass: north + west walls, full height, inner faces */
  const openMass = (
    mass: { x: number; y: number; w: number; d: number; h: number },
    anchor: { x: number; y: number },
    depth: number,
    name: string,
    inner?: (s: PixelSurface, fN: Faces, fW: Faces) => void,
  ) => {
    const mN = { x: mass.x, y: mass.y, w: mass.w, d: 3, h: mass.h };
    const mW = { x: mass.x, y: mass.y, w: 3, d: mass.d, h: mass.h };
    const bN = massBounds(pr, mN.x, mN.y, mN.w, mN.d, mN.h);
    const bW = massBounds(pr, mW.x, mW.y, mW.w, mW.d, mW.h);
    const mnx = Math.min(bN.minX, bW.minX);
    const mny = Math.min(bN.minY, bW.minY);
    const mxx = Math.max(bN.minX + bN.w, bW.minX + bW.w);
    const mxy = Math.max(bN.minY + bN.h, bW.minY + bW.h);
    const surf = new PixelSurface(mxx - mnx, mxy - mny);
    const lp = new LocalProj(pr, -mnx, -mny);
    let fN: Faces | null = null;
    let fW: Faces | null = null;
    paintBox(surf, lp, mN.x, mN.y, mN.w, mN.d, mN.h, INNER_MAT, (f) => {
      fN = f;
    });
    paintBox(surf, lp, mW.x, mW.y, mW.w, mW.d, mW.h, { ...INNER_MAT, east: [slate.s4, slate.s3] }, (f) => {
      fW = f;
    });
    if (inner && fN && fW) inner(surf, fN, fW);
    const [gx, gy] = pr.g(anchor.x, anchor.y);
    const bk: Baked = { sprite: surf, ax: Math.round(gx - mnx), ay: Math.round(gy - mny) };
    push(bk, anchor.x, anchor.y, depth, 'int', name);
  };

  const innerDetail = (s: PixelSurface, fN: Faces, fW: Faces) => {
    // industrial inner faces: stripe, panel rows, conduits
    faceLine(s, fN.front, 0, 3, fN.front.uw, 3, mix(rust.x3, hazard.h2, 0.3));
    for (let u = 8; u < fN.front.uw - 10; u += 18) faceRect(s, fN.front, u, 6, 12, 3, slate.s3);
    faceLine(s, fN.front, 2, fN.front.vh - 2, fN.front.uw - 2, fN.front.vh - 2, slate.s2);
    faceLine(s, fW.east, 0, 3, fW.east.uw, 3, mix(rust.x3, hazard.h2, 0.3));
    for (let u = 6; u < fW.east.uw - 8; u += 14) faceRect(s, fW.east, u, 6, 8, 3, slate.s3);
    faceLine(s, fW.east, 1, fW.east.vh - 2, fW.east.uw - 1, fW.east.vh - 2, slate.s2);
    void s;
  };

  // ------------------------------------------------------------ hall
  const hallAnchor = { x: B.hall.x + B.hall.w - 3, y: B.hall.y + B.hall.d - 3 };
  const hallDepth = pr.depth(hallAnchor.x, hallAnchor.y);
  closedMass(B.hall, CREAM, hallAnchor, hallDepth, 'hall', (s, f) => {
    // near facade: blast door, canopy, stairs, rails, ribbon windows
    faceRect(s, f.front, B.doorU - 1, 4, B.doorW + 2, f.front.vh - 4, rust.x1);
    faceRect(s, f.front, B.doorU, 5, B.doorW, f.front.vh - 5, metal.m3);
    faceLine(s, f.front, B.doorU + B.doorW / 2, 5, B.doorU + B.doorW / 2, f.front.vh - 1, amber.a5);
    faceRect(s, f.front, B.doorU + 2, 7, 3, 4, teal.t1);
    faceRect(s, f.front, B.doorU + B.doorW - 5, 7, 3, 4, teal.t1);
    windowOnFace(s, f.front, 8, 6, 16, 7, true);
    windowOnFace(s, f.front, 58, 6, 16, 7, true);
    faceLine(s, f.front, 0, f.front.vh - 3, f.front.uw, f.front.vh - 3, mix(hazard.h2, metal.m3, 0.5));
    const sx0 = Math.round(f.front.origin[0] + f.front.u[0] * 30 + f.front.v[0] * 4);
    const sy0 = Math.round(f.front.origin[1] + f.front.u[1] * 30 + f.front.v[1] * 4);
    drawText(s, sx0, sy0, 'OPS', mix(metal.m8, dust.d7, 0.3), { worn: 0.2 });
    faceRect(s, f.front, 52, f.front.vh - 8, 3, 5, rust.x3);
    facePx(s, f.front, B.doorU + B.doorW / 2, 2, amber.a5);
    // east wall: windows + vent block
    windowOnFace(s, f.east, 12, 6, 12, 7, true);
    faceRect(s, f.east, 34, 5, 10, 8, metal.m3);
    for (let j = 6; j < 12; j += 2) faceLine(s, f.east, 34, j, 44, j, metal.m2);
    // roof machinery
    faceRect(s, f.top, 8, 8, 14, 10, metal.m4);
    faceRect(s, f.top, 9, 9, 12, 8, metal.m2);
    faceLine(s, f.top, 10, 10, 20, 10, metal.m5);
    faceRect(s, f.top, 56, 12, 12, 9, metal.m5);
    faceLine(s, f.top, 57, 13, 66, 13, metal.m7);
    faceRect(s, f.top, 30, 30, 10, 8, metal.m3);
    faceLine(s, f.top, 31, 31, 38, 31, metal.m6);
    faceLine(s, f.top, 44, 6, 44, f.top.vh - 6, metal.m5);
    faceLine(s, f.top, 45, 6, 45, f.top.vh - 6, metal.m3);
    for (let u = 6; u < f.top.uw - 6; u += 10) facePx(s, f.top, u, f.top.vh - 4, dust.d6);
    faceRect(s, f.top, 66, 34, 8, 6, metal.m4);
    // canopy + posts + stairs + rails (world-attached, lifted)
    const b = massBounds(pr, B.hall.x, B.hall.y, B.hall.w, B.hall.d, B.hall.h);
    const mnx = b.minX;
    const mny = b.minY;
    const lp2 = new LocalProj(pr, -mnx, -mny - pr.lift(20));
    paintBox(
      s,
      lp2,
      B.hall.x + B.doorU - 7,
      B.hall.y + B.hall.d - 2,
      B.doorW + 14,
      7,
      3,
      { top: [mix(metal.m7, dust.d7, 0.3), mix(metal.m6, dust.d6, 0.3)], front: [metal.m5, metal.m4, metal.m2], east: [metal.m2, metal.m1], rim: mix(metal.m8, amber.a6, 0.2), edge: metal.m1 },
      (cf) => {
        faceLine(s, cf.front, 0, 1, cf.front.uw, 1, mix(hazard.h2, metal.m3, 0.5));
        void s;
      },
    );
    for (const pu of [B.doorU - 5, B.doorU + B.doorW + 4]) {
      const a = lp2.g(B.hall.x + pu, B.hall.y + B.hall.d + 3);
      s.vline(Math.round(a[0]), Math.round(a[1]) - 2, 20, metal.m4);
      s.vline(Math.round(a[0]) + 1, Math.round(a[1]) - 2, 20, metal.m2);
    }
    const lb = lp2.g(B.hall.x + B.doorU + B.doorW / 2, B.hall.y + B.hall.d + 4);
    s.hline(Math.round(lb[0]) - 5, Math.round(lb[1]) + 2, 11, amber.a5);
    for (let i = 0; i < 3; i++) {
      const sw = B.doorW + 8 + i * 4;
      const stx = B.hall.x + B.doorU + B.doorW / 2 - sw / 2;
      const sty = B.hall.y + B.hall.d + 1 + i * 2;
      const q = [pr.g(stx, sty), pr.g(stx + sw, sty), pr.g(stx + sw, sty + 2), pr.g(stx, sty + 2)].map((p) => [Math.round(p[0] - mnx), Math.round(p[1] - mny - pr.lift(2 - i))]);
      s.polygon(q, mix(metal.m4, dust.d4, 0.35 + i * 0.15));
      s.line(q[0][0], q[0][1], q[1][0], q[1][1], mix(metal.m6, dust.d6, 0.3 + i * 0.2));
    }
    for (const sgn of [-1, 1]) {
      const rx = B.hall.x + B.doorU + B.doorW / 2 + sgn * (B.doorW / 2 + 7);
      const a = lp2.g(rx, B.hall.y + B.hall.d + 6);
      s.vline(Math.round(a[0]), Math.round(a[1]) - 8, 10, metal.m5);
      s.hline(Math.round(a[0]) - 2, Math.round(a[1]) - 8, 5, metal.m6);
    }
  });
  openMass(B.hall, hallAnchor, hallDepth + BIAS.shellNW, 'hall-open', innerDetail);

  // ------------------------------------------------------------ wing
  const wingAnchor = { x: B.wing.x + B.wing.w - 3, y: B.wing.y + B.wing.d - 3 };
  const wingDepth = pr.depth(wingAnchor.x, wingAnchor.y);
  closedMass(B.wing, CREAM, wingAnchor, wingDepth, 'wing', (s, f) => {
    faceRect(s, f.front, 6, 5, 8, f.front.vh - 6, metal.m3);
    faceLine(s, f.front, 10, 6, 10, f.front.vh - 2, metal.m6);
    windowOnFace(s, f.front, 18, 6, 10, 6, true);
    windowOnFace(s, f.front, 30, 6, 8, 6, true);
    faceLine(s, f.front, 0, f.front.vh - 3, f.front.uw, f.front.vh - 3, mix(hazard.h2, metal.m3, 0.5));
    faceRect(s, f.top, 6, 6, 14, 10, teal.t1);
    faceLine(s, f.top, 7, 8, 18, 8, teal.t3);
    faceLine(s, f.top, 7, 11, 18, 11, teal.t3);
    faceLine(s, f.top, 7, 14, 18, 14, teal.t3);
    faceRect(s, f.top, 26, 8, 10, 8, metal.m4);
    faceLine(s, f.top, 27, 9, 34, 9, metal.m6);
    void s;
  });
  openMass(B.wing, wingAnchor, wingDepth + BIAS.shellNW, 'wing-open', innerDetail);

  // ------------------------------------------------------------ tech
  const techAnchor = { x: B.tech.x + B.tech.w - 3, y: B.tech.y + B.tech.d - 3 };
  const techDepth = pr.depth(techAnchor.x, techAnchor.y);
  closedMass(B.tech, TECH_MAT, techAnchor, techDepth, 'tech', (s, f) => {
    for (let j = 6; j < 16; j += 3) faceLine(s, f.front, 6, j, 20, j, metal.m3);
    faceRect(s, f.front, 26, 6, 8, 10, metal.m2);
    facePx(s, f.front, 28, 8, cyan.c4);
    facePx(s, f.front, 30, 10, amber.a4);
    faceRect(s, f.top, 8, 8, 12, 10, metal.m4);
    faceLine(s, f.top, 9, 10, 18, 10, metal.m6);
    faceLine(s, f.top, 24, 6, 24, f.top.vh - 6, metal.m5);
    faceLine(s, f.top, 25, 6, 25, f.top.vh - 6, metal.m3);
    void s;
  });
  openMass(B.tech, techAnchor, techDepth + BIAS.shellNW, 'tech-open', innerDetail);

  // ------------------------------------------------------------ garage
  const garAnchor = { x: B.garage.x + B.garage.w - 3, y: B.garage.y + B.garage.d - 3 };
  const garDepth = pr.depth(garAnchor.x, garAnchor.y);
  closedMass(B.garage, GARAGE_MAT, garAnchor, garDepth, 'garage', (s, f) => {
    faceRect(s, f.front, 8, 4, 24, f.front.vh - 5, metal.m3);
    for (let j = 5; j < f.front.vh - 3; j += 2) faceLine(s, f.front, 8, j, 32, j, metal.m4);
    faceLine(s, f.front, 8, f.front.vh - 4, 32, f.front.vh - 4, hazard.h2);
    faceRect(s, f.front, 35, 6, 6, f.front.vh - 7, metal.m2);
    faceLine(s, f.front, 38, 7, 38, f.front.vh - 3, metal.m5);
    faceRect(s, f.top, 10, 10, 10, 8, metal.m3);
    faceLine(s, f.top, 11, 11, 18, 11, metal.m5);
    faceLine(s, f.top, 30, 6, 30, f.top.vh - 6, metal.m4);
    void s;
  });
  openMass(B.garage, garAnchor, garDepth + BIAS.shellNW, 'garage-open', innerDetail);

  // ------------------------------------------------------------ tower / shaft
  const towerAnchor = { x: B.tower.x + B.tower.w / 2, y: B.tower.y + B.tower.d };
  const tower = bakeMass(
    pr,
    { x: B.tower.x, y: B.tower.y, w: B.tower.w, d: B.tower.d, h: 26 },
    TOWER_MAT,
    towerAnchor,
    B.hall.h,
    (s, f) => {
      for (let u = 3; u < f.front.uw - 2; u += 4) faceLine(s, f.front, u, 2, u, f.front.vh - 2, mix(rust.x4, rust.x3, 0.5));
      faceRect(s, f.front, 5, 7, 16, 6, rust.x2);
      const fx = Math.round(f.front.origin[0] + f.front.u[0] * 6 + f.front.v[0] * 8);
      const fy = Math.round(f.front.origin[1] + f.front.u[1] * 6 + f.front.v[1] * 8);
      drawText(s, fx, fy, 'K-7', mix(rust.x7, metal.m8, 0.35), { worn: 0.15 });
      facePx(s, f.front, 26, 14, cyan.c4);
      faceRect(s, f.front, 8, 18, 10, 4, rust.x1);
      faceLine(s, f.front, 9, 19, 16, 19, teal.t3);
      const ax = Math.round(f.top.origin[0] + f.top.u[0] * 6 + f.top.v[0] * 6);
      const ay = Math.round(f.top.origin[1] + f.top.u[1] * 6 + f.top.v[1] * 6);
      s.vline(ax, ay - 18, 18, metal.m4);
      s.vline(ax + 1, ay - 18, 18, metal.m2);
      s.hline(ax - 4, ay - 13, 9, metal.m3);
      s.hline(ax - 3, ay - 8, 7, metal.m3);
      s.set(ax, ay - 19, mix(rust.x5, amber.a3, 0.2));
      void s;
    },
  );
  push(tower, towerAnchor.x, towerAnchor.y, pr.depth(towerAnchor.x, towerAnchor.y, B.hall.h, 60), 'ext', 'tower');
  const shaft = bakeMass(
    pr,
    { x: B.tower.x, y: B.tower.y, w: B.tower.w, d: B.tower.d, h: 20 },
    { top: [rust.x3, rust.x2], front: [rust.x4, rust.x3, rust.x1], east: [rust.x2, rust.x1], rim: rust.x5, edge: rust.x0 },
    towerAnchor,
    0,
    (s, f) => {
      faceLine(s, f.front, 0, 3, f.front.uw, 3, mix(hazard.h2, rust.x2, 0.4));
      faceRect(s, f.front, 10, 8, 12, 8, rust.x1);
      faceLine(s, f.front, 11, 9, 20, 9, rust.x4);
      facePx(s, f.front, 26, 6, amber.a4);
      void s;
    },
  );
  push(shaft, towerAnchor.x, towerAnchor.y, pr.depth(B.tower.x + B.tower.w - 4, B.tower.y + B.tower.d - 4, 0, BIAS.shaft), 'int', 'shaft');

  // ------------------------------------------------------------ partitions (real boxes with door gaps)
  const partH = tilted ? 16 : 22;
  const partition = (x: number, y: number, w: number, d: number, gapA: number, gapB: number, horizontal: boolean, name: string) => {
    const bb = massBounds(pr, x, y, w, d, partH);
    const surf = new PixelSurface(bb.w, bb.h);
    const lp = new LocalProj(pr, -bb.minX, -bb.minY);
    const mat: Mat = { top: [metal.m5, metal.m4], front: [metal.m4, metal.m3, metal.m2], east: [metal.m3, metal.m2], rim: metal.m6, edge: metal.m1 };
    if (horizontal) {
      paintBox(surf, lp, x, y, gapA - x, d, partH, mat);
      paintBox(surf, lp, gapB, y, x + w - gapB, d, partH, mat);
      paintBox(surf, lp, gapA, y, gapB - gapA, d, 6, mat);
    } else {
      paintBox(surf, lp, x, y, w, gapA - y, partH, mat);
      paintBox(surf, lp, x, gapB, w, y + d - gapB, partH, mat);
      paintBox(surf, lp, x, gapA, w, gapB - gapA, 6, mat);
    }
    const anchor = { x: x + w / 2, y: y + d };
    const [gx, gy] = pr.g(anchor.x, anchor.y);
    push({ sprite: surf, ax: Math.round(gx - bb.minX), ay: Math.round(gy - bb.minY) }, anchor.x, anchor.y, pr.depth(x + w / 2, y + d, 0, BIAS.partition), 'int', name);
  };
  partition(150, R2.hall.y, 3, R2.hall.h, 124, 134, false, 'part-wing-hall');
  partition(234, R2.hall.y, 3, R2.tech.y + R2.tech.h - R2.hall.y, 118, 128, false, 'part-hall-tech');
  partition(R2.tech.x, 154, R2.tech.w, 3, 252, 262, true, 'part-tech-garage');

  // ------------------------------------------------------------ interior furniture
  const SLATE_MAT: Mat = { top: [slate.s5, slate.s4], front: [slate.s5, slate.s4, slate.s3], east: [slate.s4, slate.s3], rim: slate.s6, edge: slate.s1 };
  const furn = (r: { x: number; y: number; w: number; d: number; h: number }, m: Mat, name: string, detail?: (s: PixelSurface, f: Faces) => void) => {
    const bk = bakeMass(pr, r, m, { x: r.x + r.w / 2, y: r.y + r.d }, 0, detail);
    push(bk, r.x + r.w / 2, r.y + r.d, pr.depth(r.x + r.w / 2, r.y + r.d), 'int', name);
  };
  const wr = R2.wing;
  furn({ x: wr.x + 2, y: wr.y + 6, w: 6, d: 12, h: 6 }, SLATE_MAT, 'bunk1', (s, f) => {
    faceRect(s, f.top, 1, 2, 4, 3, mix(rust.x3, slate.s4, 0.5));
    faceRect(s, f.top, 1, 7, 4, 2, mix(metal.m7, slate.s5, 0.4));
    void s;
  });
  furn({ x: wr.x + 2, y: wr.y + 22, w: 6, d: 12, h: 6 }, SLATE_MAT, 'bunk2', (s, f) => {
    faceRect(s, f.top, 1, 2, 4, 3, mix(metal.m3, slate.s4, 0.5));
    faceRect(s, f.top, 1, 8, 4, 2, mix(metal.m7, slate.s5, 0.4));
    void s;
  });
  furn({ x: wr.x + 6, y: wr.y + 2, w: 20, d: 5, h: 10 }, SLATE_MAT, 'lockers', (s, f) => {
    for (let u = 2; u < f.front.uw - 2; u += 5) {
      faceLine(s, f.front, u, 1, u, f.front.vh - 1, slate.s2);
      facePx(s, f.front, u + 2, 4, metal.m6);
    }
    void s;
  });
  furn({ x: wr.x + 14, y: wr.y + 16, w: 10, d: 7, h: 5 }, { top: [warm.w5, warm.w4], front: [warm.w4, warm.w3, warm.w2], east: [warm.w1, warm.w0], rim: warm.w6, edge: warm.w0 }, 'messtable', (s, f) => {
    facePx(s, f.top, 3, 3, metal.m6);
    facePx(s, f.top, 6, 4, mix(rust.x3, warm.w3, 0.4));
    void s;
  });
  const hr = R2.hall;
  furn({ x: hr.x + 6, y: hr.y + 2, w: 18, d: 6, h: 9 }, SLATE_MAT, 'console1', (s, f) => {
    faceRect(s, f.front, 2, 1, 14, 5, cyan.c0);
    faceLine(s, f.front, 3, 2, 12, 2, cyan.c3);
    faceLine(s, f.front, 3, 4, 9, 4, cyan.c2);
    facePx(s, f.front, 14, 4, amber.a4);
    void s;
  });
  furn({ x: hr.x + 34, y: hr.y + 2, w: 18, d: 6, h: 9 }, SLATE_MAT, 'console2', (s, f) => {
    faceRect(s, f.front, 2, 1, 14, 5, cyan.c0);
    faceLine(s, f.front, 3, 3, 14, 3, cyan.c2);
    facePx(s, f.front, 5, 2, cyan.c5);
    void s;
  });
  furn({ x: hr.x + 24, y: hr.y + 44, w: 16, d: 9, h: 7 }, SLATE_MAT, 'holotable', (s, f) => {
    faceRect(s, f.top, 3, 2, 10, 6, cyan.c0);
    facePx(s, f.top, 7, 4, cyan.c5);
    facePx(s, f.top, 9, 5, cyan.c3);
    void s;
  });
  furn({ x: hr.x + 2, y: hr.y + hr.h - 10, w: 5, d: 9, h: 8 }, SLATE_MAT, 'armory', (s, f) => {
    for (let v = 2; v < f.east.uw - 1; v += 3) {
      faceLine(s, f.east, v, 1, v, 6, metal.m2);
      facePx(s, f.east, v, 2, warm.w4);
    }
    void s;
  });
  furn({ x: hr.x + hr.w - 8, y: hr.y + 6, w: 6, d: 14, h: 10 }, SLATE_MAT, 'rackNE', (s, f) => {
    for (let v = 2; v < f.east.uw - 2; v += 4) {
      faceLine(s, f.east, v, 2, v, f.east.vh - 2, slate.s2);
      facePx(s, f.east, v + 1, 3, mix(metal.m4, slate.s5, 0.4));
      facePx(s, f.east, v + 1, 6, mix(rust.x4, slate.s5, 0.4));
    }
    void s;
  });
  furn({ x: hr.x + hr.w - 10, y: hr.y + hr.h - 12, w: 8, d: 8, h: 7 }, RUSTY, 'crateE', (s, f) => {
    facePx(s, f.front, 2, 3, metal.m7);
    void s;
  });
  const tr = R2.tech;
  furn({ x: tr.x + 4, y: tr.y + 4, w: 8, d: 8, h: 12 }, { top: [metal.m6, metal.m5], front: [metal.m5, metal.m4, metal.m2], east: [metal.m3, metal.m2], rim: metal.m7, edge: metal.m1 }, 'tank1', (s, f) => {
    faceLine(s, f.front, 1, 4, f.front.uw - 1, 4, metal.m6);
    facePx(s, f.front, 5, 2, amber.a4);
    void s;
  });
  furn({ x: tr.x + 16, y: tr.y + 4, w: 8, d: 8, h: 12 }, { top: [metal.m6, metal.m5], front: [metal.m5, metal.m4, metal.m2], east: [metal.m3, metal.m2], rim: metal.m7, edge: metal.m1 }, 'tank2', (s, f) => {
    faceLine(s, f.front, 1, 6, f.front.uw - 1, 6, metal.m6);
    facePx(s, f.front, 3, 3, cyan.c4);
    void s;
  });
  furn({ x: tr.x + 2, y: tr.y + 16, w: 12, d: 5, h: 8 }, SLATE_MAT, 'manifold', (s, f) => {
    for (let u = 2; u < f.front.uw - 1; u += 3) facePx(s, f.front, u, 2, metal.m7);
    faceLine(s, f.front, 1, 5, f.front.uw - 1, 5, warm.w3);
    void s;
  });
  furn({ x: tr.x + tr.w - 6, y: tr.y + 14, w: 4, d: 12, h: 9 }, SLATE_MAT, 'panelE', (s, f) => {
    faceRect(s, f.east, 1, 2, 2, 6, cyan.c0);
    facePx(s, f.east, 2, 3, cyan.c4);
    facePx(s, f.east, 2, 5, amber.a4);
    void s;
  });
  const gr2 = R2.garage;
  furn({ x: gr2.x + 2, y: gr2.y + 8, w: 5, d: 14, h: 8 }, { top: [warm.w5, warm.w4], front: [warm.w4, warm.w3, warm.w2], east: [warm.w1, warm.w0], rim: warm.w6, edge: warm.w0 }, 'baybench', (s, f) => {
    facePx(s, f.east, 2, 2, metal.m6);
    facePx(s, f.east, 4, 4, warm.w6);
    facePx(s, f.east, 6, 3, cyan.c3);
    void s;
  });
  furn({ x: gr2.x + 6, y: gr2.y + 2, w: 14, d: 5, h: 10 }, SLATE_MAT, 'toolcab', (s, f) => {
    for (let j = 2; j < f.front.vh - 1; j += 3) faceLine(s, f.front, 2, j, f.front.uw - 2, j, slate.s2);
    facePx(s, f.front, 7, 3, metal.m7);
    void s;
  });
  furn({ x: gr2.x + gr2.w - 6, y: gr2.y + 4, w: 4, d: 12, h: 9 }, SLATE_MAT, 'bayshelf', (s, f) => {
    for (let v = 2; v < f.east.uw - 2; v += 4) {
      faceLine(s, f.east, v, 3, v, f.east.vh - 2, slate.s2);
      facePx(s, f.east, v + 1, 4, mix(rust.x4, slate.s5, 0.4));
    }
    void s;
  });
  furn({ x: gr2.x + 10, y: gr2.y + gr2.h - 8, w: 8, d: 5, h: 4 }, DARK, 'sparetracks', (s, f) => {
    faceLine(s, f.front, 1, 1, f.front.uw - 1, 1, metal.m4);
    void s;
  });

  // ------------------------------------------------------------ props
  for (const c of L2.containers) push(bakeContainer2(pr, c.x), c.x, c.y, pr.depth(c.x, c.y), 'both', 'container');
  for (const c of L2.crateStack) push(bakeCrate2(pr, c.x + c.y), c.x, c.y, pr.depth(c.x, c.y), 'both', 'crate');
  for (const r of L2.rocks) push(bakeRock2(pr, r.r, r.x), r.x, r.y, pr.depth(r.x, r.y), 'both', 'rock');
  for (const p of L2.plants) push(bakePlant2(pr, p.x), p.x, p.y, pr.depth(p.x, p.y), 'both', 'plant');
  for (const g of L2.generators) push(bakeGenerator2(pr), g.x, g.y, pr.depth(g.x, g.y), 'both', 'generator');
  push(bakeTransformer2(pr), L2.transformer.x, L2.transformer.y, pr.depth(L2.transformer.x, L2.transformer.y), 'both', 'transformer');
  for (const l of L2.lamps) push(bakeLamp2(pr), l.x, l.y, pr.depth(l.x, l.y) + 0.1, 'both', 'lamp');
  push(bakeBarrier2(pr), L2.barrier.x, L2.barrier.y, pr.depth(L2.barrier.x, L2.barrier.y), 'both', 'barrier');
  push(bakeBench2(pr), L2.bench.x, L2.bench.y, pr.depth(L2.bench.x, L2.bench.y), 'both', 'bench');
  push(bakeDish2(pr), L2.dish.x, L2.dish.y, pr.depth(L2.dish.x, L2.dish.y) + 0.1, 'both', 'dish');
  push(bakeTank2(pr), L2.tank.x, L2.tank.y, pr.depth(L2.tank.x, L2.tank.y), 'both', 'tank');
  push(bakeSpool2(pr), L2.spool.x, L2.spool.y, pr.depth(L2.spool.x, L2.spool.y), 'both', 'spool');
  push(bakeSandbags2(pr), L2.sandbags.x, L2.sandbags.y, pr.depth(L2.sandbags.x, L2.sandbags.y), 'both', 'sandbags');
  push(bakeSign2(pr), L2.sign.x, L2.sign.y, pr.depth(L2.sign.x, L2.sign.y) + 0.1, 'both', 'sign');
  push(bakeCart2(pr), L2.cart.x, L2.cart.y, pr.depth(L2.cart.x, L2.cart.y), 'both', 'cart');
  for (const d of L2.drums) push(bakeDrum2(pr, d.x), d.x, d.y, pr.depth(d.x, d.y), 'both', 'drum');
  push(bakeVehicle2(pr), L2.vehicle.x, L2.vehicle.y, pr.depth(L2.vehicle.x, L2.vehicle.y), 'both', 'vehicle');
  void rnd;

  // ------------------------------------------------------------ lights
  lights.push({ x: B.hall.x + B.doorU + B.doorW / 2, y: B.hall.y + B.hall.d + 3, r: 24, c: [1, 0.66, 0.34], i: 0.8, mode: 'ext' });
  lights.push({ x: B.hall.x + 16, y: B.hall.y + B.hall.d + 2, r: 11, c: [0.2, 0.8, 0.9], i: 0.35, mode: 'ext' });
  lights.push({ x: B.hall.x + 66, y: B.hall.y + B.hall.d + 2, r: 11, c: [0.2, 0.8, 0.9], i: 0.35, mode: 'ext' });
  lights.push({ x: B.wing.x + 10, y: B.wing.y + B.wing.d + 2, r: 9, c: [0.2, 0.8, 0.9], i: 0.3, mode: 'ext' });
  lights.push({ x: B.tower.x + 17, y: B.tower.y - 2, r: 9, c: [1, 0.22, 0.18], i: 0.5, blink: 2.2, mode: 'ext' });
  for (const l of L2.lamps) lights.push({ x: l.x, y: l.y - 24, r: 26, c: [1, 0.72, 0.4], i: 0.55, mode: 'both' });
  for (const g of L2.generators) lights.push({ x: g.x + 2, y: g.y - 8, r: 14, c: [1, 0.5, 0.2], i: 0.45, flicker: 0.25, mode: 'both' });
  lights.push({ x: L2.transformer.x, y: L2.transformer.y - 12, r: 10, c: [0.3, 0.8, 1], i: 0.3, blink: 4.7, mode: 'both' });
  lights.push({ x: L2.vehicle.x + 16, y: L2.vehicle.y - 2, r: 16, c: [1, 0.75, 0.45], i: 0.4, mode: 'both' });
  lights.push({ x: L2.dish.x, y: L2.dish.y - 16, r: 8, c: [0.2, 0.9, 1], i: 0.3, blink: 3.3, mode: 'both' });
  lights.push({ x: hr.x + 14, y: hr.y + 26, r: 32, c: [1, 0.84, 0.6], i: 1.0, mode: 'int' });
  lights.push({ x: hr.x + 44, y: hr.y + 44, r: 32, c: [1, 0.84, 0.6], i: 1.0, mode: 'int' });
  lights.push({ x: hr.x + 15, y: hr.y + 6, r: 14, c: [0.25, 0.85, 0.9], i: 0.45, mode: 'int' });
  lights.push({ x: hr.x + 43, y: hr.y + 6, r: 14, c: [0.25, 0.85, 0.9], i: 0.45, mode: 'int' });
  lights.push({ x: hr.x + 32, y: hr.y + 48, r: 16, c: [0.2, 0.9, 1], i: 0.5, mode: 'int' });
  lights.push({ x: wr.x + wr.w / 2, y: wr.y + wr.h / 2, r: 26, c: [1, 0.8, 0.55], i: 0.7, mode: 'int' });
  lights.push({ x: wr.x + 19, y: wr.y + 19, r: 10, c: [1, 0.7, 0.4], i: 0.4, mode: 'int' });
  lights.push({ x: tr.x + tr.w / 2, y: tr.y + tr.h / 2, r: 26, c: [1, 0.82, 0.58], i: 0.7, mode: 'int' });
  lights.push({ x: tr.x + tr.w - 4, y: tr.y + 20, r: 10, c: [0.25, 0.85, 0.9], i: 0.4, mode: 'int' });
  lights.push({ x: gr2.x + gr2.w / 2, y: gr2.y + gr2.h / 2, r: 28, c: [1, 0.82, 0.58], i: 0.75, mode: 'int' });
  lights.push({ x: gr2.x + 4, y: gr2.y + 14, r: 10, c: [1, 0.7, 0.4], i: 0.4, flicker: 0.1, mode: 'int' });

  // ------------------------------------------------------------ colliders
  const collidersExt = [
    { x: B.wing.x, y: B.wing.y, w: B.garage.x + B.garage.w - B.wing.x, h: B.tech.y + B.tech.d - B.wing.y },
    { x: B.garage.x, y: B.garage.y, w: B.garage.w, h: B.garage.d },
    { x: B.hall.x + B.doorU - 2, y: B.hall.y + B.hall.d, w: B.doorW + 4, h: 7 },
    { x: L2.vehicle.x - 17, y: L2.vehicle.y - 9, w: 34, h: 18 },
    { x: L2.containers[0].x - 13, y: L2.containers[0].y - 6, w: 26, h: 13 },
    { x: L2.containers[1].x - 13, y: L2.containers[1].y - 6, w: 26, h: 13 },
    { x: L2.crateStack[0].x - 6, y: L2.crateStack[0].y - 5, w: 24, h: 22 },
    { x: L2.generators[0].x - 10, y: L2.generators[0].y - 6, w: 34, h: 20 },
    { x: L2.transformer.x - 6, y: L2.transformer.y - 5, w: 12, h: 10 },
    { x: L2.barrier.x - 17, y: L2.barrier.y - 3, w: 34, h: 8 },
    { x: L2.tank.x - 9, y: L2.tank.y - 8, w: 18, h: 12 },
    { x: L2.cart.x - 14, y: L2.cart.y - 6, w: 28, h: 10 },
    { x: L2.rocks[0].x - 10, y: L2.rocks[0].y - 6, w: 20, h: 11 },
    { x: L2.rocks[1].x - 8, y: L2.rocks[1].y - 5, w: 16, h: 9 },
    { x: L2.rocks[4].x - 8, y: L2.rocks[4].y - 5, w: 16, h: 9 },
    { x: L2.rocks[5].x - 9, y: L2.rocks[5].y - 5, w: 18, h: 10 },
    { x: L2.sandbags.x - 12, y: L2.sandbags.y - 4, w: 24, h: 8 },
  ];
  const wallBands = (r: { x: number; y: number; w: number; h: number }) => [
    { x: r.x - 3, y: r.y - 3, w: r.w + 6, h: 3 },
    { x: r.x - 3, y: r.y, w: 3, h: r.h },
    { x: r.x + r.w, y: r.y, w: 3, h: r.h },
    { x: r.x, y: r.y + r.h, w: r.w, h: 3 },
  ];
  const collidersInt = [
    ...wallBands(R2.wing),
    ...wallBands(R2.hall),
    ...wallBands(R2.tech),
    ...wallBands(R2.garage),
    { x: 150, y: R2.hall.y, w: 3, h: 124 - R2.hall.y },
    { x: 150, y: 134, w: 3, h: R2.hall.y + R2.hall.h - 134 },
    { x: 234, y: R2.hall.y, w: 3, h: 118 - R2.hall.y },
    { x: 234, y: 128, w: 3, h: R2.tech.y + R2.tech.h - 128 },
    { x: R2.tech.x, y: 154, w: 252 - R2.tech.x, h: 3 },
    { x: 262, y: 154, w: R2.tech.x + R2.tech.w - 262, h: 3 },
    { x: wr.x + 2, y: wr.y + 6, w: 6, h: 28 },
    { x: wr.x + 8, y: wr.y + 2, w: 18, h: 5 },
    { x: wr.x + 14, y: wr.y + 16, w: 10, h: 7 },
    { x: hr.x + 6, y: hr.y + 2, w: 18, h: 6 },
    { x: hr.x + 34, y: hr.y + 2, w: 18, h: 6 },
    { x: hr.x + 24, y: hr.y + 44, w: 16, h: 9 },
    { x: hr.x + 2, y: hr.y + hr.h - 10, w: 5, h: 9 },
    { x: hr.x + hr.w - 8, y: hr.y + 6, w: 6, h: 14 },
    { x: hr.x + hr.w - 10, y: hr.y + hr.h - 12, w: 8, h: 8 },
    { x: B.tower.x, y: B.tower.y, w: B.tower.w, h: B.tower.d },
    { x: tr.x + 4, y: tr.y + 4, w: 20, h: 8 },
    { x: tr.x + 2, y: tr.y + 16, w: 12, h: 5 },
    { x: tr.x + tr.w - 6, y: tr.y + 14, w: 4, h: 12 },
    { x: gr2.x + 2, y: gr2.y + 8, w: 5, h: 14 },
    { x: gr2.x + 6, y: gr2.y + 2, w: 14, h: 5 },
    { x: gr2.x + gr2.w - 6, y: gr2.y + 4, w: 4, h: 12 },
    { x: gr2.x + 10, y: gr2.y + gr2.h - 8, w: 8, h: 5 },
  ];

  return {
    width: W,
    height: H,
    ox,
    oy,
    ground,
    shadow,
    shadowCut,
    renderables,
    lights,
    collidersExt,
    collidersInt,
    boundsExt: { x: 40, y: 70, w: 480, h: 310 },
    boundsInt: { x: R2.wing.x - 2, y: R2.wing.y - 2, w: R2.garage.x + R2.garage.w - R2.wing.x + 4, h: R2.garage.y + R2.garage.h - R2.wing.y + 4 },
    entrance: { ext: { x: B.hall.x + B.doorU + B.doorW / 2, y: B.hall.y + B.hall.d + 8 }, int: { x: B.hall.x + B.doorU + B.doorW / 2, y: B.hall.y + B.hall.d - 6 } },
    interiorRect: R2.hall,
    focus: { x: B.hall.x + B.hall.w / 2, y: B.hall.y + B.hall.d / 2 + 30 },
    worldW: 560,
    worldH: 420,
  };
}

export { withAlpha, bayer4, packRGBA };
