import { PixelSurface } from '../rendering/PixelSurface';
import { LightingSystem } from '../lighting/LightingSystem';
import { rigPlacements, FULL_KIT, type Equipment, type RigPose2 } from '../entities/CompositeRig';
import { VIEW_H, VIEW_W } from '../data/config';
import { bayer4, bayer8 } from '../rendering/dither';
import { fbm, makeRng, valueNoise } from '../rendering/noise';
import { mix, packRGBA, withAlpha } from '../rendering/color';
import { amber, cyan, dust, metal, olive, rock, rust, slate, warm } from '../data/palette';
import { drawText } from '../rendering/text';
import type { Input } from '../input/Input';

/**
 * CHARACTER SHOWCASE — a dedicated review scene for the composite rig.
 *
 * The mercenary is rendered at 3x gameplay scale from his independent part
 * sprites (head / torso / arms / legs / backpack / weapon + equipment layers),
 * standing on Pale Meridian terrain with contact shadow and the game's
 * lighting language. States: idle / walk / aim / turn (auto-cycle or keys
 * 1-4), equipment toggles Q W E R T, F4 anchor/part debug, F1 clean mode.
 */

export type ShowState = 'idle' | 'walk' | 'aim' | 'turn';

const PART_CACHE = new Map<string[], PixelSurface>();
function partSurface(map: string[]): PixelSurface {
  let s = PART_CACHE.get(map);
  if (!s) {
    const w = Math.max(...map.map((r) => r.length));
    s = new PixelSurface(w, map.length);
    // colourise through the rig palette by re-using drawPart on a blank surface
    // (drawPart is internal to the rig module, so replicate the palette here)
    const P = RIG_PALETTE;
    for (let ry = 0; ry < map.length; ry++) {
      for (let rx = 0; rx < map[ry].length; rx++) {
        const c = P[map[ry][rx]];
        if (c === undefined) continue;
        s.set(rx, ry, c);
      }
    }
    PART_CACHE.set(map, s);
  }
  return s;
}

/** mirror of entities/CompositeRig palette (kept in sync by convention) */
const RIG_PALETTE: Record<string, number> = {
  s: slate.s3,
  S: slate.s5,
  t: slate.s7,
  d: slate.s2,
  k: warm.w1,
  K: warm.w3,
  a: metal.m8,
  A: metal.m6,
  b: metal.m4,
  B: metal.m2,
  w: olive.o3,
  W: olive.o1,
  p: olive.o2,
  P: olive.o4,
  v: cyan.c2,
  V: cyan.c5,
  c: cyan.c3,
  o: amber.a4,
  r: rust.x4,
  q: warm.w2,
  Q: warm.w5,
  x: warm.w0,
  y: cyan.c4,
  m: warm.w1,
  H: metal.m6,
  h: metal.m8,
  g: metal.m4,
  G: metal.m3,
};

function blitScaled(s: PixelSurface, src: PixelSurface, dx: number, dy: number, scale: number, flip: boolean): void {
  for (let y = 0; y < src.height; y++) {
    for (let x = 0; x < src.width; x++) {
      const c = src.data[y * src.width + (flip ? src.width - 1 - x : x)];
      if (((c >>> 24) & 0xff) === 0) continue;
      for (let sy = 0; sy < scale; sy++) {
        for (let sx = 0; sx < scale; sx++) {
          s.set(dx + x * scale + sx, dy + y * scale + sy, c);
        }
      }
    }
  }
}

export class ShowcaseScene {
  readonly lighting = new LightingSystem();
  private ground: PixelSurface;
  state: ShowState = 'idle';
  auto = true;
  eq: Equipment = { ...FULL_KIT };
  debug = false;
  showHud = true;
  t = 0;
  private walkX = 0;
  private walkDir = 1;
  private turnIdx = 0;
  private turnT = 0;
  private charX = VIEW_W / 2 - 20;
  private charY = 208;

  constructor() {
    this.lighting.resize(VIEW_W, VIEW_H);
    this.ground = this.bakeGround();
  }

  private bakeGround(): PixelSurface {
    const s = new PixelSurface(VIEW_W, VIEW_H);
    const rnd = makeRng(31337);
    for (let y = 0; y < VIEW_H; y++) {
      for (let x = 0; x < VIEW_W; x++) {
        const form = fbm(x / 150, y / 90, 3, 11);
        const grain = fbm(x / 12, y / 9, 3, 41);
        let v = grain * 0.6 + form * 0.3 + 0.16;
        v = Math.max(0, Math.min(0.999, v));
        const ramp = [dust.d3, dust.d4, dust.d5, dust.d6, dust.d7];
        const t = v * (ramp.length - 1);
        const i = Math.floor(t);
        let c = bayer4(x, y) < t - i ? ramp[Math.min(4, i + 1)] : ramp[i];
        const lit = (form - 0.5) * 0.4;
        c = mix(c, lit > 0 ? dust.d8 : dust.d2, Math.min(0.2, Math.abs(lit)));
        const streak = valueNoise(x / 46, y / 5, 61);
        if (streak > 0.8 && bayer4(x, y) < 0.5) c = mix(c, dust.d7, 0.25);
        s.setRaw(x, y, packRGBA(c & 0xff, (c >>> 8) & 0xff, (c >>> 16) & 0xff));
      }
    }
    // pebbles + debris
    for (let i = 0; i < 900; i++) {
      const x = rnd.int(0, VIEW_W - 1);
      const y = rnd.int(120, VIEW_H - 1);
      if (valueNoise(x / 30, y / 30, 3) < 0.5) continue;
      s.set(x, y, rnd.chance(0.5) ? dust.d7 : dust.d2);
    }
    // cracks
    for (let i = 0; i < 5; i++) {
      let x = rnd.int(20, VIEW_W - 20);
      let y = rnd.int(150, VIEW_H - 10);
      let ang = rnd() * Math.PI * 2;
      for (let k = 0; k < 40; k++) {
        ang += (rnd() - 0.5) * 0.5;
        x += Math.cos(ang) * 1.6;
        y += Math.sin(ang) * 1.1;
        s.set(Math.round(x), Math.round(y), mix(dust.d1, dust.d2, 0.4));
        if (rnd() < 0.2) s.set(Math.round(x), Math.round(y) + 1, dust.d6);
      }
    }
    // rocks
    for (const [rx, ry, rr] of [
      [70, 190, 12],
      [410, 210, 10],
      [330, 160, 7],
    ]) {
      for (let y = -rr; y <= rr * 0.7; y++) {
        for (let x = -rr; x <= rr; x++) {
          const d = Math.sqrt((x * x) / (rr * rr) + (y * y) / ((rr * 0.7) * (rr * 0.7)));
          const wob = 0.8 + valueNoise((rx + x) / 4, (ry + y) / 4, 7) * 0.4;
          if (d / wob > 1) continue;
          const nl = (-x / rr) * 0.5 + (-y / rr) * 0.8;
          let v = 0.35 + nl * 0.33 + (valueNoise((rx + x) / 3, (ry + y) / 3, 8) - 0.5) * 0.4;
          v = Math.max(0, Math.min(0.999, v));
          const ramp = [rock.r1, rock.r2, rock.r3, rock.r4, rock.r5];
          const t = v * 4;
          s.set(rx + x, ry + y, bayer4(x, y) < t - Math.floor(t) ? ramp[Math.min(4, Math.floor(t) + 1)] : ramp[Math.floor(t)]);
        }
      }
      s.contactShadow(rx + rr * 0.6, ry + rr * 0.5, rr, rr * 0.4, packRGBA(40, 24, 20, 110), 0.8);
    }
    // distant structure silhouette + lamp post
    s.rect(20, 96, 90, 26, mix(slate.s3, dust.d6, 0.65));
    s.hline(20, 96, 90, mix(slate.s5, dust.d7, 0.55));
    s.rect(34, 84, 26, 12, mix(slate.s4, dust.d7, 0.65));
    s.hline(34, 84, 26, mix(slate.s6, dust.d8, 0.55));
    s.rect(60, 104, 10, 8, mix(rust.x4, dust.d6, 0.6));
    for (let i = 0; i < 40; i++) if (bayer8(i, 3) < 0.4) s.set(20 + i, 122, dust.d4);
    s.vline(430, 90, 60, metal.m3);
    s.vline(431, 90, 60, metal.m5);
    s.rect(425, 84, 12, 6, metal.m4);
    s.hline(425, 84, 12, metal.m6);
    s.rect(427, 89, 8, 2, amber.a4);
    // cable on ground
    let cx = 120;
    let cy = 236;
    for (let i = 0; i < 60; i++) {
      cx += 1;
      cy += Math.sin(i / 6) * 0.6;
      s.set(Math.round(cx), Math.round(cy), slate.s2);
      s.set(Math.round(cx), Math.round(cy) - 1, slate.s4);
    }
    return s;
  }

  update(dt: number, input: Input): void {
    this.t += dt;
    if (input.consume('Digit1')) {
      this.state = 'idle';
      this.auto = false;
    }
    if (input.consume('Digit2')) {
      this.state = 'walk';
      this.auto = false;
    }
    if (input.consume('Digit3')) {
      this.state = 'aim';
      this.auto = false;
    }
    if (input.consume('Digit4')) {
      this.state = 'turn';
      this.auto = false;
    }
    if (input.consume('Digit0')) this.auto = true;
    if (input.consume('KeyQ')) this.eq.helmet = !this.eq.helmet;
    if (input.consume('KeyW')) this.eq.shoulderArmor = !this.eq.shoulderArmor;
    if (input.consume('KeyE')) this.eq.torsoPlate = !this.eq.torsoPlate;
    if (input.consume('KeyR')) this.eq.backpack = !this.eq.backpack;
    if (input.consume('KeyT')) this.eq.weapon = !this.eq.weapon;
    if (input.consume('F4')) this.debug = !this.debug;
    if (input.consume('F1')) this.showHud = !this.showHud;

    if (this.auto) {
      const cycle: ShowState[] = ['idle', 'walk', 'aim', 'turn'];
      this.state = cycle[Math.floor(this.t / 2.2) % 4];
    }
    if (this.state === 'walk') {
      this.walkX += this.walkDir * 26 * dt;
      if (this.walkX > 46) this.walkDir = -1;
      if (this.walkX < -46) this.walkDir = 1;
    } else {
      this.walkX *= 0.9;
    }
    if (this.state === 'turn') {
      this.turnT += dt;
      if (this.turnT > 0.9) {
        this.turnT = 0;
        this.turnIdx = (this.turnIdx + 1) % 4;
      }
    }
    input.endFrame();
  }

  private pose(): RigPose2 {
    const orients: RigPose2['orient'][] = ['e', 's', 'w', 'n'];
    const orient = this.state === 'turn' ? orients[this.turnIdx] : this.state === 'walk' ? (this.walkDir > 0 ? 'e' : 'w') : 'e';
    const phase = this.state === 'walk' ? Math.floor(this.t * 8) % 4 : 0;
    return {
      state: this.state === 'turn' ? 'idle' : this.state,
      phase,
      orient,
      breath: Math.sin(this.t * 2.4) > 0.5 ? 1 : 0,
      look: this.state === 'idle' && Math.sin(this.t * 0.9) > 0.6 ? 1 : 0,
    };
  }

  render(): PixelSurface {
    const s = new PixelSurface(VIEW_W, VIEW_H);
    s.data.set(this.ground.data);
    const pose = this.pose();
    const SCALE = 3;
    const cx = Math.round(this.charX + this.walkX);
    const cy = this.charY;
    const lay = rigPlacements(pose, this.eq);

    // contact + cast shadow at showcase scale
    s.contactShadow(cx + 2, cy + 2, 10, 4, packRGBA(30, 17, 14, 130), 0.9);
    for (let i = 0; i < 26; i++) {
      const t = i / 26;
      if (bayer8(i, 2) < t * 0.7) continue;
      s.set(cx + 4 + Math.round(t * 22), cy + 2 + Math.round(t * 10), packRGBA(35, 20, 17, 90));
      s.set(cx + 5 + Math.round(t * 22), cy + 3 + Math.round(t * 10), packRGBA(35, 20, 17, 70));
    }

    // parts, back-to-front by placement order
    for (const pl of lay.list) {
      const surf = partSurface(pl.map);
      blitScaled(s, surf, cx + pl.x * SCALE - (pl.flip ? 0 : 0), cy + pl.y * SCALE, SCALE, pl.flip);
    }

    // lighting
    this.lighting.timeOfDay = 'dusk';
    this.lighting.enabled = true;
    this.lighting.begin();
    this.lighting.addLight({ x: cx - 40, y: cy - 50, radius: 130, r: 1, g: 0.74, b: 0.44, intensity: 0.95 }, this.t, [], 0, 0);
    this.lighting.addLight({ x: cx + 90, y: cy - 40, radius: 90, r: 0.3, g: 0.8, b: 0.95, intensity: 0.4 }, this.t, [], 0, 0);
    this.lighting.addLight({ x: 431, y: 92, radius: 60, r: 1, g: 0.7, b: 0.4, intensity: 0.6 }, this.t, [], 0, 0);
    this.lighting.addLight({ x: cx + 10, y: cy - 60, radius: 24, r: 0.3, g: 0.9, b: 1, intensity: 0.25 }, this.t, [], 0, 0);
    this.lighting.apply(s);

    // vignette
    for (let y = 0; y < VIEW_H; y++) {
      for (let x = 0; x < VIEW_W; x++) {
        const dx = (x - VIEW_W / 2) / (VIEW_W / 2);
        const dy = (y - VIEW_H / 2) / (VIEW_H / 2);
        const d = Math.sqrt(dx * dx * 0.8 + dy * dy * 1.15);
        if (d < 0.78) continue;
        const t = Math.min(1, (d - 0.78) / 0.45) * 0.4;
        if (bayer4(x, y) <= t) s.data[y * VIEW_W + x] = mix(s.data[y * VIEW_W + x], packRGBA(12, 10, 9), 0.6);
      }
    }

    if (this.debug) {
      // part bounds + anchors
      const cols = [cyan.c4, amber.a4, rust.x5, metal.m8, olive.o5, slate.s7];
      lay.list.forEach((pl, i) => {
        const surf = partSurface(pl.map);
        const x0 = cx + pl.x * SCALE;
        const y0 = cy + pl.y * SCALE;
        const c = cols[i % cols.length];
        for (let x = 0; x < surf.width * SCALE; x++) {
          s.set(x0 + x, y0, withAlpha(c, 160));
          s.set(x0 + x, y0 + surf.height * SCALE - 1, withAlpha(c, 160));
        }
        for (let y = 0; y < surf.height * SCALE; y++) {
          s.set(x0, y0 + y, withAlpha(c, 160));
          s.set(x0 + surf.width * SCALE - 1, y0 + y, withAlpha(c, 160));
        }
      });
      for (const [name, a] of Object.entries(lay.anchors)) {
        const ax = cx + a[0] * SCALE;
        const ay = cy + a[1] * SCALE;
        s.set(ax, ay, cyan.c6);
        s.set(ax + 1, ay, cyan.c4);
        s.set(ax, ay + 1, cyan.c4);
        drawText(s, ax + 3, ay - 2, name.toUpperCase(), cyan.c4, {});
      }
    }

    if (this.showHud) {
      s.rect(6, 6, 208, 74, withAlpha(packRGBA(8, 9, 11), 200));
      s.strokeRect(6, 6, 208, 74, withAlpha(metal.m5, 200));
      drawText(s, 12, 12, 'CHARACTER SHOWCASE', metal.m9, {});
      drawText(s, 12, 22, `STATE ${this.state.toUpperCase()}${this.auto ? ' (AUTO)' : ''}`, amber.a4, {});
      const eqLines = [
        ['Q HELMET', this.eq.helmet],
        ['W SHOULDER', this.eq.shoulderArmor],
        ['E TORSO PLATE', this.eq.torsoPlate],
        ['R BACKPACK', this.eq.backpack],
        ['T WEAPON', this.eq.weapon],
      ] as const;
      eqLines.forEach(([label, on], i) => {
        drawText(s, 12 + (i % 2) * 100, 32 + Math.floor(i / 2) * 9, `${label} ${on ? 'ON' : 'OFF'}`, on ? cyan.c4 : slate.s6, {});
      });
      drawText(s, 12, 60, '1-4 STATE · 0 AUTO · F4 DEBUG · F1 CLEAN', slate.s6, {});
      drawText(s, 12, 69, 'PARTS: HEAD TORSO ARMS LEGS PACK WEAPON', slate.s6, {});
    }
    return s;
  }
}
