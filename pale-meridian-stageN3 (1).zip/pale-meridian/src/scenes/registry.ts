import { OutpostPlay } from './OutpostPlay';

/**
 * Scene registry: the three playable benchmarks.
 * Scene 1 lives in game/Game (stage-1 outpost, unchanged); scenes 2 and 3 are
 * the same world baked through two projection profiles.
 */
export type SceneKey = 'scene1' | 'scene2' | 'scene3';

const cache: Partial<Record<'scene2' | 'scene3', OutpostPlay>> = {};

export function getOutpost(key: 'scene2' | 'scene3'): OutpostPlay {
  if (!cache[key]) cache[key] = new OutpostPlay(key);
  return cache[key]!;
}

export const SCENE_ORDER: SceneKey[] = ['scene1', 'scene2', 'scene3'];
export const SCENE_TITLES: Record<SceneKey, string> = {
  scene1: 'SCENE 1 · FRONTIER OUTPOST (stage 1, approved)',
  scene2: 'SCENE 2 · ISOMETRIC / AXONOMETRIC',
  scene3: 'SCENE 3 · TILTED ORTHOGRAPHIC TOP-DOWN',
};
