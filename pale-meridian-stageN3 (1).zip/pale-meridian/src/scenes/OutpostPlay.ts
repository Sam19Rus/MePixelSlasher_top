import { PixelSurface } from '../rendering/PixelSurface';
import { LightingSystem, TIME_OF_DAY, type TimeOfDay } from '../lighting/LightingSystem';
import { Proj, SCENE_PROFILES, type ProjectionProfile } from '../lab/profiles';
import { type SceneBake } from './outpostKit';
import { bakeOutpost2 } from './outpostKit2';
import { rigShadow, type Orient } from '../lab/rig';
import { drawComposite, FULL_KIT, type RigPose2 } from '../entities/CompositeRig';
import { drawRobotRig, robotShadow } from '../lab/robotRig';
import { Input } from '../input/Input';
import { VIEW_H, VIEW_W } from '../data/config';
import { bayer4 } from '../rendering/dither';
import { mix, packRGBA, withAlpha } from '../rendering/color';
import { amber, cyan, dust, metal } from '../data/palette';
import { drawText } from '../rendering/text';

/**
 * A playable outpost scene in one of the two shipping projections.
 *
 * Scene 2 = SCENE2_AXON (isometric / axonometric)
 * Scene 3 = SCENE3_TILTED (tilted orthographic top-down)
 *
 * Same world, same scenography; only the ProjectionProfile differs. Exterior
 * and interior are one physical space: entering hides roof + SE shell
 * (cutaway) while terrain, props, lights and world coordinates persist.
 */

export interface SceneHost {
  name: string;
  projection: ProjectionProfile;
  update(dt: number, input: Input): void;
  render(): PixelSurface;
  lighting: LightingSystem;
  review: { lighting: boolean; timeOfDay: TimeOfDay; debug: boolean };
  zone: 'ext' | 'int';
}

const WAYPOINTS = [
  { x: 268, y: 214 },
  { x: 302, y: 204 },
  { x: 314, y: 234 },
  { x: 272, y: 246 },
];

export class OutpostPlay implements SceneHost {
  readonly lighting = new LightingSystem();
  readonly review = { lighting: true, timeOfDay: 'dusk' as TimeOfDay, debug: false };
  readonly name: string;
  readonly projection: ProjectionProfile;
  private pr: Proj;
  private bake: SceneBake;
  private surface = new PixelSurface(VIEW_W, VIEW_H);
  private atmo: PixelSurface | null = null;

  zone: 'ext' | 'int' = 'ext';
  reviewShow = true;
  time = 0;
  private px: number;
  private py: number;
  private vx = 0;
  private vy = 0;
  private orient: Orient = 'e';
  private orientT = 0;
  private animT = 0;
  private moving = false;
  private aiming = false;
  private camX = 0;
  private camY = 0;
  private drone = { x: WAYPOINTS[0].x, y: WAYPOINTS[0].y, wp: 0, flip: false, alert: false, t: 0 };
  private fade = 0;
  private pendingZone: 'ext' | 'int' | null = null;
  prompt = false;

  constructor(sceneKey: 'scene2' | 'scene3') {
    this.projection = SCENE_PROFILES[sceneKey];
    this.name = sceneKey === 'scene2' ? 'SCENE 2 · ISOMETRIC / AXONOMETRIC' : 'SCENE 3 · TILTED ORTHOGRAPHIC';
    this.pr = new Proj(this.projection);
    this.bake = bakeOutpost2(this.pr);
    this.lighting.resize(VIEW_W, VIEW_H);
    this.px = this.bake.entrance.ext.x - 4;
    this.py = this.bake.entrance.ext.y + 26;
    this.snapCam();
  }

  private snapCam(): void {
    const [gx, gy] = this.pr.g(this.px, this.py);
    const fx = gx + this.bake.ox;
    const fy = gy + this.bake.oy;
    this.camX = this.clampCam(fx - VIEW_W / 2, this.bake.width - VIEW_W);
    this.camY = this.clampCam(fy - 10 - VIEW_H / 2, this.bake.height - VIEW_H);
  }
  private clampCam(v: number, max: number): number {
    if (max <= 0) return Math.round(max / 2);
    return Math.round(Math.max(0, Math.min(max, v)));
  }

  get nearEntrance(): boolean {
    const e = this.zone === 'ext' ? this.bake.entrance.ext : this.bake.entrance.int;
    return Math.hypot(this.px - e.x, this.py - e.y) < 12;
  }

  update(dt: number, input: Input): void {
    this.time += dt;
    this.orientT = Math.max(0, this.orientT - dt);
    if (this.pendingZone) {
      this.fade = Math.min(1, this.fade + dt * 5);
      if (this.fade >= 1) {
        this.zone = this.pendingZone;
        this.pendingZone = null;
        const e = this.zone === 'ext' ? this.bake.entrance.ext : this.bake.entrance.int;
        this.px = e.x;
        this.py = e.y + (this.zone === 'ext' ? 4 : -2);
        this.vx = this.vy = 0;
        this.snapCam();
      }
    } else if (this.fade > 0) this.fade = Math.max(0, this.fade - dt * 4);

    if (!this.pendingZone) {
      const axis = input.axis();
      this.aiming = input.isDown('Space');
      const speed = input.running ? 78 : 52;
      const tx = axis.x * speed;
      const ty = axis.y * speed;
      const dvx = tx - this.vx;
      const dvy = ty - this.vy;
      const dl = Math.hypot(dvx, dvy);
      const step = Math.min(dl, 620 * dt);
      if (dl > 0) {
        this.vx += (dvx / dl) * step;
        this.vy += (dvy / dl) * step;
      }
      this.moving = Math.hypot(this.vx, this.vy) > 6;
      const bounds = this.zone === 'ext' ? this.bake.boundsExt : this.bake.boundsInt;
      const colliders = this.zone === 'ext' ? this.bake.collidersExt : this.bake.collidersInt;
      const nx = this.px + this.vx * dt;
      if (!this.hits(nx, this.py, colliders, bounds)) this.px = nx;
      else this.vx = 0;
      const ny = this.py + this.vy * dt;
      if (!this.hits(this.px, ny, colliders, bounds)) this.py = ny;
      else this.vy = 0;
      if (this.moving && !this.aiming) {
        const want: Orient = Math.abs(this.vx) > Math.abs(this.vy) ? (this.vx > 0 ? 'e' : 'w') : this.vy > 0 ? 's' : 'n';
        if (want !== this.orient) {
          this.orient = want;
          this.orientT = 0.22;
        }
        this.animT += dt * (input.running ? 11 : 8);
      }
      // entrance interaction
      this.prompt = this.nearEntrance;
      if (this.prompt && input.consume('KeyE', 'Enter')) this.pendingZone = this.zone === 'ext' ? 'int' : 'ext';
      // drone patrol
      const d = this.drone;
      d.t += dt;
      const target = WAYPOINTS[d.wp];
      const ddx = target.x - d.x;
      const ddy = target.y - d.y;
      const dd = Math.hypot(ddx, ddy);
      d.alert = Math.hypot(this.px - d.x, this.py - d.y) < 46;
      if (!d.alert) {
        if (dd < 4) d.wp = (d.wp + 1) % WAYPOINTS.length;
        else {
          d.x += (ddx / dd) * 13 * dt;
          d.y += (ddy / dd) * 13 * dt;
          if (Math.abs(ddx) > 2) d.flip = ddx < 0;
        }
      } else d.flip = this.px < d.x;
    }

    // camera follow (bake-space coordinates)
    const [gx2, gy2] = this.pr.g(this.px, this.py);
    const dx = this.clampCam(gx2 + this.bake.ox - VIEW_W / 2, this.bake.width - VIEW_W) - this.camX;
    const dy = this.clampCam(gy2 + this.bake.oy - 10 - VIEW_H / 2, this.bake.height - VIEW_H) - this.camY;
    const k = 1 - Math.exp(-7.5 * dt);
    this.camX += dx * k;
    this.camY += dy * k;
    input.endFrame();
  }

  private hits(x: number, y: number, colliders: { x: number; y: number; w: number; h: number }[], bounds: { x: number; y: number; w: number; h: number }): boolean {
    const r = 4.5;
    if (x - r < bounds.x || x + r > bounds.x + bounds.w || y - r < bounds.y || y + r > bounds.y + bounds.h) return true;
    for (const c of colliders) {
      if (x + r > c.x && x - r < c.x + c.w && y + r > c.y && y - r < c.y + c.h) return true;
    }
    return false;
  }

  private pose(): RigPose2 {
    const state = this.orientT > 0 ? 'turn' : this.aiming ? 'aim' : this.moving ? 'walk' : 'idle';
    return {
      state,
      phase: this.moving ? Math.floor(this.animT) % 4 : 0,
      orient: this.orient,
      breath: Math.sin(this.time * 2.4) > 0.5 ? 1 : 0,
      look: state === 'idle' && Math.sin(this.time * 0.9) > 0.6 ? 1 : 0,
    };
  }

  render(): PixelSurface {
    const s = this.surface;
    const b = this.bake;
    const camX = Math.round(this.camX);
    const camY = Math.round(this.camY);

    // ground
    for (let y = 0; y < VIEW_H; y++) {
      const sy = camY + y;
      const row = y * VIEW_W;
      if (sy < 0 || sy >= b.height) {
        s.data.fill(0xff0d0b0a, row, row + VIEW_W);
        continue;
      }
      const srcRow = sy * b.width;
      if (camX >= 0 && camX + VIEW_W <= b.width) s.data.set(b.ground.data.subarray(srcRow + camX, srcRow + camX + VIEW_W), row);
      else {
        for (let x = 0; x < VIEW_W; x++) {
          const sx = camX + x;
          s.data[row + x] = sx >= 0 && sx < b.width ? b.ground.data[srcRow + sx] : 0xff0d0b0a;
        }
      }
    }
    // sun shadows (cutaway-aware)
    const shadow = this.zone === 'ext' ? b.shadow : b.shadowCut;
    for (let y = 0; y < VIEW_H; y++) {
      const sy = camY + y;
      if (sy < 0 || sy >= b.height) continue;
      const srcRow = sy * b.width;
      for (let x = 0; x < VIEW_W; x++) {
        const sx = camX + x;
        if (sx < 0 || sx >= b.width) continue;
        const c = shadow.data[srcRow + sx];
        if (((c >>> 24) & 0xff) === 0) continue;
        if (bayer4(x, y) > Math.min(1, TIME_OF_DAY[this.review.timeOfDay].shadowScale)) continue;
        const i = y * VIEW_W + x;
        s.data[i] = blendOver(s.data[i], c);
      }
    }
    // depth-sorted renderables
    const list = b.renderables
      .filter((o) => o.mode === 'both' || (o.mode === 'ext') === (this.zone === 'ext'))
      .sort((p, q) => p.depth - q.depth);
    for (const o of list) s.blit(o.sprite, o.x - camX, o.y - camY);

    // drone
    const d = this.drone;
    const [dsx, dsy] = this.pr.g(d.x, d.y);
    const dbx = Math.round(dsx + b.ox) - camX;
    const dby = Math.round(dsy + b.oy) - camY;
    robotShadow(s, dbx, dby, Math.round(Math.sin(d.t * 2.6) * 1.5));
    drawRobotRig(s, dbx, dby, { t: d.t, flip: d.flip, alert: d.alert });

    // player (composite rig)
    const [psx, psy] = this.pr.g(this.px, this.py);
    const pbx = Math.round(psx + b.ox) - camX;
    const pby = Math.round(psy + b.oy) - camY;
    rigShadow(s, pbx, pby, this.pr.p.shadow.x, this.pr.p.shadow.y);
    drawComposite(s, pbx, pby, this.pose(), FULL_KIT);

    // lights (world space -> screen)
    this.lighting.timeOfDay = this.review.timeOfDay;
    this.lighting.enabled = this.review.lighting;
    this.lighting.begin();
    for (const l of b.lights) {
      if (l.mode !== 'both' && (l.mode === 'int') !== (this.zone === 'int')) continue;
      const [lx, ly] = this.pr.g(l.x, l.y);
      this.lighting.addLight(
        { x: lx + b.ox - camX, y: ly + b.oy - camY, radius: l.r, r: l.c[0], g: l.c[1], b: l.c[2], intensity: l.i, flicker: l.flicker, blink: l.blink },
        this.time,
        [],
        0,
        0,
      );
    }
    this.lighting.addLight({ x: dbx, y: dby - 8, radius: 11, r: 0.25, g: 0.9, b: 1, intensity: 0.42 }, this.time, [], 0, 0);
    this.lighting.addLight({ x: pbx, y: pby - 22, radius: 6, r: 0.2, g: 0.8, b: 0.9, intensity: 0.18 }, this.time, [], 0, 0);
    this.lighting.apply(s);

    // atmosphere (cached vignette + horizon haze)
    if (!this.atmo) this.atmo = this.bakeAtmo();
    for (let i = 0; i < this.atmo.data.length; i++) {
      const c = this.atmo.data[i];
      if (((c >>> 24) & 0xff) === 0) continue;
      s.data[i] = blendOver(s.data[i], c);
    }

    // interaction prompt
    if (this.prompt && this.fade < 0.5) {
      const e = this.zone === 'ext' ? b.entrance.ext : b.entrance.int;
      const [ex, ey] = this.pr.g(e.x, e.y);
      this.promptBox(s, Math.round(ex + b.ox) - camX, Math.round(ey + b.oy) - camY - 26);
    }
    if (this.review.debug) this.debug(s, camX, camY);
    if (this.fade > 0.01) {
      for (let y = 0; y < VIEW_H; y++) for (let x = 0; x < VIEW_W; x++) if (bayer4(x, y) < this.fade) s.data[y * VIEW_W + x] = 0xff080708;
    }
    return s;
  }

  /** tooling / tests: force zone and stand at the corresponding entrance */
  setZoneForced(z: 'ext' | 'int'): void {
    this.zone = z;
    this.pendingZone = null;
    this.fade = 0;
    const e = z === 'ext' ? this.bake.entrance.ext : this.bake.entrance.int;
    this.px = e.x;
    this.py = e.y + (z === 'ext' ? 4 : -2);
    this.snapCam();
  }

  /** tooling: arbitrary world point to view pixels */
  worldToScreen(x: number, y: number): { x: number; y: number } {
    const [gx, gy] = this.pr.g(x, y);
    return { x: Math.round(gx + this.bake.ox - this.camX), y: Math.round(gy + this.bake.oy - this.camY) };
  }

  /** tooling: player position in view pixels (for close-up crops) */
  playerScreenPos(): { x: number; y: number } {
    const [psx, psy] = this.pr.g(this.px, this.py);
    return { x: Math.round(psx + this.bake.ox - this.camX), y: Math.round(psy + this.bake.oy - this.camY) };
  }

  private bakeAtmo(): PixelSurface {
    const a = new PixelSurface(VIEW_W, VIEW_H);
    const cx = VIEW_W / 2;
    const cy = VIEW_H / 2;
    for (let y = 0; y < VIEW_H; y++) {
      for (let x = 0; x < VIEW_W; x++) {
        const dx = (x - cx) / cx;
        const dy = (y - cy) / cy;
        const d = Math.sqrt(dx * dx * 0.8 + dy * dy * 1.15);
        if (d > 0.74) {
          const t = Math.min(1, (d - 0.74) / 0.5) * 0.34;
          if (bayer4(x, y) <= t) a.data[y * VIEW_W + x] = withAlpha(mix(dust.d0, 0x00000000, 0.45), Math.round(t * 255));
        }
        if (y < 24) {
          const t = (1 - y / 24) * 0.2;
          if (bayer4(x, y) <= t) a.data[y * VIEW_W + x] = withAlpha(mix(mix(dust.d6, metal.m6, 0.3), 0x00000000, 0.6), Math.round(t * 255));
        }
      }
    }
    return a;
  }

  private promptBox(s: PixelSurface, x: number, y: number): void {
    const bob = Math.sin(this.time * 4) > 0 ? 0 : 1;
    const px = x - 5;
    const py = y - bob;
    s.rect(px, py, 11, 9, withAlpha(packRGBA(16, 18, 20), 200));
    s.strokeRect(px, py, 11, 9, withAlpha(metal.m6, 220));
    const g = ['111', '100', '110', '100', '111'];
    for (let ry = 0; ry < 5; ry++) for (let rx = 0; rx < 3; rx++) if (g[ry][rx] === '1') s.set(px + 4 + rx, py + 2 + ry, metal.m9);
    s.set(x, py + 9, withAlpha(metal.m6, 200));
  }

  private debug(s: PixelSurface, camX: number, camY: number): void {
    const b = this.bake;
    const colliders = this.zone === 'ext' ? b.collidersExt : b.collidersInt;
    for (const c of colliders) this.worldRect(s, c.x, c.y, c.w, c.h, camX, camY, packRGBA(255, 60, 60, 200));
    const e = this.zone === 'ext' ? b.entrance.ext : b.entrance.int;
    this.worldRect(s, e.x - 12, e.y - 12, 24, 24, camX, camY, packRGBA(80, 255, 120, 220));
    for (const o of b.renderables) {
      if (o.mode !== 'both' && (o.mode === 'int') !== (this.zone === 'int')) continue;
      s.set(o.x + 2 - camX, o.y + 2 - camY, packRGBA(80, 200, 255, 220));
      s.set(o.x + 3 - camX, o.y + 2 - camY, packRGBA(80, 200, 255, 220));
    }
    drawText(s, 4, 4, `DEPTH-SORTED ${b.renderables.length} RENDERABLES · ${this.projection.id}`, cyan.c4, {});
    drawText(s, 4, 12, `ZONE ${this.zone.toUpperCase()} · CAM ${camX},${camY}`, amber.a4, {});
  }

  private worldRect(s: PixelSurface, x: number, y: number, w: number, h: number, camX: number, camY: number, c: number): void {
    const b = this.bake;
    const pts = [this.pr.g(x, y), this.pr.g(x + w, y), this.pr.g(x + w, y + h), this.pr.g(x, y + h)].map((p) => [Math.round(p[0] + b.ox) - camX, Math.round(p[1] + b.oy) - camY]);
    for (let i = 0; i < 4; i++) {
      const a = pts[i];
      const q = pts[(i + 1) % 4];
      s.line(a[0], a[1], q[0], q[1], c);
    }
  }
}

function blendOver(dst: number, src: number): number {
  const sa = (src >>> 24) & 0xff;
  if (sa === 255) return src;
  const isa = 255 - sa;
  const r = ((src & 0xff) * sa + (dst & 0xff) * isa) >> 8;
  const g = (((src >>> 8) & 0xff) * sa + ((dst >>> 8) & 0xff) * isa) >> 8;
  const b = (((src >>> 16) & 0xff) * sa + ((dst >>> 16) & 0xff) * isa) >> 8;
  return (0xff << 24) | (b << 16) | (g << 8) | r;
}
