import { mix, withAlpha } from '../rendering/color';
import { bayer4 } from '../rendering/dither';
import { makeRng } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, hazard, metal, rust, signal, warm } from '../data/palette';
import { cable, rustRun, weatherSpeckle } from '../rendering/detail';
import { drawText } from '../rendering/text';

/**
 * THE ROBOT — a hovering frontier utility/security drone.
 *
 * Deliberately machine-like: an armoured carapace with a single big sensor
 * lens, two asymmetric manipulators (claw + tool module), ventral thruster,
 * antenna whip, external cables and honest weathering. Animation variants
 * move the lens highlight, flicker the thruster and blink the beacon.
 */

export interface RobotFrames {
  frames: PixelSurface[];
  ax: number;
  ay: number;
  /** lens centre in sprite coords (for the light pass) */
  lens: { x: number; y: number };
  thruster: { x: number; y: number };
}

const RW = 26;
const RH = 24;

const SHELL = [
  '..........................',
  '................m.........',
  '................m.........',
  '................m.........',
  '........HHHHHHHHm.........',
  '.......HhhhhhhhhHH........',
  '......HHhaaaaaahHH........',
  '.....HHaaaaaaaaaaHH.......',
  '.....HaaaaaaaaaaaaH.......',
  '....HHooaxxxxxxaaаH.......',
  '....HooaaxvVVVvxaaaH......',
  '....HaaaxvVVVvxaaaH.......',
  '....HHaaaxxxxxxaaaHH......',
  '.....HaaaaaaaaaaHH........',
  '.....HHbbbbbbbbHH.........',
  '......HHbbbbbbHH..........',
  '.......HHbbbbHH...........',
  '........HHHHHH............',
  '.........xKKKx............',
  '..........KKK.............',
  '..........................',
  '..........................',
  '..........................',
  '..........................',
];

const C: Record<string, number> = {
  o: amber.a3,
  H: metal.m4,
  h: metal.m7,
  a: metal.m5,
  b: metal.m3,
  x: warm.w0,
  v: cyan.c2,
  V: cyan.c5,
  K: warm.w1,
  m: metal.m4,
};

export function buildRobot(): RobotFrames {
  const rnd = makeRng(777);
  const frames: PixelSurface[] = [];
  for (let f = 0; f < 4; f++) {
    const s = new PixelSurface(RW, RH);
    for (let y = 0; y < SHELL.length; y++) {
      for (let x = 0; x < SHELL[y].length; x++) {
        const ch = SHELL[y][x];
        const c = C[ch];
        if (c === undefined) continue;
        s.set(x + 1, y, c);
      }
    }
    // carapace panel line + rivets
    s.hline(6, 8, 14, metal.m3);
    s.hline(6, 9, 14, metal.m6);
    for (const [rx, ry] of [
      [7, 7],
      [18, 7],
      [7, 13],
      [18, 13],
    ]) {
      s.set(rx, ry, metal.m2);
      s.set(rx, ry - 1, metal.m7);
    }
    // louvres on the flanks
    for (let i = 0; i < 3; i++) {
      s.hline(6, 11 + i, 3, i === 1 ? metal.m2 : metal.m3);
      s.hline(17, 11 + i, 3, i === 1 ? metal.m2 : metal.m3);
    }
    // stencil + hazard
    drawText(s, 7, 14, '02', mix(metal.m7, warm.w5, 0.3), { worn: 0.3, seed: 2 });
    s.hline(15, 15, 4, hazard.h2);
    s.hline(15, 16, 4, warm.w1);
    // rust + grime on the lower shell
    rustRun(s, 9, 13, 5, [rust.x3, rust.x2], 1, 1);
    rustRun(s, 16, 12, 6, [rust.x3, rust.x2], 1, 2);
    weatherSpeckle(s, 4, 4, 18, 14, [metal.m3, rust.x3, warm.w3], 0.03, rnd);

    // ---- manipulators
    // left: two-finger claw on a shoulder ball
    s.set(4, 10, metal.m4);
    s.set(4, 11, metal.m6);
    s.set(3, 11, metal.m2);
    s.line(3, 12, 2, 13, metal.m5);
    s.line(4, 12, 4, 14, metal.m3);
    // finger A
    s.line(2, 14, 1, 16, metal.m4);
    s.set(1, 17, metal.m6);
    s.set(2, 17, metal.m2);
    // finger B
    s.line(4, 15, 4, 17, metal.m3);
    s.set(4, 18, metal.m5);
    s.set(3, 18, metal.m2);
    // right: tool / weapon module
    s.set(21, 10, metal.m4);
    s.set(21, 11, metal.m6);
    s.rect(21, 12, 4, 4, metal.m3);
    s.hline(21, 12, 4, metal.m7);
    s.hline(21, 15, 4, metal.m1);
    s.vline(21, 12, 4, metal.m5);
    s.rect(25, 13, 1, 2, warm.w0);
    s.set(22, 13, amber.a4);
    s.set(22, 14, amber.a2);
    // cables
    cable(s, 5, 10, 3, 13, 1.5, warm.w0, metal.m4);
    cable(s, 20, 10, 22, 12, 1.5, warm.w0, metal.m4);

    // ---- per-frame animation bits
    const lensShift = [0, 1, 0, -1][f];
    // lens highlight sweep
    s.set(11 + lensShift, 10, cyan.c6);
    s.set(12 + lensShift, 11, cyan.c4);
    s.set(10 + lensShift, 11, cyan.c1);
    // thruster flicker
    const th = [3, 4, 3, 2][f];
    s.rect(10, 18, 5, 2, warm.w0);
    s.hline(10, 18, 5, warm.w2);
    for (let i = 0; i < th; i++) {
      const wdt = i === 0 ? 4 : i === 1 ? 3 : i === 2 ? 2 : 1;
      const cx = 12 - Math.floor(wdt / 2);
      s.hline(cx, 20 + i, wdt, i === 0 ? cyan.c6 : i === 1 ? cyan.c4 : i === 2 ? cyan.c2 : cyan.c1);
    }
    s.set(11, 20, cyan.c7);
    s.set(12, 20, cyan.c7);
    s.set(12, 21, cyan.c5);
    // beacon blink
    if (f === 1 || f === 2) {
      s.set(17, 3, signal.s4);
      s.set(17, 2, withAlpha(signal.s3, 180));
    } else {
      s.set(17, 3, signal.s1);
    }

    // form shading + rim + outline
    for (let y = 0; y < RH; y++) {
      for (let x = 15; x < RW; x++) {
        const c = s.get(x, y);
        if (((c >>> 24) & 0xff) === 0) continue;
        if (bayer4(x, y) < 0.3) s.set(x, y, mix(c, warm.w0, 0.4));
      }
    }
    for (let y = 0; y < RH; y++) {
      for (let x = 1; x < RW; x++) {
        const c = s.get(x, y);
        const l = s.get(x - 1, y);
        if (((c >>> 24) & 0xff) > 0 && ((l >>> 24) & 0xff) === 0) {
          s.set(x, y, mix(c, metal.m9, 0.4));
          break;
        }
      }
    }
    s.outline(withAlpha(warm.w0, 235), false);
    frames.push(s);
  }
  return { frames, ax: 13, ay: 20, lens: { x: 12, y: 10 }, thruster: { x: 12, y: 21 } };
}
