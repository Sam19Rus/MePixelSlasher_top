import { mix, withAlpha } from '../rendering/color';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, metal, warm } from '../data/palette';

/**
 * The mercenary's carbine — a compact bullpup-ish SMG with its own silhouette:
 * stock, receiver, top rail, handguard, barrel, curved magazine, emissive
 * charge indicator. Gloves are baked in at the grip and handguard so the
 * weapon always reads as *held*, never as a floating rectangle.
 */
export interface WeaponSprite {
  sprite: PixelSurface;
  /** offset of the trigger-hand pixel inside the sprite */
  gripX: number;
  gripY: number;
  muzzleX: number;
  muzzleY: number;
}

export function carbine(): WeaponSprite {
  const s = new PixelSurface(18, 8);
  const map = [
    '..................',
    '.....QQQQQQ.......',
    '..xxqqqqqqqqqqxx..',
    '..xKqqqqqqqqqqqQy.',
    '...Kqq.qqqqqqq....',
    '......mm..K.......',
    '......mm..........',
    '..................',
  ];
  const C: Record<string, number> = {
    Q: metal.m6,
    q: warm.w2,
    x: warm.w0,
    K: warm.w3,
    y: cyan.c4,
    m: warm.w1,
  };
  for (let y = 0; y < map.length; y++) {
    for (let x = 0; x < map[y].length; x++) {
      const c = C[map[y][x]];
      if (c === undefined) continue;
      s.set(x, y, c);
    }
  }
  // shade the underside of the receiver + light the rail
  for (let x = 2; x < 16; x++) {
    const c = s.get(x, 3);
    if (((c >>> 24) & 0xff) > 0) s.set(x, 3, mix(c, warm.w0, 0.35));
  }
  s.set(15, 3, cyan.c5);
  s.set(16, 3, withAlpha(amber.a4, 200));
  // magazine curve
  s.set(6, 6, warm.w0);
  s.set(7, 6, warm.w2);
  return { sprite: s, gripX: 3, gripY: 3, muzzleX: 16, muzzleY: 3 };
}
