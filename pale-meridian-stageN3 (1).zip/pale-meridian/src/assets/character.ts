import { Color, mix, withAlpha } from '../rendering/color';
import { bayer4 } from '../rendering/dither';
import { PixelSurface } from '../rendering/PixelSurface';
import { cyan, metal, olive, signal, slate, warm } from '../data/palette';
import { carbine } from './weapon';

/**
 * THE MERCENARY.
 *
 * A ~28px human with real proportions: small helmeted head (≈1/5 of height),
 * an armoured torso with asymmetric pauldrons, dark undersuit arms that reach
 * the weapon, and a 4-phase stride. Bodies are hand-authored pixel maps —
 * that is where silhouette quality lives — and the carbine is composited on
 * top so it always reads as a physical object in the hands.
 */

export type Dir = 's' | 'n' | 'e' | 'w';

const P: Record<string, Color> = {
  H: metal.m5,
  h: metal.m7,
  g: metal.m3,
  G: metal.m2,
  v: cyan.c2,
  V: cyan.c4,
  s: slate.s2,
  S: slate.s4,
  t: slate.s6,
  a: metal.m7,
  A: metal.m5,
  b: metal.m3,
  B: metal.m2,
  w: olive.o3,
  W: olive.o1,
  p: olive.o2,
  P: olive.o4,
  k: warm.w1,
  K: warm.w3,
  c: cyan.c3,
  r: signal.s3,
  R: signal.s1,
};

/** Front (south). Arms are the dark S/s columns; torso is the plated centre. */
const BODY_S = [
  '..........hhhh..........',
  '........HhhhhhhH........',
  '........HgvvvvvG........',
  '........HggggggG........',
  '........GGggggGG........',
  '..........ssss.r........',
  '......AA..ssss..rr......',
  '......aaSsSSSSsSaa.R....',
  '......AbSsScScSsbA.R....',
  '......SbSsSSSSSsSbS.....',
  '......SSsSwSSwSsSS......',
  '......SSsWWWWWWsSS......',
  '.....SSs........sSS.....',
  '.....SSs........sSS.....',
  '......SS........SS......',
  '......SS........SS......',
];

/** Back (north): pack with straps, scarf tail, slung weapon added on top. */
const BODY_N = [
  '..........hhhh..........',
  '........HhhhhhhH........',
  '........HgHHHHgH........',
  '........HgggggGH........',
  '........GGggggGG........',
  '..........ssss..........',
  '......AA..ssss..AA......',
  '......aappppppppaa.r....',
  '......abpPPPPPPbaA.R....',
  '......SbpPPPPPPpbS.R....',
  '......SSbpwWWwppSS......',
  '......SSSwWWWWWWsSS.....',
  '.....SSs........sSS.....',
  '.....SSs........sSS.....',
  '......SS........SS......',
  '......SS........SS......',
];

/** Profile (east): pack on the back, weapon level and aimed forward. */
const BODY_E = [
  '..........hhhh..........',
  '.........HhhhhHH........',
  '.........HggvvvH........',
  '.........HgggggH........',
  '.........GGggGG.........',
  '..........sss...........',
  '.......AAASSs.AA........',
  '......pPaSSSSsaA........',
  '......pPabSSSSbA........',
  '......ppbSSSSSbS........',
  '......ppbwSSSwbS........',
  '.......SWWWWWW.S........',
  '......SSs.....sSS.......',
  '......SSs.....sSS.......',
  '.......SS.....SS........',
  '.......SS.....SS........',
];

export interface MercFrames {
  frames: Record<Dir, PixelSurface[]>;
  ax: number;
  ay: number;
}

const FW = 28;
const FH = 30;
const AX = 14;
const AY = 28;

export function buildMerc(): MercFrames {
  const gun = carbine();
  const frames = {} as Record<Dir, PixelSurface[]>;
  for (const dir of ['s', 'n', 'e', 'w'] as Dir[]) {
    frames[dir] = [];
    for (let phase = 0; phase < 4; phase++) frames[dir].push(buildFrame(dir, phase, gun.sprite));
  }
  return { frames, ax: AX, ay: AY };
}

function buildFrame(dir: Dir, phase: number, gun: PixelSurface): PixelSurface {
  const s = new PixelSurface(FW, FH);
  const map = dir === 's' ? BODY_S : dir === 'n' ? BODY_N : BODY_E;
  const flip = dir === 'w';
  const bw = map[0].length;
  const ox = AX - Math.floor(bw / 2);
  const oy = 1;
  const bob = phase === 1 || phase === 3 ? 0 : 1;

  drawLegs(s, dir, phase, bob);

  for (let ry = 0; ry < map.length; ry++) {
    const row = map[ry];
    for (let rx = 0; rx < row.length; rx++) {
      const ch = row[rx];
      if (ch === '.') continue;
      const c = P[ch];
      if (c === undefined) continue;
      const px = flip ? ox + bw - 1 - rx : ox + rx;
      s.set(px, oy + ry + (ry >= 5 ? bob : 0), c);
    }
  }

  // weapon, always in the hands
  if (dir === 's') s.blit(gun, AX - 6, 11 + bob);
  else if (dir === 'n') s.blit(gun, AX - 5, 11 + bob, { flipX: true });
  else if (dir === 'e') s.blit(gun, AX - 6, 10 + bob);
  else s.blit(gun, AX + 6 - gun.width, 10 + bob, { flipX: true });

  // form shading: right side falls away from the sun
  for (let y = 0; y < FH; y++) {
    for (let x = AX + 4; x < FW; x++) {
      const c = s.get(x, y);
      if (((c >>> 24) & 0xff) === 0) continue;
      if (bayer4(x, y) < 0.3) s.set(x, y, mix(c, slate.s1, 0.4));
    }
  }
  // rim light along the left silhouette
  for (let y = 0; y < FH; y++) {
    for (let x = 1; x < FW; x++) {
      const c = s.get(x, y);
      const l = s.get(x - 1, y);
      if (((c >>> 24) & 0xff) > 0 && ((l >>> 24) & 0xff) === 0) {
        s.set(x, y, mix(c, metal.m8, 0.45));
        break;
      }
    }
  }
  s.outline(withAlpha(mix(slate.s0, warm.w0, 0.4), 235), false);
  return s;
}

/** 4-phase stride; profile directions get a real fore/aft stride. */
function drawLegs(s: PixelSurface, dir: Dir, phase: number, bob: number): void {
  const hipY = 16 + bob;
  const profile = dir === 'e' || dir === 'w';
  const flip = dir === 'w';

  const leg = (hipX: number, swing: number, lift: number, front: boolean) => {
    const cD = front ? slate.s3 : slate.s2;
    const cM = front ? slate.s5 : slate.s3;
    for (let i = 0; i < 4; i++) {
      s.set(hipX, hipY + i, cD);
      s.set(hipX + 1, hipY + i, cM);
    }
    s.set(hipX, hipY, front ? slate.s6 : slate.s4);
    s.set(hipX, hipY + 4, metal.m4);
    s.set(hipX + 1, hipY + 4, metal.m3);
    const kx = hipX + Math.round(swing * 0.5);
    const shinLen = 4 - lift;
    for (let i = 0; i < shinLen; i++) {
      s.set(kx, hipY + 5 + i, front ? slate.s3 : slate.s2);
      s.set(kx + 1, hipY + 5 + i, front ? slate.s4 : slate.s2);
    }
    const by = hipY + 5 + shinLen;
    s.set(kx, by, warm.w3);
    s.set(kx + 1, by, warm.w2);
    const toe = profile ? (flip ? -1 : 2) : 1;
    s.set(kx + toe, by, warm.w2);
    s.set(kx, by + 1, warm.w1);
    s.set(kx + 1, by + 1, warm.w1);
    s.set(kx + toe, by + 1, mix(warm.w1, warm.w0, 0.5));
  };

  if (profile) {
    const stride: [number, number, number, number][] = [
      [2, 0, -2, 1],
      [1, 1, 0, 0],
      [-2, 0, 2, 1],
      [-1, 0, 1, 1],
    ];
    const st = stride[phase];
    leg(AX - 2 + (flip ? 1 : 0), st[2], st[3], false);
    leg(AX - 1, st[0], st[1], true);
  } else {
    const lift: [number, number] = phase === 0 ? [0, 1] : phase === 2 ? [1, 0] : [0, 0];
    const spread = phase === 1 || phase === 3 ? 1 : 0;
    leg(AX - 3 - spread, 0, lift[0], dir === 's');
    leg(AX + 1 + spread, 0, lift[1], dir === 's');
  }
}
