import { Color, mix, withAlpha } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { makeRng, valueNoise } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, dust, grime, hazard, metal, olive, rock, rust, signal, teal, warm } from '../data/palette';
import { drawMass, floorQuad, type MassColors } from '../rendering/projection';
import { bolts, cable, hazardStripes, panelSeams, pipeRun, rustRun, ventGrille, weatherSpeckle } from '../rendering/detail';
import { drawText, stencilPlate } from '../rendering/text';

/**
 * Exterior props.
 *
 * Each builder returns a sprite whose bottom-centre is the ground anchor.
 * They are small but dense: every prop carries material contrast, a lit edge,
 * a shaded side and at least one story-telling detail (a stencil, a leak, a
 * patched panel, a blinking LED).
 */

export interface Prop {
  sprite: PixelSurface;
  /** ground anchor offset inside the sprite */
  ax: number;
  ay: number;
  /** emissive points in world-local sprite coords, for the lighting pass */
  glows?: { x: number; y: number; c: 'amber' | 'cyan' | 'red' }[];
}

const CRATE_M: MassColors = {
  front: [mix(metal.m6, olive.o4, 0.35), mix(metal.m4, olive.o3, 0.35), mix(metal.m2, olive.o2, 0.4)],
  top: [mix(metal.m7, olive.o5, 0.3), mix(metal.m5, olive.o4, 0.3)],
  east: [mix(metal.m2, olive.o2, 0.4), mix(metal.m1, olive.o1, 0.4)],
  rim: mix(metal.m8, olive.o6, 0.3),
  edge: metal.m1,
};
const CRATE_R: MassColors = {
  front: [rust.x5, rust.x4, rust.x2],
  top: [mix(rust.x6, dust.d7, 0.25), rust.x4],
  east: [rust.x2, rust.x1],
  rim: rust.x7,
  edge: rust.x0,
};

export function crate(size: 'lg' | 'sm' | 'md', variant = 0): Prop {
  const w = size === 'lg' ? 20 : size === 'md' ? 15 : 11;
  const h = size === 'lg' ? 16 : size === 'md' ? 12 : 9;
  const d = size === 'lg' ? 14 : size === 'md' ? 10 : 7;
  const s = new PixelSurface(w + 8, h + 8);
  const rnd = makeRng(300 + variant * 17 + w);
  const M = variant % 2 === 0 ? CRATE_M : CRATE_R;
  const x = 2;
  const y = h + 4;
  drawMass(s, x, y, w, h, d, M, { dust: dust.d5, dustAmount: 0.7 });
  panelSeams(s, x, y - h, w, h, mix(M.front[2], metal.m1, 0.4), mix(M.front[0], metal.m8, 0.4), [Math.floor(w / 2)], [Math.floor(h / 2)]);
  // latches
  for (const lx of [x + 2, x + w - 4]) {
    s.rect(lx, y - h + 3, 2, h - 6, metal.m3);
    s.vline(lx, y - h + 3, h - 6, metal.m6);
    s.set(lx, y - h + 4, metal.m8);
  }
  // lid seam on the top face
  const kx = Math.round(0.34 * d);
  const ky = Math.round(0.6 * d);
  s.line(x + 1, y - h - Math.round(ky / 2) , x + w + Math.round(kx / 2), y - h - Math.round(ky / 2), mix(M.top[1], metal.m2, 0.4));
  // stencil
  if (size !== 'sm') {
    drawText(s, x + 3, y - 7, variant % 2 ? 'K7' : 'A2', mix(metal.m8, dust.d7, 0.4), { worn: 0.4, seed: variant + w });
  }
  if (size === 'lg') {
    stencilPlate(s, x + w - 12, y - h + 2, '04', M.front[1], metal.m1, metal.m8, 0.3);
    s.set(x + w - 3, y - 4, cyan.c3);
    s.set(x + w - 3, y - 5, cyan.c1);
  }
  rustRun(s, x + 3, y - h + 2, h - 3, [rust.x3, rust.x2], 1, variant);
  weatherSpeckle(s, x, y - h - ky, w + kx, h + ky, [dust.d5, M.front[2], rust.x3], 0.03, rnd);
  return { sprite: s, ax: x + Math.round(w / 2), ay: y };
}

export function drum(variant = 0): Prop {
  const s = new PixelSurface(14, 20);
  const rnd = makeRng(90 + variant);
  const cx = 7;
  const top = 4;
  const bot = 18;
  const rx = 5;
  // body
  for (let y = top; y <= bot; y++) {
    for (let x = -rx; x <= rx; x++) {
      const d = Math.abs(x) / rx;
      const lit = 0.5 - d * 0.9 + 0.35;
      const c = mix(rust.x2, rust.x6, Math.max(0, Math.min(1, lit)));
      s.set(cx + x, y, bayer4(x + 2, y) < 0.2 ? mix(c, rust.x3, 0.5) : c);
    }
  }
  // ribs
  for (const ry of [top + 4, top + 9]) {
    for (let x = -rx; x <= rx; x++) {
      const d = Math.abs(x) / rx;
      s.set(cx + x, ry, mix(rust.x6, rust.x8, 0.4 - d * 0.4));
      s.set(cx + x, ry + 1, rust.x1);
    }
  }
  // top ellipse
  s.ellipse(cx, top, rx, 2, mix(rust.x5, dust.d6, 0.3));
  s.ellipse(cx, top, rx - 1, 1, mix(rust.x3, rust.x4, 0.5));
  s.set(cx - 1, top - 1, rust.x7);
  s.set(cx + 2, top, rust.x2);
  // cap
  s.set(cx + 2, top - 1, metal.m5);
  s.set(cx + 2, top, metal.m3);
  // rust + label
  for (let i = 0; i < 8; i++) s.set(cx - rx + rnd.int(0, rx * 2), rnd.int(top + 2, bot - 1), rust.x2);
  s.rect(cx - 3, top + 6, 6, 4, mix(hazard.h1, rust.x3, 0.4));
  s.hline(cx - 3, top + 6, 6, hazard.h3);
  s.hline(cx - 3, top + 9, 6, hazard.h0);
  // base contact shade
  for (let x = -rx; x <= rx; x++) s.set(cx + x, bot, mix(grime.g1, rust.x1, 0.5));
  return { sprite: s, ax: cx, ay: bot };
}

export function generator(): Prop {
  const s = new PixelSurface(52, 40);
  const rnd = makeRng(5150);
  const x = 4;
  const y = 34;
  const w = 36;
  const h = 22;
  const d = 16;
  const M: MassColors = {
    front: [mix(metal.m6, warm.w5, 0.4), mix(metal.m4, warm.w4, 0.4), mix(metal.m2, warm.w2, 0.4)],
    top: [mix(metal.m7, dust.d7, 0.3), mix(metal.m5, dust.d6, 0.3)],
    east: [warm.w2, warm.w1],
    rim: mix(metal.m8, amber.a6, 0.2),
    edge: warm.w0,
  };
  drawMass(s, x, y, w, h, d, M, { dust: dust.d5, dustAmount: 0.8 });
  // louvred intake
  ventGrille(s, x + 3, y - h + 5, 14, 12, warm.w1, warm.w4);
  // emissive exhaust glow slot
  s.rect(x + 20, y - h + 6, 12, 7, warm.w1);
  for (let i = 0; i < 5; i++) {
    s.hline(x + 21, y - h + 7 + i, 10, i % 2 === 0 ? amber.a3 : amber.a1);
  }
  s.hline(x + 21, y - h + 8, 10, amber.a5);
  // gauge + switches
  s.ellipse(x + 26, y - 7, 3, 3, metal.m2);
  s.ellipse(x + 26, y - 7, 2, 2, mix(cyan.c1, metal.m2, 0.3));
  s.set(x + 26, y - 8, cyan.c4);
  s.set(x + 31, y - 6, signal.s3);
  s.set(x + 33, y - 6, amber.a4);
  // hazard band
  hazardStripes(s, x + 1, y - 5, w - 2, 3, hazard.h1, warm.w1, 5);
  // exhaust stack + heat shimmer anchor
  s.rect(x + 28, y - h - 8, 4, 9, warm.w2);
  s.vline(x + 28, y - h - 8, 9, warm.w4);
  s.rect(x + 27, y - h - 10, 6, 3, warm.w1);
  s.hline(x + 27, y - h - 10, 6, warm.w4);
  // cables out the back
  cable(s, x + w - 2, y - 6, x + w + 10, y + 2, 3, warm.w0, warm.w3);
  cable(s, x + w - 2, y - 10, x + w + 8, y - 2, 4, metal.m0, metal.m3);
  // stencil + weathering
  drawText(s, x + 20, y - 12, 'GEN-2', mix(metal.m7, dust.d6, 0.4), { worn: 0.35, seed: 4 });
  rustRun(s, x + 6, y - h + 3, h - 4, [rust.x3, rust.x2], 2, 2);
  rustRun(s, x + 30, y - h + 3, h - 6, [rust.x4, rust.x3], 1, 3);
  weatherSpeckle(s, x, y - h - 10, w + 12, h + 12, [dust.d5, warm.w3, rust.x3], 0.035, rnd);
  bolts(s, x + 2, y - h + 2, warm.w1, metal.m7);
  bolts(s, x + w - 4, y - h + 2, warm.w1, metal.m7);
  return {
    sprite: s,
    ax: x + Math.round(w / 2),
    ay: y,
    glows: [
      { x: x + 26, y: y - h + 9, c: 'amber' },
      { x: x + 26, y: y - 7, c: 'cyan' },
    ],
  };
}

export function container(): Prop {
  const s = new PixelSurface(96, 44);
  const rnd = makeRng(811);
  const x = 3;
  const y = 38;
  const w = 78;
  const h = 28;
  const d = 18;
  const M: MassColors = {
    front: [teal.t4, teal.t3, teal.t1],
    top: [mix(teal.t5, dust.d7, 0.35), mix(teal.t4, dust.d6, 0.35)],
    east: [teal.t1, teal.t0],
    rim: mix(teal.t6, dust.d8, 0.3),
    edge: teal.t0,
  };
  drawMass(s, x, y, w, h, d, M, { dust: dust.d5, dustAmount: 0.9 });
  // corrugation
  for (let px = 2; px < w - 2; px += 4) {
    s.vline(x + px, y - h + 2, h - 4, teal.t2);
    s.vline(x + px + 1, y - h + 2, h - 4, teal.t4);
    s.vline(x + px + 2, y - h + 2, h - 4, teal.t3);
  }
  // frame posts
  for (const px of [x + 1, x + w - 4]) {
    s.rect(px, y - h + 1, 3, h - 2, teal.t2);
    s.vline(px, y - h + 1, h - 2, teal.t5);
  }
  s.hline(x, y - h + 1, w, teal.t5);
  s.hline(x, y - 3, w, teal.t0);
  // doors on the east end
  const kx = Math.round(0.34 * d);
  const ky = Math.round(0.6 * d);
  s.polygon(floorQuad(x + w - 26, y - h - 1, 24, d - 2), mix(teal.t3, dust.d6, 0.3));
  for (let i = 0; i < 3; i++) {
    const t = i / 2;
    s.line(x + w - 24 + Math.round(kx * t * 0.8), y - h - 2 - Math.round(ky * t * 0.8), x + w - 4 + Math.round(kx * t * 0.8), y - h - 2 - Math.round(ky * t * 0.8), teal.t2);
  }
  // decal + stencil
  drawText(s, x + 8, y - h + 8, 'FREIGHT', mix(metal.m8, dust.d7, 0.35), { worn: 0.45, seed: 2 });
  drawText(s, x + 8, y - 12, 'TC-118', mix(hazard.h3, dust.d6, 0.4), { worn: 0.5, seed: 6 });
  s.rect(x + 52, y - h + 6, 12, 8, mix(metal.m6, dust.d6, 0.4));
  s.strokeRect(x + 52, y - h + 6, 12, 8, teal.t1);
  drawText(s, x + 54, y - h + 8, '07', teal.t1, { worn: 0.2 });
  // rust + grime
  rustRun(s, x + 10, y - h + 3, h - 5, [rust.x3, rust.x2], 2, 1);
  rustRun(s, x + 40, y - h + 3, h - 8, [rust.x4, rust.x3], 2, 2);
  rustRun(s, x + 66, y - h + 3, h - 4, [rust.x3, rust.x2], 1, 3);
  for (let px = 0; px < w; px++) {
    for (let i = 0; i < 6; i++) if (bayer8(px, i * 3) < i / 7) s.set(x + px, y - 2 - i, mix(dust.d4, teal.t2, 0.4));
  }
  weatherSpeckle(s, x, y - h - ky, w + kx, h + ky, [dust.d5, teal.t2, rust.x3], 0.03, rnd);
  return { sprite: s, ax: x + Math.round(w / 2), ay: y };
}

export function mast(): Prop {
  const s = new PixelSurface(30, 74);
  const bx = 14;
  const by = 70;
  // lattice
  for (let y = by; y > 8; y -= 1) {
    const wdt = y > by - 20 ? 3 : 2;
    s.set(bx - wdt, y, metal.m4);
    s.set(bx + wdt, y, metal.m2);
    if ((by - y) % 5 === 0) {
      s.hline(bx - wdt, y, wdt * 2 + 1, metal.m3);
      s.line(bx - wdt, y, bx + wdt, y - 4, metal.m2);
      s.line(bx + wdt, y, bx - wdt, y - 4, metal.m2);
    }
  }
  // base plate
  s.rect(bx - 5, by - 3, 11, 4, metal.m3);
  s.hline(bx - 5, by - 3, 11, metal.m6);
  bolts(s, bx - 4, by - 2, metal.m1, metal.m7);
  bolts(s, bx + 3, by - 2, metal.m1, metal.m7);
  // cross arms + dish
  s.hline(bx - 7, 16, 15, metal.m3);
  s.hline(bx - 5, 22, 11, metal.m2);
  s.ellipse(bx + 6, 12, 5, 4, metal.m5);
  s.ellipse(bx + 6, 12, 3, 2, metal.m2);
  s.set(bx + 6, 12, metal.m8);
  s.line(bx + 6, 12, bx + 2, 16, metal.m4);
  s.vline(bx, 6, 10, metal.m4);
  s.set(bx, 5, signal.s3);
  s.set(bx, 4, withAlpha(signal.s4, 200));
  // guy wires
  s.line(bx, 10, bx - 10, by - 2, withAlpha(metal.m5, 150));
  s.line(bx, 10, bx + 10, by - 2, withAlpha(metal.m4, 150));
  rustRun(s, bx - 2, 30, 20, [rust.x3, rust.x2], 1, 1);
  return { sprite: s, ax: bx, ay: by, glows: [{ x: bx, y: 5, c: 'red' }] };
}

export function floodPole(): Prop {
  const s = new PixelSurface(20, 46);
  const bx = 9;
  const by = 42;
  s.vline(bx, 8, by - 8, metal.m3);
  s.vline(bx + 1, 8, by - 8, metal.m5);
  s.vline(bx - 1, 10, by - 10, metal.m1);
  s.rect(bx - 3, by - 3, 7, 4, metal.m2);
  s.hline(bx - 3, by - 3, 7, metal.m5);
  // head
  s.rect(bx - 4, 4, 10, 6, metal.m3);
  s.hline(bx - 4, 4, 10, metal.m6);
  s.rect(bx - 3, 8, 8, 2, amber.a4);
  s.hline(bx - 3, 8, 8, amber.a6);
  s.rect(bx - 2, 2, 3, 2, metal.m2);
  rustRun(s, bx, 14, 16, [rust.x3, rust.x2], 1, 2);
  cable(s, bx + 1, 12, bx + 6, by - 6, 4, metal.m0, metal.m3);
  return { sprite: s, ax: bx, ay: by, glows: [{ x: bx + 1, y: 9, c: 'amber' }] };
}

export function cart(): Prop {
  const s = new PixelSurface(52, 30);
  const rnd = makeRng(471);
  const x = 4;
  const y = 24;
  const w = 36;
  // bed
  s.polygon(floorQuad(x, y - 8, w, 12), mix(metal.m5, dust.d6, 0.35));
  s.rect(x, y - 8, w, 6, mix(metal.m4, warm.w3, 0.4));
  s.hline(x, y - 8, w, mix(metal.m7, dust.d7, 0.3));
  s.hline(x, y - 3, w, warm.w1);
  hazardStripes(s, x + 2, y - 6, w - 4, 2, hazard.h1, warm.w1, 6);
  // rails
  s.hline(x, y - 12, w, metal.m4);
  for (let px = x; px <= x + w; px += 6) s.vline(px, y - 12, 5, metal.m3);
  // wheels
  for (const wx of [x + 6, x + w - 8]) {
    s.ellipse(wx, y - 1, 4, 3, warm.w0);
    s.ellipse(wx, y - 1, 2, 2, warm.w2);
    s.set(wx, y - 2, warm.w4);
  }
  // cargo: a strapped crate + a pipe bundle
  const c = crate('md', 1);
  s.blit(c.sprite, x + 6 - c.ax, y - 8 - c.ay + c.ay);
  s.blit(c.sprite, x + 6 - c.ax, y - 8 - c.ay);
  for (let i = 0; i < 3; i++) {
    s.hline(x + 24, y - 11 - i * 2, 12, i === 1 ? metal.m5 : metal.m3);
  }
  s.vline(x + 27, y - 15, 6, hazard.h2);
  s.vline(x + 33, y - 15, 6, hazard.h2);
  weatherSpeckle(s, x, y - 16, w + 8, 18, [dust.d5, warm.w3, rust.x3], 0.03, rnd);
  return { sprite: s, ax: x + Math.round(w / 2), ay: y };
}

export function barrier(): Prop {
  const s = new PixelSurface(52, 16);
  const x = 3;
  const y = 13;
  const w = 46;
  s.polygon(
    [
      [x, y],
      [x + w, y],
      [x + w - 2, y - 9],
      [x + 2, y - 9],
    ],
    mix(metal.m5, dust.d5, 0.45),
  );
  s.hline(x + 2, y - 9, w - 4, mix(metal.m7, dust.d7, 0.35));
  hazardStripes(s, x + 3, y - 7, w - 6, 4, hazard.h2, warm.w1, 7);
  for (let px = 0; px < w; px++) {
    if (bayer4(px, 2) < 0.4) s.set(x + px, y - 1, dust.d4);
    if (valueNoise(px / 5, 1, 9) > 0.7) s.set(x + px, y - 5, mix(rust.x3, dust.d4, 0.5));
  }
  s.hline(x, y, w, mix(grime.g1, dust.d1, 0.5));
  return { sprite: s, ax: x + Math.round(w / 2), ay: y };
}

export function scrapPile(): Prop {
  const s = new PixelSurface(48, 24);
  const rnd = makeRng(1234);
  const cx = 24;
  const cy = 21;
  // heap silhouette
  for (let i = 0; i < 26; i++) {
    const px = cx + rnd.int(-20, 20);
    const py = cy - Math.round((1 - Math.abs(px - cx) / 22) * rnd.range(2, 12));
    const w = rnd.int(3, 9);
    const h = rnd.int(2, 4);
    const tone = rnd.pick([warm.w2, warm.w3, rust.x2, rust.x3, metal.m2]);
    s.rect(px, py, w, h, tone);
    s.hline(px, py, w, mix(tone, metal.m7, 0.4));
    s.hline(px, py + h - 1, w, mix(tone, warm.w0, 0.6));
    if (rnd.chance(0.4)) s.set(px + rnd.int(0, w - 1), py + 1, rust.x4);
  }
  // a bent panel sticking out
  s.line(cx - 6, cy - 14, cx + 2, cy - 18, metal.m4);
  s.line(cx - 6, cy - 13, cx + 2, cy - 17, metal.m2);
  s.line(cx + 8, cy - 12, cx + 12, cy - 17, rust.x4);
  // cable loop
  cable(s, cx - 14, cy - 4, cx + 10, cy - 6, 5, metal.m0, metal.m3);
  for (let px = 0; px < 48; px++) if (bayer4(px, 3) < 0.5) s.set(px, cy, dust.d4);
  return { sprite: s, ax: cx, ay: cy };
}

export function pipeSupport(): Prop {
  const s = new PixelSurface(60, 18);
  pipeRun(
    s,
    [
      [0, 8],
      [60, 8],
    ],
    4,
    warm.w1,
    warm.w3,
    warm.w5,
    warm.w2,
  );
  pipeRun(
    s,
    [
      [0, 13],
      [60, 13],
    ],
    3,
    metal.m1,
    metal.m3,
    metal.m5,
    metal.m2,
  );
  for (const px of [8, 30, 52]) {
    s.rect(px - 1, 6, 3, 10, metal.m2);
    s.vline(px - 1, 6, 10, metal.m4);
    s.rect(px - 3, 15, 7, 2, metal.m2);
  }
  s.set(20, 6, rust.x4);
  s.set(41, 11, rust.x3);
  return { sprite: s, ax: 30, ay: 16 };
}

export function cableSpool(): Prop {
  const s = new PixelSurface(18, 16);
  const cx = 9;
  const cy = 12;
  s.ellipse(cx, cy - 4, 7, 3, warm.w2);
  for (let i = 0; i < 6; i++) s.ellipseOutline(cx, cy - 4 + (i > 2 ? 1 : 0), 7 - (i % 3), 3 - (i % 2), i % 2 ? metal.m1 : metal.m3);
  s.ellipse(cx, cy - 5, 3, 1, warm.w4);
  s.rect(cx - 7, cy - 2, 14, 4, warm.w1);
  s.hline(cx - 7, cy - 2, 14, warm.w3);
  cable(s, cx + 6, cy - 2, cx + 9, cy + 2, 2, metal.m0, metal.m3);
  return { sprite: s, ax: cx, ay: cy + 1 };
}

export function targetDummy(): Prop {
  const s = new PixelSurface(20, 34);
  const bx = 10;
  const by = 31;
  // base
  s.ellipse(bx, by - 1, 6, 2, warm.w1);
  s.ellipse(bx, by - 2, 5, 2, warm.w3);
  s.vline(bx, by - 16, 15, metal.m3);
  s.vline(bx + 1, by - 16, 15, metal.m5);
  // torso plate
  s.rect(bx - 5, by - 26, 11, 12, mix(metal.m5, dust.d6, 0.3));
  s.strokeRect(bx - 5, by - 26, 11, 12, metal.m2);
  s.hline(bx - 5, by - 26, 11, metal.m7);
  // rings + hit marks
  s.ellipseOutline(bx, by - 20, 4, 4, signal.s2);
  s.ellipseOutline(bx, by - 20, 2, 2, signal.s3);
  s.set(bx, by - 20, signal.s4);
  for (const [hx, hy] of [
    [-2, -22],
    [3, -18],
    [1, -24],
  ]) {
    s.set(bx + hx, by + hy, grime.g1);
    s.set(bx + hx + 1, by + hy, grime.g2);
  }
  // head block
  s.rect(bx - 2, by - 30, 5, 4, metal.m4);
  s.hline(bx - 2, by - 30, 5, metal.m6);
  rustRun(s, bx - 4, by - 24, 8, [rust.x3, rust.x2], 1, 1);
  return { sprite: s, ax: bx, ay: by };
}

export function ventUnit(): Prop {
  const s = new PixelSurface(20, 18);
  const x = 3;
  const y = 15;
  drawMass(
    s,
    x,
    y,
    13,
    9,
    8,
    {
      front: [metal.m5, metal.m4, metal.m2],
      top: [mix(metal.m7, dust.d7, 0.3), metal.m5],
      east: [metal.m2, metal.m1],
      rim: metal.m8,
      edge: metal.m1,
    },
    { dust: dust.d5, dustAmount: 0.8 },
  );
  ventGrille(s, x + 2, y - 7, 9, 5, metal.m1, metal.m5);
  s.set(x + 11, y - 3, cyan.c3);
  rustRun(s, x + 4, y - 8, 6, [rust.x3, rust.x2], 1, 2);
  return { sprite: s, ax: x + 6, ay: y };
}

/** A large foreground boulder: dark, faceted, silhouette-first. */
export function boulder(): Prop {
  const s = new PixelSurface(56, 30);
  const rnd = makeRng(555);
  const cx = 28;
  const cy = 22;
  const rx = 24;
  const ry = 12;
  for (let y = -ry - 2; y <= ry; y++) {
    for (let x = -rx - 1; x <= rx + 1; x++) {
      const wob = 0.8 + valueNoise((cx + x) / 6, (cy + y) / 6, 44) * 0.4;
      const d = Math.sqrt((x * x) / (rx * rx) + (y * y) / (ry * ry)) / wob;
      if (d > 1) continue;
      const nl = (-x / rx) * 0.5 + (-y / ry) * 0.8;
      let v = 0.3 + nl * 0.3 + (valueNoise((cx + x) / 3, (cy + y) / 3, 45) - 0.5) * 0.4;
      v = Math.max(0, Math.min(0.999, v));
      let c = rampRock(v);
      if (nl > 0.5 && valueNoise(cx + x, cy + y, 46) > 0.6) c = mix(c, rock.r6, 0.5);
      // foreground boulders sit in shade: push them dark
      c = mix(c, rock.r1, 0.35);
      s.set(cx + x, cy + y, c);
    }
  }
  for (let x = -rx - 2; x <= rx + 2; x++) {
    for (let y = -ry - 3; y <= ry + 1; y++) {
      const px = cx + x;
      const py = cy + y;
      if (((s.get(px, py) >>> 24) & 0xff) > 0) continue;
      let near = false;
      for (const o of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        if (((s.get(px + o[0], py + o[1]) >>> 24) & 0xff) > 0) near = true;
      }
      if (near) s.set(px, py, rock.r0);
    }
  }
  for (let i = 0; i < 6; i++) s.set(cx - 10 + rnd.int(0, 20), cy - 6 + rnd.int(0, 8), rock.r2);
  return { sprite: s, ax: cx, ay: cy };
}
function rampRock(v: number): Color {
  const r = [rock.r1, rock.r2, rock.r3, rock.r4, rock.r5];
  const t = v * (r.length - 1);
  const i = Math.min(r.length - 2, Math.floor(t));
  return t - i > 0.5 ? r[i + 1] : r[i];
}

/** A ground light fixture: small post with a warm lamp head. */
export function groundLamp(): Prop {
  const s = new PixelSurface(10, 14);
  s.vline(4, 5, 8, metal.m2);
  s.vline(5, 5, 8, metal.m4);
  s.rect(2, 2, 6, 4, metal.m3);
  s.hline(2, 2, 6, metal.m6);
  s.rect(3, 5, 4, 1, amber.a4);
  s.rect(1, 12, 8, 2, metal.m2);
  return { sprite: s, ax: 4, ay: 13, glows: [{ x: 5, y: 5, c: 'amber' }] };
}

