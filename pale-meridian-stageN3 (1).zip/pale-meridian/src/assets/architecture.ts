import { mix, packRGBA, withAlpha } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { makeRng, valueNoise } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { dust, metal, rust, teal, warm, hazard, cyan, amber, slate, signal } from '../data/palette';
import { drawMass, floorQuad, type MassColors } from '../rendering/projection';
import { bolts, cable, hazardStripes, panelSeams, pipeRun, rivets, rustRun, screenFill, ventGrille, weatherSpeckle } from '../rendering/detail';
import { drawText, stencilPlate } from '../rendering/text';
import { B } from '../data/layout';

/**
 * THE OUTPOST BUILDING — the visual centre of the benchmark.
 *
 * Four interlocking masses (crew wing, main hall, rusty tech module carrying
 * the entrance, east garage) plus a porch canopy. Every mass gets front / top
 * / east faces, panel seams, rivets, corrosion, conduits, roof furniture and a
 * dust-loaded base, so it reads as a maintained-but-tired piece of frontier
 * infrastructure rather than a box with a door.
 */

export interface BuildingBake {
  sprite: PixelSurface;
  origin: { x: number; y: number };
  /** world-space anchor points of emissive elements, for the lighting pass */
  emitters: { x: number; y: number; kind: 'door' | 'sign' | 'screen' | 'beacon' | 'porch' }[];
}

const CREAM: MassColors = {
  front: [metal.m7, metal.m5, metal.m3],
  top: [mix(metal.m9, dust.d8, 0.32), mix(metal.m7, dust.d7, 0.32)],
  east: [metal.m2, metal.m1],
  rim: mix(metal.mA, amber.a7, 0.25),
  edge: metal.m1,
};
const CREAM_DIRTY: MassColors = {
  front: [metal.m6, metal.m4, metal.m2],
  top: [mix(metal.m8, dust.d7, 0.4), mix(metal.m6, dust.d6, 0.4)],
  east: [metal.m1, metal.m0],
  rim: mix(metal.m9, amber.a6, 0.2),
  edge: metal.m0,
};
const RUSTY: MassColors = {
  front: [rust.x5, rust.x4, rust.x2],
  top: [mix(rust.x7, dust.d7, 0.3), mix(rust.x5, dust.d6, 0.3)],
  east: [rust.x2, rust.x1],
  rim: mix(rust.x8, amber.a6, 0.2),
  edge: rust.x0,
};

const ORIGIN = { x: 196, y: 182 };
const SW = 312;
const SH = 196;

const wx = (x: number) => x - ORIGIN.x;
const wy = (y: number) => y - ORIGIN.y;

export function bakeBuilding(): BuildingBake {
  const s = new PixelSurface(SW, SH);
  const rnd = makeRng(6601);
  const emitters: BuildingBake['emitters'] = [];

  // ---------------------------------------------------------- west wing
  drawMass(s, wx(B.westWing.x), wy(B.westWing.y), B.westWing.w, B.westWing.h, B.westWing.d, CREAM_DIRTY, { dust: dust.d5, dustAmount: 0.8 });
  {
    const x = wx(B.westWing.x);
    const y = wy(B.westWing.y);
    const w = B.westWing.w;
    const h = B.westWing.h;
    panelSeams(s, x, y - h, w, h, metal.m3, metal.m7, [14, 30], [12, 26]);
    // two small crew windows
    window(s, x + 6, y - h + 8, 12, 10, false);
    window(s, x + 26, y - h + 8, 12, 10, false);
    // wall vent + conduit
    ventGrille(s, x + 8, y - 14, 14, 8, metal.m2, metal.m5);
    pipeRun(s, [
      [x + 40, y - h + 4],
      [x + 40, y - 6],
    ], 3, metal.m2, metal.m4, metal.m6, metal.m3);
    // roof: solar-ish panel array
    const rx = x + 4;
    const ry = y - h;
    for (let i = 0; i < 3; i++) {
      const qx = rx + 2 + i * 13;
      s.polygon(floorQuad(qx, ry - 2, 11, 16), teal.t1);
      for (let k = 0; k < 4; k++) {
        const [ax, ay] = [qx + 1 + (k / 4) * 13 * 0 + k * 0.8, ry - 3 - k * 2];
        s.line(Math.round(ax), Math.round(ay), Math.round(ax + 9), Math.round(ay), teal.t3);
      }
      s.polygon(floorQuad(qx, ry - 2, 11, 16), withAlpha(cyan.c1, 40));
      s.set(qx + 3, ry - 8, cyan.c4);
    }
    rivets(s, x + 2, y - h + 2, w - 4, h - 4, metal.m3, metal.m8, 6);
    weatherSpeckle(s, x, y - h, w, h, [metal.m4, rust.x3, dust.d4], 0.02, rnd);
  }

  // ---------------------------------------------------------- main hall
  drawMass(s, wx(B.hall.x), wy(B.hall.y), B.hall.w, B.hall.h, B.hall.d, CREAM, { dust: dust.d5, dustAmount: 0.9 });
  {
    const x = wx(B.hall.x);
    const y = wy(B.hall.y);
    const w = B.hall.w;
    const h = B.hall.h;
    // panel grid
    panelSeams(s, x, y - h, w, h, metal.m4, metal.m8, [24, 52, 80, 108, 132], [14, 30, 44]);
    rivets(s, x + 3, y - h + 3, w - 6, h - 6, metal.m4, metal.m9, 7);
    // clerestory window band
    window(s, x + 10, y - h + 10, 30, 13, true);
    window(s, x + 96, y - h + 10, 40, 13, true);
    // hull number
    drawText(s, x + 52, y - h + 26, '07', mix(metal.m2, slate.s4, 0.4), { scale: 2, worn: 0.3, seed: 7 });
    drawText(s, x + 52, y - h + 25, '07', mix(metal.m5, slate.s6, 0.3), { scale: 2, worn: 0.35, seed: 7 });
    // corrosion under the seams
    rustRun(s, x + 45, y - h + 25, 26, [rust.x4, rust.x3, rust.x2], 2, 1);
    rustRun(s, x + 90, y - h + 25, 32, [rust.x4, rust.x3, rust.x2], 2, 2);
    rustRun(s, x + 120, y - h + 31, 20, [rust.x3, rust.x2], 2, 3);
    rustRun(s, x + 8, y - h + 25, 18, [rust.x3, rust.x2], 2, 8);
    // wall lamp over the walkway
    s.rect(x + 66, y - 22, 5, 3, metal.m2);
    s.set(x + 68, y - 20, amber.a5);
    emitters.push({ x: B.hall.x + 68, y: B.hall.y - 20, kind: 'porch' });
    // conduit run across the facade
    pipeRun(
      s,
      [
        [x + 2, y - 8],
        [x + 44, y - 8],
        [x + 44, y - h + 20],
        [x + 92, y - h + 20],
      ],
      2,
      metal.m2,
      metal.m5,
      metal.m8,
      metal.m3,
    );
    cable(s, x + 92, y - h + 21, x + 140, y - h + 26, 5, metal.m1, metal.m4);

    // -------- roof furniture on the hall
    const ry = y - h;
    const kx = Math.round(0.34 * B.hall.d);
    const ky = Math.round(0.6 * B.hall.d);
    // roof dust + panel seams (sheared)
    for (let i = 0; i < 4; i++) {
      const t = i / 3;
      s.line(x + Math.round(kx * t), ry - Math.round(ky * t), x + w + Math.round(kx * t), ry - Math.round(ky * t), mix(metal.m6, metal.m8, 0.5));
    }
    for (let i = 0; i < 5; i++) {
      const t = i / 4;
      s.line(x + Math.round(w * t), ry, x + Math.round(w * t) + kx, ry - ky, metal.m6);
    }
    // hatch
    s.polygon(floorQuad(x + 18, ry - 6, 16, 12), metal.m5);
    s.polygon(floorQuad(x + 20, ry - 7, 12, 9), metal.m3);
    s.set(x + 22, ry - 10, metal.m8);
    // AC / vent unit
    s.polygon(floorQuad(x + 60, ry - 4, 22, 16), metal.m4);
    s.rect(x + 60, ry - 4 - 8, 22, 8, metal.m5);
    s.hline(x + 60, ry - 4 - 8, 22, metal.m8);
    ventGrille(s, x + 62, ry - 4 - 6, 18, 5, metal.m2, metal.m6);
    // exhaust stack (animated steam later)
    s.rect(x + 96, ry - 22, 7, 20, metal.m4);
    s.vline(x + 96, ry - 22, 20, metal.m7);
    s.vline(x + 102, ry - 22, 20, metal.m2);
    s.rect(x + 94, ry - 25, 11, 4, metal.m3);
    s.hline(x + 94, ry - 25, 11, metal.m7);
    emitters.push({ x: B.hall.x + 99, y: B.hall.y - B.hall.h - 24, kind: 'screen' });
    // pipe run across the roof
    pipeRun(
      s,
      [
        [x + 120, ry - 6],
        [x + 140, ry - 6],
        [x + 140, ry - 16],
      ],
      3,
      metal.m2,
      metal.m5,
      metal.m8,
      metal.m3,
    );
    // dust drifts + stain blooms across the roof
    for (let px = 0; px < w + kx; px++) {
      if (bayer8(px, 3) < 0.5) s.set(x + px + Math.round(kx * 0.9), ry - ky + Math.round(valueNoise(px / 7, 1, 4) * 2), dust.d6);
      const n = valueNoise(px / 9, 2, 12);
      if (n > 0.62 && bayer4(px, 1) < 0.6) s.set(x + px + Math.round(kx * 0.5), ry - Math.round(ky * 0.5), mix(dust.d6, dust.d5, 0.5));
    }
    for (let i = 0; i < 5; i++) {
      const bx = x + 8 + Math.floor(rnd() * (w - 20));
      const by = ry - 4 - Math.floor(rnd() * (ky - 6));
      for (let dy2 = 0; dy2 < 5; dy2++)
        for (let dx2 = 0; dx2 < 7; dx2++) {
          const d = Math.hypot(dx2 / 7 - 0.5, dy2 / 5 - 0.5);
          if (d < 0.5 && bayer4(dx2, dy2) < 0.7) s.set(bx + dx2, by + dy2, mix(metal.m5, dust.d5, 0.6));
        }
    }
    weatherSpeckle(s, x, ry - ky, w + kx, ky + 4, [dust.d6, metal.m5, rust.x4], 0.035, rnd);
  }

  // ---------------------------------------------------------- east garage
  drawMass(s, wx(B.garage.x), wy(B.garage.y), B.garage.w, B.garage.h, B.garage.d, CREAM_DIRTY, { dust: dust.d6, dustAmount: 1 });
  {
    const x = wx(B.garage.x);
    const y = wy(B.garage.y);
    const w = B.garage.w;
    const h = B.garage.h;
    panelSeams(s, x, y - h, w, h, metal.m3, metal.m7, [16, 58], [10]);
    // rolling shutter
    const sx = x + 20;
    const sy = y - h + 8;
    const sw = 36;
    const sh = h - 10;
    s.rect(sx - 2, sy - 2, sw + 4, sh + 2, metal.m2);
    for (let i = 0; i < sh; i += 3) {
      s.hline(sx, sy + i, sw, i % 6 === 0 ? metal.m4 : metal.m5);
      s.hline(sx, sy + i + 1, sw, metal.m2);
    }
    s.hline(sx, sy + sh - 3, sw, hazard.h2);
    s.hline(sx, sy + sh - 2, sw, metal.m1);
    s.rect(sx - 2, sy - 2, sw + 4, 2, metal.m6);
    // hazard chevrons beside the shutter
    hazardStripes(s, x + 2, y - 10, 14, 6, hazard.h1, metal.m2, 6);
    stencilPlate(s, x + 60, y - h + 12, 'B2', metal.m3, metal.m1, metal.m7, 0.3);
    rustRun(s, x + 17, y - h + 10, 26, [rust.x3, rust.x2], 2, 4);
    rustRun(s, x + 57, y - h + 10, 20, [rust.x4, rust.x3], 2, 5);
    // roof fan housing (animated) + tank
    const ry = y - h;
    s.polygon(floorQuad(x + 8, ry - 3, 18, 14), metal.m4);
    s.ellipse(x + 17, ry - 12, 8, 4, metal.m3);
    s.ellipse(x + 17, ry - 13, 6, 3, metal.m1);
    s.polygon(floorQuad(x + 40, ry - 2, 24, 12), metal.m5);
    s.ellipse(x + 52, ry - 10, 10, 4, metal.m6);
    s.ellipse(x + 52, ry - 11, 8, 3, metal.m8);
    weatherSpeckle(s, x, ry - 20, w + 12, 24, [dust.d6, metal.m4, rust.x3], 0.03, rnd);
  }

  // ---------------------------------------------------------- tech module
  drawMass(s, wx(B.module.x), wy(B.module.y), B.module.w, B.module.h, B.module.d, RUSTY, { dust: dust.d5, dustAmount: 0.7 });
  {
    const x = wx(B.module.x);
    const y = wy(B.module.y);
    const w = B.module.w;
    const h = B.module.h;
    // vertical ribs (low contrast so they read as metal, not wood)
    for (let px = 3; px < w - 2; px += 5) {
      s.vline(x + px, y - h + 3, h - 6, mix(rust.x3, rust.x2, 0.6));
      s.vline(x + px + 1, y - h + 3, h - 6, mix(rust.x5, rust.x4, 0.6));
    }
    // mismatched patch panels break the stripe rhythm
    s.rect(x + 16, y - h + 40, 15, 14, mix(rust.x3, metal.m3, 0.35));
    s.strokeRect(x + 16, y - h + 40, 15, 14, rust.x1);
    bolts(s, x + 17, y - h + 41, rust.x1, rust.x6);
    bolts(s, x + 28, y - h + 51, rust.x1, rust.x6);
    s.rect(x + 40, y - h + 52, 16, 10, mix(rust.x4, metal.m4, 0.3));
    s.strokeRect(x + 40, y - h + 52, 16, 10, rust.x1);
    // broad grime bloom at the base
    for (let px = 0; px < w; px++) {
      for (let i = 0; i < 10; i++) {
        if (bayer8(px * 3, i * 5) < i / 11) s.set(x + px, y - 3 - i, mix(rust.x1, warm.w1, 0.5));
      }
    }
    s.hline(x, y - h + 3, w, rust.x6);
    s.hline(x, y - 4, w, rust.x1);
    // horizontal band with stencil
    s.rect(x, y - h + 26, w, 10, rust.x2);
    s.hline(x, y - h + 26, w, rust.x5);
    drawText(s, x + 8, y - h + 29, 'MERIDIAN', mix(rust.x7, metal.m8, 0.35), { worn: 0.12, seed: 11 });
    // tall narrow window slit
    s.rect(x + 8, y - h + 10, 6, 13, teal.t1);
    s.vline(x + 9, y - h + 11, 11, teal.t3);
    s.set(x + 10, y - h + 12, teal.t5);
    s.rect(x + 7, y - h + 9, 8, 1, metal.m6);
    s.rect(x + 7, y - h + 23, 8, 1, metal.m2);
    // status screen next to the door
    s.rect(x + 44, y - 30, 13, 10, metal.m1);
    screenFill(s, x + 45, y - 29, 11, 8, cyan.c0, cyan.c3, cyan.c5, rnd);
    s.strokeRect(x + 44, y - 30, 13, 10, metal.m5);
    emitters.push({ x: B.module.x + 50, y: B.module.y - 25, kind: 'screen' });
    // conduits up the face
    pipeRun(
      s,
      [
        [x + 40, y - 2],
        [x + 40, y - h + 40],
        [x + 30, y - h + 40],
        [x + 30, y - h + 6],
      ],
      2,
      rust.x1,
      rust.x4,
      rust.x6,
      metal.m3,
    );
    cable(s, x + 4, y - h + 42, x + 20, y - h + 46, 4, metal.m0, metal.m4);
    rivets(s, x + 2, y - h + 2, w - 4, h - 4, rust.x1, rust.x7, 6);
    rustRun(s, x + 12, y - h + 36, 40, [rust.x2, rust.x1], 2, 6);
    // roof: antenna + beacon
    const ry = y - h;
    s.polygon(floorQuad(x + 6, ry - 2, 14, 10), rust.x4);
    s.vline(x + 12, ry - 30, 28, metal.m3);
    s.vline(x + 13, ry - 30, 28, metal.m5);
    for (let i = 0; i < 4; i++) {
      s.hline(x + 8 - i, ry - 26 + i * 6, 9 + i * 2 - i * 4 + 4, metal.m4);
    }
    s.set(x + 12, ry - 31, signal.s3);
    emitters.push({ x: B.module.x + 12, y: B.module.y - B.module.h - 31, kind: 'beacon' });
    // small dish
    s.ellipse(x + 40, ry - 12, 7, 5, metal.m5);
    s.ellipse(x + 40, ry - 12, 5, 3, metal.m3);
    s.set(x + 40, ry - 12, metal.m8);
    s.vline(x + 40, ry - 8, 8, metal.m3);
  }

  // ---------------------------------------------------------- porch + door
  {
    const x = wx(B.porch.x);
    const y = wy(B.porch.y);
    const w = B.porch.w;
    // canopy slab
    const ch = B.porch.h;
    s.polygon(floorQuad(x, y - ch, w, B.porch.d), mix(metal.m6, dust.d6, 0.35));
    s.rect(x, y - ch, w, 5, metal.m4);
    s.hline(x, y - ch, w, mix(metal.m8, amber.a6, 0.2));
    s.hline(x, y - ch + 5, w, metal.m1);
    hazardStripes(s, x + 2, y - ch + 1, w - 4, 3, hazard.h2, metal.m2, 5);
    // dark underside + warm light bar
    s.hline(x + 1, y - ch + 6, w - 2, mix(metal.m1, amber.a0, 0.4));
    // posts
    for (const px of [x + 3, x + w - 5]) {
      s.rect(px, y - ch + 4, 3, ch - 4, metal.m4);
      s.vline(px, y - ch + 4, ch - 4, metal.m7);
      s.vline(px + 2, y - ch + 4, ch - 4, metal.m2);
      s.rect(px - 1, y - 3, 5, 3, metal.m3);
    }
    // under-canopy light bar
    s.rect(x + 8, y - ch + 7, w - 16, 2, amber.a2);
    s.hline(x + 9, y - ch + 7, w - 18, amber.a5);
    // shadow the canopy throws on the module face
    for (let i = 0; i < 5; i++) {
      for (let px = 0; px < w; px++) if (bayer4(px, i) < 1 - i / 5) s.set(x + px, y - ch + 9 + i, withAlpha(rust.x1, 150));
    }
    emitters.push({ x: B.porch.x + w / 2, y: B.porch.y - ch + 6, kind: 'porch' });
  }
  // door recess + blast door
  {
    const x = wx(B.door.x);
    const y = wy(B.door.y);
    const w = B.door.w;
    const h = B.door.h;
    s.rect(x - 2, y - h - 2, w + 4, h + 2, rust.x1);
    s.rect(x, y - h, w, h, slate.s1);
    // two sliding leaves, slightly ajar showing lit interior seam
    s.rect(x, y - h, w / 2 - 1, h, metal.m3);
    s.rect(x + w / 2 + 1, y - h, w / 2 - 1, h, metal.m2);
    for (let i = 0; i < h; i += 4) {
      s.hline(x, y - h + i, w / 2 - 1, metal.m4);
      s.hline(x + w / 2 + 1, y - h + i, w / 2 - 1, metal.m3);
    }
    // vision slits
    s.rect(x + 3, y - h + 6, 4, 6, teal.t1);
    s.set(x + 4, y - h + 7, amber.a3);
    s.rect(x + w - 7, y - h + 6, 4, 6, teal.t1);
    s.set(x + w - 6, y - h + 7, amber.a3);
    hazardStripes(s, x + 1, y - 5, w / 2 - 2, 3, hazard.h1, metal.m2, 5);
    hazardStripes(s, x + w / 2 + 1, y - 5, w / 2 - 2, 3, hazard.h1, metal.m2, 5);
    s.vline(x + w / 2 - 1, y - h, h, metal.m5);
    s.vline(x + w / 2 + 1, y - h, h, metal.m4);
    s.vline(x + w / 2, y - h, h, amber.a5);
    s.hline(x, y - h, w, metal.m6);
    // door lamp
    s.rect(x + w / 2 - 3, y - h - 5, 7, 3, metal.m2);
    s.set(x + w / 2, y - h - 3, amber.a5);
    emitters.push({ x: B.door.x + w / 2, y: B.door.y - h - 3, kind: 'door' });
    // steps
    for (let i = 0; i < 3; i++) {
      const sw = w + 8 + i * 6;
      const sx = Math.round(x + w / 2 - sw / 2);
      const sy = y + i * 3;
      s.polygon(floorQuad(sx, sy + 3, sw, 4), mix(metal.m3, dust.d3, 0.35 + i * 0.18));
      s.hline(sx, sy + 3, sw, mix(metal.m5, dust.d6, 0.35 + i * 0.2));
      s.hline(sx, sy + 4, sw, mix(metal.m4, dust.d4, 0.3 + i * 0.2));
      s.hline(sx, sy + 6, sw, mix(metal.m1, dust.d1, 0.4));
      // shadow each tread casts on the one below
      for (let px = 0; px < sw; px++) if (bayer4(px, i) < 0.5) s.set(sx + px, sy + 5, withAlpha(metal.m1, 160));
    }
    // handrails
    for (const sgn of [-1, 1]) {
      const rx = x + w / 2 + sgn * (w / 2 + 6);
      s.vline(rx, y - 8, 10, metal.m5);
      s.vline(rx + (sgn > 0 ? 1 : -1), y - 5, 7, metal.m4);
      s.hline(Math.min(rx, rx + sgn * 2) - 1, y - 8, 4, metal.m6);
    }
  }

  // ------------------------------------------------- base plinth + grime
  for (const m of [B.westWing, B.hall, B.module, B.garage]) {
    const x = wx(m.x);
    const y = wy(m.y);
    s.hline(x - 1, y - 3, m.w + 2, mix(slate.s2, warm.w2, 0.5));
    s.hline(x - 1, y - 2, m.w + 2, mix(slate.s1, warm.w1, 0.5));
    for (let px = 0; px < m.w; px++) {
      if (bayer4(px, y) < 0.5) s.set(x + px, y - 1, dust.d4);
    }
    bolts(s, x + 3, y - 6, metal.m2, metal.m7);
    bolts(s, x + m.w - 5, y - 6, metal.m2, metal.m7);
  }

  // ------------------------------------------------- silhouette clean-up
  s.outline(withAlpha(mix(metal.m0, dust.d0, 0.5), 210), false);

  return { sprite: s, origin: ORIGIN, emitters };
}

/** A framed window on a front face. */
function window(s: PixelSurface, x: number, y: number, w: number, h: number, glow: boolean): void {
  s.rect(x - 1, y - 1, w + 2, h + 2, metal.m2);
  s.hline(x - 1, y - 1, w + 2, metal.m7);
  s.vline(x - 1, y - 1, h + 2, metal.m6);
  s.hline(x - 1, y + h, w + 2, metal.m1);
  for (let py = 0; py < h; py++) {
    for (let px = 0; px < w; px++) {
      const t = py / h;
      let c = mix(teal.t0, teal.t2, t);
      if (bayer4(px, py) < t * 0.6) c = mix(c, teal.t1, 0.6);
      // diagonal reflection, sparse
      if ((px + py * 2) % 13 === 4 && py < h - 2) c = mix(c, teal.t4, 0.55);
      if (glow && py > h - 4 && bayer4(px, py) > 0.45) c = mix(c, cyan.c1, 0.5);
      s.set(x + px, y + py, c);
    }
  }
  // mullions
  for (let px = Math.floor(w / 3); px < w; px += Math.floor(w / 3)) {
    s.vline(x + px, y, h, metal.m3);
    s.vline(x + px + 1, y, h, metal.m6);
  }
  // sill shadow
  s.hline(x - 1, y + h + 1, w + 2, withAlpha(dust.d1, 120));
}

/** Cast shadow of the whole building on the ground (SE sun). */
export function buildingShadow(): { surface: PixelSurface; origin: { x: number; y: number } } {
  const s = new PixelSurface(SW + 90, SH + 60);
  const ox = ORIGIN.x;
  const oy = ORIGIN.y;
  const L = { x: 0.95, y: 0.34 };
  const masses = [B.westWing, B.hall, B.module, B.garage];
  for (const m of masses) {
    const kx = 0.34 * m.d;
    const ky = 0.6 * m.d;
    const hEff = m.h * 0.8;
    const dx = hEff * L.x;
    const dy = hEff * L.y;
    // footprint quad pushed along the shadow vector
    const base: number[][] = [
      [m.x, m.y],
      [m.x + m.w, m.y],
      [m.x + m.w + kx, m.y - ky],
      [m.x + kx, m.y - ky],
    ];
    const far = base.map((p) => [p[0] + dx, p[1] + dy]);
    // draw the union hull as two quads + footprint
    s.polygon(base.map((p) => [p[0] - ox, p[1] - oy]), packRGBA(36, 21, 19, 132));
    s.polygon(
      [
        [base[0][0] - ox, base[0][1] - oy],
        [base[1][0] - ox, base[1][1] - oy],
        [far[1][0] - ox, far[1][1] - oy],
        [far[0][0] - ox, far[0][1] - oy],
      ],
      packRGBA(36, 21, 19, 132),
    );
    s.polygon(
      [
        [base[1][0] - ox, base[1][1] - oy],
        [base[2][0] - ox, base[2][1] - oy],
        [far[2][0] - ox, far[2][1] - oy],
        [far[1][0] - ox, far[1][1] - oy],
      ],
      packRGBA(36, 21, 19, 132),
    );
  }
  // dither the outer edge so it never looks like a hard decal
  for (let y = 0; y < s.height; y++) {
    for (let x = 0; x < s.width; x++) {
      const i = y * s.width + x;
      if ((s.data[i] >>> 24) === 0) continue;
      let outside = false;
      for (const o of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
        [2, 0],
        [0, 2],
      ]) {
        const nx = x + o[0];
        const ny = y + o[1];
        if (nx < 0 || ny < 0 || nx >= s.width || ny >= s.height || (s.data[ny * s.width + nx] >>> 24) === 0) outside = true;
      }
      if (outside && bayer8(x, y) < 0.62) s.data[i] = 0;
    }
  }
  return { surface: s, origin: { x: ox - 0, y: oy - 0 } };
}
