import { mix, packRGBA, withAlpha } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { makeRng, valueNoise } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, dust, grime, hazard, metal, olive, rust, signal, slate, teal, warm } from '../data/palette';
import { PROJ, ROOM_H, ROOM_W } from '../data/config';
import { bolts, cable, hazardStripes, panelSeams, pipeRun, rivets, rustRun, screenFill, ventGrille, weatherSpeckle } from '../rendering/detail';
import { drawText, stencilPlate } from '../rendering/text';
import type { LightDef } from '../lighting/LightingSystem';

/**
 * INTERIOR of the outpost module — one room that works for a living.
 *
 * Console bank with live screens, server racks with blinking LEDs, lockers,
 * a weapon rack, a workbench with a half-stripped drone, a holo table, a bunk
 * with a blanket, storage shelving, floor cable trays, stains, stencils and
 * ceiling light cones. The walls carry the house style (slate panels + orange
 * industrial stripe + conduits) so inside and outside read as one world.
 */

export interface InteriorBake {
  surface: PixelSurface;
  lights: LightDef[];
  screens: { x: number; y: number; w: number; h: number; seed: number }[];
  leds: { x: number; y: number; c: number; period: number }[];
  holo: { x: number; y: number };
}

const WALL_X0 = 14;
const WALL_X1 = ROOM_W - 14;
const WALL_Y0 = 12;
const WALL_Y1 = ROOM_H - 12;
const KX = Math.round(PROJ.kx * 22);

export function bakeInterior(): InteriorBake {
  const s = new PixelSurface(ROOM_W, ROOM_H);
  const rnd = makeRng(31337);
  const screens: InteriorBake['screens'] = [];
  const leds: InteriorBake['leds'] = [];
  const lights: LightDef[] = [];

  // ------------------------------------------------------------ floor
  for (let y = WALL_Y0; y < WALL_Y1; y++) {
    for (let x = WALL_X0; x < WALL_X1; x++) {
      const pxI = (x / 18) | 0;
      const pyI = (y / 18) | 0;
      const hash = ((pxI * 73856093) ^ (pyI * 19349663)) >>> 0;
      let c = mix(slate.s4, (hash & 1) ? slate.s3 : slate.s5, 0.22 + ((hash >>> 3) & 3) * 0.06);
      const n = valueNoise(x / 7, y / 7, 5);
      if (n > 0.66) c = mix(c, slate.s5, 0.35);
      if (n < 0.3) c = mix(c, slate.s3, 0.45);
      if (x % 18 === 0 || y % 18 === 0) c = mix(c, slate.s2, 0.6);
      if (x % 18 === 1 || y % 18 === 1) c = mix(c, slate.s6, 0.22);
      s.set(x, y, c);
    }
  }
  // central grating walkway
  const gw0 = ROOM_W / 2 - 26;
  const gw1 = ROOM_W / 2 + 26;
  for (let y = WALL_Y0 + 6; y < WALL_Y1 - 4; y++) {
    for (let x = gw0; x < gw1; x++) {
      if ((x + y) % 4 === 0) s.set(x, y, slate.s3);
      else if ((x + y) % 4 === 2) s.set(x, y, slate.s5);
      else s.set(x, y, slate.s4);
      if (y % 9 === 0) s.set(x, y, slate.s2);
    }
  }
  s.strokeRect(gw0, WALL_Y0 + 6, gw1 - gw0, WALL_Y1 - WALL_Y0 - 10, slate.s2);
  s.hline(gw0, WALL_Y0 + 6, gw1 - gw0, slate.s6);
  // stains + scuffs
  for (let i = 0; i < 14; i++) {
    const cx = rnd.int(WALL_X0 + 16, WALL_X1 - 16);
    const cy = rnd.int(WALL_Y0 + 16, WALL_Y1 - 12);
    const r = rnd.int(4, 11);
    for (let y = -r; y <= r; y++)
      for (let x = -r; x <= r; x++) {
        const d = Math.hypot(x / r, y / (r * 0.7));
        if (d > 1) continue;
        if (d > 0.5 && bayer8(cx + x, cy + y) < d - 0.4) continue;
        s.set(cx + x, cy + y, mix(s.get(cx + x, cy + y), grime.g2, 0.42));
      }
  }
  // painted markings
  hazardStripes(s, ROOM_W / 2 - 30, WALL_Y1 - 10, 60, 4, hazard.h2, slate.s3, 6);
  drawText(s, WALL_X0 + 12, WALL_Y1 - 24, 'DECK 1 / MODULE 07', mix(slate.s7, slate.s5, 0.4), { worn: 0.45, seed: 3 });
  drawText(s, ROOM_W / 2 + 40, WALL_Y0 + 20, 'AIRLOCK', mix(hazard.h3, slate.s4, 0.35), { worn: 0.5, seed: 8 });
  for (let i = 0; i < 4; i++) {
    const ax = ROOM_W / 2 + 34;
    const ay = WALL_Y0 + 40 + i * 40;
    s.polygon(
      [
        [ax, ay],
        [ax + 7, ay + 4],
        [ax, ay + 8],
      ],
      mix(hazard.h3, slate.s4, 0.35),
    );
  }

  // ------------------------------------------------------------ walls
  s.rect(0, 0, ROOM_W, WALL_Y0, slate.s2);
  s.rect(WALL_X0, 0, WALL_X1 - WALL_X0, WALL_Y0, slate.s3);
  for (let x = WALL_X0; x < WALL_X1; x++) {
    s.set(x, WALL_Y0 - 1, mix(slate.s6, slate.s5, (x % 24) / 24));
    if (x % 24 === 0) s.vline(x, 1, WALL_Y0 - 2, slate.s2);
    if (bayer4(x, 3) < 0.25) s.set(x, 3, slate.s4);
  }
  // house stripe
  s.rect(WALL_X0, WALL_Y0 - 5, WALL_X1 - WALL_X0, 2, mix(signal.s3, rust.x4, 0.35));
  s.hline(WALL_X0, WALL_Y0 - 5, WALL_X1 - WALL_X0, mix(signal.s4, rust.x5, 0.35));
  // side walls
  s.polygon(
    [
      [0, 0],
      [WALL_X0, 0],
      [WALL_X0 + KX, WALL_Y0],
      [WALL_X0 + KX, WALL_Y1],
      [WALL_X0, ROOM_H],
      [0, ROOM_H],
    ],
    slate.s3,
  );
  s.polygon(
    [
      [ROOM_W, 0],
      [WALL_X1, 0],
      [WALL_X1 - KX, WALL_Y0],
      [WALL_X1 - KX, WALL_Y1],
      [WALL_X1, ROOM_H],
      [ROOM_W, ROOM_H],
    ],
    mix(slate.s3, slate.s2, 0.5),
  );
  for (let y = WALL_Y0; y < WALL_Y1; y++) {
    s.vline(WALL_X0 + KX - 1, y, 1, slate.s6);
    s.vline(WALL_X1 - KX, y, 1, slate.s2);
    if (y % 14 === 0) {
      s.hline(WALL_X0, y, KX + 2, mix(slate.s2, slate.s3, 0.5));
      s.hline(WALL_X1 - KX - 2, y, KX + 2, slate.s2);
    }
  }
  s.rect(WALL_X0, WALL_Y0 - 5, KX, 2, mix(signal.s2, rust.x3, 0.5));
  s.rect(WALL_X1 - KX, WALL_Y0 - 5, KX, 2, mix(signal.s2, rust.x3, 0.5));
  // bottom wall + airlock surround
  s.rect(0, WALL_Y1, ROOM_W, ROOM_H - WALL_Y1, slate.s2);
  s.rect(0, WALL_Y1, ROOM_W, 3, slate.s4);
  for (let x = 0; x < ROOM_W; x++) if (x % 20 === 0) s.vline(x, WALL_Y1 + 3, ROOM_H - WALL_Y1 - 3, slate.s2);

  // conduits along the top wall
  pipeRun(
    s,
    [
      [WALL_X0 + 2, 3],
      [WALL_X1 - 40, 3],
      [WALL_X1 - 40, 8],
    ],
    2,
    slate.s2,
    slate.s5,
    slate.s7,
    slate.s3,
  );
  pipeRun(
    s,
    [
      [WALL_X0 + 2, 7],
      [WALL_X0 + 90, 7],
    ],
    3,
    slate.s2,
    slate.s4,
    slate.s6,
    slate.s3,
  );
  cable(s, WALL_X0 + 100, 8, WALL_X0 + 170, 10, 3, slate.s1, slate.s5);
  // ceiling pipe crossing the room (on the floor plane, reads as overhead)
  for (let x = WALL_X0 + KX; x < WALL_X1 - KX; x++) {
    if (x % 40 < 2) continue;
    s.set(x, WALL_Y0 + 2, mix(slate.s5, slate.s4, 0.5));
    s.set(x, WALL_Y0 + 3, slate.s3);
  }

  // ------------------------------------------------------------ viewport
  {
    const vx = ROOM_W / 2 - 60;
    const vy = 2;
    const vw = 120;
    const vh = 8;
    s.rect(vx - 2, vy - 1, vw + 4, vh + 3, slate.s2);
    for (let y = 0; y < vh; y++) {
      for (let x = 0; x < vw; x++) {
        const t = y / vh;
        let c = mix(dust.d6, dust.d4, t);
        const dune = valueNoise((vx + x) / 26, 1, 9);
        if (y > 3 + dune * 3) c = mix(c, dust.d2, 0.5);
        if (y < 2) c = mix(c, dust.d8, 0.4);
        if (bayer4(x, y) < 0.2) c = mix(c, dust.d7, 0.3);
        s.set(vx + x, vy + y, c);
      }
    }
    for (let x = 0; x < vw; x++) {
      const hgt = 3 + Math.round(valueNoise((vx + x) / 15, 4, 2) * 3);
      s.set(vx + x, vy + hgt, mix(dust.d1, rockC(), 0.4));
    }
    s.vline(vx + 82, vy + 1, 4, slate.s5);
    s.strokeRect(vx - 2, vy - 1, vw + 4, vh + 3, slate.s6);
    s.hline(vx - 2, vy - 1, vw + 4, slate.s7);
    for (const mx of [vx + 40, vx + 80]) s.vline(mx, vy, vh, slate.s3);
    for (let i = 0; i < vw; i += 9) s.line(vx + i, vy + vh - 1, vx + i + 5, vy, withAlpha(slate.s7, 36));
  }

  // ------------------------------------------------------------ console bank (left)
  {
    const cx = WALL_X0 + KX + 6;
    const cy = WALL_Y0 + 34;
    for (let i = 0; i < 3; i++) {
      const y = cy + i * 52;
      s.rect(cx, y, 42, 18, slate.s4);
      s.hline(cx, y, 42, slate.s6);
      s.vline(cx, y, 18, slate.s5);
      s.hline(cx, y + 17, 42, slate.s2);
      s.polygon(
        [
          [cx, y],
          [cx + 42, y],
          [cx + 42 + 6, y - 4],
          [cx + 6, y - 4],
        ],
        slate.s5,
      );
      s.rect(cx + 5, y - 14, 32, 11, slate.s2);
      screenFill(s, cx + 6, y - 13, 30, 9, cyan.c0, cyan.c2, cyan.c4, rnd);
      s.strokeRect(cx + 5, y - 14, 32, 11, slate.s6);
      s.hline(cx + 5, y - 14, 32, slate.s7);
      screens.push({ x: cx + 6, y: y - 13, w: 30, h: 9, seed: i * 7 + 1 });
      lights.push({ x: cx + 22, y: y - 8, radius: 26, r: 0.25, g: 0.85, b: 0.9, intensity: 0.55, flicker: 0.08 });
      s.rect(cx + 8, y + 3, 22, 5, slate.s3);
      for (let k = 0; k < 10; k++) s.set(cx + 9 + k * 2, y + 4 + (k % 2), slate.s6);
      s.set(cx + 34, y + 4, mix(olive.o4, rust.x4, 0.3));
      s.set(cx + 34, y + 3, mix(olive.o5, rust.x5, 0.3));
      s.set(cx + 37, y + 5, amber.a4);
      s.ellipse(cx + 18, y + 26, 6, 3, slate.s3);
      s.ellipse(cx + 18, y + 25, 5, 2, slate.s5);
      s.set(cx + 18, y + 28, slate.s2);
      panelSeams(s, cx, y, 42, 18, slate.s3, slate.s6, [14, 28], [9]);
      rustRun(s, cx + 40, y + 2, 12, [rust.x3, rust.x2], 1, i + 2);
    }
  }

  // ------------------------------------------------------------ server racks (right)
  {
    const rx = WALL_X1 - KX - 26;
    for (let r = 0; r < 2; r++) {
      const y = WALL_Y0 + 30 + r * 92;
      s.rect(rx, y, 24, 74, slate.s3);
      s.strokeRect(rx, y, 24, 74, slate.s2);
      s.hline(rx, y, 24, slate.s6);
      s.vline(rx, y, 74, slate.s5);
      for (let u = 0; u < 15; u++) {
        const uy = y + 3 + u * 4.6;
        s.rect(rx + 2, uy, 20, 3, u % 3 === 0 ? slate.s4 : slate.s3);
        s.hline(rx + 2, uy, 20, slate.s5);
        ventGrille(s, rx + 3, uy + 1, 9, 2, slate.s2, slate.s5);
        for (let l = 0; l < 3; l++) {
          const lx = rx + 16 + l * 2;
          const col = l === 0 ? cyan.c3 : l === 1 ? amber.a4 : signal.s3;
          leds.push({ x: lx, y: Math.round(uy + 1), c: col, period: 0.4 + ((u * 3 + l * 7 + r * 5) % 9) * 0.23 });
          s.set(lx, Math.round(uy + 1), mix(col, slate.s2, 0.65));
        }
      }
      cable(s, rx + 4, y, rx - 8, y - 10, 3, slate.s1, slate.s5);
      cable(s, rx + 12, y, rx + 2, y - 12, 4, slate.s1, slate.s4);
    }
    lights.push({ x: rx + 12, y: WALL_Y0 + 70, radius: 22, r: 0.2, g: 0.7, b: 0.8, intensity: 0.35, flicker: 0.15 });
  }

  // ------------------------------------------------------------ lockers + weapon rack
  {
    const lx = WALL_X1 - KX - 56;
    const ly = WALL_Y1 - 62;
    for (let i = 0; i < 4; i++) {
      const x = lx + i * 12;
      s.rect(x, ly, 11, 36, i === 1 ? mix(slate.s4, teal.t2, 0.3) : slate.s4);
      s.strokeRect(x, ly, 11, 36, slate.s2);
      s.vline(x, ly, 36, slate.s6);
      ventGrille(s, x + 2, ly + 3, 7, 5, slate.s2, slate.s5);
      s.set(x + 8, ly + 18, metal.m7);
      stencilPlate(s, x + 1, ly + 26, String(i + 1), slate.s3, slate.s2, slate.s7, 0.3);
    }
    const wx = WALL_X0 + 60;
    s.rect(wx, WALL_Y1 - 18, 40, 5, slate.s4);
    s.hline(wx, WALL_Y1 - 18, 40, slate.s6);
    s.hline(wx, WALL_Y1 - 14, 40, slate.s2);
    for (let i = 0; i < 2; i++) {
      const gx = wx + 7 + i * 18;
      s.rect(gx, WALL_Y1 - 16, 14, 2, warm.w2);
      s.hline(gx, WALL_Y1 - 16, 14, warm.w4);
      s.rect(gx + 12, WALL_Y1 - 15, 4, 1, warm.w5);
      s.rect(gx + 4, WALL_Y1 - 14, 2, 4, warm.w1);
      s.set(gx + 8, WALL_Y1 - 15, cyan.c3);
    }
    drawText(s, wx, WALL_Y1 - 24, 'ARMORY', mix(slate.s7, slate.s5, 0.3), { worn: 0.4, seed: 5 });
  }

  // ------------------------------------------------------------ workbench (top right)
  {
    const bx = WALL_X1 - KX - 118;
    const by = WALL_Y0 + 16;
    s.rect(bx, by, 56, 16, warm.w4);
    s.hline(bx, by, 56, warm.w6);
    s.hline(bx, by + 15, 56, warm.w2);
    s.polygon(
      [
        [bx, by],
        [bx + 56, by],
        [bx + 56 + 5, by - 3],
        [bx + 5, by - 3],
      ],
      warm.w5,
    );
    // half-stripped drone
    s.ellipse(bx + 14, by + 6, 7, 4, metal.m5);
    s.ellipse(bx + 14, by + 5, 5, 3, metal.m7);
    s.set(bx + 14, by + 5, cyan.c2);
    s.set(bx + 12, by + 4, metal.m2);
    s.rect(bx + 24, by + 4, 10, 5, metal.m4);
    s.hline(bx + 24, by + 4, 10, metal.m7);
    s.rect(bx + 26, by + 6, 3, 2, warm.w1);
    // tools + parts tray
    for (let i = 0; i < 6; i++) {
      const tx = bx + 38 + (i % 3) * 5;
      const ty = by + 4 + Math.floor(i / 3) * 5;
      s.rect(tx, ty, 4, 1, i % 2 ? metal.m6 : warm.w5);
      s.set(tx + 4, ty, warm.w2);
    }
    s.rect(bx + 36, by + 10, 16, 5, slate.s3);
    s.strokeRect(bx + 36, by + 10, 16, 5, slate.s2);
    s.set(bx + 39, by + 12, metal.m6);
    s.set(bx + 43, by + 12, rust.x4);
    // task lamp
    s.vline(bx + 52, by - 10, 10, metal.m4);
    s.rect(bx + 48, by - 12, 7, 3, metal.m5);
    s.hline(bx + 49, by - 10, 5, amber.a6);
    lights.push({ x: bx + 50, y: by - 4, radius: 30, r: 1, g: 0.72, b: 0.38, intensity: 0.6, flicker: 0.05 });
    s.ellipse(bx + 26, by + 24, 5, 3, slate.s4);
    s.set(bx + 26, by + 26, slate.s2);
  }

  // ------------------------------------------------------------ storage shelf (mid right)
  {
    const sx = WALL_X1 - KX - 60;
    const sy = WALL_Y0 + 120;
    s.rect(sx, sy, 40, 26, slate.s4);
    s.strokeRect(sx, sy, 40, 26, slate.s2);
    for (let r = 0; r < 3; r++) {
      const ry = sy + 3 + r * 8;
      s.hline(sx + 1, ry, 38, slate.s6);
      s.hline(sx + 1, ry + 1, 38, slate.s2);
      for (let b = 0; b < 4; b++) {
        const bxx = sx + 3 + b * 9 + (r % 2) * 3;
        if (bxx > sx + 34) continue;
        const hgt = 4 + ((b + r) % 3);
        s.rect(bxx, ry - hgt, 6, hgt, [olive.o3, mix(rust.x3, slate.s4, 0.4), mix(metal.m4, slate.s4, 0.4), olive.o2][(b + r) % 4]);
        s.hline(bxx, ry - hgt, 6, [olive.o5, rust.x5, metal.m6, olive.o4][(b + r) % 4]);
      }
    }
  }

  // ------------------------------------------------------------ holo table (centre-left)
  const hx = ROOM_W / 2 - 84;
  const hy = ROOM_H / 2 + 20;
  {
    s.ellipse(hx, hy, 18, 9, slate.s3);
    s.ellipse(hx, hy - 1, 17, 8, slate.s5);
    s.ellipse(hx, hy - 2, 15, 7, slate.s4);
    s.ellipse(hx, hy - 2, 11, 5, cyan.c0);
    s.ellipse(hx, hy - 2, 9, 4, cyan.c1);
    lights.push({ x: hx, y: hy - 8, radius: 34, r: 0.2, g: 0.9, b: 1, intensity: 0.6, pulse: 3.1 });
  }

  // ------------------------------------------------------------ crates / canisters / bunk
  {
    for (const [cxx, cyy, w, h] of [
      [WALL_X0 + KX + 8, WALL_Y1 - 34, 18, 14],
      [WALL_X0 + KX + 28, WALL_Y1 - 30, 14, 11],
      [WALL_X0 + KX + 10, WALL_Y1 - 48, 14, 11],
    ]) {
      s.rect(cxx, cyy, w, h, mix(olive.o3, slate.s4, 0.4));
      s.hline(cxx, cyy, w, mix(olive.o5, slate.s6, 0.4));
      s.vline(cxx, cyy, h, mix(olive.o4, slate.s5, 0.4));
      s.hline(cxx, cyy + h - 1, w, slate.s2);
      s.vline(cxx + w - 1, cyy, h, slate.s2);
      s.set(cxx + 2, cyy + 2, metal.m6);
      drawText(s, cxx + 3, cyy + 4, 'K', mix(slate.s7, olive.o5, 0.4), { worn: 0.4 });
    }
    // fuel canisters
    for (let i = 0; i < 2; i++) {
      const cx2 = WALL_X0 + KX + 52 + i * 9;
      const cy2 = WALL_Y1 - 26;
      s.rect(cx2, cy2, 7, 11, mix(rust.x3, slate.s4, 0.3));
      s.vline(cx2, cy2, 11, mix(rust.x5, slate.s5, 0.3));
      s.vline(cx2 + 6, cy2, 11, slate.s2);
      s.hline(cx2, cy2, 7, mix(rust.x6, slate.s6, 0.3));
      s.set(cx2 + 3, cy2 - 1, metal.m6);
      s.hline(cx2 + 1, cy2 + 4, 5, hazard.h2);
    }
    // bunk
    const kx2 = WALL_X0 + KX + 8;
    const ky2 = WALL_Y0 + 168;
    s.rect(kx2, ky2, 30, 16, slate.s4);
    s.rect(kx2 + 1, ky2 + 1, 28, 14, mix(olive.o2, slate.s3, 0.35));
    s.rect(kx2 + 2, ky2 + 2, 7, 12, mix(metal.m7, slate.s6, 0.4));
    for (let i = 0; i < 14; i++) s.set(kx2 + 11 + i, ky2 + 3 + (i % 4), mix(signal.s3, slate.s4, 0.45));
    for (let i = 0; i < 14; i++) s.set(kx2 + 11 + i, ky2 + 4 + (i % 4), mix(signal.s4, slate.s5, 0.4));
    s.strokeRect(kx2, ky2, 30, 16, slate.s2);
    s.hline(kx2, ky2, 30, slate.s6);
    // rug
    for (let y = 0; y < 12; y++)
      for (let x = 0; x < 26; x++) {
        if ((x + y) % 3 === 0) continue;
        s.set(kx2 + 34 + x, ky2 + 2 + y, mix(signal.s1, slate.s3, 0.55));
      }
    s.strokeRect(kx2 + 34, ky2 + 2, 26, 12, mix(signal.s2, slate.s3, 0.5));
  }

  // ------------------------------------------------------------ tool cabinet (left of airlock)
  {
    const tx = ROOM_W / 2 - 96;
    const ty = WALL_Y1 - 40;
    s.rect(tx, ty, 26, 22, slate.s4);
    s.strokeRect(tx, ty, 26, 22, slate.s2);
    s.hline(tx, ty, 26, slate.s6);
    for (let r = 0; r < 4; r++) {
      const ry = ty + 3 + r * 5;
      s.rect(tx + 2, ry, 22, 4, slate.s3);
      s.hline(tx + 2, ry, 22, slate.s5);
      s.hline(tx + 9, ry + 2, 8, metal.m6);
    }
    rustRun(s, tx + 24, ty + 4, 14, [rust.x3, rust.x2], 1, 3);
  }

  // ------------------------------------------------------------ ceiling lights
  for (const [fx, fy] of [
    [ROOM_W / 2 - 110, ROOM_H / 2 - 46],
    [ROOM_W / 2 + 110, ROOM_H / 2 - 46],
    [ROOM_W / 2 - 110, ROOM_H / 2 + 52],
    [ROOM_W / 2 + 110, ROOM_H / 2 + 52],
  ]) {
    s.rect(fx - 9, fy - 2, 18, 5, slate.s3);
    s.strokeRect(fx - 9, fy - 2, 18, 5, slate.s2);
    s.rect(fx - 7, fy - 1, 14, 3, mix(amber.a6, metal.m9, 0.5));
    s.hline(fx - 7, fy - 1, 14, mix(amber.a7, metal.mA, 0.4));
    lights.push({ x: fx, y: fy + 8, radius: 84, r: 1, g: 0.84, b: 0.6, intensity: 0.85, static: true });
  }
  // room fill so slate never goes black
  lights.push({ x: ROOM_W / 2, y: ROOM_H / 2, radius: 240, r: 0.9, g: 0.8, b: 0.66, intensity: 0.5, static: true });

  // ------------------------------------------------------------ airlock (bottom)
  {
    const dx = ROOM_W / 2 - 16;
    s.rect(dx - 5, WALL_Y1 - 2, 42, ROOM_H - WALL_Y1 + 2, slate.s3);
    s.rect(dx, WALL_Y1, 32, ROOM_H - WALL_Y1, slate.s2);
    s.rect(dx + 2, WALL_Y1 + 1, 13, ROOM_H - WALL_Y1 - 1, metal.m4);
    s.rect(dx + 17, WALL_Y1 + 1, 13, ROOM_H - WALL_Y1 - 1, metal.m3);
    for (let i = 0; i < ROOM_H - WALL_Y1; i += 3) {
      s.hline(dx + 2, WALL_Y1 + 1 + i, 13, metal.m5);
      s.hline(dx + 17, WALL_Y1 + 1 + i, 13, metal.m4);
    }
    s.vline(dx + 16, WALL_Y1 + 1, ROOM_H - WALL_Y1 - 1, amber.a5);
    hazardStripes(s, dx - 5, WALL_Y1 - 4, 42, 2, hazard.h2, slate.s3, 6);
    s.rect(dx - 3, WALL_Y1 - 14, 38, 9, mix(slate.s3, olive.o1, 0.4));
    for (let i = 0; i < 34; i += 3) s.hline(dx - 2 + i, WALL_Y1 - 12, 2, slate.s4);
    lights.push({ x: ROOM_W / 2, y: WALL_Y1 - 6, radius: 26, r: 1, g: 0.6, b: 0.3, intensity: 0.5, static: true });
    drawText(s, dx - 4, WALL_Y1 - 20, 'EXIT', mix(hazard.h4, slate.s5, 0.3), { worn: 0.3, seed: 9 });
  }

  // floor cable trays
  cable(s, WALL_X1 - KX - 20, WALL_Y0 + 108, ROOM_W / 2 + 20, WALL_Y0 + 118, 6, slate.s1, slate.s5);
  cable(s, WALL_X0 + KX + 46, WALL_Y0 + 130, ROOM_W / 2 - 20, WALL_Y0 + 140, 5, slate.s1, slate.s4);
  cable(s, ROOM_W / 2 - 60, WALL_Y1 - 30, ROOM_W / 2 - 20, WALL_Y1 - 24, 4, slate.s1, slate.s4);

  // ------------------------------------------------------------ mid-right life: pallet, hand truck, hose, stencil, heater
  {
    const px = ROOM_W / 2 + 96;
    const py = ROOM_H / 2 + 34;
    // pallet
    s.polygon(
      [
        [px, py],
        [px + 40, py],
        [px + 46, py - 5],
        [px + 6, py - 5],
      ],
      warm.w3,
    );
    s.hline(px, py, 40, warm.w5);
    for (let i = 0; i < 4; i++) s.hline(px + 2 + i * 10, py - 2, 6, warm.w1);
    // stacked crates on the pallet
    for (const [cx3, cy3, w3, h3, tone] of [
      [px + 4, py - 16, 16, 12, olive.o3],
      [px + 21, py - 14, 13, 10, mix(rust.x3, slate.s4, 0.4)],
      [px + 9, py - 26, 12, 10, mix(metal.m4, slate.s4, 0.4)],
    ] as [number, number, number, number, number][]) {
      s.rect(cx3, cy3, w3, h3, tone);
      s.hline(cx3, cy3, w3, mix(tone, metal.m8, 0.35));
      s.vline(cx3, cy3, h3, mix(tone, metal.m8, 0.2));
      s.hline(cx3, cy3 + h3 - 1, w3, slate.s2);
      s.vline(cx3 + w3 - 1, cy3, h3, slate.s2);
      s.set(cx3 + 2, cy3 + 2, metal.m6);
    }
    drawText(s, px + 6, py - 12, 'FRG', mix(slate.s7, olive.o5, 0.4), { worn: 0.4 });
    // hand truck
    const tx3 = px + 52;
    s.vline(tx3, py - 18, 18, metal.m4);
    s.vline(tx3 + 1, py - 18, 18, metal.m2);
    s.hline(tx3 - 3, py - 18, 6, metal.m5);
    s.polygon(
      [
        [tx3 - 4, py],
        [tx3 + 6, py],
        [tx3 + 8, py - 3],
        [tx3 - 2, py - 3],
      ],
      metal.m4,
    );
    s.ellipse(tx3 - 3, py - 1, 2, 2, warm.w0);
    s.ellipse(tx3 + 6, py - 1, 2, 2, warm.w0);
    // coiled hose
    for (let i = 0; i < 26; i++) {
      const a = (i / 26) * Math.PI * 4;
      const rr = 5 + (i / 26) * 4;
      const hx3 = Math.round(px - 26 + Math.cos(a) * rr);
      const hy3 = Math.round(py + 16 + Math.sin(a) * rr * 0.5);
      s.set(hx3, hy3, i % 5 === 0 ? slate.s6 : slate.s4);
    }
    // big floor stencil
    s.ellipseOutline(ROOM_W / 2 + 60, ROOM_H / 2 - 30, 26, 14, mix(slate.s6, slate.s4, 0.5));
    s.ellipseOutline(ROOM_W / 2 + 60, ROOM_H / 2 - 30, 24, 12, mix(slate.s6, slate.s4, 0.6));
    drawText(s, ROOM_W / 2 + 52, ROOM_H / 2 - 34, '07', mix(slate.s7, slate.s5, 0.35), { scale: 2, worn: 0.5, seed: 4 });
    // heater unit with a warm glow
    const hx4 = WALL_X1 - KX - 84;
    const hy4 = WALL_Y1 - 34;
    s.rect(hx4, hy4, 14, 18, slate.s4);
    s.strokeRect(hx4, hy4, 14, 18, slate.s2);
    ventGrille(s, hx4 + 2, hy4 + 3, 10, 8, slate.s2, slate.s6);
    s.hline(hx4 + 2, hy4 + 13, 10, amber.a3);
    s.hline(hx4 + 2, hy4 + 14, 10, amber.a5);
    s.set(hx4 + 12, hy4 + 2, cyan.c3);
    lights.push({ x: hx4 + 7, y: hy4 + 14, radius: 26, r: 1, g: 0.55, b: 0.25, intensity: 0.5, flicker: 0.1 });
  }

  // ---- furniture contact shadows
  for (const c of interiorColliders().slice(4)) {
    for (let x = c.x - 1; x < c.x + c.w + 3; x++) {
      for (let y = c.y + c.h - 2; y < c.y + c.h + 5; y++) {
        const d = y - (c.y + c.h - 2);
        if (bayer8(x, y) < d / 7) continue;
        if (x < WALL_X0 || y >= WALL_Y1) continue;
        s.set(x, y, mix(s.get(x, y), grime.g1, 0.5));
      }
    }
    for (let y = c.y; y < c.y + c.h; y++) {
      for (let x = c.x + c.w; x < c.x + c.w + 4; x++) {
        if (bayer8(x, y) < (x - c.x - c.w) / 4) continue;
        if (x >= WALL_X1 - KX) continue;
        s.set(x, y, mix(s.get(x, y), grime.g1, 0.4));
      }
    }
  }

  weatherSpeckle(s, WALL_X0, WALL_Y0, WALL_X1 - WALL_X0, WALL_Y1 - WALL_Y0, [slate.s3, slate.s6, rust.x2], 0.012, rnd);
  bolts(s, WALL_X0 + 4, WALL_Y0 + 4, slate.s2, slate.s7);
  bolts(s, WALL_X1 - 6, WALL_Y0 + 4, slate.s2, slate.s7);
  rivets(s, WALL_X0 + 2, 2, WALL_X1 - WALL_X0 - 4, WALL_Y0 - 4, slate.s2, slate.s6, 9);
  // wall poster / stencil near the airlock
  s.rect(ROOM_W / 2 + 52, WALL_Y1 - 30, 20, 14, mix(slate.s5, teal.t2, 0.2));
  s.strokeRect(ROOM_W / 2 + 52, WALL_Y1 - 30, 20, 14, slate.s2);
  s.ellipse(ROOM_W / 2 + 62, WALL_Y1 - 24, 5, 4, mix(signal.s2, slate.s4, 0.3));
  drawText(s, ROOM_W / 2 + 55, WALL_Y1 - 19, 'SAFE', mix(slate.s7, slate.s5, 0.3), { worn: 0.35 });

  return { surface: s, lights, screens, leds, holo: { x: hx, y: hy } };
}

function rockC(): number {
  return packRGBA(96, 82, 74);
}

/** Interior colliders (room space). */
export function interiorColliders(): { x: number; y: number; w: number; h: number }[] {
  return [
    { x: 0, y: 0, w: ROOM_W, h: WALL_Y0 + KX },
    { x: 0, y: 0, w: WALL_X0 + KX, h: ROOM_H },
    { x: WALL_X1 - KX, y: 0, w: ROOM_W - WALL_X1 + KX, h: ROOM_H },
    { x: 0, y: WALL_Y1 - 2, w: ROOM_W, h: ROOM_H - WALL_Y1 + 2 },
    // console bank
    { x: WALL_X0 + KX + 4, y: WALL_Y0 + 22, w: 50, h: 150 },
    // server racks
    { x: WALL_X1 - KX - 28, y: WALL_Y0 + 28, w: 28, h: 168 },
    // lockers
    { x: WALL_X1 - KX - 58, y: WALL_Y1 - 64, w: 52, h: 38 },
    // workbench
    { x: WALL_X1 - KX - 120, y: WALL_Y0 + 12, w: 60, h: 20 },
    // shelf
    { x: WALL_X1 - KX - 62, y: WALL_Y0 + 118, w: 44, h: 28 },
    // holo table
    { x: ROOM_W / 2 - 102, y: ROOM_H / 2 + 12, w: 36, h: 18 },
    // crates + canisters
    { x: WALL_X0 + KX + 6, y: WALL_Y1 - 50, w: 40, h: 38 },
    // bunk + rug
    { x: WALL_X0 + KX + 6, y: WALL_Y0 + 166, w: 34, h: 18 },
    // tool cabinet
    { x: ROOM_W / 2 - 98, y: WALL_Y1 - 42, w: 30, h: 24 },
    // pallet stack
    { x: ROOM_W / 2 + 94, y: ROOM_H / 2 + 12, w: 50, h: 26 },
    // heater
    { x: WALL_X1 - KX - 86, y: WALL_Y1 - 36, w: 18, h: 20 },
  ];
}
