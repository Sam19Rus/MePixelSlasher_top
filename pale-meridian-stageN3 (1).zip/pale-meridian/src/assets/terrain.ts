import { Color, mix, packRGBA } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { fbm, makeRng, ridged, valueNoise, type Rng } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { dust, grime, haze, hazard, metal, olive, rock, rust, slate, teal, warm } from '../data/palette';
import { drawText } from '../rendering/text';
import { PROJ, WORLD_H, WORLD_W } from '../data/config';
import { L } from '../data/layout';

/**
 * EXTERIOR GROUND — the dusty surface of an unnamed frontier world.
 *
 * Baked once into a world-sized buffer. The read is: broad sunlit dune forms
 * with a consistent north-west light, three muted soil biomes, a compacted
 * man-made pad as the compositional anchor, and sparse *authored* detail
 * (cracks, tracks, footprints, debris, scrub). High-frequency noise is kept
 * deliberately low so the surface never turns into static.
 */

function rampAt(ramp: Color[], v: number, x: number, y: number): Color {
  const n = ramp.length - 1;
  const t = Math.max(0, Math.min(n - 0.0001, v * n));
  const i = Math.floor(t);
  return bayer4(x, y) < t - i ? ramp[i + 1] : ramp[i];
}

const CRUST: Color[] = [dust.d0, dust.d1, dust.d2];
const OCHRE: Color[] = [dust.d1, dust.d2, dust.d3, dust.d4, dust.d5];
const PALE: Color[] = [dust.d3, dust.d4, dust.d5, dust.d6, dust.d7];
const RUSTY: Color[] = [dust.d1, mix(rust.x1, dust.d1, 0.55), mix(rust.x2, dust.d2, 0.55), mix(rust.x3, dust.d3, 0.6), mix(rust.x4, dust.d4, 0.7)];
const ROCKY: Color[] = [rock.r1, rock.r2, rock.r3, rock.r4];

export interface GroundLayers {
  ground: PixelSurface;
  /** static sun shadows, kept separate so review mode can modulate them */
  shadow: PixelSurface;
}

const SHADOW_C = packRGBA(42, 24, 22, 138);

export function bakeExteriorGround(): GroundLayers {
  const g = new PixelSurface(WORLD_W, WORLD_H);
  const shadow = new PixelSurface(WORLD_W, WORLD_H);
  const rnd = makeRng(9137);

  // ---- broad dune field (used for directional shading of the ground) -----
  const field = new Float32Array(WORLD_W * WORLD_H);
  for (let y = 0; y < WORLD_H; y++) {
    for (let x = 0; x < WORLD_W; x++) {
      field[y * WORLD_W + x] = fbm(x / 168, y / 62, 3, 91);
    }
  }
  const F = (x: number, y: number) => field[Math.max(0, Math.min(WORLD_H - 1, y)) * WORLD_W + Math.max(0, Math.min(WORLD_W - 1, x))];

  // ---------------------------------------------------------------- base soil
  for (let y = 0; y < WORLD_H; y++) {
    const north = 1 - Math.min(1, y / 260);
    for (let x = 0; x < WORLD_W; x++) {
      const form = field[y * WORLD_W + x];
      const grain = fbm(x / 13, y / 10, 3, 41);
      const micro = valueNoise(x / 2.7, y / 2.7, 77);

      // slope lighting: light from the north-west
      const sx = F(x + 2, y) - F(x - 2, y);
      const sy = F(x, y + 2) - F(x, y - 2);
      let lit = -sx * 5.2 - sy * 6.4;
      lit = Math.max(-1, Math.min(1, lit));
      const q = Math.round(lit * 2) / 2; // 5 dithered lighting steps
      const litT = bayer4(x, y) < Math.abs(lit * 2 - Math.round(Math.abs(lit * 2))) ? Math.abs(q) + 0.25 : Math.abs(q);

      let biome = fbm(x / 82, y / 60, 3, 5) * 0.8 + form * 0.2 + north * 0.16;
      const bEdge = bayer8(x, y) * 0.1 - 0.05;

      let v = grain * 0.62 + form * 0.24 + (micro - 0.5) * 0.1 + 0.12;
      v = Math.max(0, Math.min(0.999, v));

      let c: Color;
      if (biome + bEdge < 0.33) {
        c = rampAt(CRUST, v * 0.9 + 0.05, x, y);
      } else if (biome + bEdge < 0.44) {
        c = rampAt(RUSTY, v * 0.85 + 0.05, x, y);
      } else if (biome + bEdge < 0.75) {
        c = rampAt(OCHRE, v, x, y);
      } else {
        c = rampAt(PALE, v * 0.9, x, y);
      }

      if (north > 0.3) {
        const t = Math.min(1, (north - 0.3) / 0.55);
        if (bayer8(x + 3, y) < t * 0.62) c = rampAt(ROCKY, v * 0.85 + 0.05, x, y);
      }

      // dune light / shade
      if (q > 0) c = mix(c, dust.d9, Math.min(0.14, litT * 0.17));
      else c = mix(c, dust.d0, Math.min(0.18, litT * 0.22));

      g.data[y * WORLD_W + x] = packRGBA(c & 0xff, (c >>> 8) & 0xff, (c >>> 16) & 0xff, 255);
    }
  }

  // ------------------------------------------- clustered grit, very sparse
  for (let i = 0; i < 6000; i++) {
    const x = rnd.int(0, WORLD_W - 1);
    const y = rnd.int(60, WORLD_H - 1);
    const gate = valueNoise(x / 30, y / 30, 3);
    if (gate < 0.68) continue;
    const bright = valueNoise(x / 9, y / 9, 13) > 0.66;
    const c = bright ? mix(dust.d7, dust.d6, 0.5) : rnd.chance(0.75) ? dust.d1 : warm.w2;
    g.set(x, y, c);
  }

  // --------------------------------------------------------------- cracks
  for (let i = 0; i < 16; i++) {
    const cx = rnd.int(12, WORLD_W - 12);
    const cy = rnd.int(150, WORLD_H - 12);
    if (cx > L.pad.x - 30 && cx < L.pad.x + L.pad.w + 30 && cy > L.pad.y - 20 && cy < L.pad.y + L.pad.h + 20) continue;
    crack(g, cx, cy, rnd);
  }

  // ------------------------------------------------- compacted work pad
  drawPad(g, L.pad.x, L.pad.y, L.pad.w, L.pad.h);

  // ------------------------------------------------------- vehicle tracks
  tracks(g, [
    [40, WORLD_H + 6],
    [96, 486],
    [168, 444],
    [238, 424],
    [286, 410],
  ]);
  tracks(g, [
    [WORLD_W - 30, WORLD_H + 6],
    [WORLD_W - 84, 492],
    [648, 452],
    [580, 428],
    [540, 414],
  ]);

  // --------------------------------------------------------- rock outcrops
  const rocks: [number, number, number, number][] = [
    [86, 214, 22, 12],
    [146, 172, 14, 8],
    [646, 198, 24, 13],
    [706, 258, 17, 10],
    [78, 404, 20, 11],
    [744, 404, 19, 11],
    [302, 132, 26, 12],
    [452, 146, 16, 9],
    [560, 120, 21, 11],
    [196, 258, 11, 7],
    [616, 326, 12, 7],
    [128, 486, 24, 13],
    [664, 500, 19, 10],
    [394, 524, 14, 8],
    [44, 126, 17, 9],
    [758, 132, 15, 8],
  ];
  for (const [x, y, rx, ry] of rocks) rockOutcrop(g, shadow, x, y, rx, ry, rnd);

  // ------------------------------------------------------------- pebbles
  for (let i = 0; i < 900; i++) {
    const x = rnd.int(4, WORLD_W - 5);
    const y = rnd.int(90, WORLD_H - 4);
    const n = valueNoise(x / 30, y / 30, 9);
    if (n < 0.5) continue;
    pebble(g, x, y, rnd.int(1, 2), rnd);
  }

  // ---------------------------------------------------- dry alien scrub
  for (let i = 0; i < 44; i++) {
    const x = rnd.int(16, WORLD_W - 16);
    const y = rnd.int(170, WORLD_H - 12);
    if (valueNoise(x / 44, y / 44, 17) < 0.55) continue;
    scrub(g, shadow, x, y, rnd);
  }

  // --------------------------------------------- scattered metal debris
  for (let i = 0; i < 40; i++) debris(g, rnd.int(20, WORLD_W - 20), rnd.int(180, WORLD_H - 14), rnd);

  // ------------------------------------------- footprints & local stains
  footprints(g, [
    [348, 470],
    [344, 440],
    [350, 412],
    [344, 384],
    [340, 362],
  ]);
  footprints(g, [
    [300, 452],
    [276, 436],
    [252, 424],
  ]);
  oilStain(g, 546, 412, 26, rnd);
  oilStain(g, 596, 442, 16, rnd);
  oilStain(g, 246, 424, 14, rnd);

  // half-buried alien ribcage, far field
  ribcage(g, 596, 214);

  // ---------------------------------------------- far badlands / horizon
  drawFarRidge(g);

  // ------------------------------------------------ atmospheric depth
  for (let y = 0; y < 168; y++) {
    const t = 1 - y / 168;
    const amount = Math.pow(t, 1.7) * 0.7;
    if (amount <= 0.01) continue;
    for (let x = 0; x < WORLD_W; x++) {
      const hz = mix(haze.h2, haze.h3, valueNoise(x / 120, y / 60, 3));
      const i = y * WORLD_W + x;
      g.data[i] = mix(g.data[i], hz, Math.min(0.9, amount));
    }
  }

  return { ground: g, shadow };
}

// --------------------------------------------------------------------------
// features
// --------------------------------------------------------------------------

function crack(g: PixelSurface, x: number, y: number, rnd: Rng, len = 0): void {
  let px = x;
  let py = y;
  let ang = rnd() * Math.PI * 2;
  const steps = len || 14 + Math.floor(rnd() * 44);
  for (let i = 0; i < steps; i++) {
    ang += (rnd() - 0.5) * 0.5;
    px += Math.cos(ang) * 1.5;
    py += Math.sin(ang) * 0.9;
    const ix = Math.round(px);
    const iy = Math.round(py);
    if (ix < 1 || iy < 1 || ix >= WORLD_W - 1 || iy >= WORLD_H - 1) return;
    const taper = i > steps - 5 ? rnd() < 0.5 : true;
    if (!taper) continue;
    g.set(ix, iy, mix(dust.d0, dust.d1, bayer4(ix, iy)));
    if (rnd() < 0.22) g.set(ix, iy + 1, mix(dust.d5, dust.d3, 0.5));
    if (rnd() < 0.05 && i > 6) crack(g, ix, iy, rnd, 6 + Math.floor(rnd() * 12));
  }
}

function pebble(g: PixelSurface, x: number, y: number, size: number, rnd: Rng): void {
  if (size <= 1) {
    g.set(x, y, rock.r4);
    g.set(x + 1, y + 1, dust.d1);
    return;
  }
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -2; dx <= 2; dx++) {
      const d = Math.abs(dx) / 2 + Math.abs(dy);
      if (d > 1) continue;
      g.set(x + dx, y + dy, dx < 0 && dy < 0 ? rock.r5 : rock.r3);
    }
  }
  g.set(x - 1, y + 1, dust.d1);
  if (rnd() < 0.5) g.set(x + 2, y + 1, dust.d0);
}

function rockOutcrop(g: PixelSurface, shadow: PixelSurface, cx: number, cy: number, rx: number, ry: number, rnd: Rng): void {
  const phase = rnd() * 10;
  const lobeN = 2 + Math.floor(rnd() * 2);
  // angular silhouette from a few overlapping lobes
  const lobes: [number, number, number, number][] = [];
  for (let i = 0; i < lobeN; i++) {
    lobes.push([
      cx + (rnd() - 0.5) * rx * 0.9,
      cy + (rnd() - 0.5) * ry * 0.6 - ry * 0.1,
      rx * (0.5 + rnd() * 0.45),
      ry * (0.55 + rnd() * 0.4),
    ]);
  }
  const inside = (x: number, y: number) => {
    for (const [lx, ly, lrx, lry] of lobes) {
      const d = ((x - lx) / lrx) ** 2 + ((y - ly) / lry) ** 2;
      if (d <= 1) return 1 - d;
    }
    return -1;
  };

  // cast shadow (SE, dithered, detached slightly from the base)
  for (let y = -ry - 3; y <= ry + 4; y++) {
    for (let x = -rx - 3; x <= rx + 9; x++) {
      if (inside(cx + x, cy + y) < 0 && inside(cx + x - 3, cy + y - 2) < 0) continue;
      const sx = cx + x + 7;
      const sy = cy + y + 4;
      if (bayer8(sx, sy) < 0.3) continue;
      shadow.set(sx, sy, SHADOW_C);
    }
  }

  // body with faceted shading
  for (let y = -ry - 3; y <= ry + 2; y++) {
    for (let x = -rx - 3; x <= rx + 4; x++) {
      const depth = inside(cx + x, cy + y);
      if (depth < 0) continue;
      const px = cx + x;
      const py = cy + y;
      // facet field: low-freq noise gives flat-ish planes
      const facet = valueNoise(px / 3.4 + phase, py / 3.4, 61);
      const dir = (-x / rx) * 0.55 + (-y / ry) * 0.85;
      let v = 0.42 + dir * 0.34 + (facet - 0.5) * 0.5 - (1 - depth) * 0.06;
      v = Math.max(0, Math.min(0.999, v));
      let c = rampAt(ROCKY, v, px, py);
      // sun rim only on the brightest facets, broken up
      if (dir > 0.55 && facet > 0.62 && bayer4(px, py) > 0.3) c = rock.r6;
      // occlusion in the crevices between lobes
      if (depth < 0.18) c = mix(c, rock.r1, 0.5);
      g.set(px, py, c);
    }
  }
  // dark contour separates the rock from the soil
  for (let y = -ry - 4; y <= ry + 3; y++) {
    for (let x = -rx - 4; x <= rx + 5; x++) {
      if (inside(cx + x, cy + y) >= 0) continue;
      let near = false;
      for (const o of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        if (inside(cx + x + o[0], cy + y + o[1]) >= 0) near = true;
      }
      if (near) g.set(cx + x, cy + y, rock.r0);
    }
  }
  // dust drift where the rock meets the ground
  for (let x = -rx - 2; x <= rx + 3; x++) {
    const hgt = Math.round(rnd() * 2.4);
    for (let i = 0; i < hgt; i++) {
      if (bayer4(cx + x, i + cy) < 0.45) continue;
      g.set(cx + x, cy + ry - hgt + i + 1, i === 0 ? dust.d5 : dust.d4);
    }
  }
}

function scrub(g: PixelSurface, shadow: PixelSurface, x: number, y: number, rnd: Rng): void {
  const blades = 3 + Math.floor(rnd() * 4);
  shadow.ellipse(x + 2, y + 1, Math.round(blades * 0.8), 2, packRGBA(40, 24, 18, 70));
  for (let i = 0; i < blades; i++) {
    const h = 2 + Math.floor(rnd() * 5);
    const lean = (rnd() - 0.5) * 3.4;
    for (let k = 0; k < h; k++) {
      const t = k / h;
      const px = Math.round(x + lean * t * t + (i - blades / 2) * 0.7);
      const py = y - k;
      const c = k === h - 1 ? mix(olive.o5, rust.x5, 0.4) : t > 0.5 ? mix(olive.o3, rust.x3, 0.25) : olive.o2;
      g.set(px, py, rnd() < 0.25 ? mix(c, dust.d3, 0.5) : c);
    }
  }
  g.set(x, y, olive.o1);
}

function debris(g: PixelSurface, x: number, y: number, rnd: Rng): void {
  const kind = Math.floor(rnd() * 5);
  if (kind === 0) {
    const w = 2 + Math.floor(rnd() * 4);
    for (let i = 0; i < w; i++) {
      g.set(x + i, y + (i % 2), rnd() < 0.5 ? rust.x3 : warm.w2);
      g.set(x + i, y - 1 + (i % 2), rnd() < 0.5 ? rust.x5 : warm.w4);
    }
  } else if (kind === 1) {
    const w = 3 + Math.floor(rnd() * 4);
    const h = 2 + Math.floor(rnd() * 2);
    g.rect(x, y, w, h, rnd() < 0.5 ? mix(rust.x2, dust.d2, 0.4) : warm.w2);
    g.hline(x, y, w, rnd() < 0.5 ? mix(rust.x4, dust.d4, 0.4) : warm.w4);
    g.set(x + w, y + h - 1, dust.d1);
  } else if (kind === 2) {
    g.set(x, y, warm.w5);
    g.set(x + 1, y, warm.w2);
    g.set(x, y + 1, warm.w1);
  } else if (kind === 3) {
    let px = x;
    let py = y;
    for (let i = 0; i < 5 + Math.floor(rnd() * 7); i++) {
      px += rnd() < 0.6 ? 1 : 0;
      py += rnd() < 0.5 ? 1 : 0;
      g.set(px, py, warm.w1);
      g.set(px, py - 1, warm.w3);
    }
  } else {
    for (let i = 0; i < 3; i++) g.set(x + Math.floor(rnd() * 4) - 2, y + Math.floor(rnd() * 3) - 1, rock.r3);
  }
}

function ribcage(g: PixelSurface, x: number, y: number): void {
  const bone = mix(rock.r5, dust.d7, 0.45);
  const boneDark = mix(rock.r3, dust.d3, 0.4);
  for (let i = 0; i < 7; i++) {
    const bx = x + i * 6;
    const h = 9 - Math.abs(i - 3) * 2;
    for (let k = 0; k < h; k++) {
      const curve = Math.round(Math.sin((k / h) * Math.PI) * 3);
      g.set(bx + curve, y - k, k > h - 3 ? boneDark : bone);
      g.set(bx + curve + 1, y - k, boneDark);
    }
  }
  for (let i = 0; i < 44; i++) g.set(x - 4 + i, y + 1 - Math.round(Math.sin(i / 9) * 1.2), i % 3 === 0 ? boneDark : bone);
  for (let i = 0; i < 52; i++) {
    if (bayer4(x + i, y) < 0.45) g.set(x - 6 + i, y + 2, dust.d3);
  }
}

function footprints(g: PixelSurface, pts: number[][]): void {
  const path: [number, number][] = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const steps = Math.max(Math.abs(pts[i + 1][0] - pts[i][0]), Math.abs(pts[i + 1][1] - pts[i][1]));
    for (let s = 0; s <= steps; s++) {
      path.push([pts[i][0] + ((pts[i + 1][0] - pts[i][0]) * s) / steps, pts[i][1] + ((pts[i + 1][1] - pts[i][1]) * s) / steps]);
    }
  }
  for (let i = 0; i < path.length; i += 4) {
    const side = (i / 3) % 2 === 0 ? 1 : -1;
    const [px, py] = path[i];
    const nx = path[Math.min(path.length - 1, i + 1)][0] - px;
    const ny = path[Math.min(path.length - 1, i + 1)][1] - py;
    const len = Math.hypot(nx, ny) || 1;
    const ox = (-ny / len) * 1.8 * side;
    const oy = (nx / len) * 1.8 * side;
    const x = Math.round(px + ox);
    const y = Math.round(py + oy);
    if (bayer4(x, y) < 0.3) continue;
    g.set(x, y, mix(dust.d2, dust.d3, 0.5));
    g.set(x + 1, y, mix(dust.d2, dust.d1, 0.4));
  }
}

function oilStain(g: PixelSurface, cx: number, cy: number, r: number, rnd: Rng): void {
  for (let y = -r; y <= r; y++) {
    for (let x = -r; x <= r; x++) {
      const wob = 0.7 + valueNoise((cx + x) / 5, (cy + y) / 5, 23) * 0.6;
      const d = Math.sqrt((x * x) / (r * r) + (y * y) / ((r * 0.62) ** 2)) / wob;
      if (d > 1) continue;
      if (d > 0.5 && bayer8(cx + x, cy + y) < d - 0.35) continue;
      const c = d < 0.4 ? grime.g2 : d < 0.75 ? mix(grime.g3, dust.d1, 0.4) : mix(grime.g3, dust.d3, 0.7);
      const i = (cy + y) * WORLD_W + (cx + x);
      g.data[i] = mix(g.data[i], c, d < 0.5 ? 0.72 : 0.5);
    }
  }
  // a few bright flecks of spilled coolant
  for (let i = 0; i < 4; i++) {
    if (rnd() < 0.5) g.set(cx + rnd.int(-r / 2, r / 2), cy + rnd.int(-r / 3, r / 3), mix(teal.t4, dust.d4, 0.55));
  }
}

/** Compacted graded pad: berm ring, stains, cracks, plates, painted marks. */
function drawPad(g: PixelSurface, x: number, y: number, w: number, h: number): void {
  const rnd = makeRng(4421);
  for (let py = 0; py < h + 6; py++) {
    for (let px = -4; px < w + 4; px++) {
      const cxp = x + px;
      const cyp = y + py;
      const ex = (px - w / 2) / (w / 2);
      const ey = (py - h / 2) / (h / 2);
      const d = Math.sqrt(ex * ex * 0.9 + ey * ey * 1.3);
      const wob = (valueNoise(cxp / 22, cyp / 22, 8) - 0.5) * 0.34;
      const dd = d + wob;
      if (dd > 1.06) continue;
      const n = fbm(cxp / 46, cyp / 34, 3, 19);
      const v = 0.4 + n * 0.34 + (valueNoise(cxp / 5, cyp / 5, 27) - 0.5) * 0.1;
      let c = rampAt([dust.d3, dust.d4, dust.d5, dust.d6], v, cxp, cyp);
      // berm: raised lip of pushed dirt around the edge
      if (dd > 0.88) c = mix(c, dust.d3, Math.min(0.5, (dd - 0.88) * 3));
      if (dd > 0.94 && bayer4(cxp, cyp) < 0.5) c = mix(c, dust.d6, 0.3);
      // polished centre
      if (dd < 0.5) c = mix(c, dust.d5, 0.25);
      if (dd > 0.98 && bayer8(cxp, cyp) < (dd - 0.98) * 9) continue;
      const i = cyp * WORLD_W + cxp;
      g.data[i] = mix(g.data[i], c, 0.92);
    }
  }
  // pad cracks + stains
  for (let i = 0; i < 6; i++) crack(g, rnd.int(x + 20, x + w - 20), rnd.int(y + 12, y + h - 12), rnd, 10 + rnd.int(0, 18));
  oilStain(g, x + 62, y + 66, 12, rnd);
  oilStain(g, x + 176, y + 40, 9, rnd);

  // bolted deck plates
  const plates: [number, number, number, number][] = [
    [x + 46, y + 24, 44, 24],
    [x + 150, y + 18, 50, 26],
    [x + 208, y + 44, 38, 20],
  ];
  for (const [px, py, pw, ph] of plates) {
    const kx = PROJ.kx * ph;
    const ky = PROJ.ky * ph;
    // sheared deck plate: lies on the ground plane
    const quad = [
      [px, py],
      [px + pw, py],
      [px + pw + kx, py - ky],
      [px + kx, py - ky],
    ];
    g.polygon(quad, mix(warm.w3, dust.d3, 0.45));
    for (let yy = 0; yy < ph; yy++) {
      const off = Math.round((yy / ph) * kx);
      const rowY = py - Math.round((yy / ph) * ky);
      for (let xx = 0; xx < pw; xx++) {
        if (((xx + yy) % 5 === 0 || (xx - yy + 20) % 5 === 0) && (xx + yy) % 2 === 0)
          g.set(px + xx + off, rowY, mix(warm.w4, dust.d4, 0.4));
        if (bayer8(xx + 5, yy) > 0.93) g.set(px + xx + off, rowY, mix(rust.x3, dust.d3, 0.5));
      }
    }
    // lit near edge + dark far edge
    g.line(px, py, px + pw, py, mix(warm.w5, dust.d5, 0.4));
    g.line(px + kx, py - ky, px + pw + kx, py - ky, warm.w1);
    g.line(px, py, px + kx, py - ky, mix(warm.w4, dust.d4, 0.4));
    g.line(px + pw, py, px + pw + kx, py - ky, warm.w1);
    // contact shadow on the near/right edges
    for (let xx = 0; xx < pw + 2; xx++) g.set(px + xx, py + 1, packRGBA(32, 20, 16, 110));
    for (let yy = 0; yy < ph; yy++) {
      const off = Math.round((yy / ph) * kx);
      g.set(px + pw + off + 1, py - Math.round((yy / ph) * ky), packRGBA(32, 20, 16, 110));
    }
    for (let bx = 3; bx < pw - 2; bx += 7) {
      g.set(px + bx, py - 1, warm.w6);
    }
    // dust over the near edge
    for (let xx = 0; xx < pw; xx++) if (rnd() < 0.45) g.set(px + xx, py, mix(dust.d4, dust.d5, 0.5));
  }

  // painted approach line + stencil markings, heavily worn
  for (let px = 12; px < w - 12; px++) {
    if (px % 12 >= 6) continue;
    const yy = y + Math.round(h * 0.74);
    const wear = valueNoise((x + px) / 8, yy / 8, 31);
    if (wear < 0.5) continue;
    g.set(x + px, yy, mix(hazard.h2, dust.d5, 0.5));
  }
  drawText(g, x + 52, y + 44, 'PAD 02', mix(metal.m6, dust.d6, 0.5), { worn: 0.5, seed: 3 });
  drawText(g, x + 178, y + 56, 'K-7', mix(hazard.h3, dust.d6, 0.45), { worn: 0.55, seed: 9 });
}
/** Double tyre track following a polyline of world points. */
function tracks(g: PixelSurface, pts: number[][]): void {
  const rnd = makeRng(771);
  const path: [number, number][] = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const [x0, y0] = pts[i];
    const [x1, y1] = pts[i + 1];
    const steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
    for (let s = 0; s <= steps; s++) path.push([x0 + ((x1 - x0) * s) / steps, y0 + ((y1 - y0) * s) / steps]);
  }
  for (let i = 0; i < path.length; i++) {
    const [px, py] = path[i];
    const nx = i < path.length - 1 ? path[i + 1][0] - px : px - path[i - 1][0];
    const ny = i < path.length - 1 ? path[i + 1][1] - py : py - path[i - 1][1];
    const len = Math.hypot(nx, ny) || 1;
    const ox = (-ny / len) * 7;
    const oy = (nx / len) * 7;
    for (const sgn of [-1, 1]) {
      const cx = Math.round(px + ox * sgn);
      const cy = Math.round(py + oy * sgn);
      for (let w = -2; w <= 2; w++) {
        const a = Math.abs(w);
        const c = a === 2 ? mix(dust.d3, dust.d4, 0.5) : a === 1 ? mix(dust.d2, dust.d3, 0.5) : mix(grime.g2, dust.d2, 0.6);
        if (bayer4(cx + w, cy) < a * 0.22) continue;
        g.set(cx + w, cy, c);
      }
      if (rnd() < 0.3) g.set(cx + Math.round(3 * sgn), cy, mix(dust.d5, dust.d4, rnd()));
      if (i % 4 === 0) g.set(cx, cy, mix(dust.d1, grime.g2, 0.6));
    }
    if (rnd() < 0.25) g.set(Math.round(px), Math.round(py), mix(dust.d4, dust.d5, 0.5));
  }
}

/** Distant badlands: plateau mesas with lit rims, cliff streaks, haze. */
function drawFarRidge(g: PixelSurface): void {
  const layers = [
    { y: 84, amp: 30, top: mix(haze.h1, rock.r2, 0.5), body: mix(haze.h1, rock.r2, 0.62), freq: 0.0042, seed: 1, rim: mix(haze.h3, rock.r5, 0.5) },
    { y: 102, amp: 22, top: mix(haze.h2, rock.r3, 0.45), body: mix(haze.h2, rock.r3, 0.55), freq: 0.0068, seed: 2, rim: mix(haze.h4, rock.r6, 0.4) },
    { y: 118, amp: 15, top: mix(haze.h3, rock.r4, 0.4), body: mix(haze.h2, rock.r3, 0.75), freq: 0.0105, seed: 3, rim: mix(haze.h4, dust.d7, 0.4) },
  ];
  for (const Ly of layers) {
    const tops = new Int32Array(WORLD_W);
    for (let x = 0; x < WORLD_W; x++) {
      const n = fbm(x * Ly.freq, 2.2, 3, Ly.seed * 31);
      // plateau quantisation gives flat mesa tops and steep cliffs
      const plateau = Math.round(n * 3.4) / 3.4;
      tops[x] = Math.round(Ly.y - plateau * Ly.amp - valueNoise(x * 0.09, Ly.seed, 7) * 2);
    }
    for (let x = 0; x < WORLD_W; x++) {
      const top = tops[x];
      for (let y = top; y < Ly.y + 46; y++) {
        if (y < 0 || y >= WORLD_H) continue;
        const depth = (y - top) / 46;
        let c = mix(Ly.top, Ly.body, Math.min(1, depth * 1.4));
        c = mix(c, dust.d1, Math.min(0.7, Math.max(0, depth - 0.35) * 1.2));
        // vertical cliff streaks
        const streak = ridged(x * 0.11, y * 0.02, 2, Ly.seed * 7);
        if (streak > 0.72) c = mix(c, rock.r1, 0.35);
        if (streak < 0.3) c = mix(c, Ly.rim, 0.12);
        g.data[y * WORLD_W + x] = mix(g.data[y * WORLD_W + x], c, 0.96);
      }
      // sun rim on mesa tops
      const edge = x === 0 || tops[x - 1] > tops[x];
      g.set(x, top, Ly.rim);
      if (edge) {
        for (let k = 0; k < Math.min(6, tops[x - 1] - tops[x]); k++) g.set(x, top + k, mix(Ly.rim, Ly.body, 0.3 + k * 0.12));
      }
    }
  }

  // a lone comm spire on the ridge — background focal point
  const sx = 636;
  const sy = 74;
  for (let i = 0; i < 44; i++) {
    g.set(sx, sy - i, i % 6 === 0 ? metal.m4 : metal.m2);
    g.set(sx + 1, sy - i, metal.m1);
    if (i % 9 === 0) {
      g.set(sx - 2, sy - i, metal.m3);
      g.set(sx + 3, sy - i, metal.m2);
    }
  }
  g.set(sx, sy - 45, packRGBA(240, 96, 80, 255));

  // half-buried derelict hull in the badlands
  const wx = 132;
  const wy = 96;
  for (let i = 0; i < 44; i++) {
    const hh = Math.round(11 * Math.sin((i / 44) * Math.PI));
    for (let k = 0; k < hh; k++) {
      const c = k > hh - 3 ? mix(slate.s3, rock.r3, 0.4) : mix(slate.s2, rock.r2, 0.4);
      g.set(wx + i, wy - k, k === 0 && i % 5 === 0 ? mix(rust.x3, rock.r3, 0.5) : c);
    }
  }
  for (let i = 0; i < 26; i++) g.set(wx + 8 + i, wy - 13 + Math.round(Math.sin(i / 5) * 2), mix(slate.s4, rock.r4, 0.4));
  for (let i = 0; i < 40; i++) g.set(wx + 36 + Math.round(i * 0.3), wy - 7 - i, i % 7 === 0 ? metal.m3 : mix(slate.s1, rock.r1, 0.5));
}
