import { Color, alphaOf, packRGBA } from './color';
import { bayer4, bayer8 } from './dither';
import { PixelSurface } from './PixelSurface';
import { PROJ } from '../data/config';

/**
 * Volumetric helpers for the oblique 3/4 projection.
 *
 * Every solid in the game is a "mass": a front face (rectangle), a top face
 * (parallelogram sheared along PROJ) and an east face (parallelogram). Those
 * three faces plus a consistent rim/shadow treatment are what stop the scene
 * from reading as flat sprites lying on a floor.
 */

export interface MassColors {
  /** front face: [upper, middle, lower] */
  front: [Color, Color, Color];
  /** top face: [far, near] */
  top: [Color, Color];
  /** east face: [upper, lower] */
  east: [Color, Color];
  /** 1px catch light along the top edges */
  rim: Color;
  /** 1px dark contour */
  edge: Color;
}

export interface MassOptions {
  rim?: boolean;
  edge?: boolean;
  /** darken the bottom of the front face (ambient occlusion against ground) */
  ao?: number;
  /** dust piled against the base, 0 = none */
  dust?: Color;
  dustAmount?: number;
}

/** Screen-space quad of a horizontal plate anchored at its front-left corner. */
export function floorQuad(x: number, y: number, w: number, d: number): number[][] {
  const kx = PROJ.kx * d;
  const ky = PROJ.ky * d;
  return [
    [x, y],
    [x + w, y],
    [x + w + kx, y - ky],
    [x + kx, y - ky],
  ];
}

export function drawFloorQuad(s: PixelSurface, x: number, y: number, w: number, d: number, c: Color): void {
  s.polygon(floorQuad(x, y, w, d), c);
}

/** Shear a point that lies on a horizontal plate of depth `d`. */
export function platePoint(x: number, y: number, w: number, d: number, u: number, v: number): [number, number] {
  return [x + u * w + v * PROJ.kx * d, y - v * PROJ.ky * d];
}

/**
 * Draw one solid mass. `y` is the ground line of the front-bottom edge.
 */
export function drawMass(
  s: PixelSurface,
  x: number,
  y: number,
  w: number,
  h: number,
  d: number,
  c: MassColors,
  opts: MassOptions = {},
): void {
  x = Math.round(x);
  y = Math.round(y);
  w = Math.round(w);
  h = Math.round(h);
  const kx = Math.round(PROJ.kx * d);
  const ky = Math.round(PROJ.ky * d);

  // --- top face -----------------------------------------------------------
  s.polygon(
    [
      [x, y - h],
      [x + w, y - h],
      [x + w + kx, y - h - ky],
      [x + kx, y - h - ky],
    ],
    c.top[0],
  );
  if (c.top[1] !== c.top[0] && ky > 1) {
    for (let i = 0; i < ky; i++) {
      const t = i / (ky - 1);
      if (bayer4(0, i) < t * 0.9) {
        const xx0 = x + Math.round((kx * i) / ky);
        s.line(xx0, y - h - i, xx0 + w + Math.round(kx - (kx * i) / ky), y - h - i, c.top[1]);
      }
    }
  }

  // --- east face ----------------------------------------------------------
  if (kx > 0 || ky > 0) {
    s.polygon(
      [
        [x + w, y],
        [x + w + kx, y - ky],
        [x + w + kx, y - ky - h],
        [x + w, y - h],
      ],
      c.east[0],
    );
    if (c.east[1] !== c.east[0] && ky > 1) {
      for (let i = 0; i < ky; i++) {
        const t = i / (ky - 1);
        if (bayer4(3, i) < t) {
          const xx = x + w + Math.round((kx * i) / ky);
          s.vline(xx, y - Math.round((ky * i) / ky) - h, h, c.east[1]);
        }
      }
    }
    // dark vertical corner where front meets east
    if (opts.edge !== false) s.vline(x + w, y - h, h, c.edge);
  }

  // --- front face ---------------------------------------------------------
  s.rect(x, y - h, w, h, c.front[1]);
  // upper band: sky bounce
  for (let i = 0; i < Math.min(4, h); i++) {
    const t = 1 - i / 4;
    for (let px = 0; px < w; px++) {
      if (bayer4(px, i) < t * 0.85) s.set(x + px, y - h + i, c.front[0]);
    }
  }
  // lower band: ambient occlusion
  const ao = opts.ao ?? 0.55;
  for (let i = 0; i < Math.min(5, h); i++) {
    const t = i / 5;
    for (let px = 0; px < w; px++) {
      if (bayer4(px + 1, i) < t * ao) s.set(x + px, y - 1 - i, c.front[2]);
    }
  }

  // --- rim + contour ------------------------------------------------------
  if (opts.rim !== false) {
    s.hline(x, y - h, w + kx + 1, c.rim);
    s.line(x + w + 1, y - h, x + w + kx, y - h - ky, c.rim);
  }
  if (opts.edge !== false) {
    s.hline(x, y - 1, w, c.edge);
    s.vline(x, y - h, h, c.edge);
    s.line(x + kx, y - h - ky, x + w + kx, y - h - ky, c.edge);
    s.line(x + w + kx, y - h - ky, x + w + kx, y - ky, c.edge);
    s.line(x + w + kx, y - ky, x + w, y, c.edge);
  }

  // --- dust against the base ---------------------------------------------
  if (opts.dust !== undefined) {
    const amount = opts.dustAmount ?? 0.6;
    for (let px = 0; px < w; px++) {
      const hgt = 1 + Math.round(bayer8(px, y) * 3 * amount);
      for (let i = 0; i < hgt; i++) {
        if (bayer8(px, y - i) < amount - i * 0.22) s.set(x + px, y - 1 - i, opts.dust);
      }
    }
  }
}

/** A recessed panel: dark inset with a lit lower-right bevel. */
export function insetPanel(s: PixelSurface, x: number, y: number, w: number, h: number, dark: Color, bevel: Color): void {
  s.rect(x, y, w, h, dark);
  s.hline(x, y, w, packRGBA(dark & 0xff, (dark >>> 8) & 0xff, (dark >>> 16) & 0xff, 255));
  s.vline(x, y, h, dark);
  s.hline(x, y + h - 1, w, bevel);
  s.vline(x + w - 1, y, h, bevel);
}

/** A raised panel: lit top-left, dark bottom-right. */
export function raisedPanel(s: PixelSurface, x: number, y: number, w: number, h: number, face: Color, light: Color, dark: Color): void {
  s.rect(x, y, w, h, face);
  s.hline(x, y, w, light);
  s.vline(x, y, h, light);
  s.hline(x, y + h - 1, w, dark);
  s.vline(x + w - 1, y, h, dark);
}

/** Clip a drawing callback to a rectangle (software scissor). */
export function withClip(s: PixelSurface, x: number, y: number, w: number, h: number, fn: (c: PixelSurface) => void): void {
  // Cheap approach: draw into a scratch surface and blit back the region.
  const scratch = new PixelSurface(s.width, s.height);
  fn(scratch);
  const x0 = Math.max(0, x);
  const y0 = Math.max(0, y);
  const x1 = Math.min(s.width, x + w);
  const y1 = Math.min(s.height, y + h);
  for (let yy = y0; yy < y1; yy++) {
    for (let xx = x0; xx < x1; xx++) {
      const c = scratch.data[yy * s.width + xx];
      if (alphaOf(c) === 0) continue;
      s.data[yy * s.width + xx] = c;
    }
  }
}
