/**
 * Packed colour helpers.
 *
 * Every pixel in the engine is a single 32-bit int laid out the same way the
 * browser's ImageData expects it on a little-endian machine:
 *
 *   byte0 = R, byte1 = G, byte2 = B, byte3 = A
 *
 * so `new Uint32Array(imageData.data.buffer)` and our surfaces share a layout
 * and the final blit to the screen is a single `putImageData`.
 *
 * All blending is done with integer maths on purpose: no floats leaking into
 * pixel positions, no anti-aliasing, no soft edges.
 */

export type Color = number;

export const packRGBA = (r: number, g: number, b: number, a = 255): Color =>
  ((a << 24) | (b << 16) | (g << 8) | r) >>> 0;

export const redOf = (c: Color): number => c & 0xff;
export const greenOf = (c: Color): number => (c >>> 8) & 0xff;
export const blueOf = (c: Color): number => (c >>> 16) & 0xff;
export const alphaOf = (c: Color): number => (c >>> 24) & 0xff;

/** Parse `#rgb`, `#rrggbb` or `#rrggbbaa` into a packed colour. */
export function hex(value: string): Color {
  let h = value.replace('#', '').trim();
  if (h.length === 3) {
    h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  }
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  const a = h.length >= 8 ? parseInt(h.slice(6, 8), 16) : 255;
  return packRGBA(r, g, b, a);
}

export function toCss(c: Color): string {
  return `rgba(${redOf(c)},${greenOf(c)},${blueOf(c)},${(alphaOf(c) / 255).toFixed(3)})`;
}

/** Linear blend of two packed colours, `t` in 0..1. Fully opaque result. */
export function mix(a: Color, b: Color, t: number): Color {
  const u = t < 0 ? 0 : t > 1 ? 1 : t;
  const ia = 1 - u;
  return packRGBA(
    Math.round(redOf(a) * ia + redOf(b) * u),
    Math.round(greenOf(a) * ia + greenOf(b) * u),
    Math.round(blueOf(a) * ia + blueOf(b) * u),
  );
}

export function withAlpha(c: Color, a: number): Color {
  return packRGBA(redOf(c), greenOf(c), blueOf(c), Math.max(0, Math.min(255, a | 0)));
}

/** Multiply rgb by a scalar (used for shading passes), keeps alpha. */
export function shade(c: Color, k: number): Color {
  return packRGBA(
    Math.min(255, Math.round(redOf(c) * k)),
    Math.min(255, Math.round(greenOf(c) * k)),
    Math.min(255, Math.round(blueOf(c) * k)),
    alphaOf(c),
  );
}

/** Shift a colour towards white (rim light) or black. */
export const WHITE: Color = packRGBA(255, 255, 255);
export const BLACK: Color = packRGBA(0, 0, 0);

export function lighten(c: Color, amount: number): Color {
  return mix(c, WHITE, amount);
}
export function darken(c: Color, amount: number): Color {
  return mix(c, BLACK, amount);
}

/** Desaturate towards the colour's own luminance — used for dusty/hazy layers. */
export function desaturate(c: Color, amount: number): Color {
  const lum = Math.round(0.299 * redOf(c) + 0.587 * greenOf(c) + 0.114 * blueOf(c));
  return mix(c, packRGBA(lum, lum, lum), amount);
}

/**
 * Source-over blend of `src` onto `dst` (both packed). Integer only.
 */
export function blendOver(dst: Color, src: Color): Color {
  const sa = (src >>> 24) & 0xff;
  if (sa === 255) return src;
  if (sa === 0) return dst;
  const da = (dst >>> 24) & 0xff;
  if (da === 0) return src;
  const isa = 255 - sa;
  const daW = ((da * isa + 127) / 255) | 0;
  const oa = sa + daW;
  const r = (((src & 0xff) * sa + (dst & 0xff) * daW) / oa) | 0;
  const g = ((((src >>> 8) & 0xff) * sa + ((dst >>> 8) & 0xff) * daW) / oa) | 0;
  const b = ((((src >>> 16) & 0xff) * sa + ((dst >>> 16) & 0xff) * daW) / oa) | 0;
  return packRGBA(r, g, b, oa > 255 ? 255 : oa);
}

/** Additive blend (used by emissive glow / light accumulation). */
export function blendAdd(dst: Color, src: Color, scale = 1): Color {
  const sa = (((src >>> 24) & 0xff) * scale) | 0;
  if (sa === 0) return dst;
  const da = (dst >>> 24) & 0xff;
  const r = Math.min(255, (dst & 0xff) + (((src & 0xff) * sa) >> 8));
  const g = Math.min(255, ((dst >>> 8) & 0xff) + ((((src >>> 8) & 0xff) * sa) >> 8));
  const b = Math.min(255, ((dst >>> 16) & 0xff) + ((((src >>> 16) & 0xff) * sa) >> 8));
  return packRGBA(r, g, b, Math.max(da, Math.min(255, sa + (da >> 1))));
}

/**
 * Build a ramp of `steps` colours between two anchors. Handy for authoring
 * consistent material ramps (metal, dust, rust) from the master palette.
 */
export function ramp(from: Color, to: Color, steps: number): Color[] {
  const out: Color[] = [];
  for (let i = 0; i < steps; i++) out.push(mix(from, to, steps === 1 ? 0 : i / (steps - 1)));
  return out;
}
