import { PixelSurface } from './PixelSurface';
import { LightingSystem, type LightDef } from '../lighting/LightingSystem';
import { VIEW_H, VIEW_W } from '../data/config';
import { bayer4 } from './dither';
import { dust, metal } from '../data/palette';
import { mix, withAlpha } from './color';
import type { DynamicOverlay } from '../world/ExteriorScene';
import type { Rect } from '../data/layout';
import type { QualitySettings } from '../data/quality';

/**
 * FRAME PIPELINE.
 *
 *   ground  →  sun-shadow layer  →  depth-sorted sprites  →  dynamic overlays
 *   →  light pass (ambient + additive lamps with ray-marched shadows)
 *   →  atmosphere (vignette / dust haze)
 *
 * Everything is integer blits into a 480x270 buffer; the browser only ever
 * upscales that buffer with nearest-neighbour.
 */

export interface Drawable {
  gy: number;
  bias?: number;
  draw: (s: PixelSurface, camX: number, camY: number, t: number) => void;
}

export interface FrameState {
  zone: 'ext' | 'int';
  quality: QualitySettings;
  ground: PixelSurface;
  shadow: PixelSurface | null;
  shadowAlpha: number;
  drawables: Drawable[];
  dynamics: DynamicOverlay[];
  lights: LightDef[];
  colliders: Rect[];
  camX: number;
  camY: number;
  time: number;
  fade: number;
  prompt: { x: number; y: number } | null;
}

export class Renderer {
  readonly scene = new PixelSurface(VIEW_W, VIEW_H);
  readonly lighting = new LightingSystem();

  constructor() {
    this.lighting.resize(VIEW_W, VIEW_H);
  }

  render(st: FrameState): PixelSurface {
    const s = this.scene;
    const { camX, camY } = st;

    // ---- ground (row-wise typed-array copy when fully inside the world)
    const g = st.ground;
    for (let y = 0; y < VIEW_H; y++) {
      const sy = camY + y;
      const row = y * VIEW_W;
      if (sy < 0 || sy >= g.height) {
        s.data.fill(0xff0d0b0a, row, row + VIEW_W);
        continue;
      }
      const srcRow = sy * g.width;
      if (camX >= 0 && camX + VIEW_W <= g.width) {
        s.data.set(g.data.subarray(srcRow + camX, srcRow + camX + VIEW_W), row);
      } else {
        for (let x = 0; x < VIEW_W; x++) {
          const sx = camX + x;
          s.data[row + x] = sx >= 0 && sx < g.width ? g.data[srcRow + sx] : 0xff0d0b0a;
        }
      }
    }

    // ---- baked sun shadows
    if (st.shadow && st.shadowAlpha > 0.01 && st.quality.sunShadows) {
      const a = Math.min(1, st.shadowAlpha);
      for (let y = 0; y < VIEW_H; y++) {
        const sy = camY + y;
        if (sy < 0 || sy >= st.shadow.height) continue;
        const srcRow = sy * st.shadow.width;
        const row = y * VIEW_W;
        for (let x = 0; x < VIEW_W; x++) {
          const sx = camX + x;
          if (sx < 0 || sx >= st.shadow.width) continue;
          const c = st.shadow.data[srcRow + sx];
          const sa = (c >>> 24) & 0xff;
          if (sa === 0) continue;
          if (bayer4(x, y) > a) continue;
          s.data[row + x] = blendFast(s.data[row + x], c);
        }
      }
    }

    // ---- depth sorted sprites
    const list = st.drawables.slice().sort((p, q) => p.gy + (p.bias ?? 0) - (q.gy + (q.bias ?? 0)));
    for (const d of list) d.draw(s, camX, camY, st.time);

    // ---- dynamic overlays (steam, fans, screens, motes)
    const fx = st.quality.ambientFx;
    for (const d of st.dynamics) {
      if (!fx && d.cost !== 'cheap') continue;
      d.draw(s, st.time, camX, camY);
    }

    // ---- light pass (budget caps lamp count; shadows are a separate toggle)
    let lights = st.lights;
    if (lights.length > st.quality.lightBudget) {
      lights = lights.slice().sort((a, b) => b.intensity * b.radius - a.intensity * a.radius).slice(0, st.quality.lightBudget);
    }
    const shadows = st.quality.lightShadows;
    const toScreen = (l: LightDef) =>
      shadows ? { ...l, x: l.x - camX, y: l.y - camY } : { ...l, x: l.x - camX, y: l.y - camY, castShadows: false };

    // the interior camera never moves, so constant lamps are baked once
    const staticLights = st.zone === 'int' ? lights.filter((l) => l.static).map(toScreen) : [];
    this.lighting.configureStatic(
      `${st.zone}:${this.lighting.timeOfDay}:${shadows}:${st.quality.lightBudget}`,
      staticLights,
      st.time,
      st.colliders,
      camX,
      camY,
    );
    this.lighting.begin();
    for (const l of lights) {
      if (l.static && st.zone === 'int') continue;
      this.lighting.addLight(toScreen(l), st.time, st.colliders, camX, camY);
    }
    this.lighting.apply(s);

    // ---- atmosphere (cached vignette + haze surface)
    if (st.quality.atmosphere) this.atmosphere(s, st.zone);

    // ---- interaction prompt
    if (st.prompt) this.prompt(s, st.prompt.x - camX, st.prompt.y - camY, st.time);

    // ---- zone fade
    if (st.fade > 0.01) {
      const a = Math.min(1, st.fade);
      for (let y = 0; y < VIEW_H; y++) {
        for (let x = 0; x < VIEW_W; x++) {
          if (bayer4(x, y) < a) s.data[y * VIEW_W + x] = 0xff080708;
        }
      }
    }
    return s;
  }

  private atmoCache: Partial<Record<'ext' | 'int', PixelSurface>> = {};

  /**
   * Vignette + haze are static per zone, so they are baked once into an alpha
   * surface and cost a single blended blit per frame instead of a per-pixel
   * sqrt loop.
   */
  private atmosphere(s: PixelSurface, zone: 'ext' | 'int'): void {
    let layer = this.atmoCache[zone];
    if (!layer) {
      layer = this.bakeAtmosphere(zone);
      this.atmoCache[zone] = layer;
    }
    const src = layer.data;
    for (let i = 0; i < src.length; i++) {
      const c = src[i];
      if (((c >>> 24) & 0xff) === 0) continue;
      s.data[i] = blendFast(s.data[i], c);
    }
  }

  private bakeAtmosphere(zone: 'ext' | 'int'): PixelSurface {
    const layer = new PixelSurface(VIEW_W, VIEW_H);
    const cx = VIEW_W / 2;
    const cy = VIEW_H / 2;
    const strength = zone === 'ext' ? 0.34 : 0.42;
    const dark = zone === 'ext' ? dust.d0 : 0xff0a0c0e;
    for (let y = 0; y < VIEW_H; y++) {
      for (let x = 0; x < VIEW_W; x++) {
        const dx = (x - cx) / cx;
        const dy = (y - cy) / cy;
        const d = Math.sqrt(dx * dx * 0.8 + dy * dy * 1.15);
        if (d >= 0.72) {
          const t = Math.min(1, (d - 0.72) / 0.5) * strength;
          if (bayer4(x, y) <= t) layer.data[y * VIEW_W + x] = withAlpha(mix(dark, 0x00000000, 0.45), Math.round(t * 255));
        }
        if (zone === 'ext' && y < 26) {
          const t = (1 - y / 26) * 0.22;
          if (bayer4(x, y) <= t) {
            const i = y * VIEW_W + x;
            const prev = layer.data[i];
            const hazeC = withAlpha(mix(mix(dust.d6, metal.m6, 0.3), 0x00000000, 0.6), Math.round(Math.max(t, ((prev >>> 24) & 0xff) / 255) * 255));
            layer.data[i] = hazeC;
          }
        }
      }
    }
    return layer;
  }

  private prompt(s: PixelSurface, x: number, y: number, t: number): void {
    const bob = Math.sin(t * 4) > 0 ? 0 : 1;
    const px = Math.round(x) - 5;
    const py = Math.round(y) - 12 - bob;
    s.rect(px, py, 11, 9, withAlpha(0xff101214, 200));
    s.strokeRect(px, py, 11, 9, withAlpha(metal.m6, 220));
    // 'E' glyph
    const g = ['111', '100', '110', '100', '111'];
    for (let ry = 0; ry < 5; ry++) {
      for (let rx = 0; rx < 3; rx++) {
        if (g[ry][rx] === '1') s.set(px + 4 + rx, py + 2 + ry, metal.m9);
      }
    }
    // pointer
    s.set(Math.round(x), py + 9, withAlpha(metal.m6, 200));
    s.set(Math.round(x), py + 10, withAlpha(metal.m6, 120));
  }
}

function blendFast(dst: number, src: number): number {
  const sa = (src >>> 24) & 0xff;
  if (sa === 255) return src;
  const isa = 255 - sa;
  const r = ((src & 0xff) * sa + (dst & 0xff) * isa) >> 8;
  const g = (((src >>> 8) & 0xff) * sa + ((dst >>> 8) & 0xff) * isa) >> 8;
  const b = (((src >>> 16) & 0xff) * sa + ((dst >>> 16) & 0xff) * isa) >> 8;
  return (0xff << 24) | (b << 16) | (g << 8) | r;
}
