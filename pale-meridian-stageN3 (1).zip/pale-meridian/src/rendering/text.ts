import { Color, packRGBA } from './color';
import { bayer8 } from './dither';
import { PixelSurface } from './PixelSurface';

/**
 * A 3x5 stencil micro-font.
 *
 * Used for in-world markings only — hull numbers, crate stencils, hazard
 * labels, console readouts. Never for UI text. Having legible 3px lettering
 * on equipment is a huge part of why a scene reads as "built" rather than
 * "generated".
 */
const GLYPHS: Record<string, string[]> = {
  A: ['010', '101', '111', '101', '101'],
  B: ['110', '101', '110', '101', '110'],
  C: ['011', '100', '100', '100', '011'],
  D: ['110', '101', '101', '101', '110'],
  E: ['111', '100', '110', '100', '111'],
  F: ['111', '100', '110', '100', '100'],
  G: ['011', '100', '101', '101', '011'],
  H: ['101', '101', '111', '101', '101'],
  I: ['010', '010', '010', '010', '010'],
  J: ['001', '001', '001', '101', '010'],
  K: ['101', '101', '110', '101', '101'],
  L: ['100', '100', '100', '100', '111'],
  M: ['101', '111', '101', '101', '101'],
  N: ['101', '111', '111', '101', '101'],
  O: ['010', '101', '101', '101', '010'],
  P: ['110', '101', '110', '100', '100'],
  Q: ['010', '101', '101', '110', '011'],
  R: ['110', '101', '110', '101', '101'],
  S: ['011', '100', '010', '001', '110'],
  T: ['111', '010', '010', '010', '010'],
  U: ['101', '101', '101', '101', '111'],
  V: ['101', '101', '101', '101', '010'],
  W: ['101', '101', '111', '111', '101'],
  X: ['101', '101', '010', '101', '101'],
  Y: ['101', '101', '010', '010', '010'],
  Z: ['111', '001', '010', '100', '111'],
  '0': ['111', '101', '101', '101', '111'],
  '1': ['010', '110', '010', '010', '111'],
  '2': ['110', '001', '010', '100', '111'],
  '3': ['110', '001', '010', '001', '110'],
  '4': ['101', '101', '111', '001', '001'],
  '5': ['111', '100', '110', '001', '110'],
  '6': ['011', '100', '111', '101', '111'],
  '7': ['111', '001', '010', '010', '010'],
  '8': ['111', '101', '111', '101', '111'],
  '9': ['111', '101', '111', '001', '110'],
  '-': ['000', '000', '111', '000', '000'],
  '.': ['000', '000', '000', '000', '010'],
  ':': ['000', '010', '000', '010', '000'],
  '/': ['001', '001', '010', '100', '100'],
  '!': ['010', '010', '010', '000', '010'],
  '?': ['110', '001', '010', '000', '010'],
  '+': ['000', '010', '111', '010', '000'],
  '=': ['000', '111', '000', '111', '000'],
  '>': ['100', '010', '001', '010', '100'],
  '<': ['001', '010', '100', '010', '001'],
  '*': ['101', '010', '111', '010', '101'],
  '#': ['101', '111', '101', '111', '101'],
  '%': ['101', '001', '010', '100', '101'],
  '(': ['010', '100', '100', '100', '010'],
  ')': ['010', '001', '001', '001', '010'],
  ',': ['000', '000', '000', '010', '100'],
  ' ': ['000', '000', '000', '000', '000'],
};

export const GLYPH_W = 3;
export const GLYPH_H = 5;

export function textWidth(text: string, spacing = 1, scale = 1): number {
  const t = text.toUpperCase();
  return (t.length * (GLYPH_W + spacing) - spacing) * scale;
}

export interface TextOptions {
  spacing?: number;
  scale?: number;
  /** painted-on look: knock out a few pixels so it looks worn */
  worn?: number;
  /** dark offset shadow under the paint */
  shadow?: Color;
  seed?: number;
}

export function drawText(s: PixelSurface, x: number, y: number, text: string, color: Color, opts: TextOptions = {}): void {
  const spacing = opts.spacing ?? 1;
  const scale = opts.scale ?? 1;
  const worn = opts.worn ?? 0;
  const seed = opts.seed ?? 0;
  const t = text.toUpperCase();
  if (opts.shadow !== undefined) drawText(s, x, y + scale, t, opts.shadow, { ...opts, shadow: undefined });
  let cx = x;
  for (const ch of t) {
    const g = GLYPHS[ch] ?? GLYPHS['?'];
    for (let ry = 0; ry < GLYPH_H; ry++) {
      for (let rx = 0; rx < GLYPH_W; rx++) {
        if (g[ry][rx] !== '1') continue;
        if (worn > 0 && bayer8(cx + rx * 7 + seed, y + ry * 13) < worn) continue;
        if (scale === 1) s.set(cx + rx, y + ry, color);
        else s.rect(cx + rx * scale, y + ry * scale, scale, scale, color);
      }
    }
    cx += (GLYPH_W + spacing) * scale;
  }
}

/** A block of fake console readout lines (no real text, just glyph shapes). */
export function drawReadout(s: PixelSurface, x: number, y: number, w: number, h: number, color: Color, rnd: () => number): void {
  for (let py = 0; py < h; py += 2) {
    const len = 1 + Math.floor(rnd() * (w - 2));
    for (let px = 0; px < len; px++) {
      if (rnd() < 0.22) continue;
      s.set(x + px, y + py, color);
    }
  }
}

/** Stencil number plate: dark recess + painted digits. */
export function stencilPlate(
  s: PixelSurface,
  x: number,
  y: number,
  text: string,
  plate: Color,
  edge: Color,
  paint: Color,
  worn = 0.2,
): void {
  const w = textWidth(text) + 4;
  s.rect(x, y, w, 9, plate);
  s.strokeRect(x, y, w, 9, edge);
  s.hline(x + 1, y + 1, w - 2, packRGBA(255, 255, 255, 24));
  drawText(s, x + 2, y + 2, text, paint, { worn, seed: x + y });
}
