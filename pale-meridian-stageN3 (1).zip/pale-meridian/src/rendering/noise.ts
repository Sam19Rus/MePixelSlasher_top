/**
 * Deterministic noise + RNG.
 *
 * Everything in the world is generated from a fixed seed so the benchmark scene
 * looks identical on every run, on every machine, and in the offline Node
 * preview tool. No Math.random() anywhere in world generation.
 */

export function hash2(x: number, y: number, seed = 0): number {
  let h = seed | 0;
  h = Math.imul(h ^ (x | 0), 0x27d4eb2d);
  h = Math.imul(h ^ (y | 0), 0x165667b1);
  h ^= h >>> 15;
  h = Math.imul(h, 0x85ebca6b);
  h ^= h >>> 13;
  return (h >>> 0) / 4294967295;
}

export function hash3(x: number, y: number, z: number, seed = 0): number {
  let h = seed | 0;
  h = Math.imul(h ^ (x | 0), 0x27d4eb2d);
  h = Math.imul(h ^ (y | 0), 0x165667b1);
  h = Math.imul(h ^ (z | 0), 0x9e3779b1);
  h ^= h >>> 15;
  h = Math.imul(h, 0x85ebca6b);
  h ^= h >>> 13;
  return (h >>> 0) / 4294967295;
}

const smooth = (t: number) => t * t * (3 - 2 * t);

/** Smooth 2D value noise in 0..1. */
export function valueNoise(x: number, y: number, seed = 0): number {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const tx = smooth(x - xi);
  const ty = smooth(y - yi);
  const a = hash2(xi, yi, seed);
  const b = hash2(xi + 1, yi, seed);
  const c = hash2(xi, yi + 1, seed);
  const d = hash2(xi + 1, yi + 1, seed);
  return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
}

/** Fractal sum of value noise, normalised to 0..1. */
export function fbm(x: number, y: number, octaves = 4, seed = 0, lacunarity = 2, gain = 0.5): number {
  let amp = 1;
  let freq = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += valueNoise(x * freq, y * freq, seed + i * 1013) * amp;
    norm += amp;
    amp *= gain;
    freq *= lacunarity;
  }
  return sum / norm;
}

/** Ridged noise — good for cracks, strata and eroded rock. */
export function ridged(x: number, y: number, octaves = 3, seed = 0): number {
  let amp = 1;
  let freq = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    const n = 1 - Math.abs(valueNoise(x * freq, y * freq, seed + i * 733) * 2 - 1);
    sum += n * n * amp;
    norm += amp;
    amp *= 0.5;
    freq *= 2;
  }
  return sum / norm;
}

/** A callable PRNG with convenience helpers attached. */
export interface Rng {
  (): number;
  next: () => number;
  /** int in [min, max] inclusive */
  int: (min: number, max: number) => number;
  /** float in [min, max) */
  range: (min: number, max: number) => number;
  pick: <T>(arr: readonly T[]) => T;
  chance: (p: number) => boolean;
  /** a fresh, independent stream derived from this one */
  fork: (salt?: number) => Rng;
}

/** Small deterministic PRNG (mulberry32) for authored-scatter work. */
export function makeRng(seed: number): Rng {
  let s0 = seed >>> 0;
  const raw = () => {
    s0 = (s0 + 0x6d2b79f5) >>> 0;
    let t = s0;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const rng = raw as Rng;
  rng.next = raw;
  rng.int = (min, max) => min + Math.floor(raw() * (max - min + 1));
  rng.range = (min, max) => min + raw() * (max - min);
  rng.pick = (arr) => arr[Math.floor(raw() * arr.length) % arr.length];
  rng.chance = (p) => raw() < p;
  rng.fork = (salt = 1) => makeRng((Math.floor(raw() * 0xffffffff) ^ Math.imul(salt, 0x9e3779b1)) >>> 0);
  return rng;
}
