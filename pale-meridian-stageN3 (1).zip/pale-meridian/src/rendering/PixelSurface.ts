import { BAYER4, bayer4, bayer8 } from './dither';
import { Color, alphaOf, blendAdd, blendOver, packRGBA } from './color';

export interface BlitOptions {
  flipX?: boolean;
  flipY?: boolean;
  /** global opacity 0..1, dithered so it stays pixel-crisp */
  alpha?: number;
  /** multiply tint, 0..1 per channel */
  tintR?: number;
  tintG?: number;
  tintB?: number;
  /** ignore source alpha and stamp `maskColor` wherever the source is opaque */
  maskColor?: Color;
  /** shift every drawn pixel by this many palette steps toward white/black */
  shadeK?: number;
}

/**
 * A CPU-side pixel buffer.
 *
 * This is the single raster primitive of the whole engine: sprites, terrain,
 * the building, the light buffer and the final frame are all PixelSurfaces.
 * Everything is integer-position, hard-edged, no anti-aliasing anywhere.
 * Because it does not depend on the DOM, the exact same code renders the
 * benchmark scene in the browser and in the offline Node preview tools.
 */
export class PixelSurface {
  readonly width: number;
  readonly height: number;
  readonly data: Uint32Array;

  constructor(width: number, height: number, fill: Color = 0) {
    this.width = width | 0;
    this.height = height | 0;
    this.data = new Uint32Array(this.width * this.height);
    if (fill !== 0) this.data.fill(fill);
  }

  clone(): PixelSurface {
    const s = new PixelSurface(this.width, this.height);
    s.data.set(this.data);
    return s;
  }

  crop(x: number, y: number, w: number, h: number): PixelSurface {
    const out = new PixelSurface(w, h);
    for (let row = 0; row < h; row++) {
      const sy = y + row;
      if (sy < 0 || sy >= this.height) continue;
      for (let col = 0; col < w; col++) {
        const sx = x + col;
        if (sx < 0 || sx >= this.width) continue;
        out.data[row * w + col] = this.data[sy * this.width + sx];
      }
    }
    return out;
  }

  clear(color: Color = 0): void {
    this.data.fill(color);
  }

  fill(color: Color): void {
    this.data.fill(color);
  }

  get(x: number, y: number): Color {
    if (x < 0 || y < 0 || x >= this.width || y >= this.height) return 0;
    return this.data[(y | 0) * this.width + (x | 0)];
  }

  set(x: number, y: number, c: Color): void {
    x |= 0;
    y |= 0;
    if (x < 0 || y < 0 || x >= this.width || y >= this.height) return;
    const i = y * this.width + x;
    this.data[i] = blendOver(this.data[i], c);
  }

  /** Hard set, no blending, no bounds check. Hot-path only. */
  setRaw(x: number, y: number, c: Color): void {
    this.data[y * this.width + x] = c;
  }

  /** Alpha-composite a single pixel against what's already there. */
  blend(x: number, y: number, c: Color): void {
    x |= 0;
    y |= 0;
    if (x < 0 || y < 0 || x >= this.width || y >= this.height) return;
    const i = y * this.width + x;
    this.data[i] = blendOver(this.data[i], c);
  }

  add(x: number, y: number, c: Color, scale = 1): void {
    x |= 0;
    y |= 0;
    if (x < 0 || y < 0 || x >= this.width || y >= this.height) return;
    const i = y * this.width + x;
    this.data[i] = blendAdd(this.data[i], c, scale);
  }

  rect(x: number, y: number, w: number, h: number, c: Color): void {
    x |= 0;
    y |= 0;
    w |= 0;
    h |= 0;
    const x0 = Math.max(0, x);
    const y0 = Math.max(0, y);
    const x1 = Math.min(this.width, x + w);
    const y1 = Math.min(this.height, y + h);
    const a = alphaOf(c);
    for (let yy = y0; yy < y1; yy++) {
      const row = yy * this.width;
      if (a === 255) {
        this.data.fill(c, row + x0, row + x1);
      } else {
        for (let xx = x0; xx < x1; xx++) this.data[row + xx] = blendOver(this.data[row + xx], c);
      }
    }
  }

  /** Rectangle outline (1px). */
  strokeRect(x: number, y: number, w: number, h: number, c: Color): void {
    this.hline(x, y, w, c);
    this.hline(x, y + h - 1, w, c);
    this.vline(x, y, h, c);
    this.vline(x + w - 1, y, h, c);
  }

  hline(x: number, y: number, w: number, c: Color): void {
    this.rect(x, y, w, 1, c);
  }

  vline(x: number, y: number, h: number, c: Color): void {
    this.rect(x, y, 1, h, c);
  }

  /** Bresenham line, integer pixels only. */
  line(x0: number, y0: number, x1: number, y1: number, c: Color): void {
    x0 |= 0;
    y0 |= 0;
    x1 |= 0;
    y1 |= 0;
    const dx = Math.abs(x1 - x0);
    const dy = -Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1;
    const sy = y0 < y1 ? 1 : -1;
    let err = dx + dy;
    for (;;) {
      this.set(x0, y0, c);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 >= dy) {
        err += dy;
        x0 += sx;
      }
      if (e2 <= dx) {
        err += dx;
        y0 += sy;
      }
    }
  }

  /** A line made of short segments defined by a list of points. */
  polyline(pts: number[][], c: Color, close = false): void {
    for (let i = 0; i < pts.length - 1; i++) {
      this.line(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], c);
    }
    if (close && pts.length > 2) {
      const a = pts[pts.length - 1];
      const b = pts[0];
      this.line(a[0], a[1], b[0], b[1], c);
    }
  }

  /** Scanline polygon fill with integer edges. */
  polygon(pts: number[][], c: Color): void {
    if (pts.length < 3) return;
    let minY = Infinity;
    let maxY = -Infinity;
    for (const p of pts) {
      minY = Math.min(minY, p[1]);
      maxY = Math.max(maxY, p[1]);
    }
    minY = Math.max(0, Math.floor(minY));
    maxY = Math.min(this.height - 1, Math.ceil(maxY));
    for (let y = minY; y <= maxY; y++) {
      const xs: number[] = [];
      for (let i = 0; i < pts.length; i++) {
        const a = pts[i];
        const b = pts[(i + 1) % pts.length];
        const y0 = a[1];
        const y1 = b[1];
        if ((y0 <= y && y1 > y) || (y1 <= y && y0 > y)) {
          const t = (y + 0.5 - y0) / (y1 - y0);
          xs.push(a[0] + t * (b[0] - a[0]));
        }
      }
      xs.sort((p, q) => p - q);
      for (let i = 0; i + 1 < xs.length; i += 2) {
        const x0 = Math.max(0, Math.ceil(xs[i] - 0.5));
        const x1 = Math.min(this.width, Math.ceil(xs[i + 1] - 0.5));
        if (x1 > x0) this.rect(x0, y, x1 - x0, 1, c);
      }
    }
  }

  /** Filled ellipse, pixel-exact. */
  ellipse(cx: number, cy: number, rx: number, ry: number, c: Color): void {
    cx |= 0;
    cy |= 0;
    const rxx = Math.max(0.5, rx * rx);
    const ryy = Math.max(0.5, ry * ry);
    for (let y = Math.floor(-ry); y <= Math.ceil(ry); y++) {
      for (let x = Math.floor(-rx); x <= Math.ceil(rx); x++) {
        if ((x * x) / rxx + (y * y) / ryy <= 1) this.set(cx + x, cy + y, c);
      }
    }
  }

  ellipseOutline(cx: number, cy: number, rx: number, ry: number, c: Color): void {
    const steps = Math.max(12, Math.round((rx + ry) * 4));
    for (let i = 0; i < steps; i++) {
      const a = (i / steps) * Math.PI * 2;
      this.set(Math.round(cx + Math.cos(a) * rx), Math.round(cy + Math.sin(a) * ry), c);
    }
  }

  /**
   * Dithered blend between two colours inside a rect, driven by `amount`
   * (0 = all `a`, 1 = all `b`) and a bayer threshold. The workhorse for
   * weathering, dust, rust blooms and soft shadow falloff.
   */
  ditherRect(x: number, y: number, w: number, h: number, a: Color, b: Color, amount: number, size: 4 | 8 = 4): void {
    const th = size === 8 ? bayer8 : bayer4;
    for (let yy = 0; yy < h; yy++) {
      for (let xx = 0; xx < w; xx++) {
        if (th(x + xx, y + yy) < amount) this.set(x + xx, y + yy, b);
        else if (a !== b && alphaOf(a) > 0) this.set(x + xx, y + yy, a);
      }
    }
  }

  /**
   * Multi-stop dithered gradient (vertical by default). Produces the classic
   * banded pixel-art ramp instead of a smooth vector gradient.
   */
  gradientDither(x: number, y: number, w: number, h: number, stops: Color[], horizontal = false): void {
    const n = stops.length;
    if (n === 0) return;
    if (n === 1) {
      this.rect(x, y, w, h, stops[0]);
      return;
    }
    for (let v = 0; v < (horizontal ? w : h); v++) {
      const t = (v / Math.max(1, (horizontal ? w : h) - 1)) * (n - 1);
      const i = Math.min(n - 2, Math.floor(t));
      const frac = t - i;
      const a = stops[i];
      const b = stops[i + 1];
      for (let u = 0; u < (horizontal ? h : w); u++) {
        const px = horizontal ? x + v : x + u;
        const py = horizontal ? y + u : y + v;
        this.set(px, py, bayer4(px, py) < frac ? b : a);
      }
    }
  }

  /** Scatter single pixels of `c` with probability `density`. */
  speckle(x: number, y: number, w: number, h: number, colors: Color[], density: number, rnd: () => number): void {
    for (let yy = 0; yy < h; yy++) {
      for (let xx = 0; xx < w; xx++) {
        if (rnd() < density) {
          this.set(x + xx, y + yy, colors[(rnd() * colors.length) | 0]);
        }
      }
    }
  }

  /**
   * Draw another surface on top.
   * All transforms are nearest-neighbour / integer; nothing is ever resampled.
   */
  blit(src: PixelSurface, dx: number, dy: number, opts: BlitOptions = {}): void {
    dx |= 0;
    dy |= 0;
    const flipX = !!opts.flipX;
    const flipY = !!opts.flipY;
    const alpha = opts.alpha ?? 1;
    const useAlphaDither = alpha < 1;
    const tr = opts.tintR ?? 1;
    const tg = opts.tintG ?? 1;
    const tb = opts.tintB ?? 1;
    const tinted = tr !== 1 || tg !== 1 || tb !== 1 || opts.shadeK !== undefined;
    const k = opts.shadeK ?? 1;
    const mask = opts.maskColor;

    const sx0 = Math.max(0, -dx);
    const sy0 = Math.max(0, -dy);
    const sx1 = Math.min(src.width, this.width - dx);
    const sy1 = Math.min(src.height, this.height - dy);

    for (let sy = sy0; sy < sy1; sy++) {
      const ty = flipY ? src.height - 1 - sy : sy;
      const dRow = (dy + sy) * this.width;
      const sRow = ty * src.width;
      for (let sx = sx0; sx < sx1; sx++) {
        const tx = flipX ? src.width - 1 - sx : sx;
        let c = src.data[sRow + tx];
        const sa = (c >>> 24) & 0xff;
        if (sa === 0) continue;
        if (useAlphaDither) {
          const px = dx + sx;
          const py = dy + sy;
          const th = BAYER4[py & 3][px & 3] / 16;
          if ((sa / 255) * alpha <= th) continue;
          c = packRGBA(c & 0xff, (c >>> 8) & 0xff, (c >>> 16) & 0xff, 255);
        }
        if (mask !== undefined) {
          c = packRGBA(mask & 0xff, (mask >>> 8) & 0xff, (mask >>> 16) & 0xff, sa);
        } else if (tinted) {
          c = packRGBA(
            Math.min(255, ((c & 0xff) * tr * k) | 0),
            Math.min(255, ((((c >>> 8) & 0xff) * tg * k) | 0)),
            Math.min(255, ((((c >>> 16) & 0xff) * tb * k) | 0)),
            sa,
          );
        }
        const i = dRow + dx + sx;
        this.data[i] = blendOver(this.data[i], c);
      }
    }
  }

  /** Additive blit — emissive glows, screen bloom, thruster fire. */
  blitAdd(src: PixelSurface, dx: number, dy: number, scale = 1): void {
    dx |= 0;
    dy |= 0;
    const sx0 = Math.max(0, -dx);
    const sy0 = Math.max(0, -dy);
    const sx1 = Math.min(src.width, this.width - dx);
    const sy1 = Math.min(src.height, this.height - dy);
    for (let sy = sy0; sy < sy1; sy++) {
      const dRow = (dy + sy) * this.width;
      const sRow = sy * src.width;
      for (let sx = sx0; sx < sx1; sx++) {
        const c = src.data[sRow + sx];
        if (((c >>> 24) & 0xff) === 0) continue;
        const i = dRow + dx + sx;
        this.data[i] = blendAdd(this.data[i], c, scale);
      }
    }
  }

  /**
   * Cast shadow from a sprite's alpha mask.
   *
   * `baseX/baseY` is the sprite's ground anchor (its feet). Each opaque pixel
   * is treated as being `(height-1-row)` pixels above the ground and is
   * projected along the ground light direction, so tall objects throw long
   * shadows while the base stays attached to the object. The tail is broken up
   * with an ordered dither so the shadow never looks like a blurred copy.
   */
  castShadow(
    src: PixelSurface,
    baseX: number,
    baseY: number,
    dirX: number,
    dirY: number,
    heightScale: number,
    color: Color,
    softness = 0.85,
  ): void {
    const h = src.height;
    const maxH = Math.max(1, h * heightScale);
    for (let sy = 0; sy < h; sy++) {
      const above = (h - 1 - sy) * heightScale;
      const ox = above * dirX;
      const oy = above * dirY;
      const rowOff = sy * src.width;
      const fade = Math.min(softness, (above / maxH) * softness);
      for (let sx = 0; sx < src.width; sx++) {
        if (((src.data[rowOff + sx] >>> 24) & 0xff) < 40) continue;
        const px = Math.round(baseX + sx + ox);
        const py = Math.round(baseY - (h - 1 - sy) + oy);
        if (px < 0 || py < 0 || px >= this.width || py >= this.height) continue;
        if (fade > 0 && bayer8(px, py) < fade) continue;
        const i = py * this.width + px;
        this.data[i] = blendOver(this.data[i], color);
      }
    }
  }

  /** Soft-ish contact shadow: dithered ellipse, darkest in the middle. */
  contactShadow(cx: number, cy: number, rx: number, ry: number, color: Color, strength = 1): void {
    for (let y = -ry; y <= ry; y++) {
      for (let x = -rx; x <= rx; x++) {
        const d = Math.sqrt((x * x) / (rx * rx) + (y * y) / (ry * ry));
        if (d > 1) continue;
        const a = (1 - d) * strength;
        if (bayer8(cx + x, cy + y) > a) continue;
        const px = cx + x;
        const py = cy + y;
        if (px < 0 || py < 0 || px >= this.width || py >= this.height) continue;
        const i = py * this.width + px;
        this.data[i] = blendOver(this.data[i], color);
      }
    }
  }

  /**
   * Dark outline around everything opaque — the trick that makes small
   * sprites separate cleanly from a busy background.
   * `inside = true` outlines within the silhouette instead of around it.
   */
  outline(color: Color, inside = false, corners = true): void {
    const w = this.width;
    const h = this.height;
    const src = this.data.slice();
    const at = (x: number, y: number) => {
      if (x < 0 || y < 0 || x >= w || y >= h) return 0;
      return (src[y * w + x] >>> 24) & 0xff;
    };
    const offs = corners
      ? [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
          [1, 1],
          [1, -1],
          [-1, 1],
          [-1, -1],
        ]
      : [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ];
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        const opaque = at(x, y) > 0;
        if (inside ? !opaque : opaque) continue;
        let touch = false;
        for (const o of offs) {
          const n = at(x + o[0], y + o[1]);
          if (inside ? n === 0 : n > 0) {
            touch = true;
            break;
          }
        }
        if (touch) this.data[i] = color;
      }
    }
  }

  /** Replace every opaque pixel's colour according to a lookup map. */
  remap(map: Map<Color, Color>): void {
    for (let i = 0; i < this.data.length; i++) {
      const c = this.data[i];
      if (c === 0) continue;
      const key = c & 0x00ffffff;
      const rep = map.get(key);
      if (rep !== undefined) this.data[i] = packRGBA(rep & 0xff, (rep >>> 8) & 0xff, (rep >>> 16) & 0xff, (c >>> 24) & 0xff);
    }
  }

  /** Per-pixel brightness multiply (used by the shading passes). */
  multiplyAll(k: number): void {
    for (let i = 0; i < this.data.length; i++) {
      const c = this.data[i];
      if (c === 0) continue;
      this.data[i] = packRGBA(
        Math.min(255, ((c & 0xff) * k) | 0),
        Math.min(255, ((((c >>> 8) & 0xff) * k) | 0)),
        Math.min(255, ((((c >>> 16) & 0xff) * k) | 0)),
        (c >>> 24) & 0xff,
      );
    }
  }

  /** Bottom-up vertical darkening, dithered — cheap ambient occlusion. */
  darkenRows(y: number, h: number, color: Color, from: number, to: number): void {
    for (let row = 0; row < h; row++) {
      const t = h === 1 ? 1 : row / (h - 1);
      const amount = from + (to - from) * t;
      for (let x = 0; x < this.width; x++) {
        if (bayer4(x, y + row) < amount) this.set(x, y + row, color);
      }
    }
  }

  /** Extract a solid silhouette of this surface (for shadows / masks). */
  silhouette(color: Color): PixelSurface {
    const out = new PixelSurface(this.width, this.height);
    for (let i = 0; i < this.data.length; i++) {
      if (((this.data[i] >>> 24) & 0xff) > 8) out.data[i] = color;
    }
    return out;
  }

  toImageData(): ImageData {
    const bytes = new Uint8ClampedArray(this.width * this.height * 4);
    const view = new Uint32Array(bytes.buffer);
    view.set(this.data);
    return new ImageData(bytes, this.width, this.height);
  }
}
