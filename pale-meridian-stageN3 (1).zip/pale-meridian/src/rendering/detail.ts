import { Color, alphaOf, mix, packRGBA } from './color';
import { bayer2, bayer4, bayer8 } from './dither';
import { PixelSurface } from './PixelSurface';
import { raisedPanel } from './projection';

/**
 * Industrial surface detailing.
 *
 * These are the small, reusable "hand-authored" passes that turn a flat mass
 * into something that looks like it was built, painted, used, abused and
 * patched up: panel seams, rivets, vent slats, hazard paint, corrosion runs,
 * grime, conduit runs and sagging cables.
 */

/** Vertical + horizontal panel seams with a lit bevel on the lower side. */
export function panelSeams(
  s: PixelSurface,
  x: number,
  y: number,
  w: number,
  h: number,
  seam: Color,
  bevel: Color,
  cols: number[],
  rows: number[],
): void {
  for (const c of cols) {
    const px = x + c;
    if (px <= x || px >= x + w - 1) continue;
    s.vline(px, y, h, seam);
    s.vline(px + 1, y, h, bevel);
  }
  for (const r of rows) {
    const py = y + r;
    if (py <= y || py >= y + h - 1) continue;
    s.hline(x, py, w, seam);
    s.hline(x, py + 1, w, bevel);
  }
}

/** Evenly spaced rivet dots along an inset rectangle. */
export function rivets(s: PixelSurface, x: number, y: number, w: number, h: number, dark: Color, light: Color, step = 4): void {
  const put = (px: number, py: number) => {
    s.set(px, py, dark);
    s.set(px, py - 1 < y ? py : py - 1, light);
  };
  for (let px = x + 1; px < x + w - 1; px += step) {
    put(px, y);
    put(px, y + h - 1);
  }
  for (let py = y + step; py < y + h - 1; py += step) {
    put(x, py);
    put(x + w - 1, py);
  }
}

/** Diagonal hazard paint, clipped naturally by the surface bounds. */
export function hazardStripes(
  s: PixelSurface,
  x: number,
  y: number,
  w: number,
  h: number,
  a: Color,
  b: Color,
  period = 6,
): void {
  s.rect(x, y, w, h, a);
  for (let py = 0; py < h; py++) {
    for (let px = 0; px < w; px++) {
      const v = ((px + py * 2) % period + period) % period;
      if (v < period / 2) s.set(x + px, y + py, b);
    }
  }
  // worn-through patches so the paint does not look brand new
  for (let py = 0; py < h; py++) {
    for (let px = 0; px < w; px++) {
      if (bayer8(x + px * 3, y + py * 5) > 0.86) {
        s.set(x + px, y + py, mix(a, 0x00000000, 0.35));
      }
    }
  }
  s.hline(x, y, w, packRGBA(255, 255, 255, 40));
  s.hline(x, y + h - 1, w, packRGBA(0, 0, 0, 70));
}

/** Horizontal vent slats with a catch-light on each lip. */
export function ventGrille(s: PixelSurface, x: number, y: number, w: number, h: number, dark: Color, lip: Color, slat = 2): void {
  s.rect(x, y, w, h, dark);
  for (let py = y + 1; py < y + h - 1; py += slat + 1) {
    s.hline(x + 1, py, w - 2, lip);
  }
  s.strokeRect(x, y, w, h, packRGBA(0, 0, 0, 120));
  s.hline(x, y - 1, w, packRGBA(255, 255, 255, 30));
}

/** Vertical exhaust louvres on an east face. */
export function louvres(s: PixelSurface, x: number, y: number, w: number, h: number, dark: Color, lip: Color): void {
  s.rect(x, y, w, h, dark);
  for (let px = x + 1; px < x + w - 1; px += 3) {
    s.vline(px, y + 1, h - 2, lip);
  }
}

/** Corrosion running down from a seam. */
export function rustRun(s: PixelSurface, x: number, y: number, len: number, colors: Color[], width = 2, seed = 0): void {
  for (let i = 0; i < len; i++) {
    const t = i / len;
    const w = Math.max(1, Math.round(width * (1 - t * 0.7)));
    for (let k = 0; k < w; k++) {
      const ci = Math.min(colors.length - 1, Math.floor(t * colors.length * 0.8 + bayer4(x + k, y + i) * 1.6));
      if (bayer8(x + k + seed, y + i) < 0.25 + t * 0.5) continue;
      s.set(x + k + (i % 2 === 0 ? 0 : 0), y + i, colors[ci]);
    }
  }
}

/** Organic grime / oil patch with a dithered edge. */
export function grimePatch(
  s: PixelSurface,
  cx: number,
  cy: number,
  r: number,
  colors: Color[],
  rnd: () => number,
  squash = 1,
): void {
  const rr = Math.max(1, r);
  for (let y = -Math.ceil(rr * squash) - 1; y <= Math.ceil(rr * squash) + 1; y++) {
    for (let x = -Math.ceil(rr) - 1; x <= Math.ceil(rr) + 1; x++) {
      const wob = 0.72 + rnd() * 0.5;
      const d = Math.sqrt((x * x) / (rr * rr) + (y * y) / ((rr * squash) ** 2)) / wob;
      if (d > 1) continue;
      const ci = Math.min(colors.length - 1, Math.floor(d * colors.length));
      if (d > 0.55 && bayer4(cx + x, cy + y) < d - 0.5) continue;
      s.set(cx + x, cy + y, colors[ci]);
    }
  }
}

/** Dust / sand drift piled along a horizontal edge. */
export function dustDrift(s: PixelSurface, x: number, y: number, w: number, colors: Color[], rnd: () => number, amount = 1): void {
  for (let px = 0; px < w; px++) {
    const hgt = Math.round((0.5 + rnd() * 2.4) * amount);
    for (let i = 0; i < hgt; i++) {
      if (bayer4(px, i) < 0.25 + i * 0.3) continue;
      s.set(x + px, y - i, colors[Math.min(colors.length - 1, i)]);
    }
  }
}

/** Bolt head cluster. */
export function bolts(s: PixelSurface, x: number, y: number, dark: Color, light: Color): void {
  s.set(x, y, dark);
  s.set(x + 1, y, light);
  s.set(x, y + 1, light);
  s.set(x + 1, y + 1, dark);
}

/** Axis-aligned conduit / pipe run with a lit top edge and joint collars. */
export function pipeRun(
  s: PixelSurface,
  pts: number[][],
  width: number,
  dark: Color,
  mid: Color,
  light: Color,
  collar: Color,
): void {
  for (let i = 0; i < pts.length - 1; i++) {
    const [x0, y0] = pts[i];
    const [x1, y1] = pts[i + 1];
    const horizontal = y0 === y1;
    if (horizontal) {
      const a = Math.min(x0, x1);
      const b = Math.max(x0, x1);
      const half = Math.floor(width / 2);
      s.rect(a, y0 - half, b - a + 1, width, mid);
      s.hline(a, y0 - half, b - a + 1, light);
      s.hline(a, y0 + half - (width % 2 === 0 ? 1 : 0), b - a + 1, dark);
      if (width >= 3) s.hline(a, y0 - half + 1, b - a + 1, mix(light, mid, 0.5));
    } else {
      const a = Math.min(y0, y1);
      const b = Math.max(y0, y1);
      const half = Math.floor(width / 2);
      s.rect(x0 - half, a, width, b - a + 1, mid);
      s.vline(x0 - half, a, b - a + 1, light);
      s.vline(x0 + half - (width % 2 === 0 ? 1 : 0), a, b - a + 1, dark);
    }
  }
  // collars at joints
  for (let i = 1; i < pts.length - 1; i++) {
    const [x, y] = pts[i];
    const half = Math.floor(width / 2) + 1;
    s.rect(x - half, y - half, half * 2 + 1, half * 2 + 1, collar);
    s.hline(x - half, y - half, half * 2 + 1, mix(collar, 0x00ffffff, 0.35));
    s.hline(x - half, y + half, half * 2 + 1, mix(collar, 0x00000000, 0.4));
  }
}

/** A sagging cable between two points (catenary), 1px thick with a highlight. */
export function cable(
  s: PixelSurface,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  sag: number,
  dark: Color,
  light: Color,
  thickness = 1,
): void {
  const steps = Math.max(4, Math.abs(x1 - x0) + Math.abs(y1 - y0));
  let prev: [number, number] | null = null;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = x0 + (x1 - x0) * t;
    const y = y0 + (y1 - y0) * t + Math.sin(t * Math.PI) * sag;
    const px = Math.round(x);
    const py = Math.round(y);
    if (prev) {
      s.line(prev[0], prev[1], px, py, dark);
      if (thickness > 1) s.line(prev[0], prev[1] - 1, px, py - 1, dark);
      s.set(px, py - (thickness > 1 ? 1 : 0), light);
    }
    prev = [px, py];
  }
}

/** A small emissive indicator lamp with a hard pixel core. */
export function lamp(s: PixelSurface, x: number, y: number, core: Color, mid: Color, halo: Color): void {
  s.set(x, y - 1, mid);
  s.set(x - 1, y, mid);
  s.set(x + 1, y, mid);
  s.set(x, y + 1, mid);
  s.set(x, y, core);
  s.set(x - 1, y - 1, halo);
  s.set(x + 1, y - 1, halo);
  s.set(x - 1, y + 1, halo);
  s.set(x + 1, y + 1, halo);
}

/** 1px scanline-y screen fill with a fake readout. */
export function screenFill(
  s: PixelSurface,
  x: number,
  y: number,
  w: number,
  h: number,
  bg: Color,
  fg: Color,
  bright: Color,
  rnd: () => number,
): void {
  s.rect(x, y, w, h, bg);
  // faint horizontal scanlines
  for (let py = y; py < y + h; py += 2) s.hline(x, py, w, mix(bg, 0x00000000, 0.35));
  // fake text rows
  const rows = Math.max(1, Math.floor((h - 2) / 3));
  for (let r = 0; r < rows; r++) {
    const ry = y + 2 + r * 3;
    if (ry + 1 >= y + h) break;
    const len = 1 + Math.floor(rnd() * (w - 4));
    s.rect(x + 2, ry, Math.min(len, w - 4), 1, fg);
    if (rnd() < 0.35) s.set(x + 2 + Math.min(len, w - 5), ry, bright);
  }
  // corner highlight of the glass
  s.vline(x + 1, y + 1, Math.max(1, h - 3), packRGBA(255, 255, 255, 26));
  s.hline(x + 1, y + 1, Math.max(1, w - 3), packRGBA(255, 255, 255, 22));
}

/** Generic "boxed unit" — a small machine with a lit top-left bevel. */
export function techBox(
  s: PixelSurface,
  x: number,
  y: number,
  w: number,
  h: number,
  face: Color,
  light: Color,
  dark: Color,
  edge: Color,
): void {
  raisedPanel(s, x, y, w, h, face, light, dark);
  s.strokeRect(x, y, w, h, edge);
}

/** Weathering speckle over an area — a few dozen intentional pixels. */
export function weatherSpeckle(s: PixelSurface, x: number, y: number, w: number, h: number, colors: Color[], density: number, rnd: () => number): void {
  const count = Math.round(w * h * density);
  for (let i = 0; i < count; i++) {
    const px = x + Math.floor(rnd() * w);
    const py = y + Math.floor(rnd() * h);
    const c = colors[Math.floor(rnd() * colors.length)];
    if (alphaOf(s.get(px, py)) === 0) continue;
    s.set(px, py, c);
  }
}

/** Scratch marks — short diagonal 2-tone strokes. */
export function scratches(s: PixelSurface, x: number, y: number, w: number, h: number, light: Color, dark: Color, count: number, rnd: () => number): void {
  for (let i = 0; i < count; i++) {
    const px = x + Math.floor(rnd() * w);
    const py = y + Math.floor(rnd() * h);
    const len = 2 + Math.floor(rnd() * 5);
    const dy = rnd() < 0.5 ? 1 : -1;
    for (let k = 0; k < len; k++) {
      s.set(px + k, py + k * dy * (k % 2), dark);
      s.set(px + k, py + k * dy * (k % 2) - 1, light);
    }
  }
}

/** Dithered vertical gradient inside a rect (banded, not smooth). */
export function bandedGradient(s: PixelSurface, x: number, y: number, w: number, h: number, top: Color, bottom: Color): void {
  for (let py = 0; py < h; py++) {
    const t = h === 1 ? 0 : py / (h - 1);
    const c = mix(top, bottom, Math.round(t * 7) / 7);
    for (let px = 0; px < w; px++) {
      const th = bayer2(px, py);
      s.set(x + px, y + py, th < t * 0.6 ? mix(c, bottom, 0.35) : c);
    }
  }
}
