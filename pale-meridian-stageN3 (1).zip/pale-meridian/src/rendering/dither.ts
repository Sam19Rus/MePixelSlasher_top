/**
 * Ordered dither matrices.
 *
 * Used everywhere instead of alpha gradients: banded dithering is what keeps
 * surfaces, shadows and light falloffs reading as hand-authored pixel art
 * rather than as soft vector fills.
 */

export const BAYER2 = [
  [0, 2],
  [3, 1],
];

export const BAYER4 = [
  [0, 8, 2, 10],
  [12, 4, 14, 6],
  [3, 11, 1, 9],
  [15, 7, 13, 5],
];

export const BAYER8 = [
  [0, 32, 8, 40, 2, 34, 10, 42],
  [48, 16, 56, 24, 50, 18, 58, 26],
  [12, 44, 4, 36, 14, 46, 6, 38],
  [60, 28, 52, 20, 62, 30, 54, 22],
  [3, 35, 11, 43, 1, 33, 9, 41],
  [51, 19, 59, 27, 49, 17, 57, 25],
  [15, 47, 7, 39, 13, 45, 5, 37],
  [63, 31, 55, 23, 61, 29, 53, 21],
];

/** Normalised 0..1 threshold for a 4x4 bayer cell. */
export const bayer4 = (x: number, y: number): number => BAYER4[y & 3][x & 3] / 16;
/** Normalised 0..1 threshold for a 2x2 bayer cell. */
export const bayer2 = (x: number, y: number): number => BAYER2[y & 1][x & 1] / 4;
/** Normalised 0..1 threshold for an 8x8 bayer cell. */
export const bayer8 = (x: number, y: number): number => BAYER8[y & 7][x & 7] / 64;
