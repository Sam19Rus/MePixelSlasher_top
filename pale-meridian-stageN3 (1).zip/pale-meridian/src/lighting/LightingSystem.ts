import { PixelSurface } from '../rendering/PixelSurface';
import { bayer4 } from '../rendering/dither';
import type { Rect } from '../data/layout';

/**
 * LIGHTING — a modern light pass sitting *on top of* hard pixel art.
 *
 * The scene is rendered fully lit-by-hand (every sprite carries its own
 * directional shading). This pass then adds:
 *   - a global ambient tint (time of day),
 *   - additive local lights with shaped falloff,
 *   - ray-marched shadows from world colliders for the important lamps,
 * and multiplies the result over the frame. Because the multiply happens per
 * pixel on integer colour data, the pixel art underneath stays perfectly
 * crisp — light never blurs an edge.
 */

export type TimeOfDay = 'dusk' | 'night' | 'day';

export interface Ambient {
  r: number;
  g: number;
  b: number;
  /** additive sky/shadow fill, 0..255 per channel */
  fr: number;
  fg: number;
  fb: number;
  /** multiplier applied to every local light */
  lightScale: number;
  /** alpha multiplier for baked sun shadows */
  shadowScale: number;
  label: string;
}

export const TIME_OF_DAY: Record<TimeOfDay, Ambient> = {
  dusk: { r: 0.62, g: 0.55, b: 0.5, fr: 12, fg: 10, fb: 10, lightScale: 1, shadowScale: 1, label: 'DUSK' },
  night: { r: 0.2, g: 0.22, b: 0.32, fr: 12, fg: 16, fb: 28, lightScale: 1.35, shadowScale: 0.35, label: 'NIGHT' },
  day: { r: 1.02, g: 0.99, b: 0.92, fr: 4, fg: 4, fb: 4, lightScale: 0.28, shadowScale: 1.25, label: 'DAY' },
};

export interface LightDef {
  x: number;
  y: number;
  radius: number;
  r: number;
  g: number;
  b: number;
  intensity: number;
  /** 0 = constant; otherwise amplitude of the flicker */
  flicker?: number;
  /** slow pulse period in seconds */
  pulse?: number;
  blink?: number;
  castShadows?: boolean;
  /**
   * Constant lights (no flicker/blink/pulse) in a static-camera zone can be
   * baked once into a persistent accumulation buffer instead of re-stamped
   * every frame.
   */
  static?: boolean;
}

export class LightingSystem {
  private acc: Float32Array = new Float32Array(0);
  private staticAcc: Float32Array = new Float32Array(0);
  private staticKey = '';
  private shadowMask: Uint8Array = new Uint8Array(0);
  private maskPool: Uint8Array | null = null;
  width = 0;
  height = 0;
  enabled = true;
  timeOfDay: TimeOfDay = 'dusk';
  /** optional clip rect (panel isolation) */
  private clip: { x0: number; y0: number; x1: number; y1: number } | null = null;

  setClip(x0: number, y0: number, x1: number, y1: number): void {
    this.clip = { x0, y0, x1, y1 };
  }

  clearClip(): void {
    this.clip = null;
  }

  resize(w: number, h: number): void {
    this.width = w;
    this.height = h;
    this.acc = new Float32Array(w * h * 3);
    this.staticAcc = new Float32Array(w * h * 3);
    this.staticKey = '';
    this.shadowMask = new Uint8Array(w * h);
  }

  begin(): void {
    this.acc.set(this.staticAcc);
  }

  invalidateStatic(): void {
    this.staticKey = '';
  }

  /**
   * Bake all `static` lights of a frame into staticAcc. `key` must capture
   * everything that changes their contribution (zone, time of day, shadow
   * toggle, camera). Cheap no-op when the key is unchanged.
   */
  configureStatic(key: string, lights: LightDef[], t: number, colliders: Rect[], ox: number, oy: number): void {
    if (key === this.staticKey) return;
    this.staticKey = key;
    this.staticAcc.fill(0);
    const saved = this.acc;
    this.acc = this.staticAcc;
    for (const l of lights) this.accumulate(l, t, colliders, ox, oy);
    this.acc = saved;
  }

  /** Add one light in screen space. */
  addLight(l: LightDef, t: number, colliders: Rect[], ox = 0, oy = 0): void {
    if (!this.enabled) return;
    this.accumulate(l, t, colliders, ox, oy);
  }

  private accumulate(l: LightDef, t: number, colliders: Rect[], ox = 0, oy = 0): void {
    const amb = TIME_OF_DAY[this.timeOfDay];
    let intensity = l.intensity * amb.lightScale;
    if (l.flicker) {
      const n = Math.sin(t * 37.3 + l.x) * 0.5 + Math.sin(t * 91.7 + l.y) * 0.5;
      intensity *= 1 - l.flicker * 0.5 * (0.5 + 0.5 * n);
    }
    if (l.pulse) intensity *= 0.72 + 0.28 * Math.sin((t / l.pulse) * Math.PI * 2);
    if (l.blink) {
      const on = (t % l.blink) / l.blink < 0.16;
      intensity *= on ? 1 : 0.06;
    }
    if (intensity <= 0.004) return;

    const R = Math.ceil(l.radius);
    const c = this.clip;
    const x0 = Math.max(c ? c.x0 : 0, Math.floor(l.x - R));
    const y0 = Math.max(c ? c.y0 : 0, Math.floor(l.y - R));
    const x1 = Math.min(c ? c.x1 : this.width - 1, Math.ceil(l.x + R));
    const y1 = Math.min(c ? c.y1 : this.height - 1, Math.ceil(l.y + R));
    if (x1 <= x0 || y1 <= y0) return;

    let mask = this.shadowMask;
    let mw = x1 - x0 + 1;
    if (l.castShadows) {
      const near: Rect[] = [];
      for (const c of colliders) {
        if (c.x + ox > l.x + R || c.x + c.w + ox < l.x - R || c.y + oy > l.y + R || c.y + c.h + oy < l.y - R) continue;
        near.push(c);
      }
      const m = this.computeShadowMask(l, x0, y0, x1, y1, near, ox, oy);
      mask = m.mask;
      mw = m.hw;
    }

    const r2 = l.radius * l.radius;
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        const dx = x - l.x;
        const dy = (y - l.y) * 1.12; // slightly squash: light pools read as ground pools
        const d2 = dx * dx + dy * dy;
        if (d2 > r2) continue;
        const d = Math.sqrt(d2) / l.radius;
        // shaped falloff: hot core, soft shoulder, hard stop
        let f = 1 - d;
        f = f * f * (3 - 2 * f);
        f = f * f * f * 0.7 + f * 0.3;
        if (l.castShadows) {
          const mi = ((y - y0) >> 1) * mw + ((x - x0) >> 1);
          f *= mask[mi] / 255;
        }
        const v = f * intensity;
        if (v <= 0.004) continue;
        const i = (y * this.width + x) * 3;
        this.acc[i] += l.r * v;
        this.acc[i + 1] += l.g * v;
        this.acc[i + 2] += l.b * v;
      }
    }
  }

  /**
   * Occlusion mask at half resolution (sampled nearest): shadow edges are
   * dithered by the falloff anyway, so full-res marching is wasted CPU.
   */
  private computeShadowMask(
    l: LightDef,
    x0: number,
    y0: number,
    x1: number,
    y1: number,
    colliders: Rect[],
    ox: number,
    oy: number,
  ): { mask: Uint8Array; hw: number } {
    const hw = Math.max(1, Math.ceil((x1 - x0 + 1) / 2));
    const hh = Math.max(1, Math.ceil((y1 - y0 + 1) / 2));
    let mask = this.maskPool;
    if (!mask || mask.length < hw * hh) {
      mask = new Uint8Array(hw * hh);
      this.maskPool = mask;
    }
    const n = colliders.length;
    for (let j = 0; j < hh; j++) {
      const py = y0 + j * 2 + 1;
      for (let i = 0; i < hw; i++) {
        const px = x0 + i * 2 + 1;
        const dx = px - l.x;
        const dy = py - l.y;
        const dist = Math.hypot(dx, dy);
        const steps = Math.max(2, Math.ceil(dist / 2));
        let lit = 255;
        for (let s = 1; s < steps; s++) {
          const t = s / steps;
          const sx = l.x + dx * t + ox;
          const sy = l.y + dy * t + oy;
          for (let c = 0; c < n; c++) {
            const r = colliders[c];
            if (sx >= r.x && sx <= r.x + r.w && sy >= r.y && sy <= r.y + r.h) {
              lit = 40;
              break;
            }
          }
          if (lit === 40) break;
        }
        mask[j * hw + i] = lit;
      }
    }
    return { mask, hw };
  }

  /** Multiply ambient + accumulated light over the frame, in place. */
  apply(dest: PixelSurface, dither = true, rect?: { x0: number; y0: number; x1: number; y1: number }): void {
    if (!this.enabled) return; // sprites already carry hand-authored lighting
    const amb = TIME_OF_DAY[this.timeOfDay];
    const data = dest.data;
    const acc = this.acc;
    const w = this.width;
    const rx0 = rect ? rect.x0 : 0;
    const ry0 = rect ? rect.y0 : 0;
    const rx1 = rect ? rect.x1 : w - 1;
    const ry1 = rect ? rect.y1 : this.height - 1;
    for (let y = ry0; y <= ry1; y++) {
      for (let x = rx0; x <= rx1; x++) {
        const i2 = y * w + x;
        const c = data[i2];
        if (c === 0) continue;
        const p = i2 * 3;
        let lr = amb.r + acc[p];
        let lg = amb.g + acc[p + 1];
        let lb = amb.b + acc[p + 2];
        if (lr > 2.2) lr = 2.2;
        if (lg > 2.2) lg = 2.2;
        if (lb > 2.2) lb = 2.2;
        if (dither) {
          const q = (bayer4(x, y) - 0.5) * 0.035;
          lr += q;
          lg += q;
          lb += q;
        }
        const r = (c & 0xff) * lr + amb.fr;
        const g = ((c >>> 8) & 0xff) * lg + amb.fg;
        const b = ((c >>> 16) & 0xff) * lb + amb.fb;
        data[i2] =
          (255 << 24) |
          ((b > 255 ? 255 : b) << 16) |
          ((g > 255 ? 255 : g) << 8) |
          (r > 255 ? 255 : r);
      }
    }
  }
}
