/**
 * N1 PROJECTION — a standalone 2D camera-like orthographic projection.
 *
 * Visual hint source: Camera Lab preset N1 (orthographic, yaw ~128.4°,
 * pitch ~37.2°). The angles are NOT copied into formulas; they only describe
 * the feel we reconstruct in 2D:
 *
 *  - camera high above, looking down at a noticeable tilt;
 *  - roof stays clearly readable (ground/roof planes keep ~62% of depth);
 *  - walls have substantial height (~78% of true height on screen) and read
 *    as vertical surfaces (verticals stay pixel-vertical);
 *  - two building faces visible (front + east) with an asymmetric ~62/38
 *    ratio, matching the yaw hint;
 *  - ground keeps top-down readability (axis-aligned lattice, mild shear).
 *
 * The module is pure math: no scene knowledge. Everything (terrain decals,
 * walls, roofs, props, shadows, interior) projects through these functions,
 * so all surfaces share one consistent transform and edges always match.
 */

export interface FaceQuad {
  pts: number[][];
  origin: [number, number];
  u: [number, number];
  v: [number, number];
  uw: number;
  vh: number;
}

export interface N1ProjectionParams {
  /** horizontal shear per depth unit (expresses yaw; east-face reveal) */
  shear: number;
  /** screen depth per depth unit (roof/ground plane foreshortening, sin pitch) */
  squash: number;
  /** screen height per height unit (wall presence, cos pitch) */
  heightScale: number;
  /** ground-plane shadow direction per height unit */
  shadowDir: { x: number; y: number };
}

/** N1 tuned values (see header for the reasoning). */
export const N1_PARAMS: N1ProjectionParams = {
  shear: 0.34,
  squash: 0.62,
  heightScale: 0.78,
  shadowDir: { x: 0.66, y: 0.4 },
};

export class N1Projection {
  constructor(public p: N1ProjectionParams = N1_PARAMS) {}

  /** world point (x, y ground, z height) -> screen point */
  projectPoint(x: number, y: number, z = 0): [number, number] {
    return [x + this.p.shear * y, this.p.squash * y - this.projectHeight(z)];
  }

  /** alias kept for readability at call sites */
  project(x: number, y: number, z = 0): [number, number] {
    return this.projectPoint(x, y, z);
  }

  /** screen height of a world height */
  projectHeight(h: number): number {
    return Math.round(h * this.p.heightScale);
  }

  /** the four vertical faces + roof of a box; footprint front-left (x,y), w east, d north-ish(depth), h height */
  projectBox(x: number, y: number, w: number, d: number, h: number) {
    const H = this.projectHeight(h);
    const [fx, fy] = this.projectPoint(x, y + d); // front-left ground (south edge)
    const [fx2, fy2] = this.projectPoint(x + w, y + d); // front-right ground
    const [ex, ey] = this.projectPoint(x + w, y); // east-back ground
    const [bx, by] = this.projectPoint(x, y); // back-left ground
    const front = {
      pts: [
        [fx, fy],
        [fx2, fy2],
        [fx2, fy2 - H],
        [fx, fy - H],
      ],
      origin: [fx, fy - H] as [number, number],
      u: [1, 0] as [number, number],
      v: [0, 1] as [number, number],
      uw: w,
      vh: H,
    };
    const east = {
      pts: [
        [fx2, fy2],
        [ex, ey],
        [ex, ey - H],
        [fx2, fy2 - H],
      ],
      origin: [fx2, fy2 - H] as [number, number],
      u: [(ex - fx2) / Math.max(1, d), (ey - fy2) / Math.max(1, d)] as [number, number],
      v: [0, 1] as [number, number],
      uw: d,
      vh: H,
    };
    const roof = {
      pts: [
        [fx, fy - H],
        [fx2, fy2 - H],
        [ex, ey - H],
        [bx, by - H],
      ],
      origin: [fx, fy - H] as [number, number],
      u: [1, 0] as [number, number],
      v: [(ex - fx2) / Math.max(1, d), (ey - fy2) / Math.max(1, d)] as [number, number],
      uw: w,
      vh: d,
    };
    const west = {
      pts: [
        [fx, fy],
        [bx, by],
        [bx, by - H],
        [fx, fy - H],
      ],
      origin: [fx, fy - H] as [number, number],
      u: [(bx - fx) / Math.max(1, d), (by - fy) / Math.max(1, d)] as [number, number],
      v: [0, 1] as [number, number],
      uw: d,
      vh: H,
    };
    return { front, east, west, roof, H };
  }

  /** convenience wrappers used by scene bakers */
  projectWall(x: number, y: number, w: number, d: number, h: number) {
    return this.projectBox(x, y, w, d, h).front;
  }
  projectRoof(x: number, y: number, w: number, d: number, h: number) {
    return this.projectBox(x, y, w, d, h).roof;
  }
  /** ground quad of a footprint (decals, shadows) */
  projectQuad(x: number, y: number, w: number, d: number): [number, number][] {
    return [this.projectPoint(x, y + d), this.projectPoint(x + w, y + d), this.projectPoint(x + w, y), this.projectPoint(x, y)];
  }
  /** cast shadow offset for a world height */
  shadowOffset(h: number): [number, number] {
    return [this.p.shadowDir.x * h * 0.5, this.p.shadowDir.y * h * 0.5];
  }
  /** painter depth: view-direction coordinate of a ground anchor */
  depth(x: number, y: number, baseZ = 0, bias = 0): number {
    return y + x * 0.06 + baseZ * 0.02 + bias;
  }
}
