import { PixelSurface } from '../rendering/PixelSurface';
import { LightingSystem, type TimeOfDay } from '../lighting/LightingSystem';
import { VIEW_H, VIEW_W } from '../data/config';
import { bayer4 } from '../rendering/dither';
import { mix, packRGBA, withAlpha } from '../rendering/color';
import { cyan, metal, warm } from '../data/palette';
import { N1Projection } from './projection';
import { bakeN1World, type N1World } from './world';
import { assembleCharacter, drawAssembly, type CharPose } from './character/CompositeCharacter';
import type { Input } from '../input/Input';

/**
 * N1 SCENE — one rectangular technical building, one composite character,
 * one drone, one room interior with cutaway. Plays like a game slice:
 * walk around, enter with E, inspect interior in the same projection.
 */

const DRONE_CHASSIS = [
  '..HHHH..',
  '.HhhhhH.',
  'HHaaaaHH',
  'HaxccxaH',
  'HHaaaaHH',
  '.HbbbbH.',
  '..HbbH..',
];
const DRONE_ARM = ['.H.', 'HhH', '.K.'];

export class N1Scene {
  readonly lighting = new LightingSystem();
  readonly proj = new N1Projection();
  world: N1World;
  zone: 'ext' | 'int' = 'ext';
  time = 0;
  review = { lighting: true, timeOfDay: 'dusk' as TimeOfDay, debug: false };
  prompt = false;

  private px: number;
  private py: number;
  private vx = 0;
  private vy = 0;
  private orient: 'side' | 'front' = 'side';
  private facing = 1;
  private animT = 0;
  private moving = false;
  private aiming = false;
  private camX = 0;
  private camY = 0;
  private drone = { x: 340, y: 250, t: 0, wp: 0 };
  private atmo: PixelSurface | null = null;
  private fade = 0;
  private pending: 'ext' | 'int' | null = null;

  constructor() {
    this.world = bakeN1World(this.proj);
    this.lighting.resize(VIEW_W, VIEW_H);
    this.px = this.world.entrance.ext.x;
    this.py = this.world.entrance.ext.y + 26;
    this.snapCam();
  }

  private snapCam(): void {
    const [gx, gy] = this.proj.projectPoint(this.px, this.py);
    this.camX = this.clamp(gx + this.world.ox - VIEW_W / 2, this.world.width - VIEW_W);
    this.camY = this.clamp(gy + this.world.oy - 10 - VIEW_H / 2, this.world.height - VIEW_H);
  }
  private clamp(v: number, max: number): number {
    if (max <= 0) return Math.round(max / 2);
    return Math.round(Math.max(0, Math.min(max, v)));
  }

  get nearEntrance(): boolean {
    const e = this.zone === 'ext' ? this.world.entrance.ext : this.world.entrance.int;
    return Math.hypot(this.px - e.x, this.py - e.y) < 14;
  }

  update(dt: number, input: Input): void {
    this.time += dt;
    if (this.pending) {
      this.fade = Math.min(1, this.fade + dt * 5);
      if (this.fade >= 1) {
        this.zone = this.pending;
        this.pending = null;
        const e = this.zone === 'ext' ? this.world.entrance.ext : this.world.entrance.int;
        this.px = e.x;
        this.py = e.y + (this.zone === 'ext' ? 6 : -2);
        this.vx = this.vy = 0;
        this.snapCam();
      }
    } else if (this.fade > 0) this.fade = Math.max(0, this.fade - dt * 4);

    if (!this.pending) {
      const axis = input.axis();
      const speed = input.running ? 76 : 50;
      const tx = axis.x * speed;
      const ty = axis.y * speed;
      const dvx = tx - this.vx;
      const dvy = ty - this.vy;
      const dl = Math.hypot(dvx, dvy);
      const step = Math.min(dl, 600 * dt);
      if (dl > 0) {
        this.vx += (dvx / dl) * step;
        this.vy += (dvy / dl) * step;
      }
      this.moving = Math.hypot(this.vx, this.vy) > 6;
      this.aiming = input.isDown('Space');
      const colliders = this.zone === 'ext' ? this.world.collidersExt : this.world.collidersInt;
      const bounds =
        this.zone === 'ext'
          ? { x: 30, y: 130, w: this.world.worldW - 60, h: this.world.worldH - 160 }
          : { x: this.world.interiorRect.x + 2, y: this.world.interiorRect.y + 2, w: this.world.interiorRect.w - 4, h: this.world.interiorRect.h - 4 };
      const r = 5;
      const hits = (x: number, y: number) => {
        if (x - r < bounds.x || x + r > bounds.x + bounds.w || y - r < bounds.y || y + r > bounds.y + bounds.h) return true;
        for (const c of colliders) if (x + r > c.x && x - r < c.x + c.w && y + r > c.y && y - r < c.y + c.h) return true;
        return false;
      };
      const nx = this.px + this.vx * dt;
      if (!hits(nx, this.py)) this.px = nx;
      else this.vx = 0;
      const ny = this.py + this.vy * dt;
      if (!hits(this.px, ny)) this.py = ny;
      else this.vy = 0;
      if (this.moving) {
        if (Math.abs(this.vx) > Math.abs(this.vy)) {
          this.orient = 'side';
          this.facing = this.vx > 0 ? 1 : -1;
        } else this.orient = 'front';
        this.animT += dt * (input.running ? 11 : 8);
      }
      this.prompt = this.nearEntrance;
      if (this.prompt && input.consume('KeyE', 'Enter')) this.pending = this.zone === 'ext' ? 'int' : 'ext';
      // drone patrol
      const wps = [
        [340, 250],
        [380, 230],
        [360, 210],
        [320, 226],
      ];
      const wp = wps[this.drone.wp];
      const dx = wp[0] - this.drone.x;
      const dy = wp[1] - this.drone.y;
      const dd = Math.hypot(dx, dy);
      if (dd < 4) this.drone.wp = (this.drone.wp + 1) % wps.length;
      else {
        this.drone.x += (dx / dd) * 12 * dt;
        this.drone.y += (dy / dd) * 12 * dt;
      }
      this.drone.t += dt;
    }
    const [gx, gy] = this.proj.projectPoint(this.px, this.py);
    const dx = this.clamp(gx + this.world.ox - VIEW_W / 2, this.world.width - VIEW_W) - this.camX;
    const dy = this.clamp(gy + this.world.oy - 10 - VIEW_H / 2, this.world.height - VIEW_H) - this.camY;
    const k = 1 - Math.exp(-7.5 * dt);
    this.camX += dx * k;
    this.camY += dy * k;
    input.endFrame();
  }

  private charPose(): CharPose {
    return {
      state: this.aiming ? 'aim' : this.moving ? 'walk' : 'idle',
      phase: this.moving ? Math.floor(this.animT) % 4 : 0,
      orient: this.orient,
      breath: Math.sin(this.time * 2.4) > 0.5 ? 1 : 0,
      look: !this.moving && Math.sin(this.time * 0.9) > 0.6 ? 1 : 0,
    };
  }

  render(): PixelSurface {
    const s = new PixelSurface(VIEW_W, VIEW_H);
    const w = this.world;
    const camX = Math.round(this.camX);
    const camY = Math.round(this.camY);
    // ground
    for (let y = 0; y < VIEW_H; y++) {
      const sy = camY + y;
      const row = y * VIEW_W;
      if (sy < 0 || sy >= w.height) {
        s.data.fill(0xff0d0b0a, row, row + VIEW_W);
        continue;
      }
      const srcRow = sy * w.width;
      if (camX >= 0 && camX + VIEW_W <= w.width) s.data.set(w.ground.data.subarray(srcRow + camX, srcRow + camX + VIEW_W), row);
      else {
        for (let x = 0; x < VIEW_W; x++) {
          const sx = camX + x;
          s.data[row + x] = sx >= 0 && sx < w.width ? w.ground.data[srcRow + sx] : 0xff0d0b0a;
        }
      }
    }
    // baked shadows
    const sh = this.zone === 'ext' ? w.shadow : w.shadowCut;
    for (let y = 0; y < VIEW_H; y++) {
      const sy = camY + y;
      if (sy < 0 || sy >= w.height) continue;
      const srcRow = sy * w.width;
      for (let x = 0; x < VIEW_W; x++) {
        const sx = camX + x;
        if (sx < 0 || sx >= w.width) continue;
        const c = sh.data[srcRow + sx];
        if (((c >>> 24) & 0xff) === 0) continue;
        if (bayer4(x, y) > 0.9) continue;
        const i = y * VIEW_W + x;
        const sa = (c >>> 24) & 0xff;
        const isa = 255 - sa;
        const d0 = s.data[i];
        s.data[i] = packRGBA(
          (((c & 0xff) * sa + (d0 & 0xff) * isa) / 255) | 0,
          ((((c >>> 8) & 0xff) * sa + ((d0 >>> 8) & 0xff) * isa) / 255) | 0,
          ((((c >>> 16) & 0xff) * sa + ((d0 >>> 16) & 0xff) * isa) / 255) | 0,
          255,
        );
      }
    }
    // renderables
    const list = w.renderables.filter((o) => o.mode === 'both' || (o.mode === 'ext') === (this.zone === 'ext'));
    list.sort((a, b) => a.depth - b.depth);
    for (const o of list) s.blit(o.sprite, o.x - camX, o.y - camY);

    // drone
    const [dsx, dsy] = this.proj.projectPoint(this.drone.x, this.drone.y);
    const dbx = Math.round(dsx + w.ox) - camX;
    const dby = Math.round(dsy + w.oy) - camY - 10 + Math.round(Math.sin(this.drone.t * 2.6) * 1.5);
    s.contactShadow(dbx + 4, dby + 14, 6, 3, packRGBA(30, 17, 14, 110), 0.85);
    const dmap = DRONE_CHASSIS;
    for (let ry = 0; ry < dmap.length; ry++) {
      for (let rx = 0; rx < dmap[ry].length; rx++) {
        const ch = dmap[ry][rx];
        const c = ch === 'H' ? metal.m4 : ch === 'h' ? metal.m7 : ch === 'a' ? metal.m5 : ch === 'b' ? metal.m2 : ch === 'c' ? cyan.c3 : ch === 'x' ? warm.w0 : 0;
        if (!c) continue;
        s.set(dbx + rx, dby + ry, c);
      }
    }
    const armOff = Math.sin(this.drone.t * 3) > 0 ? 0 : 1;
    for (let ry = 0; ry < DRONE_ARM.length; ry++) {
      for (let rx = 0; rx < 3; rx++) {
        const ch = DRONE_ARM[ry][rx];
        const c = ch === 'H' ? metal.m3 : ch === 'h' ? metal.m6 : ch === 'K' ? warm.w3 : 0;
        if (!c) continue;
        s.set(dbx + 8 + rx, dby + 4 + ry + armOff, c);
      }
    }
    // thruster glow
    s.set(dbx + 3, dby + 8, cyan.c5);
    s.set(dbx + 4, dby + 8, cyan.c4);
    s.set(dbx + 3, dby + 9, withAlpha(cyan.c2, 140));
    s.set(dbx + 4, dby + 9, withAlpha(cyan.c2, 140));

    // character
    const [csx, csy] = this.proj.projectPoint(this.px, this.py);
    const cbx = Math.round(csx + w.ox) - camX;
    const cby = Math.round(csy + w.oy) - camY;
    s.contactShadow(cbx + 1, cby + 1, 6, 3, packRGBA(28, 16, 13, 120), 0.9);
    const assembly = assembleCharacter(this.charPose(), cbx, cby, this.orient === 'side' && this.facing < 0);
    drawAssembly(s, assembly);

    // lights
    this.lighting.timeOfDay = this.review.timeOfDay;
    this.lighting.enabled = this.review.lighting;
    this.lighting.begin();
    for (const l of w.lights) {
      if (l.mode !== 'both' && (l.mode === 'int') !== (this.zone === 'int')) continue;
      const [lx, ly] = this.proj.projectPoint(l.x, l.y);
      this.lighting.addLight(
        { x: lx + w.ox - camX, y: ly + w.oy - camY, radius: l.r, r: l.c[0], g: l.c[1], b: l.c[2], intensity: l.i, flicker: l.flicker, blink: l.blink },
        this.time,
        [],
        0,
        0,
      );
    }
    this.lighting.addLight({ x: assembly.muzzle[0], y: assembly.muzzle[1], radius: 6, r: 0.2, g: 0.85, b: 0.95, intensity: 0.2 }, this.time, [], 0, 0);
    this.lighting.addLight({ x: dbx + 4, y: dby + 3, radius: 10, r: 0.25, g: 0.9, b: 1, intensity: 0.35 }, this.time, [], 0, 0);
    this.lighting.apply(s);

    // atmosphere
    if (!this.atmo) this.atmo = this.bakeAtmo();
    for (let i = 0; i < this.atmo.data.length; i++) {
      const c = this.atmo.data[i];
      if (((c >>> 24) & 0xff) === 0) continue;
      s.data[i] = blendOver(s.data[i], c);
    }

    if (this.review.debug) {
      for (const c of this.zone === 'ext' ? w.collidersExt : w.collidersInt) {
        const q = [this.proj.projectPoint(c.x, c.y), this.proj.projectPoint(c.x + c.w, c.y), this.proj.projectPoint(c.x + c.w, c.y + c.h), this.proj.projectPoint(c.x, c.y + c.h)];
        for (let i = 0; i < 4; i++) {
          const a = q[i];
          const b = q[(i + 1) % 4];
          s.line(Math.round(a[0] + w.ox) - camX, Math.round(a[1] + w.oy) - camY, Math.round(b[0] + w.ox) - camX, Math.round(b[1] + w.oy) - camY, packRGBA(80, 255, 120, 200));
        }
      }
      const e = this.zone === 'ext' ? w.entrance.ext : w.entrance.int;
      const [ex, ey] = this.proj.projectPoint(e.x, e.y);
      s.ellipseOutline(Math.round(ex + w.ox) - camX, Math.round(ey + w.oy) - camY, 10, 6, packRGBA(80, 255, 120, 220));
    }

    if (this.fade > 0.01) {
      for (let y = 0; y < VIEW_H; y++) for (let x = 0; x < VIEW_W; x++) if (bayer4(x, y) < this.fade) s.data[y * VIEW_W + x] = 0xff080708;
    }
    return s;
  }

  private bakeAtmo(): PixelSurface {
    const a = new PixelSurface(VIEW_W, VIEW_H);
    for (let y = 0; y < VIEW_H; y++) {
      for (let x = 0; x < VIEW_W; x++) {
        const dx = (x - VIEW_W / 2) / (VIEW_W / 2);
        const dy = (y - VIEW_H / 2) / (VIEW_H / 2);
        const d = Math.sqrt(dx * dx * 0.8 + dy * dy * 1.15);
        if (d < 0.78) continue;
        const t = Math.min(1, (d - 0.78) / 0.45) * 0.38;
        if (bayer4(x, y) <= t) a.data[y * VIEW_W + x] = withAlpha(mix(0x00000000, 0x0c0a09, 1), Math.round(t * 255));
      }
    }
    return a;
  }
}

function blendOver(dst: number, src: number): number {
  const sa = (src >>> 24) & 0xff;
  if (sa === 255) return src;
  const isa = 255 - sa;
  const da = (dst >>> 24) & 0xff;
  const oa = sa + ((da * isa) >> 8);
  if (oa === 0) return 0;
  const r = (((src & 0xff) * sa + (dst & 0xff) * da * isa / 255) / oa) | 0;
  const g = ((((src >>> 8) & 0xff) * sa + ((dst >>> 8) & 0xff) * da * isa / 255) / oa) | 0;
  const b = ((((src >>> 16) & 0xff) * sa + ((dst >>> 16) & 0xff) * da * isa / 255) / oa) | 0;
  return packRGBA(r, g, b, oa);
}
