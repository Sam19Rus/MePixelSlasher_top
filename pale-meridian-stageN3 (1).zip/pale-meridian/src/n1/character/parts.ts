/**
 * N1 COMPOSITE CHARACTER — part assets.
 *
 * Every part below is an independently authored pixel-art asset (the equivalent
 * of head.png / torso.png / arm_l.png / ...): own silhouette, own shading, own
 * detail pass. Nothing is sliced from a finished full-body sprite. Parts join
 * through explicit anchors (neck, shoulders, hands, hips, feet, pack mount,
 * weapon grip / secondary hand / muzzle).
 */
import { Color } from '../../rendering/color';
import { PixelSurface } from '../../rendering/PixelSurface';
import { amber, cyan, metal, olive, slate, warm } from '../../data/palette';

export const CHAR_PALETTE: Record<string, Color> = {
  // undersuit
  s: slate.s3,
  S: slate.s5,
  t: slate.s7,
  d: slate.s2,
  // gloves / boots
  k: warm.w1,
  K: warm.w3,
  // armour plates
  a: metal.m8,
  A: metal.m6,
  b: metal.m4,
  B: metal.m2,
  // webbing / pack
  w: olive.o3,
  W: olive.o1,
  p: olive.o2,
  P: olive.o4,
  // visor / lamps
  v: cyan.c2,
  V: cyan.c5,
  c: cyan.c3,
  o: amber.a4,
  // weapon
  q: warm.w2,
  Q: warm.w5,
  x: warm.w0,
  y: cyan.c4,
  m: warm.w1,
  // helmet
  H: metal.m6,
  h: metal.m8,
  g: metal.m4,
  G: metal.m3,
};

export interface PartAsset {
  name: string;
  map: string[];
  anchors: Record<string, [number, number]>;
  surface?: PixelSurface;
}

const part = (name: string, map: string[], anchors: Record<string, [number, number]>): PartAsset => ({ name, map, anchors });

// ------------------------------------------------------------------ HEAD
export const HEAD_SIDE = part(
  'head_side',
  [
    '.hhhh..',
    'hHHHHh.',
    'hHHHHh.',
    'ggvvvg.',
    'ggvvvg.',
    '.GggG..',
    '..ss...',
  ],
  { neck: [3, 6] },
);
export const HEAD_FRONT = part(
  'head_front',
  [
    '.hhhh..',
    'hHHHHh.',
    'gvvvvg.',
    'gVVVVg.',
    'GggggG.',
    '.GggG..',
    '..ss...',
  ],
  { neck: [3, 6] },
);

// ------------------------------------------------------------------ TORSO
export const TORSO_SIDE = part(
  'torso_side',
  [
    '..AAAA..',
    '.aAAAAb.',
    '.aAccAb.',
    '.bAAAAb.',
    '.bSSSSb.',
    '.SSSSSS.',
    '.wWWWWw.',
    '.s.ss.s.',
  ],
  { neck: [4, 0], shoulder: [4, 1], shoulderFar: [2, 1], hipNear: [4, 7], hipFar: [2, 7], packMount: [1, 2] },
);
export const TORSO_FRONT = part(
  'torso_front',
  [
    '..AAAA..',
    '.aAAAAa.',
    '.aAccAa.',
    '.bAAAAb.',
    '.bSSSSb.',
    '.SSSSSS.',
    '.wWWWWw.',
    '.s.ss.s.',
  ],
  { neck: [3, 0], shoulderL: [1, 1], shoulderR: [6, 1], hipL: [2, 7], hipR: [5, 7], packMount: [3, 1] },
);

// ------------------------------------------------------------------ ARMS
export const ARM_R_SIDE_DOWN = part('arm_r_side_down', ['.A.', '.S.', '.S.', '.s.', '.s.', '.K.', '.K.'], { shoulder: [1, 0], hand: [1, 5] });
export const ARM_R_SIDE_SWING_A = part('arm_r_side_swing_a', ['.A.', '.S.', '..S', '..s', '..s', '..K'], { shoulder: [1, 0], hand: [2, 5] });
export const ARM_R_SIDE_SWING_B = part('arm_r_side_swing_b', ['.A.', '.S.', 'S..', 's..', 's..', 'K..'], { shoulder: [1, 0], hand: [0, 5] });
export const ARM_R_SIDE_AIM = part('arm_r_side_aim', ['.....', '.ASSK', '.....'], { shoulder: [1, 1], hand: [4, 1] });
export const ARM_L_SIDE_DOWN = part('arm_l_side_down', ['.b.', '.S.', '.S.', '.s.', '.s.', '.k.', '.k.'], { shoulder: [1, 0], hand: [1, 5] });
export const ARM_L_SIDE_SWING_A = part('arm_l_side_swing_a', ['.b.', '.S.', '..S', '..s', '..s', '..k'], { shoulder: [1, 0], hand: [2, 5] });
export const ARM_L_SIDE_SWING_B = part('arm_l_side_swing_b', ['.b.', '.S.', 'S..', 's..', 's..', 'k..'], { shoulder: [1, 0], hand: [0, 5] });
export const ARM_L_SIDE_AIM = part('arm_l_side_aim', ['....', 'bSSK', '....'], { shoulder: [1, 1], hand: [3, 1] });

export const ARM_FRONT_DOWN = part('arm_front_down', ['A.', 'S.', 'S.', 's.', 's.', 'K.', 'K.'], { shoulder: [0, 0], hand: [0, 5] });
export const ARM_FRONT_SWING_A = part('arm_front_swing_a', ['A.', 'S.', '.S', '.s', '.s', '.K'], { shoulder: [0, 0], hand: [1, 5] });
export const ARM_FRONT_SWING_B = part('arm_front_swing_b', ['.A', '.S', 'S.', 's.', 's.', 'K.'], { shoulder: [1, 0], hand: [0, 5] });
export const ARM_FRONT_AIM_L = part('arm_front_aim_l', ['ASSK.'], { shoulder: [0, 0], hand: [3, 0] });
export const ARM_FRONT_HOLD_L = part('arm_front_hold_l', ['AS..', '.sK.'], { shoulder: [0, 0], hand: [2, 1] });
export const ARM_FRONT_HOLD_R = part('arm_front_hold_r', ['..SA', '.Ks.'], { shoulder: [3, 0], hand: [1, 1] });
export const ARM_FRONT_AIM_R = part('arm_front_aim_r', ['.KSSA'], { shoulder: [4, 0], hand: [1, 0] });

// ------------------------------------------------------------------ LEGS
export const LEG_SIDE_STAND = part('leg_side_stand', ['.SS.', '.Ss.', '.ss.', '.bb.', '.ss.', '.ss.', '.KK.', '.kk.', 'kkk.'], { hip: [1, 0], foot: [1, 8] });
export const LEG_SIDE_W0 = part('leg_side_w0', ['.SS.', '.Ss.', '..ss', '..bb', '..ss', '..ss', '..KK', '..kk', '.kkk'], { hip: [1, 0], foot: [2, 8] });
export const LEG_SIDE_W1 = part('leg_side_w1', ['.SS.', '.Ss.', '.ss.', '.bb.', '.ss.', '.KK.', '.kk.', 'kkk.', '....'], { hip: [1, 0], foot: [1, 7] });
export const LEG_SIDE_W2 = part('leg_side_w2', ['.SS.', '.Ss.', 'ss..', 'bb..', 'ss..', 'ss..', 'KK..', 'kk..', 'kkk.'], { hip: [1, 0], foot: [1, 8] });
export const LEG_FRONT_STAND = part('leg_front_stand', ['SS.', 'Ss.', 'ss.', 'bb.', 'ss.', 'ss.', 'KK.', 'kk.', 'kkk'], { hip: [1, 0], foot: [1, 8] });
export const LEG_FRONT_LIFT = part('leg_front_lift', ['SS.', 'Ss.', 'ss.', 'bb.', 'ss.', 'KK.', 'kk.', 'kk.', '...'], { hip: [1, 0], foot: [1, 7] });

// ------------------------------------------------------------------ PACK
export const PACK_SIDE = part(
  'pack_side',
  ['pPPp.', 'pPPpp', 'pPppp', 'ppppp', 'wPppw', 'wWWWw', '.ppp.', '.kKk.'],
  { mount: [4, 1] },
);
export const PACK_FRONT = part('pack_front', ['pPPPPp.', 'pPppPp.', 'pppppp.', 'wWWWWw.', '.pppp..'], { mount: [3, 1] });

// ------------------------------------------------------------------ WEAPON
export const WEAPON_SIDE = part(
  'weapon_side',
  ['..QQQQQ.......', 'xxqqqqqqqqqqx.', 'xKqqyyqqqqqQy.', '..qqqqqqxx....', '...q.mm.......'],
  { grip: [3, 2], hand2: [8, 2], muzzle: [12, 2] },
);
export const WEAPON_FRONT = part('weapon_front', ['.QQQQQQQQQ.', 'KqqyyqqqqQy', '.qqqqqqxx..', '..mm.......'], { grip: [2, 1], hand2: [8, 1], muzzle: [10, 1] });

export const ALL_PARTS: PartAsset[] = [
  HEAD_SIDE,
  HEAD_FRONT,
  TORSO_SIDE,
  TORSO_FRONT,
  ARM_R_SIDE_DOWN,
  ARM_R_SIDE_SWING_A,
  ARM_R_SIDE_SWING_B,
  ARM_R_SIDE_AIM,
  ARM_L_SIDE_DOWN,
  ARM_L_SIDE_SWING_A,
  ARM_L_SIDE_SWING_B,
  ARM_L_SIDE_AIM,
  ARM_FRONT_DOWN,
  ARM_FRONT_SWING_A,
  ARM_FRONT_SWING_B,
  ARM_FRONT_AIM_L,
  ARM_FRONT_AIM_R,
  LEG_SIDE_STAND,
  LEG_SIDE_W0,
  LEG_SIDE_W1,
  LEG_SIDE_W2,
  LEG_FRONT_STAND,
  LEG_FRONT_LIFT,
  PACK_SIDE,
  PACK_FRONT,
  WEAPON_SIDE,
  WEAPON_FRONT,
];

/** bake every part asset once into its own PixelSurface (its ".png") */
export function bakePart(p: PartAsset): PixelSurface {
  if (p.surface) return p.surface;
  const w = Math.max(...p.map.map((r) => r.length));
  const s = new PixelSurface(w, p.map.length);
  for (let ry = 0; ry < p.map.length; ry++) {
    for (let rx = 0; rx < p.map[ry].length; rx++) {
      const c = CHAR_PALETTE[p.map[ry][rx]];
      if (c === undefined) continue;
      s.set(rx, ry, c);
    }
  }
  p.surface = s;
  return s;
}
