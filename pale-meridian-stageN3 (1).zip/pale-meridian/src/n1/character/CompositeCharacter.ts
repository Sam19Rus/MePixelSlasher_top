import { PixelSurface } from '../../rendering/PixelSurface';
import {
  ALL_PARTS,
  ARM_FRONT_AIM_L,
  ARM_FRONT_AIM_R,
  ARM_FRONT_HOLD_L,
  ARM_FRONT_HOLD_R,
  ARM_L_SIDE_AIM,
  ARM_L_SIDE_DOWN,
  ARM_L_SIDE_SWING_A,
  ARM_L_SIDE_SWING_B,
  ARM_R_SIDE_AIM,
  ARM_R_SIDE_DOWN,
  ARM_R_SIDE_SWING_A,
  ARM_R_SIDE_SWING_B,
  HEAD_FRONT,
  HEAD_SIDE,
  LEG_FRONT_LIFT,
  LEG_FRONT_STAND,
  LEG_SIDE_STAND,
  LEG_SIDE_W0,
  LEG_SIDE_W1,
  LEG_SIDE_W2,
  PACK_FRONT,
  PACK_SIDE,
  TORSO_FRONT,
  TORSO_SIDE,
  WEAPON_FRONT,
  WEAPON_SIDE,
  bakePart,
  type PartAsset,
} from './parts';

/**
 * Composite character assembly: parts are joined through anchors only.
 * Changing a pose re-places parts; nothing is repainted, so new poses or gear
 * swaps never require redrawing the body.
 */

export type CharOrient = 'side' | 'front';
export type CharState = 'idle' | 'walk' | 'aim';

export interface CharPose {
  state: CharState;
  phase: number; // 0..3 walk cycle
  orient: CharOrient;
  breath: number; // 0|1
  look: number; // -1|0|1 head offset
}

export interface PlacedPart {
  part: PartAsset;
  x: number;
  y: number;
  flip: boolean;
}

export interface AssemblyResult {
  parts: PlacedPart[];
  anchors: Record<string, [number, number]>;
  muzzle: [number, number];
  top: number;
}

export function assembleCharacter(pose: CharPose, feetX: number, feetY: number, flip = false): AssemblyResult {
  const side = pose.orient === 'side';
  const bob = pose.state === 'walk' ? (pose.phase === 1 || pose.phase === 3 ? 0 : 1) : pose.breath;
  const lean = pose.state === 'aim' ? (flip ? -1 : 1) : 0;
  const parts: PlacedPart[] = [];
  const anchors: Record<string, [number, number]> = {};

  const torso = side ? TORSO_SIDE : TORSO_FRONT;
  const torsoX = feetX - 4 + lean;
  const torsoY = feetY - 9 - 8 + 1 + bob;
  const at = (p: PartAsset, name: string, x: number, y: number, f: boolean): [number, number] => {
    const a = p.anchors[name];
    const w = Math.max(...p.map.map((r) => r.length));
    return [x + (f ? w - 1 - a[0] : a[0]), y + a[1]];
  };

  // legs (behind torso)
  const ph = pose.phase;
  if (side) {
    const near = pose.state === 'walk' ? [LEG_SIDE_W0, LEG_SIDE_W1, LEG_SIDE_W2, LEG_SIDE_W1][ph] : LEG_SIDE_STAND;
    const far = pose.state === 'walk' ? [LEG_SIDE_W2, LEG_SIDE_W1, LEG_SIDE_W0, LEG_SIDE_W1][ph] : LEG_SIDE_STAND;
    const hipF = at(torso, 'hipFar', torsoX, torsoY, flip);
    const hipN = at(torso, 'hipNear', torsoX, torsoY, flip);
    parts.push({ part: far, x: hipF[0] - far.anchors.hip[0], y: hipF[1] - far.anchors.hip[1], flip });
    parts.push({ part: near, x: hipN[0] - near.anchors.hip[0], y: hipN[1] - near.anchors.hip[1], flip });
    anchors.footL = [parts[0].x + 1, parts[0].y + 8];
    anchors.footR = [parts[1].x + 1, parts[1].y + 8];
  } else {
    const l = pose.state === 'walk' ? [LEG_FRONT_LIFT, LEG_FRONT_STAND, LEG_FRONT_STAND, LEG_FRONT_STAND][ph] : LEG_FRONT_STAND;
    const r = pose.state === 'walk' ? [LEG_FRONT_STAND, LEG_FRONT_STAND, LEG_FRONT_LIFT, LEG_FRONT_STAND][ph] : LEG_FRONT_STAND;
    const hipL = at(torso, 'hipL', torsoX, torsoY, false);
    const hipR = at(torso, 'hipR', torsoX, torsoY, false);
    parts.push({ part: l, x: hipL[0] - l.anchors.hip[0], y: hipL[1] - l.anchors.hip[1], flip: false });
    parts.push({ part: r, x: hipR[0] - r.anchors.hip[0], y: hipR[1] - r.anchors.hip[1], flip: false });
    anchors.footL = [parts[0].x + 1, parts[0].y + 8];
    anchors.footR = [parts[1].x + 1, parts[1].y + 8];
  }
  anchors.hipL = [torsoX + 2, torsoY + 7];
  anchors.hipR = [torsoX + 5, torsoY + 7];

  // far arm behind torso
  if (side) {
    const far = pose.state === 'walk' ? [ARM_L_SIDE_SWING_A, ARM_L_SIDE_DOWN, ARM_L_SIDE_SWING_B, ARM_L_SIDE_DOWN][ph] : pose.state === 'aim' ? ARM_L_SIDE_AIM : ARM_L_SIDE_DOWN;
    const sh = at(torso, 'shoulderFar', torsoX, torsoY, flip);
    const px = sh[0] - (flip ? far.map[0].length - 1 - far.anchors.shoulder[0] : far.anchors.shoulder[0]);
    const py = sh[1] - far.anchors.shoulder[1];
    parts.push({ part: far, x: px, y: py, flip });
    if (pose.state === 'aim') anchors.handFar = at(far, 'hand', px, py, flip);
  }

  // backpack behind torso
  const pack = side ? PACK_SIDE : PACK_FRONT;
  const pm = at(torso, 'packMount', torsoX, torsoY, flip);
  parts.push({ part: pack, x: pm[0] - (flip ? pack.map[0].length - 1 - pack.anchors.mount[0] : pack.anchors.mount[0]), y: pm[1] - pack.anchors.mount[1], flip });
  anchors.packMount = pm;

  // torso
  parts.push({ part: torso, x: torsoX, y: torsoY, flip });
  anchors.neck = at(torso, 'neck', torsoX, torsoY, flip);
  anchors.shoulderNear = at(torso, side ? 'shoulder' : 'shoulderR', torsoX, torsoY, flip);

  // head + look
  const head = side ? HEAD_SIDE : HEAD_FRONT;
  const hx = anchors.neck[0] - (flip ? head.map[0].length - 1 - head.anchors.neck[0] : head.anchors.neck[0]) + (side ? (flip ? -pose.look : pose.look) : pose.look);
  const hy = anchors.neck[1] - head.anchors.neck[1] - 1 + (pose.state === 'aim' ? 1 : 0);
  parts.push({ part: head, x: hx, y: hy, flip });

  // near arm + weapon anchored to hands
  let muzzle: [number, number] = [feetX, feetY - 20];
  if (side) {
    const near = pose.state === 'walk' ? [ARM_R_SIDE_SWING_B, ARM_R_SIDE_DOWN, ARM_R_SIDE_SWING_A, ARM_R_SIDE_DOWN][ph] : pose.state === 'aim' ? ARM_R_SIDE_AIM : ARM_R_SIDE_DOWN;
    const sh = at(torso, 'shoulder', torsoX, torsoY, flip);
    const ax = sh[0] - (flip ? near.map[0].length - 1 - near.anchors.shoulder[0] : near.anchors.shoulder[0]);
    const ay = sh[1] - near.anchors.shoulder[1];
    parts.push({ part: near, x: ax, y: ay, flip });
    const hand = at(near, 'hand', ax, ay, flip);
    anchors.handNear = hand;
    const wpn = WEAPON_SIDE;
    const gx = hand[0] - (flip ? wpn.map[0].length - 1 - wpn.anchors.grip[0] : wpn.anchors.grip[0]) - (flip ? -1 : 1);
    const gy = hand[1] - wpn.anchors.grip[1] + (pose.state === 'aim' ? -3 : 1);
    parts.push({ part: wpn, x: gx, y: gy, flip });
    muzzle = at(wpn, 'muzzle', gx, gy, flip);
    anchors.weaponGrip = [gx + (flip ? wpn.map[0].length - 1 - wpn.anchors.grip[0] : wpn.anchors.grip[0]), gy + wpn.anchors.grip[1]];
  } else {
    if (pose.state === 'aim') {
      const shL = at(torso, 'shoulderL', torsoX, torsoY, false);
      const shR = at(torso, 'shoulderR', torsoX, torsoY, false);
      parts.push({ part: ARM_FRONT_AIM_L, x: shL[0] - ARM_FRONT_AIM_L.anchors.shoulder[0], y: shL[1] - ARM_FRONT_AIM_L.anchors.shoulder[1], flip: false });
      parts.push({ part: ARM_FRONT_AIM_R, x: shR[0] - ARM_FRONT_AIM_R.anchors.shoulder[0], y: shR[1] - ARM_FRONT_AIM_R.anchors.shoulder[1], flip: false });
      const wpn = WEAPON_FRONT;
      const gx = torsoX + 4 - wpn.anchors.grip[0];
      const gy = torsoY + 3 - wpn.anchors.grip[1];
      parts.push({ part: wpn, x: gx, y: gy, flip: false });
      muzzle = at(wpn, 'muzzle', gx, gy, false);
      anchors.handNear = [torsoX + 4, torsoY + 3];
    } else {
      // both arms bend inward and hold the weapon at the hip (hands on grip
      // and handguard anchors), so the weapon never floats
      const shL = at(torso, 'shoulderL', torsoX, torsoY, false);
      const shR = at(torso, 'shoulderR', torsoX, torsoY, false);
      const swing = pose.state === 'walk' ? (ph === 0 || ph === 2 ? 1 : 0) : 0;
      parts.push({ part: ARM_FRONT_HOLD_L, x: shL[0] - ARM_FRONT_HOLD_L.anchors.shoulder[0], y: shL[1] - ARM_FRONT_HOLD_L.anchors.shoulder[1] + swing, flip: false });
      parts.push({ part: ARM_FRONT_HOLD_R, x: shR[0] - ARM_FRONT_HOLD_R.anchors.shoulder[0] + 1, y: shR[1] - ARM_FRONT_HOLD_R.anchors.shoulder[1] + swing, flip: false });
      const handL = at(ARM_FRONT_HOLD_L, 'hand', shL[0] - ARM_FRONT_HOLD_L.anchors.shoulder[0], shL[1] - ARM_FRONT_HOLD_L.anchors.shoulder[1] + swing, false);
      anchors.handNear = handL;
      const wpn = WEAPON_FRONT;
      const gx = handL[0] - wpn.anchors.grip[0];
      const gy = handL[1] - wpn.anchors.grip[1];
      parts.push({ part: wpn, x: gx, y: gy, flip: false });
      muzzle = at(wpn, 'muzzle', gx, gy, false);
      anchors.weaponGrip = [gx + wpn.anchors.grip[0], gy + wpn.anchors.grip[1]];
    }
  }
  anchors.muzzle = muzzle;
  return { parts, anchors, muzzle, top: hy - 1 };
}

/** draw an assembly onto a surface */
export function drawAssembly(s: PixelSurface, a: AssemblyResult): void {
  for (const pl of a.parts) {
    const surf = bakePart(pl.part);
    s.blit(surf, Math.round(pl.x), Math.round(pl.y), { flipX: pl.flip });
  }
}

/** QA helper: exploded layout proving parts are independent assets */
export function explodedSheet(): PixelSurface {
  const s = new PixelSurface(ALL_PARTS.reduce((acc, p) => acc + Math.max(...p.map.map((r) => r.length)) + 4, 0), 40);
  let x = 2;
  for (const p of ALL_PARTS) {
    const surf = bakePart(p);
    s.blit(surf, x, 4);
    x += surf.width + 4;
  }
  return s;
}
