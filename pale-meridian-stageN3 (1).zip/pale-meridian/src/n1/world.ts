import { mix, packRGBA, withAlpha } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { fbm, makeRng, valueNoise } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, dust, grime, hazard, metal, olive, rock, rust, slate, teal, warm } from '../data/palette';
import { drawText } from '../rendering/text';
import { N1Projection, type FaceQuad } from './projection';

/**
 * N1 WORLD BAKES — terrain, one rectangular technical building (closed and
 * cutaway variants), its single-room interior, and exterior dressing.
 * All geometry goes through N1Projection, so every surface shares one
 * transform and edges always meet.
 */

export interface N1Renderable {
  sprite: PixelSurface;
  x: number;
  y: number;
  depth: number;
  mode: 'both' | 'ext' | 'int';
  name: string;
}

export interface N1World {
  width: number;
  height: number;
  ox: number;
  oy: number;
  ground: PixelSurface;
  shadow: PixelSurface;
  shadowCut: PixelSurface;
  renderables: N1Renderable[];
  lights: { x: number; y: number; r: number; c: [number, number, number]; i: number; flicker?: number; blink?: number; mode: 'both' | 'ext' | 'int' }[];
  collidersExt: { x: number; y: number; w: number; h: number }[];
  collidersInt: { x: number; y: number; w: number; h: number }[];
  entrance: { ext: { x: number; y: number }; int: { x: number; y: number } };
  interiorRect: { x: number; y: number; w: number; h: number };
  worldW: number;
  worldH: number;
}

export const N1_BUILDING = { x: 240, y: 150, w: 132, d: 84, h: 54 };
const WT = 4; // wall thickness
export const N1_ROOM = { x: N1_BUILDING.x + WT, y: N1_BUILDING.y + WT, w: N1_BUILDING.w - WT * 2, h: N1_BUILDING.d - WT * 2 };
const DOOR_U = 52; // door offset along south face
const DOOR_W = 16;

interface Baked {
  sprite: PixelSurface;
  ax: number;
  ay: number;
}

type Faces = { front: FaceQuad; east: FaceQuad; west: FaceQuad; roof: FaceQuad; H: number };

function bakeBox(pr: N1Projection, r: { x: number; y: number; w: number; d: number; h: number }, anchor: { x: number; y: number }, faces: (s: PixelSurface, f: Faces) => void, opts: { front?: boolean; east?: boolean; west?: boolean; roof?: boolean } = {}): Baked {
  const o = { front: true, east: true, west: true, roof: true, ...opts };
  const f = pr.projectBox(r.x, r.y, r.w, r.d, r.h);
  const xs = [...f.roof.pts.map((p) => p[0]), ...f.front.pts.map((p) => p[0]), ...f.east.pts.map((p) => p[0]), ...f.west.pts.map((p) => p[0])];
  const ys = [...f.roof.pts.map((p) => p[1]), ...f.front.pts.map((p) => p[1]), ...f.east.pts.map((p) => p[1]), ...f.west.pts.map((p) => p[1])];
  const minX = Math.floor(Math.min(...xs)) - 4;
  const minY = Math.floor(Math.min(...ys)) - 4;
  const maxX = Math.ceil(Math.max(...xs)) + 4;
  const maxY = Math.ceil(Math.max(...ys)) + 4;
  const s = new PixelSurface(maxX - minX, maxY - minY);
  const lx = -minX;
  const ly = -minY;
  const sh = (q: FaceQuad): FaceQuad => ({ ...q, origin: [q.origin[0] + lx, q.origin[1] + ly] as [number, number], pts: q.pts.map((p) => [p[0] + lx, p[1] + ly]) });
  const F: Faces = { front: sh(f.front), east: sh(f.east), west: sh(f.west), roof: sh(f.roof), H: f.H };
  const fill = (q: FaceQuad, c: number) => s.polygon(q.pts, c);
  if (o.roof) {
    fill(F.roof, 0); // placeholder replaced by caller via faces()
  }
  faces(s, F);
  const [gx, gy] = pr.projectPoint(anchor.x, anchor.y);
  return { sprite: s, ax: Math.round(gx - minX), ay: Math.round(gy - minY) };
}

const faceRamp = (s: PixelSurface, f: FaceQuad, stops: number[]) => {
  for (let v = 0; v < f.vh; v++) {
    const t = f.vh === 1 ? 0 : v / (f.vh - 1);
    const tt = t * (stops.length - 1);
    const i = Math.floor(tt);
    const c = bayer4(0, v) < tt - i ? stops[Math.min(stops.length - 1, i + 1)] : stops[i];
    const ax = Math.round(f.origin[0] + f.v[0] * v);
    const ay = Math.round(f.origin[1] + f.v[1] * v);
    const bx = Math.round(f.origin[0] + f.u[0] * f.uw + f.v[0] * v);
    const by = Math.round(f.origin[1] + f.u[1] * f.uw + f.v[1] * v);
    s.line(ax, ay, bx, by, c);
  }
};
const facePx = (s: PixelSurface, f: FaceQuad, u: number, v: number, c: number) => {
  const x = Math.round(f.origin[0] + f.u[0] * u + f.v[0] * v);
  const y = Math.round(f.origin[1] + f.u[1] * u + f.v[1] * v);
  s.set(x, y, c);
};
const faceLine = (s: PixelSurface, f: FaceQuad, u0: number, v0: number, u1: number, v1: number, c: number) => {
  const ax = Math.round(f.origin[0] + f.u[0] * u0 + f.v[0] * v0);
  const ay = Math.round(f.origin[1] + f.u[1] * u0 + f.v[1] * v0);
  const bx = Math.round(f.origin[0] + f.u[0] * u1 + f.v[1] * v1 * 0 + f.u[1] * v1);
  const by = Math.round(f.origin[1] + f.u[1] * u1 + f.v[1] * v1);
  s.line(ax, ay, bx, by, c);
};
const faceRect = (s: PixelSurface, f: FaceQuad, u0: number, v0: number, uw: number, vh: number, c: number) => {
  const p = (u: number, v: number): [number, number] => [Math.round(f.origin[0] + f.u[0] * u + f.v[0] * v), Math.round(f.origin[1] + f.u[1] * u + f.v[1] * v)];
  s.polygon([p(u0, v0), p(u0 + uw, v0), p(u0 + uw, v0 + vh), p(u0, v0 + vh)], c);
};

export function bakeN1World(pr: N1Projection): N1World {
  const rnd = makeRng(777);
  const B = N1_BUILDING;
  const renderables: N1Renderable[] = [];
  const lights: N1World['lights'] = [];

  const WORLD_W = 640;
  const WORLD_H = 440;
  const cs = [pr.projectPoint(-40, -40), pr.projectPoint(WORLD_W + 40, -40), pr.projectPoint(WORLD_W + 40, WORLD_H + 40), pr.projectPoint(-40, WORLD_H + 40)];
  const xs = cs.map((c) => c[0]);
  const ys = cs.map((c) => c[1]);
  const minX = Math.floor(Math.min(...xs));
  const maxX = Math.ceil(Math.max(...xs));
  const minY = Math.floor(Math.min(...ys));
  const maxY = Math.ceil(Math.max(...ys));
  const W = maxX - minX;
  const H = maxY - minY;
  const ox = -minX;
  const oy = -minY;

  // ------------------------------------------------------------ terrain
  const ground = new PixelSurface(W, H);
  for (let py = 0; py < H; py++) {
    for (let px = 0; px < W; px++) {
      const [wx, wy] = [px - ox, py - oy];
      const ix = wx - pr.p.shear * (wy / pr.p.squash);
      const iy = wy / pr.p.squash;
      const form = fbm(ix / 150, iy / 110, 3, 11);
      const grain = fbm(ix / 12, iy / 10, 3, 41);
      let v = grain * 0.6 + form * 0.3 + 0.16;
      v = Math.max(0, Math.min(0.999, v));
      const ramp = [dust.d2, dust.d3, dust.d4, dust.d5, dust.d6];
      const t = v * (ramp.length - 1);
      const i = Math.floor(t);
      let c = bayer4(px, py) < t - i ? ramp[Math.min(4, i + 1)] : ramp[i];
      const lit = (form - 0.5) * 0.4;
      c = mix(c, lit > 0 ? dust.d8 : dust.d1, Math.min(0.18, Math.abs(lit)));
      const streak = valueNoise(ix / 44, iy / 5, 61);
      if (streak > 0.8 && bayer4(px, py) < 0.5) c = mix(c, dust.d7, 0.22);
      ground.setRaw(px, py, packRGBA(c & 0xff, (c >>> 8) & 0xff, (c >>> 16) & 0xff));
    }
  }
  const gp = (wx: number, wy: number): [number, number] => {
    const [sx, sy] = pr.projectPoint(wx, wy);
    return [Math.round(sx + ox), Math.round(sy + oy)];
  };
  // cracks
  for (let i = 0; i < 10; i++) {
    let wx = rnd.range(40, WORLD_W - 40);
    let wy = rnd.range(180, WORLD_H - 30);
    let ang = rnd() * Math.PI * 2;
    for (let k = 0; k < 36; k++) {
      ang += (rnd() - 0.5) * 0.5;
      wx += Math.cos(ang) * 1.7;
      wy += Math.sin(ang) * 1.3;
      const [px, py] = gp(wx, wy);
      ground.set(px, py, mix(dust.d1, dust.d2, 0.4));
      if (rnd() < 0.2) ground.set(px, py + 1, dust.d6);
    }
  }
  // pebbles
  for (let i = 0; i < 700; i++) {
    const wx = rnd.range(0, WORLD_W);
    const wy = rnd.range(120, WORLD_H);
    if (valueNoise(wx / 30, wy / 30, 3) < 0.5) continue;
    const [px, py] = gp(wx, wy);
    ground.set(px, py, rnd.chance(0.5) ? dust.d7 : dust.d2);
  }
  // vehicle tracks from south
  for (const side of [-7, 7]) {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 26; t++) {
      const wx = 306 + side + Math.sin(t / 7) * 5;
      const wy = WORLD_H + 10 - t * 5;
      const p = gp(wx, wy);
      if (prev) ground.line(prev[0], prev[1], p[0], p[1], mix(dust.d2, grime.g2, 0.45));
      prev = p;
    }
  }
  // footpath to door
  for (let i = 0; i < 22; i++) {
    const wx = B.x + DOOR_U + DOOR_W / 2 + (i % 2 === 0 ? -2 : 2);
    const wy = B.y + B.d + 6 + i * 3;
    const [px, py] = gp(wx, wy);
    ground.set(px, py, mix(dust.d2, dust.d3, 0.5));
  }
  // compacted pad in front of door
  const padQ = [pr.projectPoint(B.x + 20, B.y + B.d + 4), pr.projectPoint(B.x + B.w - 20, B.y + B.d + 4), pr.projectPoint(B.x + B.w - 20, B.y + B.d + 52), pr.projectPoint(B.x + 20, B.y + B.d + 52)].map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
  ground.polygon(padQ, mix(dust.d5, dust.d6, 0.45));
  // cable on ground
  let cx = B.x - 30;
  let cy = B.y + B.d + 20;
  for (let i = 0; i < 40; i++) {
    cx += 1.6;
    cy += Math.sin(i / 5) * 0.8;
    const [px, py] = gp(cx, cy);
    ground.set(px, py, slate.s2);
    ground.set(px, py - 1, slate.s4);
  }

  // ------------------------------------------------------------ shadows (baked)
  const shadow = new PixelSurface(W, H);
  const shadowCut = new PixelSurface(W, H);
  const castBox = (target: PixelSurface, r: { x: number; y: number; w: number; d: number; h: number }) => {
    const [dx, dy] = pr.shadowOffset(r.h);
    const q = pr.projectQuad(r.x, r.y, r.w, r.d).map((p) => [p[0] + ox, p[1] + oy]);
    const far = q.map((p) => [p[0] + dx, p[1] + dy]);
    target.polygon([q[0], q[1], far[1], far[0]], packRGBA(38, 22, 20, 120));
    target.polygon([q[1], q[2], far[2], far[1]], packRGBA(38, 22, 20, 120));
    target.polygon(q, packRGBA(38, 22, 20, 120));
  };
  castBox(shadow, B);
  castBox(shadowCut, { x: B.x, y: B.y, w: B.w, d: WT, h: B.h }); // north wall only when cut
  for (const r of [
    { x: 420, y: 190, w: 46, d: 26, h: 26 },
    { x: 170, y: 210, w: 30, d: 22, h: 20 },
  ]) {
    castBox(shadow, r);
    castBox(shadowCut, r);
  }
  for (const target of [shadow, shadowCut]) {
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = y * W + x;
        if ((target.data[i] >>> 24) === 0) continue;
        let outside = false;
        for (const o of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ]) {
          const nx = x + o[0];
          const ny = y + o[1];
          if (nx < 0 || ny < 0 || nx >= W || ny >= H || (target.data[ny * W + nx] >>> 24) === 0) outside = true;
        }
        if (outside && bayer8(x, y) < 0.6) target.data[i] = 0;
      }
    }
  }

  // ------------------------------------------------------------ building masses
  const push = (bk: Baked, wx: number, wy: number, depth: number, mode: N1Renderable['mode'], name: string) => {
    const [sx, sy] = pr.projectPoint(wx, wy);
    renderables.push({ sprite: bk.sprite, x: Math.round(sx + ox) - bk.ax, y: Math.round(sy + oy) - bk.ay, depth, mode, name });
  };

  const wallDetailFront = (s: PixelSurface, f: Faces) => {
    faceRamp(s, f.front, [mix(metal.m7, dust.d7, 0.3), mix(metal.m5, dust.d6, 0.3), mix(metal.m3, dust.d4, 0.3)]);
    // panels + seams + rivets
    for (let u = 12; u < f.front.uw - 6; u += 22) faceLine(s, f.front, u, 2, u, f.front.vh - 4, metal.m3);
    for (let v = 12; v < f.front.vh - 6; v += 14) faceLine(s, f.front, 4, v, f.front.uw - 4, v, metal.m4);
    for (let u = 6; u < f.front.uw - 6; u += 11) {
      facePx(s, f.front, u, 6, metal.m8);
      facePx(s, f.front, u, f.front.vh - 6, metal.m2);
    }
    // windows / dark tech panels
    faceRect(s, f.front, 14, 10, 26, 12, metal.m2);
    faceRect(s, f.front, 15, 11, 24, 10, teal.t1);
    faceLine(s, f.front, 16, 13, 30, 13, teal.t3);
    faceRect(s, f.front, 88, 10, 26, 12, metal.m2);
    faceRect(s, f.front, 89, 11, 24, 10, teal.t1);
    faceLine(s, f.front, 90, 14, 104, 14, teal.t3);
    // door / airlock
    faceRect(s, f.front, DOOR_U - 2, 8, DOOR_W + 4, f.front.vh - 8, rust.x1);
    faceRect(s, f.front, DOOR_U, 10, DOOR_W, f.front.vh - 10, metal.m3);
    faceLine(s, f.front, DOOR_U + DOOR_W / 2, 10, DOOR_U + DOOR_W / 2, f.front.vh - 1, amber.a5);
    faceRect(s, f.front, DOOR_U + 3, 14, 4, 5, teal.t1);
    faceRect(s, f.front, DOOR_U + DOOR_W - 7, 14, 4, 5, teal.t1);
    // hazard base + dirt
    faceLine(s, f.front, 2, f.front.vh - 4, f.front.uw - 2, f.front.vh - 4, mix(hazard.h2, metal.m3, 0.5));
    for (let u = 4; u < f.front.uw - 4; u += 3) facePx(s, f.front, u, f.front.vh - 2, mix(dust.d4, metal.m3, 0.5));
    // signage
    const sx0 = Math.round(f.front.origin[0] + f.front.u[0] * 44 + f.front.v[0] * 6);
    const sy0 = Math.round(f.front.origin[1] + f.front.u[1] * 44 + f.front.v[1] * 6);
    drawText(s, sx0, sy0, 'N1', mix(metal.m8, dust.d7, 0.3), { worn: 0.2 });
    // wall lamps beside door
    facePx(s, f.front, DOOR_U - 5, 12, amber.a5);
    facePx(s, f.front, DOOR_U + DOOR_W + 4, 12, amber.a5);
  };
  const wallDetailEast = (s: PixelSurface, f: Faces) => {
    faceRamp(s, f.east, [metal.m3, metal.m2]);
    for (let u = 8; u < f.east.uw - 6; u += 12) faceLine(s, f.east, u, 8, u, f.east.vh - 6, metal.m2);
    faceRect(s, f.east, 12, 10, 18, 14, metal.m3);
    for (let v = 12; v < 24; v += 3) faceLine(s, f.east, 13, v, 28, v, metal.m2); // louvres
    faceRect(s, f.east, 40, 14, 12, 10, metal.m2);
    facePx(s, f.east, 44, 17, cyan.c4);
    // pipes down
    faceLine(s, f.east, 60, 4, 60, f.east.vh - 3, metal.m4);
    faceLine(s, f.east, 63, 4, 63, f.east.vh - 3, metal.m3);
    for (let u = 4; u < f.east.uw - 4; u += 3) facePx(s, f.east, u, f.east.vh - 2, mix(dust.d4, metal.m2, 0.5));
  };
  const wallDetailWest = (s: PixelSurface, f: Faces) => {
    faceRamp(s, f.west, [mix(metal.m7, dust.d7, 0.25), mix(metal.m5, dust.d6, 0.25)]);
    for (let u = 10; u < f.west.uw - 6; u += 14) faceLine(s, f.west, u, 8, u, f.west.vh - 6, metal.m2);
    faceRect(s, f.west, 20, 12, 16, 12, metal.m3);
    for (let v = 14; v < 24; v += 3) faceLine(s, f.west, 21, v, 34, v, metal.m2);
    faceLine(s, f.west, 44, 4, 44, f.west.vh - 3, metal.m4);
    faceLine(s, f.west, 47, 4, 47, f.west.vh - 3, metal.m3);
    faceRect(s, f.west, 52, 10, 10, 8, metal.m3);
    facePx(s, f.west, 55, 13, cyan.c4);
  };
  const roofDetail = (s: PixelSurface, f: Faces) => {
    // roof base + panel seams
    s.polygon(f.roof.pts, mix(metal.m7, dust.d7, 0.35));
    for (let u = 16; u < f.roof.uw - 8; u += 24) faceLine(s, f.roof, u, 2, u, f.roof.vh - 2, metal.m5);
    for (let v = 12; v < f.roof.vh - 6; v += 16) faceLine(s, f.roof, 4, v, f.roof.uw - 4, v, metal.m6);
    // AC units
    faceRect(s, f.roof, 18, 14, 20, 14, metal.m4);
    faceRect(s, f.roof, 20, 16, 16, 10, metal.m2);
    faceRect(s, f.roof, 70, 30, 16, 12, metal.m5);
    faceLine(s, f.roof, 71, 32, 84, 32, metal.m7);
    // vents
    faceRect(s, f.roof, 48, 10, 10, 8, metal.m2);
    faceRect(s, f.roof, 96, 12, 8, 7, metal.m2);
    // hatch
    faceRect(s, f.roof, 40, 40, 12, 10, metal.m3);
    faceLine(s, f.roof, 41, 42, 50, 42, metal.m6);
    // pipes
    faceLine(s, f.roof, 60, 8, 60, 44, metal.m4);
    faceLine(s, f.roof, 63, 8, 63, 44, metal.m3);
    // solar strip
    faceRect(s, f.roof, 104, 34, 18, 12, teal.t1);
    faceLine(s, f.roof, 105, 37, 120, 37, teal.t3);
    faceLine(s, f.roof, 105, 41, 120, 41, teal.t3);
    // antenna + beacon
    const ax = Math.round(f.roof.origin[0] + f.roof.u[0] * 12 + f.roof.v[0] * 8);
    const ay = Math.round(f.roof.origin[1] + f.roof.u[1] * 12 + f.roof.v[1] * 8);
    s.vline(ax, ay - 26, 26, metal.m4);
    s.vline(ax + 1, ay - 26, 26, metal.m2);
    s.hline(ax - 4, ay - 18, 9, metal.m3);
    s.hline(ax - 3, ay - 10, 7, metal.m3);
    s.set(ax, ay - 27, mix(rust.x5, amber.a3, 0.2));
    // maintenance crate + dust
    faceRect(s, f.roof, 84, 44, 10, 8, mix(olive.o3, metal.m4, 0.4));
    for (let u = 8; u < f.roof.uw - 8; u += 9) facePx(s, f.roof, u, f.roof.vh - 3, dust.d6);
    // gutter rim + thin fascia band only (must not cover the wall faces)
    faceLine(s, f.roof, 0, 0, f.roof.uw, 0, metal.m8);
    faceLine(s, f.front, 0, 0, f.front.uw, 0, metal.m6);
    faceLine(s, f.front, 0, 1, f.front.uw, 1, metal.m4);
    faceLine(s, f.front, 0, 2, f.front.uw, 2, metal.m2);
  };

  const innerFace = (s: PixelSurface, f: FaceQuad) => {
    faceRamp(s, f, [slate.s5, slate.s4, slate.s3]);
    faceLine(s, f, 0, 4, f.uw, 4, mix(rust.x3, hazard.h2, 0.35));
    for (let u = 10; u < f.uw - 10; u += 22) faceRect(s, f, u, 8, 14, 4, slate.s3);
    faceLine(s, f, 4, f.vh - 3, f.uw - 4, f.vh - 3, slate.s2);
    for (let u = 6; u < f.uw - 6; u += 9) facePx(s, f, u, 7, slate.s6);
  };
  const wallN = bakeBox(pr, { x: B.x, y: B.y, w: B.w, d: WT, h: B.h }, { x: B.x + B.w / 2, y: B.y + WT }, (s, f) => {
    innerFace(s, f.front); // its south face = interior north wall
  });
  const wallW = bakeBox(pr, { x: B.x, y: B.y, w: WT, d: B.d, h: B.h }, { x: B.x + WT, y: B.y + B.d / 2 }, (s, f) => {
    wallDetailWest(s, f); // exterior west
    innerFace(s, f.east); // interior west wall
  });
  const wallE = bakeBox(pr, { x: B.x + B.w - WT, y: B.y, w: WT, d: B.d, h: B.h }, { x: B.x + B.w - WT, y: B.y + B.d / 2 }, (s, f) => {
    wallDetailEast(s, f); // exterior east
    innerFace(s, f.west); // interior east wall
  });
  const wallS = bakeBox(pr, { x: B.x, y: B.y + B.d - WT, w: B.w, d: WT, h: B.h }, { x: B.x + B.w / 2, y: B.y + B.d }, (s, f) => {
    wallDetailFront(s, f);
  });
  const roof = bakeBox(pr, { x: B.x - 2, y: B.y - 2, w: B.w + 4, d: B.d + 4, h: B.h + 2 }, { x: B.x + B.w / 2, y: B.y + B.d }, (s, f) => {
    roofDetail(s, f);
  });
  push(wallN, B.x + B.w / 2, B.y + WT, pr.depth(B.x + B.w / 2, B.y + WT), 'both', 'wallN');
  push(wallW, B.x + WT, B.y + B.d / 2, pr.depth(B.x + WT, B.y + B.d / 2), 'both', 'wallW');
  push(wallE, B.x + B.w - WT, B.y + B.d / 2, pr.depth(B.x + B.w - WT, B.y + B.d / 2), 'both', 'wallE');
  push(wallS, B.x + B.w / 2, B.y + B.d, pr.depth(B.x + B.w / 2, B.y + B.d), 'ext', 'wallS');
  push(roof, B.x + B.w / 2, B.y + B.d, pr.depth(B.x + B.w / 2, B.y + B.d, 0, 12), 'ext', 'roof');

  // canopy + stairs (exterior dressing, attached to south face)
  const canopy = bakeBox(
    pr,
    { x: B.x + DOOR_U - 8, y: B.y + B.d - 2, w: DOOR_W + 16, d: 14, h: 30 },
    { x: B.x + DOOR_U + DOOR_W / 2, y: B.y + B.d + 12 },
    (s, f) => {
      s.polygon(f.roof.pts, mix(metal.m6, dust.d6, 0.35));
      faceLine(s, f.roof, 0, 0, f.roof.uw, 0, metal.m8);
      faceLine(s, f.roof, 0, f.roof.vh - 1, f.roof.uw, f.roof.vh - 1, metal.m2);
      // hazard edge on the slab front
      const ax = Math.round(f.roof.origin[0]);
      const ay = Math.round(f.roof.origin[1] + f.roof.v[0] * 0 + f.roof.vh * f.roof.v[1]);
      for (let u = 0; u < f.roof.uw; u += 6) faceLine(s, f.roof, u, f.roof.vh - 2, u + 3, f.roof.vh - 2, hazard.h2);
      // support posts down to ground
      for (const pu of [2, f.roof.uw - 3]) {
        const px = Math.round(f.roof.origin[0] + f.roof.u[0] * pu + f.roof.v[0] * f.roof.vh);
        const py = Math.round(f.roof.origin[1] + f.roof.u[1] * pu + f.roof.v[1] * f.roof.vh);
        s.vline(px, py, 20, metal.m4);
        s.vline(px + 1, py, 20, metal.m2);
      }
      void ax;
      void ay;
    },
    { front: false, east: false, west: false },
  );
  push(canopy, B.x + DOOR_U + DOOR_W / 2, B.y + B.d + 12, pr.depth(B.x + DOOR_U + DOOR_W / 2, B.y + B.d + 12), 'ext', 'canopy');
  // stairs
  const stairs = (() => {
    const s = new PixelSurface(60, 26);
    for (let i = 0; i < 3; i++) {
      const sw = DOOR_W + 10 + i * 6;
      const q = [pr.projectPoint(B.x + DOOR_U + DOOR_W / 2 - sw / 2, B.y + B.d + 2 + i * 3), pr.projectPoint(B.x + DOOR_U + DOOR_W / 2 + sw / 2, B.y + B.d + 2 + i * 3), pr.projectPoint(B.x + DOOR_U + DOOR_W / 2 + sw / 2, B.y + B.d + 4 + i * 3), pr.projectPoint(B.x + DOOR_U + DOOR_W / 2 - sw / 2, B.y + B.d + 4 + i * 3)].map((p) => [Math.round(p[0] + 30 - pr.projectPoint(B.x + DOOR_U + DOOR_W / 2, B.y + B.d)[0]), Math.round(p[1] + 20 - pr.projectPoint(B.x + DOOR_U + DOOR_W / 2, B.y + B.d)[1] - pr.projectHeight(2 - i))]);
      s.polygon(q, mix(metal.m4, dust.d4, 0.35 + i * 0.15));
      s.line(Math.round(q[0][0]), Math.round(q[0][1]), Math.round(q[1][0]), Math.round(q[1][1]), mix(metal.m6, dust.d6, 0.3 + i * 0.2));
    }
    const [ax, ay] = pr.projectPoint(B.x + DOOR_U + DOOR_W / 2, B.y + B.d);
    return { sprite: s, ax: Math.round(ax - (pr.projectPoint(B.x + DOOR_U + DOOR_W / 2, B.y + B.d)[0] - 30)), ay: Math.round(ay - (pr.projectPoint(B.x + DOOR_U + DOOR_W / 2, B.y + B.d)[1] - 20)) };
  })();
  push(stairs, B.x + DOOR_U + DOOR_W / 2, B.y + B.d + 8, pr.depth(B.x + DOOR_U + DOOR_W / 2, B.y + B.d + 8), 'ext', 'stairs');

  // ------------------------------------------------------------ interior
  const R = N1_ROOM;
  const furn = (r: { x: number; y: number; w: number; d: number; h: number }, name: string, detail?: (s: PixelSurface, f: Faces) => void) => {
    const bk = bakeBox(pr, r, { x: r.x + r.w / 2, y: r.y + r.d }, (s, f) => detail?.(s, f));
    push(bk, r.x + r.w / 2, r.y + r.d, pr.depth(r.x + r.w / 2, r.y + r.d), 'int', name);
  };
  furn({ x: R.x + 6, y: R.y + 4, w: 26, d: 10, h: 16 }, 'terminal', (s, f) => {
    faceRamp(s, f.front, [slate.s5, slate.s4, slate.s3]);
    faceRect(s, f.front, 3, 3, 20, 9, cyan.c0);
    faceLine(s, f.front, 4, 5, 16, 5, cyan.c3);
    faceLine(s, f.front, 4, 8, 12, 8, cyan.c2);
    faceLine(s, f.front, 4, 10, 10, 10, cyan.c2);
    facePx(s, f.front, 20, 6, amber.a4);
    s.polygon(f.roof.pts, slate.s5);
  });
  furn({ x: R.x + 40, y: R.y + 4, w: 22, d: 10, h: 15 }, 'console', (s, f) => {
    faceRamp(s, f.front, [slate.s5, slate.s4, slate.s3]);
    faceRect(s, f.front, 2, 2, 18, 8, cyan.c0);
    faceLine(s, f.front, 3, 4, 14, 4, cyan.c2);
    faceLine(s, f.front, 3, 7, 10, 7, cyan.c2);
    s.polygon(f.roof.pts, slate.s5);
    facePx(s, f.roof, 6, 4, metal.m7);
  });
  furn({ x: R.x + 8, y: R.y + 30, w: 20, d: 12, h: 12 }, 'workbench', (s, f) => {
    faceRamp(s, f.front, [warm.w4, warm.w3, warm.w2]);
    s.polygon(f.roof.pts, warm.w5);
    facePx(s, f.roof, 4, 4, metal.m7);
    facePx(s, f.roof, 8, 6, cyan.c3);
    facePx(s, f.roof, 12, 3, warm.w6);
    facePx(s, f.roof, 15, 6, rust.x4);
  });
  furn({ x: R.x + R.w - 14, y: R.y + 8, w: 10, d: 20, h: 18 }, 'lockers', (s, f) => {
    faceRamp(s, f.east, [slate.s5, slate.s4, slate.s3]);
    for (let v = 2; v < f.east.uw - 2; v += 6) faceLine(s, f.east, v, 2, v, f.east.vh - 2, slate.s2);
    facePx(s, f.east, 4, 6, metal.m7);
    facePx(s, f.east, 10, 12, metal.m7);
    facePx(s, f.east, 16, 8, metal.m7);
    s.polygon(f.roof.pts, slate.s5);
  });
  furn({ x: R.x + R.w - 16, y: R.y + R.h - 14, w: 12, d: 10, h: 13 }, 'genblock', (s, f) => {
    faceRamp(s, f.front, [metal.m4, metal.m3, metal.m2]);
    faceRect(s, f.front, 2, 2, 8, 6, warm.w1);
    faceLine(s, f.front, 3, 3, 8, 3, amber.a3);
    faceLine(s, f.front, 3, 5, 8, 5, amber.a2);
    facePx(s, f.front, 9, 6, cyan.c4);
    s.polygon(f.roof.pts, metal.m4);
  });
  furn({ x: R.x + 34, y: R.y + R.h - 12, w: 14, d: 9, h: 9 }, 'table', (s, f) => {
    faceRamp(s, f.front, [warm.w4, warm.w3, warm.w2]);
    s.polygon(f.roof.pts, mix(warm.w5, dust.d6, 0.2));
    facePx(s, f.roof, 5, 3, slate.s6); // mug
    facePx(s, f.roof, 9, 5, metal.m6);
  });
  furn({ x: R.x + 4, y: R.y + R.h - 10, w: 8, d: 8, h: 10 }, 'intcrate', (s, f) => {
    faceRamp(s, f.front, [mix(olive.o4, metal.m5, 0.3), mix(olive.o3, metal.m4, 0.3), olive.o2]);
    facePx(s, f.front, 2, 3, metal.m7);
    s.polygon(f.roof.pts, mix(olive.o4, metal.m5, 0.3));
  });
  // interior floor detail baked into ground
  const floorQ = [pr.projectPoint(R.x, R.y), pr.projectPoint(R.x + R.w, R.y), pr.projectPoint(R.x + R.w, R.y + R.h), pr.projectPoint(R.x, R.y + R.h)].map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
  ground.polygon(floorQ, slate.s5);
  const floorQ2 = [pr.projectPoint(R.x + 1, R.y + 1), pr.projectPoint(R.x + R.w - 1, R.y + 1), pr.projectPoint(R.x + R.w - 1, R.y + R.h - 1), pr.projectPoint(R.x + 1, R.y + R.h - 1)].map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
  ground.polygon(floorQ2, slate.s4);
  for (let u = 8; u < R.w - 4; u += 12) {
    const a = gp(R.x + u, R.y + 2);
    const b = gp(R.x + u, R.y + R.h - 2);
    ground.line(a[0], a[1], b[0], b[1], slate.s3);
  }
  // grating strip
  for (let u = 10; u < R.w - 10; u += 3) {
    const a = gp(R.x + u, R.y + R.h / 2 - 3);
    const b = gp(R.x + u, R.y + R.h / 2 + 3);
    ground.line(a[0], a[1], b[0], b[1], u % 6 === 0 ? slate.s6 : slate.s3);
  }

  // ------------------------------------------------------------ exterior props
  const propBox = (r: { x: number; y: number; w: number; d: number; h: number }, name: string, mat: { body: number; top: number; dark: number }, detail?: (s: PixelSurface, f: Faces) => void) => {
    const bk = bakeBox(pr, r, { x: r.x + r.w / 2, y: r.y + r.d }, (s, f) => {
      s.polygon(f.roof.pts, mat.top);
      s.polygon(f.front.pts, mat.body);
      s.polygon(f.east.pts, mat.dark);
      faceLine(s, f.roof, 0, 0, f.roof.uw, 0, mix(mat.top, metal.m9, 0.4));
      detail?.(s, f);
    });
    push(bk, r.x + r.w / 2, r.y + r.d, pr.depth(r.x + r.w / 2, r.y + r.d), 'both', name);
  };
  propBox({ x: 420, y: 190, w: 46, d: 26, h: 26 }, 'container', { body: teal.t3, top: mix(teal.t4, dust.d6, 0.3), dark: teal.t1 }, (s, f) => {
    for (let u = 4; u < f.front.uw - 3; u += 5) faceLine(s, f.front, u, 2, u, f.front.vh - 2, teal.t2);
    const sx0 = Math.round(f.front.origin[0] + f.front.u[0] * 8);
    const sy0 = Math.round(f.front.origin[1] + f.front.u[1] * 8 + f.front.v[1] * 6);
    drawText(s, sx0, sy0, 'FRG', mix(metal.m8, teal.t2, 0.3), { worn: 0.3 });
  });
  propBox({ x: 170, y: 210, w: 30, d: 22, h: 20 }, 'generator', { body: mix(metal.m4, warm.w4, 0.3), top: mix(metal.m5, dust.d6, 0.3), dark: warm.w1 }, (s, f) => {
    for (let v = 4; v < 14; v += 3) faceLine(s, f.front, 3, v, 12, v, warm.w1);
    faceRect(s, f.front, 16, 4, 10, 8, warm.w1);
    faceLine(s, f.front, 17, 6, 24, 6, amber.a5);
    faceLine(s, f.front, 17, 9, 24, 9, amber.a3);
    facePx(s, f.front, 25, 12, cyan.c4);
  });
  for (const [cx2, cy2] of [
    [392, 236],
    [402, 244],
  ]) {
    propBox({ x: cx2, y: cy2, w: 12, d: 10, h: 12 }, 'crate', { body: mix(olive.o3, metal.m4, 0.3), top: mix(olive.o4, dust.d6, 0.3), dark: olive.o1 }, (s, f) => {
      facePx(s, f.front, 3, 4, metal.m7);
    });
  }
  for (const [bx, by] of [
    [452, 232],
    [458, 238],
  ]) {
    propBox({ x: bx, y: by, w: 8, d: 8, h: 12 }, 'barrel', { body: rust.x4, top: rust.x5, dark: rust.x2 }, (s, f) => {
      faceLine(s, f.front, 1, 4, f.front.uw - 1, 4, rust.x6);
      faceLine(s, f.front, 1, 8, f.front.uw - 1, 8, rust.x1);
    });
  }
  // lamp posts
  for (const [lx, ly] of [
    [282, 268],
    [352, 268],
  ]) {
    const s = new PixelSurface(14, 40);
    s.vline(7, 12, 26, metal.m3);
    s.vline(8, 12, 26, metal.m5);
    s.rect(4, 8, 8, 4, metal.m4);
    s.hline(4, 8, 8, metal.m6);
    s.rect(5, 11, 6, 2, amber.a4);
    s.hline(5, 11, 6, amber.a6);
    s.rect(5, 36, 6, 3, metal.m2);
    push({ sprite: s, ax: 7, ay: 38 }, lx, ly, pr.depth(lx, ly) + 0.1, 'both', 'lamp');
    lights.push({ x: lx, y: ly - 26, r: 26, c: [1, 0.72, 0.4], i: 0.55, mode: 'both' });
  }
  // rocks + plants + debris
  for (const [rx, ry, rr] of [
    [140, 300, 12],
    [520, 300, 10],
    [90, 160, 9],
    [560, 150, 8],
  ]) {
    const s = new PixelSurface(rr * 2 + 8, rr + 8);
    const ccx = rr + 4;
    const ccy = rr + 2;
    const rry = Math.max(3, Math.round(rr * 0.62));
    for (let y = -rry - 1; y <= rry; y++) {
      for (let x = -rr - 1; x <= rr + 1; x++) {
        const wob = 0.78 + valueNoise((ccx + x) / 4, (ccy + y) / 4, 7) * 0.44;
        const d = Math.sqrt((x * x) / (rr * rr) + (y * y) / (rry * rry)) / wob;
        if (d > 1) continue;
        const nl = (-x / rr) * 0.5 + (-y / rry) * 0.8;
        let v = 0.35 + nl * 0.33 + (valueNoise((ccx + x) / 3, (ccy + y) / 3, 8) - 0.5) * 0.4;
        v = Math.max(0, Math.min(0.999, v));
        const ramp = [rock.r1, rock.r2, rock.r3, rock.r4, rock.r5];
        const t = v * 4;
        s.set(ccx + x, ccy + y, bayer4(x, y) < t - Math.floor(t) ? ramp[Math.min(4, Math.floor(t) + 1)] : ramp[Math.floor(t)]);
      }
    }
    push({ sprite: s, ax: ccx, ay: ccy + rry - 1 }, rx, ry, pr.depth(rx, ry), 'both', 'rock');
  }
  for (let i = 0; i < 14; i++) {
    const wx = rnd.range(60, WORLD_W - 60);
    const wy = rnd.range(180, WORLD_H - 20);
    const s = new PixelSurface(10, 10);
    const blades = 3 + rnd.int(0, 3);
    for (let b = 0; b < blades; b++) {
      const h = 3 + rnd.int(0, 4);
      const lean = (rnd() - 0.5) * 3;
      for (let k = 0; k < h; k++) {
        const t = k / h;
        s.set(Math.round(5 + lean * t * t + (b - blades / 2) * 0.8), 8 - k, k === h - 1 ? mix(olive.o5, rust.x5, 0.4) : olive.o3);
      }
    }
    push({ sprite: s, ax: 5, ay: 8 }, wx, wy, pr.depth(wx, wy), 'both', 'plant');
  }

  // pipe rack between generator and building
  {
    const s = new PixelSurface(70, 20);
    for (let i = 0; i < 3; i++) {
      const a = gp(196 + i * 2, 232);
      void a;
    }
    const p0 = gp(196, 236);
    const p1 = gp(236, 224);
    for (let k = 0; k < 3; k++) {
      s.line(Math.round(p0[0]) - 20, Math.round(p0[1]) - 6 - k * 3, Math.round(p1[0]) - 20, Math.round(p1[1]) - 6 - k * 3, k === 0 ? metal.m4 : k === 1 ? metal.m3 : rust.x3);
    }
    for (let u = 0; u < 4; u++) {
      const t = u / 3;
      const sx = Math.round(p0[0] - 20 + (p1[0] - p0[0]) * t);
      const sy = Math.round(p0[1] - 6 + (p1[1] - p0[1]) * t);
      s.vline(sx, sy - 6, 8, metal.m2);
    }
    push({ sprite: s, ax: 20, ay: 14 }, 216, 230, pr.depth(216, 230), 'both', 'piperack');
  }
  // pallet near crates
  {
    const s = new PixelSurface(30, 14);
    const q = [pr.projectPoint(380, 258), pr.projectPoint(402, 258), pr.projectPoint(402, 272), pr.projectPoint(380, 272)].map((p) => [Math.round(p[0]) - Math.round(pr.projectPoint(380, 272)[0]) + 4, Math.round(p[1]) - Math.round(pr.projectPoint(380, 272)[1]) + 10]);
    s.polygon(q, warm.w3);
    s.line(Math.round(q[0][0]), Math.round(q[0][1]), Math.round(q[1][0]), Math.round(q[1][1]), warm.w5);
    push({ sprite: s, ax: 4, ay: 12 }, 380, 272, pr.depth(380, 272), 'both', 'pallet');
  }
  // foreground rocks + scrub + debris (frame the shot)
  for (const [rx, ry, rr] of [
    [110, 400, 16],
    [560, 410, 14],
    [300, 420, 10],
  ]) {
    const s = new PixelSurface(rr * 2 + 8, rr + 10);
    const ccx = rr + 4;
    const ccy = rr + 3;
    const rry = Math.max(3, Math.round(rr * 0.6));
    for (let y = -rry - 1; y <= rry; y++) {
      for (let x = -rr - 1; x <= rr + 1; x++) {
        const wob = 0.76 + valueNoise((ccx + x) / 4, (ccy + y) / 4, 12) * 0.46;
        const d = Math.sqrt((x * x) / (rr * rr) + (y * y) / (rry * rry)) / wob;
        if (d > 1) continue;
        const nl = (-x / rr) * 0.5 + (-y / rry) * 0.8;
        let v = 0.32 + nl * 0.34 + (valueNoise((ccx + x) / 3, (ccy + y) / 3, 13) - 0.5) * 0.4;
        v = Math.max(0, Math.min(0.999, v));
        const ramp = [rock.r2, rock.r3, rock.r4, rock.r5, rock.r6];
        const t = v * 4;
        s.set(ccx + x, ccy + y, bayer4(x, y) < t - Math.floor(t) ? ramp[Math.min(4, Math.floor(t) + 1)] : ramp[Math.floor(t)]);
      }
    }
    push({ sprite: s, ax: ccx, ay: ccy + rry - 1 }, rx, ry, pr.depth(rx, ry), 'both', 'fgrock');
  }
  for (let i = 0; i < 10; i++) {
    const wx = rnd.range(80, WORLD_W - 80);
    const wy = rnd.range(330, WORLD_H - 20);
    const s = new PixelSurface(12, 10);
    const blades = 4 + rnd.int(0, 3);
    for (let b = 0; b < blades; b++) {
      const h = 4 + rnd.int(0, 5);
      const lean = (rnd() - 0.5) * 4;
      for (let k = 0; k < h; k++) {
        const t = k / h;
        s.set(Math.round(6 + lean * t * t + (b - blades / 2) * 0.9), 9 - k, k === h - 1 ? mix(olive.o5, rust.x5, 0.4) : olive.o3);
      }
    }
    push({ sprite: s, ax: 6, ay: 9 }, wx, wy, pr.depth(wx, wy), 'both', 'fgplant');
  }
  // cable coil foreground
  {
    const s = new PixelSurface(20, 12);
    for (let i = 0; i < 22; i++) {
      const a = (i / 22) * Math.PI * 3;
      const rr2 = 3 + (i / 22) * 5;
      s.set(Math.round(10 + Math.cos(a) * rr2), Math.round(7 + Math.sin(a) * rr2 * 0.5), slate.s3);
    }
    push({ sprite: s, ax: 10, ay: 10 }, 470, 380, pr.depth(470, 380), 'both', 'cablecoil');
  }
  // distant mesas + haze band at world top
  for (const [mx, my, mw, mh] of [
    [90, 118, 120, 26],
    [420, 112, 150, 30],
  ]) {
    const s = new PixelSurface(mw + 8, mh + 8);
    for (let x = 0; x < mw; x++) {
      const win = Math.pow(Math.max(0, Math.sin((Math.PI * x) / mw)), 0.6);
      const n = fbm(x / 40, my, 3, 21);
      const top = Math.round(mh - win * (mh * 0.7 + n * 8));
      for (let y = top; y < mh; y++) {
        const depth = (y - top) / mh;
        let c = mix(mix(dust.d4, rock.r4, 0.4), dust.d3, Math.min(0.6, depth));
        c = mix(c, dust.d6, 0.35);
        if (y === top || y === top + 1) c = mix(c, dust.d7, 0.45);
        if (y > mh - 4 && bayer4(x, y) < (y - (mh - 4)) / 4) continue;
        s.set(x + 4, y + 4, c);
      }
    }
    push({ sprite: s, ax: mw / 2, ay: mh + 3 }, mx + mw / 2, my, pr.depth(mx, my) - 30, 'both', 'mesa');
  }

  // ------------------------------------------------------------ lights
  lights.push({ x: B.x + DOOR_U + DOOR_W / 2, y: B.y + B.d + 2, r: 22, c: [1, 0.66, 0.34], i: 0.7, mode: 'ext' });
  lights.push({ x: B.x + 26, y: B.y + B.d + 1, r: 10, c: [0.2, 0.8, 0.9], i: 0.35, mode: 'ext' });
  lights.push({ x: B.x + 102, y: B.y + B.d + 1, r: 10, c: [0.2, 0.8, 0.9], i: 0.35, mode: 'ext' });
  lights.push({ x: B.x + 12, y: B.y + 4, r: 9, c: [1, 0.22, 0.18], i: 0.5, blink: 2.2, mode: 'ext' });
  lights.push({ x: 176, y: 216, r: 14, c: [1, 0.5, 0.2], i: 0.45, flicker: 0.25, mode: 'both' });
  lights.push({ x: R.x + R.w / 2, y: R.y + R.h / 2, r: 40, c: [1, 0.84, 0.6], i: 1.25, mode: 'int' });
  lights.push({ x: R.x + 16, y: R.y + R.h - 14, r: 24, c: [1, 0.8, 0.55], i: 0.7, mode: 'int' });
  lights.push({ x: R.x + 18, y: R.y + 8, r: 12, c: [0.25, 0.85, 0.9], i: 0.4, mode: 'int' });
  lights.push({ x: R.x + 50, y: R.y + 8, r: 12, c: [0.25, 0.85, 0.9], i: 0.4, mode: 'int' });
  lights.push({ x: R.x + R.w - 10, y: R.y + R.h - 10, r: 10, c: [1, 0.6, 0.3], i: 0.35, flicker: 0.1, mode: 'int' });

  // ------------------------------------------------------------ colliders
  const collidersExt = [
    { x: B.x, y: B.y, w: B.w, h: B.d },
    { x: 420, y: 190, w: 46, h: 26 },
    { x: 170, y: 210, w: 30, h: 22 },
    { x: 392, y: 236, w: 22, h: 18 },
    { x: 452, y: 232, w: 14, h: 14 },
    { x: 140, y: 300, w: 24, h: 12 },
    { x: 520, y: 300, w: 20, h: 10 },
  ];
  const collidersInt = [
    { x: R.x - WT, y: R.x - WT, w: 0, h: 0 }, // placeholder removed below
  ];
  collidersInt.length = 0;
  collidersInt.push(
    { x: R.x - WT, y: R.y - WT, w: R.w + WT * 2, h: WT },
    { x: R.x - WT, y: R.y, w: WT, h: R.h },
    { x: R.x + R.w, y: R.y, w: WT, h: R.h },
    { x: R.x, y: R.y + R.h, w: R.w, h: WT },
    { x: R.x + 6, y: R.y + 4, w: 26, h: 10 },
    { x: R.x + 40, y: R.y + 4, w: 22, h: 10 },
    { x: R.x + 8, y: R.y + 30, w: 20, h: 12 },
    { x: R.x + R.w - 14, y: R.y + 8, w: 10, h: 20 },
    { x: R.x + R.w - 16, y: R.y + R.h - 14, w: 12, h: 10 },
    { x: R.x + 34, y: R.y + R.h - 12, w: 14, h: 9 },
    { x: R.x + 4, y: R.y + R.h - 10, w: 8, h: 8 },
  );

  return {
    width: W,
    height: H,
    ox,
    oy,
    ground,
    shadow,
    shadowCut,
    renderables,
    lights,
    collidersExt,
    collidersInt,
    entrance: { ext: { x: B.x + DOOR_U + DOOR_W / 2, y: B.y + B.d + 10 }, int: { x: B.x + DOOR_U + DOOR_W / 2, y: B.y + B.d - 8 } },
    interiorRect: R,
    worldW: WORLD_W,
    worldH: WORLD_H,
  };
}

export { withAlpha };
