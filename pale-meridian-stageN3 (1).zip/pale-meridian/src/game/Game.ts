import { Camera } from './Camera';
import { Renderer, type Drawable, type FrameState } from '../rendering/Renderer';
import { LightingSystem, TIME_OF_DAY, type TimeOfDay } from '../lighting/LightingSystem';
import { Input } from '../input/Input';
import { Mercenary } from '../entities/Mercenary';
import { Robot } from '../entities/Robot';
import { buildExterior, type ExteriorScene } from '../world/ExteriorScene';
import { bakeInterior, interiorColliders, type InteriorBake } from '../assets/interior';
import { PixelSurface } from '../rendering/PixelSurface';
import { ROOM_H, ROOM_W, VIEW_H, VIEW_W, WORLD_H, WORLD_W } from '../data/config';
import { WALK_MAX_X, WALK_MAX_Y, WALK_MIN_X, WALK_MIN_Y } from '../data/layout';
import type { Rect } from '../data/layout';
import { packRGBA, withAlpha } from '../rendering/color';
import { cloneQuality, presetOf, QUALITY_PRESETS, type QualityPreset, type QualitySettings } from '../data/quality';
import { bayer4 } from '../rendering/dither';
import { cyan, metal, slate } from '../data/palette';

/**
 * GAME — the benchmark orchestrator.
 *
 * Owns the two zones (exterior / interior), the player, the patrol drone, the
 * camera and the style-review state. Deliberately tiny: everything beyond
 * "look at it, walk around, go inside" is out of scope for stage 1.
 */

export type Zone = 'ext' | 'int';

/**
 * The world bake is the expensive part (~1s), so the instance is shared:
 * React StrictMode's double mount must not pay for it twice.
 */
let shared: Game | null = null;
export function getSharedGame(): Game {
  if (!shared) shared = new Game();
  return shared;
}

/** camera looks ahead of the player so the architecture stays in frame */
const LOOK_Y = 70;

export interface ReviewState {
  showUi: boolean;
  lighting: boolean;
  timeOfDay: TimeOfDay;
  debug: boolean;
}

export class Game {
  readonly renderer = new Renderer();
  readonly input = new Input();
  readonly camera = new Camera();
  readonly review: ReviewState = { showUi: true, lighting: true, timeOfDay: 'dusk', debug: false };

  private ext: ExteriorScene;
  private int: InteriorBake;
  private intColliders: Rect[];
  player: Mercenary;
  robot: Robot;

  /** quality / performance balance (tuned from the review panel) */
  quality: QualitySettings = cloneQuality(QUALITY_PRESETS.cinematic);

  zone: Zone = 'ext';
  time = 0;
  private fade = 0;
  private pendingZone: Zone | null = null;
  fps = 0;
  private fpsAcc = 0;
  private fpsN = 0;

  constructor() {
    this.ext = buildExterior();
    this.int = bakeInterior();
    this.intColliders = interiorColliders();
    this.player = new Mercenary(this.ext.playerSpawn.x, this.ext.playerSpawn.y);
    this.robot = new Robot(this.ext.robotPatrol);
    this.camera.setWorld(WORLD_W, WORLD_H);
    this.camera.snapTo(this.player.x, this.player.y - LOOK_Y);
    this.initInteriorDynamics();
  }

  get lighting(): LightingSystem {
    return this.renderer.lighting;
  }

  update(dt: number): void {
    this.time += dt;
    this.fpsAcc += dt;
    this.fpsN++;
    if (this.fpsAcc > 0.5) {
      this.fps = Math.round(this.fpsN / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsN = 0;
    }

    // ---- style review keys
    if (this.input.consume('F1')) this.review.showUi = !this.review.showUi;
    if (this.input.consume('F2')) {
      this.review.lighting = !this.review.lighting;
      this.renderer.lighting.enabled = this.review.lighting;
    }
    if (this.input.consume('F3')) {
      const order: TimeOfDay[] = ['dusk', 'night', 'day'];
      this.review.timeOfDay = order[(order.indexOf(this.review.timeOfDay) + 1) % order.length];
      this.renderer.lighting.timeOfDay = this.review.timeOfDay;
      this.renderer.lighting.invalidateStatic();
    }
    if (this.input.consume('F4')) this.review.debug = !this.review.debug;
    this.handleQualityKeys();

    // ---- zone transition fade
    if (this.pendingZone) {
      this.fade = Math.min(1, this.fade + dt * 5);
      if (this.fade >= 1) {
        this.zone = this.pendingZone;
        this.pendingZone = null;
        this.enterZone(this.zone);
      }
    } else if (this.fade > 0) {
      this.fade = Math.max(0, this.fade - dt * 4);
    }

    const frozen = this.pendingZone !== null;
    if (!frozen) {
      const axis = this.input.axis();
      const colliders = this.zone === 'ext' ? this.ext.colliders : this.intColliders;
      const bounds: Rect =
        this.zone === 'ext'
          ? { x: WALK_MIN_X, y: WALK_MIN_Y, w: WALK_MAX_X - WALK_MIN_X, h: WALK_MAX_Y - WALK_MIN_Y }
          : { x: 24, y: 22, w: ROOM_W - 48, h: ROOM_H - 40 };
      this.player.update(dt, axis, this.input.running, colliders, bounds);
      if (this.zone === 'ext') this.robot.update(dt, this.player);
      this.handleDoors();
    }

    this.camera.setWorld(this.zone === 'ext' ? WORLD_W : ROOM_W, this.zone === 'ext' ? WORLD_H : ROOM_H);
    this.camera.follow(this.player.x, this.player.y - LOOK_Y, dt);
    this.input.endFrame();
  }

  private handleQualityKeys(): void {
    if (this.input.consume('F5')) {
      const order: Exclude<QualityPreset, 'custom'>[] = ['cinematic', 'balanced', 'performance'];
      const cur = presetOf(this.quality);
      const idx = cur === 'custom' ? 0 : (order.indexOf(cur) + 1) % order.length;
      this.quality = cloneQuality(QUALITY_PRESETS[order[idx]]);
    }
  }

  private handleDoors(): void {
    if (this.zone === 'ext') {
      const d = this.ext.doorZone;
      const inside = this.player.x > d.x && this.player.x < d.x + d.w && this.player.y > d.y && this.player.y < d.y + d.h;
      if (inside && this.input.consume('KeyE', 'Enter', 'Space')) {
        this.pendingZone = 'int';
      }
    } else {
      const near = Math.abs(this.player.x - ROOM_W / 2) < 26 && this.player.y > ROOM_H - 50;
      if (near && this.input.consume('KeyE', 'Enter', 'Space')) {
        this.pendingZone = 'ext';
      }
    }
  }

  private enterZone(z: Zone): void {
    if (z === 'int') {
      this.player.x = ROOM_W / 2;
      this.player.y = ROOM_H - 40;
      this.player.dir = 'n';
    } else {
      this.player.x = this.ext.doorReturn.x;
      this.player.y = this.ext.doorReturn.y;
      this.player.dir = 's';
    }
    this.player.vx = 0;
    this.player.vy = 0;
    this.camera.snapTo(this.player.x, this.player.y - LOOK_Y);
  }

  get nearDoor(): boolean {
    if (this.zone === 'ext') {
      const d = this.ext.doorZone;
      return this.player.x > d.x && this.player.x < d.x + d.w && this.player.y > d.y && this.player.y < d.y + d.h;
    }
    return Math.abs(this.player.x - ROOM_W / 2) < 26 && this.player.y > ROOM_H - 50;
  }

  render(): PixelSurface {
    const camX = this.camera.ix;
    const camY = this.camera.iy;
    const drawables: Drawable[] = [];

    if (this.zone === 'ext') {
      for (const st of this.ext.statics) {
        drawables.push({
          gy: st.gy,
          bias: st.bias,
          draw: (s, cx, cy) => s.blit(st.sprite, Math.round(st.x - cx), Math.round(st.y - cy)),
        });
      }
      drawables.push({ gy: this.robot.y + 6, draw: (s, cx, cy) => this.robot.draw(s, cx, cy, this.quality.entityShadows) });
    }
    drawables.push({ gy: this.player.y, draw: (s, cx, cy, t) => this.player.draw(s, cx, cy, t, this.quality.entityShadows) });

    const lights = this.zone === 'ext' ? this.ext.lights(this.time) : this.int.lights;
    if (this.zone === 'ext') {
      lights.push({ x: this.robot.lens.x, y: this.robot.lens.y, radius: 14, r: 0.2, g: 0.9, b: 1, intensity: 0.5, pulse: 2.3 });
      lights.push({ x: this.robot.thruster.x, y: this.robot.thruster.y, radius: 12, r: 0.3, g: 0.9, b: 1, intensity: 0.45, flicker: 0.3 });
      lights.push({ x: this.player.visorGlow.x, y: this.player.visorGlow.y, radius: 7, r: 0.2, g: 0.8, b: 0.9, intensity: 0.22 });
    }

    const st: FrameState = {
      zone: this.zone,
      quality: this.quality,
      ground: this.zone === 'ext' ? this.ext.ground : this.int.surface,
      shadow: this.zone === 'ext' ? this.ext.shadow : null,
      shadowAlpha: TIME_OF_DAY[this.review.timeOfDay].shadowScale,
      drawables,
      dynamics: this.zone === 'ext' ? this.ext.dynamics : this.intDynamics,
      lights,
      colliders: this.zone === 'ext' ? this.ext.colliders : this.intColliders,
      camX,
      camY,
      time: this.time,
      fade: this.fade,
      prompt: this.nearDoor && this.review.showUi ? { x: this.player.x, y: this.player.y - 26 } : null,
    };
    return this.renderer.render(st);
  }

  // ---------------------------------------------------------------- interior
  private intDynamics: ExteriorScene['dynamics'] = [];

  /** Interior dynamic overlays: screens, LEDs, holo table, dust motes. */
  initInteriorDynamics(): void {
    const b = this.int;
    this.intDynamics = [
      {
        cost: 'cheap',
        draw: (s, t, camX, camY) => {
          for (const sc of b.screens) {
            const x = Math.round(sc.x - camX);
            const y = Math.round(sc.y - camY);
            const scan = Math.floor(t * 10 + sc.seed) % sc.h;
            s.hline(x, y + scan, sc.w, withAlpha(cyan.c3, 70));
            if (Math.floor(t * 1.7 + sc.seed) % 5 === 2) {
              s.rect(x + 2, y + 2, 6, 1, withAlpha(cyan.c5, 150));
            }
          }
        },
      },
      {
        cost: 'cheap',
        draw: (s, t, camX, camY) => {
          for (const led of b.leds) {
            const on = Math.sin(t / led.period + led.x) > -0.2;
            if (!on) continue;
            s.set(Math.round(led.x - camX), Math.round(led.y - camY), led.c);
          }
        },
      },
      {
        cost: 'full',
        draw: (s, t, camX, camY) => {
          // holo projector: flickering wireframe globe
          const hx = Math.round(b.holo.x - camX);
          const hy = Math.round(b.holo.y - camY);
          const ph = t * 1.4;
          for (let i = 0; i < 22; i++) {
            const a = (i / 22) * Math.PI * 2 + ph;
            const rx = 7;
            const ry = 3;
            const px = Math.round(hx + Math.cos(a) * rx);
            const py = Math.round(hy - 8 + Math.sin(a) * ry);
            if (bayer4(px, py) < 0.25) continue;
            s.blend(px, py, withAlpha(cyan.c4, 150));
          }
          for (let i = 0; i < 14; i++) {
            const a = (i / 14) * Math.PI * 2 - ph * 0.6;
            const px = Math.round(hx + Math.cos(a) * 4);
            const py = Math.round(hy - 8 + Math.sin(a) * 6);
            if (bayer4(px + 1, py) < 0.35) continue;
            s.blend(px, py, withAlpha(cyan.c2, 130));
          }
          s.blend(hx, hy - 8, withAlpha(cyan.c6, 180));
          // projection cone
          for (let i = 0; i < 6; i++) {
            s.blend(hx - 2 + i, hy - 3 - i, withAlpha(cyan.c2, 40));
            s.blend(hx + 2 - i, hy - 3 - i, withAlpha(cyan.c2, 40));
          }
        },
      },
      {
        cost: 'full',
        draw: (s, t, camX, camY) => {
          // dust motes in the lamp cones
          for (let i = 0; i < 14; i++) {
            const seed = i * 51.7;
            const px = Math.round((Math.sin(seed) * 0.5 + 0.5) * ROOM_W + Math.sin(t * 0.4 + i) * 8 - camX);
            const py = Math.round((Math.cos(seed * 1.3) * 0.5 + 0.5) * ROOM_H + t * 3 - camY) % ROOM_H;
            if (px < 0 || py < 0 || px >= VIEW_W || py >= VIEW_H) continue;
            if (bayer4(i, Math.floor(t * 3)) < 0.6) continue;
            s.blend(px, py, withAlpha(metal.m8, 50));
          }
        },
      },
    ];
  }

  /** Debug overlay: colliders, door zones, light radii, grid. */
  drawDebug(s: PixelSurface): void {
    const camX = this.camera.ix;
    const camY = this.camera.iy;
    const colliders = this.zone === 'ext' ? this.ext.colliders : this.intColliders;
    for (const c of colliders) {
      for (let x = c.x; x < c.x + c.w; x++) {
        s.set(x - camX, c.y - camY, packRGBA(255, 60, 60, 200));
        s.set(x - camX, c.y + c.h - camY, packRGBA(255, 60, 60, 200));
      }
      for (let y = c.y; y < c.y + c.h; y++) {
        s.set(c.x - camX, y - camY, packRGBA(255, 60, 60, 200));
        s.set(c.x + c.w - camX, y - camY, packRGBA(255, 60, 60, 200));
      }
    }
    if (this.zone === 'ext') {
      const d = this.ext.doorZone;
      s.strokeRect(d.x - camX, d.y - camY, d.w, d.h, packRGBA(80, 255, 120, 220));
    }
    s.ellipseOutline(Math.round(this.player.x - camX), Math.round(this.player.y - camY), 5, 5, packRGBA(80, 255, 120, 220));
    for (const l of this.zone === 'ext' ? this.ext.lights(this.time) : this.int.lights) {
      s.ellipseOutline(Math.round(l.x - camX), Math.round(l.y - camY), l.radius, l.radius * 0.9, packRGBA(255, 200, 60, 120));
    }
    // 32px grid
    for (let x = -(camX % 32); x < VIEW_W; x += 32) s.vline(x, 0, VIEW_H, packRGBA(255, 255, 255, 26));
    for (let y = -(camY % 32); y < VIEW_H; y += 32) s.hline(0, y, VIEW_W, packRGBA(255, 255, 255, 26));
    void slate;
  }
}
