import { CAMERA, VIEW_H, VIEW_W } from '../data/config';

/**
 * Smooth-follow camera.
 *
 * Stores the view's top-left corner in world space. Targets are clamped to
 * the world (worlds smaller than the view are centred), then the corner eases
 * toward the target with a speed cap so fast player motion never yanks the
 * frame. Rounded on read so every blit stays pixel-perfect.
 */
export class Camera {
  x = 0;
  y = 0;
  worldW = VIEW_W;
  worldH = VIEW_H;

  setWorld(w: number, h: number): void {
    this.worldW = w;
    this.worldH = h;
  }

  private desired(tx: number, ty: number): { x: number; y: number } {
    const minX = this.worldW <= VIEW_W ? (this.worldW - VIEW_W) / 2 : 0;
    const minY = this.worldH <= VIEW_H ? (this.worldH - VIEW_H) / 2 : 0;
    const maxX = this.worldW <= VIEW_W ? minX : this.worldW - VIEW_W;
    const maxY = this.worldH <= VIEW_H ? minY : this.worldH - VIEW_H;
    return {
      x: Math.max(minX, Math.min(maxX, tx - VIEW_W / 2)),
      y: Math.max(minY, Math.min(maxY, ty - VIEW_H / 2)),
    };
  }

  snapTo(tx: number, ty: number): void {
    const d = this.desired(tx, ty);
    this.x = d.x;
    this.y = d.y;
  }

  follow(tx: number, ty: number, dt: number): void {
    const d = this.desired(tx, ty);
    let dx = d.x - this.x;
    let dy = d.y - this.y;
    const dist = Math.hypot(dx, dy);
    if (dist < 0.01) return;
    const cap = Math.max(24, CAMERA.maxDelta * dt);
    const step = Math.min(dist, cap);
    const k = 1 - Math.exp(-CAMERA.follow * dt);
    this.x += (dx / dist) * step * k;
    this.y += (dy / dist) * step * k;
  }

  get ix(): number {
    return Math.round(this.x);
  }
  get iy(): number {
    return Math.round(this.y);
  }
}
