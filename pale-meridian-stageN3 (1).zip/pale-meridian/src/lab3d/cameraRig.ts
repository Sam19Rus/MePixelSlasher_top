import * as THREE from 'three';

/**
 * Free camera rig for the lab: orbit / zoom / pan with orthographic and
 * perspective projections. Presets are plain parameter sets, so a good angle
 * can be copied (C) and reproduced exactly later.
 */

export type CamMode = 'ortho' | 'persp';

export interface CamConfig {
  mode: CamMode;
  yaw: number; // deg
  pitch: number; // deg (90 = straight down)
  distance: number;
  target: [number, number, number];
  fov: number;
  orthoScale: number;
}

export const CAM_PRESETS: Record<string, CamConfig> = {
  'TOP-DOWN': { mode: 'ortho', yaw: 0, pitch: 88, distance: 30, target: [0, 1.2, 0], fov: 40, orthoScale: 13 },
  'TILTED ORTHO': { mode: 'ortho', yaw: 32, pitch: 56, distance: 30, target: [0, 1.4, 0], fov: 40, orthoScale: 12.5 },
  'STRONG 3/4': { mode: 'persp', yaw: 36, pitch: 38, distance: 26, target: [0, 1.6, 0], fov: 38, orthoScale: 12 },
  'SHALLOW 3/4': { mode: 'persp', yaw: 42, pitch: 22, distance: 24, target: [0, 2, 0], fov: 42, orthoScale: 12 },
  LOW: { mode: 'persp', yaw: 48, pitch: 8, distance: 20, target: [0, 2.4, 2], fov: 46, orthoScale: 12 },
  FREE: { mode: 'persp', yaw: 20, pitch: 30, distance: 22, target: [0, 1.5, 0], fov: 40, orthoScale: 12 },
};
export const PRESET_ORDER = ['TOP-DOWN', 'TILTED ORTHO', 'STRONG 3/4', 'SHALLOW 3/4', 'LOW', 'FREE'];

export class CameraRig {
  config: CamConfig = { ...CAM_PRESETS['TILTED ORTHO'], target: [...CAM_PRESETS['TILTED ORTHO'].target] as [number, number, number] };
  presetName = 'TILTED ORTHO';
  persp = new THREE.PerspectiveCamera(40, 16 / 9, 0.1, 300);
  ortho = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 300);

  applyPreset(name: string): void {
    const p = CAM_PRESETS[name];
    if (!p) return;
    this.presetName = name;
    this.config = { ...p, target: [...p.target] as [number, number, number] };
  }

  reset(): void {
    this.applyPreset(this.presetName);
  }

  toggleMode(): void {
    this.config.mode = this.config.mode === 'ortho' ? 'persp' : 'ortho';
    this.presetName = 'FREE';
  }

  orbit(dyaw: number, dpitch: number): void {
    this.config.yaw = (this.config.yaw + dyaw + 360) % 360;
    this.config.pitch = Math.max(2, Math.min(90, this.config.pitch + dpitch));
    this.presetName = 'FREE';
  }

  zoom(d: number): void {
    if (this.config.mode === 'persp') this.config.distance = Math.max(6, Math.min(80, this.config.distance + d));
    else this.config.orthoScale = Math.max(4, Math.min(40, this.config.orthoScale + d * 0.4));
    this.presetName = 'FREE';
  }

  pan(dx: number, dz: number): void {
    const yaw = (this.config.yaw * Math.PI) / 180;
    const fx = Math.cos(yaw);
    const fz = -Math.sin(yaw);
    const rx = -fz;
    const rz = fx;
    this.config.target[0] += rx * dx + fx * dz;
    this.config.target[2] += rz * dx + fz * dz;
    this.presetName = 'FREE';
  }

  active(): THREE.Camera {
    return this.config.mode === 'ortho' ? this.ortho : this.persp;
  }

  update(aspect: number): void {
    const c = this.config;
    const yaw = (c.yaw * Math.PI) / 180;
    const pitch = (c.pitch * Math.PI) / 180;
    const tx = c.target[0];
    const ty = c.target[1];
    const tz = c.target[2];
    const dx = Math.cos(pitch) * Math.cos(yaw) * c.distance;
    const dy = Math.sin(pitch) * c.distance;
    const dz = Math.cos(pitch) * Math.sin(yaw) * c.distance;
    if (c.mode === 'persp') {
      this.persp.fov = c.fov;
      this.persp.aspect = aspect;
      this.persp.position.set(tx + dx, ty + dy, tz + dz);
      this.persp.lookAt(tx, ty, tz);
      this.persp.updateProjectionMatrix();
    } else {
      const s = c.orthoScale;
      this.ortho.left = -s * aspect;
      this.ortho.right = s * aspect;
      this.ortho.top = s;
      this.ortho.bottom = -s;
      this.ortho.position.set(tx + dx, ty + dy, tz + dz);
      this.ortho.lookAt(tx, ty, tz);
      this.ortho.updateProjectionMatrix();
    }
  }

  format(): string {
    const c = this.config;
    return [
      'CAMERA',
      `mode: ${c.mode === 'ortho' ? 'orthographic' : 'perspective'}`,
      `yaw: ${c.yaw.toFixed(1)}`,
      `pitch: ${c.pitch.toFixed(1)}`,
      `distance: ${c.distance.toFixed(1)}`,
      `target: (${c.target[0].toFixed(1)}, ${c.target[1].toFixed(1)}, ${c.target[2].toFixed(1)})`,
      c.mode === 'ortho' ? `orthoScale: ${c.orthoScale.toFixed(1)}` : `fov: ${c.fov.toFixed(1)}`,
    ].join('\n');
  }
}
