import * as THREE from 'three';

/**
 * Pixel-art post pass: the 3D scene is rendered into a low-res target, then
 * this shader applies deliberate pixel-art treatment on top:
 *  - ordered-dither quantisation (palette restraint, no smooth gradients)
 *  - depth-edge outlines (crisp silhouettes)
 *  - subtle vignette
 * Output stays at internal resolution; the canvas is upscaled with
 * nearest-neighbour CSS scaling.
 */

export interface PostSettings {
  dither: boolean;
  posterize: number; // 0 = off, else levels per channel
  outline: boolean;
  vignette: boolean;
}

const VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`;

const FRAG = /* glsl */ `
precision mediump float;
varying vec2 vUv;
uniform sampler2D tDiffuse;
uniform sampler2D tDepth;
uniform vec2 uRes;
uniform float uDither;
uniform float uPosterize;
uniform float uOutline;
uniform float uVignette;

float bayer4(vec2 p) {
  vec2 i = mod(p, 4.0);
  float m = mod(i.x, 2.0) * 2.0 + mod(i.y, 2.0);
  float q = floor(i.x / 2.0) + 2.0 * floor(i.y / 2.0);
  float v = mod(m * 2.0 + q, 4.0);
  return v / 4.0;
}

vec3 lin2srgb(vec3 c) {
  return mix(c * 12.92, 1.055 * pow(max(c, vec3(0.0)), vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c));
}

void main() {
  vec3 col = lin2srgb(texture2D(tDiffuse, vUv).rgb);
  vec2 px = gl_FragCoord.xy;

  if (uPosterize > 1.0) {
    float lv = uPosterize - 1.0;
    float d = (uDither > 0.5) ? (bayer4(px) - 0.5) / lv : 0.0;
    col = floor(col * lv + d + 0.5) / lv;
  }

  if (uOutline > 0.5) {
    float d0 = texture2D(tDepth, vUv).x;
    float dx = 1.0 / uRes.x;
    float dy = 1.0 / uRes.y;
    float d1 = texture2D(tDepth, vUv + vec2(dx, 0.0)).x;
    float d2 = texture2D(tDepth, vUv + vec2(-dx, 0.0)).x;
    float d3 = texture2D(tDepth, vUv + vec2(0.0, dy)).x;
    float d4 = texture2D(tDepth, vUv + vec2(0.0, -dy)).x;
    float edge = max(max(abs(d0 - d1), abs(d0 - d2)), max(abs(d0 - d3), abs(d0 - d4)));
    float th = 0.0035 + d0 * 0.012;
    if (edge > th && d0 < 0.999) col = mix(col, vec3(0.055, 0.043, 0.043), 0.75);
  }

  if (uVignette > 0.5) {
    vec2 q = vUv - 0.5;
    float v = dot(q, q) * 0.9;
    col *= 1.0 - v * 0.55;
  }

  gl_FragColor = vec4(col, 1.0);
}
`;

export class PixelPost {
  readonly material: THREE.ShaderMaterial;
  private quad: THREE.Mesh;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

  constructor() {
    this.material = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      uniforms: {
        tDiffuse: { value: null },
        tDepth: { value: null },
        uRes: { value: new THREE.Vector2(480, 270) },
        uDither: { value: 1 },
        uPosterize: { value: 8 },
        uOutline: { value: 1 },
        uVignette: { value: 1 },
      },
      depthTest: false,
      depthWrite: false,
    });
    this.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.material);
    this.quad.frustumCulled = false;
    this.scene.add(this.quad);
  }

  apply(settings: PostSettings, res: [number, number]): void {
    const u = this.material.uniforms;
    u.uDither.value = settings.dither ? 1 : 0;
    u.uPosterize.value = settings.posterize;
    u.uOutline.value = settings.outline ? 1 : 0;
    u.uVignette.value = settings.vignette ? 1 : 0;
    (u.uRes.value as THREE.Vector2).set(res[0], res[1]);
  }
}
