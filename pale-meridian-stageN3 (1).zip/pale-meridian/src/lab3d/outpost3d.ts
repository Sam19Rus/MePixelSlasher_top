import * as THREE from 'three';

/**
 * REAL 3D outpost built for the Camera Lab.
 *
 * Proper architecture chain: terrain -> footprint -> walls (real height and
 * thickness) -> roof slab -> roof equipment. Named meshes (roof, southWall)
 * exist so a cutaway can hide them later. Everything is genuine geometry:
 * orbiting the camera always shows correct volume, occlusion and silhouettes.
 */

export interface Outpost3D {
  group: THREE.Group;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  points: THREE.PointLight[];
  emissives: { mat: THREE.MeshBasicMaterial; base: THREE.Color; kind: 'window' | 'door' | 'beacon' | 'vent' }[];
  roof: THREE.Mesh;
  southWall: THREE.Mesh;
  character: THREE.Mesh;
  setCharacterTexture: (tex: THREE.Texture) => void;
  setTOD: (tod: 'day' | 'dusk' | 'night') => void;
  setShadows: (on: boolean) => void;
  setLightQuality: (high: boolean) => void;
  setCutaway: (on: boolean) => void;
  update: (t: number) => void;
}

const MAT = {
  sand: 0xb78f61,
  sandDark: 0x8a6a44,
  stone: 0x7d6a58,
  cream: 0xcfd0c4,
  creamDark: 0x9aa1a4,
  rust: 0x934727,
  rustDark: 0x52251a,
  industrial: 0x484f59,
  industrialDark: 0x23272d,
  teal: 0x143d4a,
  slate: 0x2b343b,
  cyan: 0x4fd4dc,
  amber: 0xf5b545,
  olive: 0x4a5636,
};

function box(w: number, h: number, d: number, color: number, x: number, y: number, z: number, name = ''): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshLambertMaterial({ color }));
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  if (name) m.name = name;
  return m;
}

export function buildOutpost3D(): Outpost3D {
  const group = new THREE.Group();
  const emissives: Outpost3D['emissives'] = [];
  const points: THREE.PointLight[] = [];

  // ------------------------------------------------------------ terrain
  const seg = 96;
  const geo = new THREE.PlaneGeometry(64, 46, seg, Math.round(seg * 0.72));
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const cSand = new THREE.Color(MAT.sand);
  const cDark = new THREE.Color(MAT.sandDark);
  const cStone = new THREE.Color(MAT.stone);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const dune = Math.sin(x * 0.11) * Math.cos(z * 0.14) * 0.55 + Math.sin(x * 0.31 + z * 0.21) * 0.18;
    const padMask = Math.max(0, 1 - Math.max(Math.abs(x) / 16, Math.abs(z - 2) / 12));
    const h = dune * (1 - padMask * 0.9) * 0.9 - padMask * 0.05;
    pos.setY(i, h);
    const patch = Math.sin(x * 0.43 + 1.7) * Math.sin(z * 0.37 + 0.4);
    const c = cSand.clone();
    if (patch > 0.4) c.lerp(cDark, 0.4);
    if (patch < -0.5) c.lerp(cStone, 0.3);
    if (padMask > 0.5) c.lerp(cSand, 0.4).lerp(new THREE.Color(0xc7a06b), 0.35);
    colors[i * 3] = c.r;
    colors[i * 3 + 1] = c.g;
    colors[i * 3 + 2] = c.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();
  const terrain = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ vertexColors: true }));
  terrain.receiveShadow = true;
  terrain.name = 'terrain';
  group.add(terrain);

  // sand paths + tracks (thin decals just above terrain)
  const path = new THREE.Mesh(new THREE.PlaneGeometry(5, 16), new THREE.MeshLambertMaterial({ color: 0xc7a06b }));
  path.rotation.x = -Math.PI / 2;
  path.position.set(0, 0.03, 9);
  path.receiveShadow = true;
  group.add(path);
  for (const sx of [-1.6, 1.6]) {
    const track = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 20), new THREE.MeshLambertMaterial({ color: MAT.sandDark }));
    track.rotation.x = -Math.PI / 2;
    track.position.set(sx + 6, 0.035, 12);
    track.receiveShadow = true;
    group.add(track);
  }

  // ------------------------------------------------------------ building
  // hall: floor + 4 walls (real thickness) + roof slab => cutaway-friendly
  const wallT = 0.35;
  const hallW = 12;
  const hallD = 9;
  const wallH = 4;
  const hallFloor = box(hallW, 0.3, hallD, MAT.slate, 0, 0.15, 0, 'hallFloor');
  const wallN = box(hallW, wallH, wallT, MAT.cream, 0, wallH / 2, -hallD / 2, 'wallN');
  const wallS = box(hallW, wallH, wallT, MAT.cream, 0, wallH / 2, hallD / 2, 'southWall');
  const wallW = box(wallT, wallH, hallD, MAT.cream, -hallW / 2, wallH / 2, 0, 'wallW');
  const wallE = box(wallT, wallH, hallD, MAT.cream, hallW / 2, wallH / 2, 0, 'wallE');
  const roof = box(hallW + 0.6, 0.4, hallD + 0.6, MAT.creamDark, 0, wallH + 0.2, 0, 'roof');
  group.add(hallFloor, wallN, wallS, wallW, wallE, roof);
  // windows on south wall (emissive quads)
  for (const wx of [-4, 4]) {
    const win = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.2), new THREE.MeshBasicMaterial({ color: MAT.teal }));
    win.position.set(wx, 2.4, hallD / 2 + 0.19);
    group.add(win);
    emissives.push({ mat: win.material as THREE.MeshBasicMaterial, base: new THREE.Color(MAT.teal), kind: 'window' });
  }
  // door + canopy + stairs + rails
  const door = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 2.6), new THREE.MeshBasicMaterial({ color: MAT.amber }));
  door.position.set(0, 1.4, hallD / 2 + 0.19);
  group.add(door);
  emissives.push({ mat: door.material as THREE.MeshBasicMaterial, base: new THREE.Color(MAT.amber), kind: 'door' });
  const canopy = box(4.4, 0.25, 2.2, MAT.creamDark, 0, 2.9, hallD / 2 + 1.1, 'canopy');
  group.add(canopy);
  for (const px of [-1.9, 1.9]) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.9, 6), new THREE.MeshLambertMaterial({ color: MAT.industrial }));
    post.position.set(px, 1.45, hallD / 2 + 2);
    post.castShadow = true;
    group.add(post);
  }
  for (let i = 0; i < 3; i++) {
    group.add(box(3.4 + i * 0.5, 0.22, 0.7, MAT.creamDark, 0, 0.11 + i * 0.22, hallD / 2 + 2.6 + i * 0.7, `step${i}`));
  }
  for (const sx of [-1.9, 1.9]) {
    const rail = box(0.08, 0.5, 2.6, MAT.industrial, sx, 1.1, hallD / 2 + 2.6);
    group.add(rail);
  }

  // wing + garage + tower (solid masses with real height)
  const wing = box(6, 3, 7, MAT.cream, -9.2, 1.5, -1, 'wing');
  const garage = box(7, 3, 7, MAT.creamDark, 9.8, 1.5, 1, 'garage');
  const tower = box(4, 8, 4, MAT.rust, 1.5, 4, -1, 'tower');
  group.add(wing, garage, tower);
  // garage shutter
  const shutter = new THREE.Mesh(new THREE.PlaneGeometry(4, 2.4), new THREE.MeshLambertMaterial({ color: MAT.industrial }));
  shutter.position.set(9.8, 1.3, 4.52);
  group.add(shutter);
  // wing windows
  for (const wz of [-2.5, 0.5]) {
    const win = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1), new THREE.MeshBasicMaterial({ color: MAT.teal }));
    win.position.set(-12.22, 1.8, wz);
    win.rotation.y = -Math.PI / 2;
    group.add(win);
    emissives.push({ mat: win.material as THREE.MeshBasicMaterial, base: new THREE.Color(MAT.teal), kind: 'window' });
  }

  // ------------------------------------------------------------ roof equipment
  const roofY = wallH + 0.4;
  group.add(box(1.6, 0.8, 1.6, MAT.industrial, -3, roofY + 0.4, -2, 'ac1'));
  group.add(box(1.2, 0.6, 1.2, MAT.industrial, 3.5, roofY + 0.3, 2, 'ac2'));
  const vent = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 1.1, 8), new THREE.MeshLambertMaterial({ color: MAT.industrialDark }));
  vent.position.set(1, roofY + 0.55, -3);
  vent.castShadow = true;
  group.add(vent);
  group.add(box(1, 0.25, 1, MAT.industrial, -1, roofY + 0.12, 2.5, 'hatch'));
  const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 7, 6), new THREE.MeshLambertMaterial({ color: MAT.industrial }));
  pipe.rotation.z = Math.PI / 2;
  pipe.position.set(1, roofY + 0.3, 0.5);
  group.add(pipe);
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 4, 5), new THREE.MeshLambertMaterial({ color: MAT.industrial }));
  antenna.position.set(1.5, roofY + 2 + 4, -1);
  group.add(antenna);
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.14, 6, 6), new THREE.MeshBasicMaterial({ color: 0xff5544 }));
  beacon.position.set(1.5, roofY + 8.1, -1);
  group.add(beacon);
  emissives.push({ mat: beacon.material as THREE.MeshBasicMaterial, base: new THREE.Color(0xff5544), kind: 'beacon' });
  // solar panels on wing roof
  for (let i = 0; i < 3; i++) {
    const panel = box(1.5, 0.08, 2.2, MAT.teal, -10.5 + i * 1.8, 3.2, -1);
    panel.rotation.z = 0.35;
    group.add(panel);
  }

  // ------------------------------------------------------------ exterior props
  const addLight = (x: number, y: number, z: number, color: number, intensity: number, dist: number) => {
    const p = new THREE.PointLight(color, intensity, dist, 1.6);
    p.position.set(x, y, z);
    points.push(p);
    group.add(p);
    return p;
  };
  // lamps
  for (const [lx, lz] of [
    [-4, 8],
    [4, 8],
    [10, 10],
  ]) {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 3.2, 6), new THREE.MeshLambertMaterial({ color: MAT.industrial }));
    pole.position.set(lx, 1.6, lz);
    pole.castShadow = true;
    group.add(pole);
    const head = box(0.7, 0.3, 0.4, MAT.industrial, lx, 3.2, lz);
    group.add(head);
    const bulb = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.3), new THREE.MeshBasicMaterial({ color: MAT.amber }));
    bulb.position.set(lx, 3.03, lz);
    bulb.rotation.x = -Math.PI / 2;
    group.add(bulb);
    emissives.push({ mat: bulb.material as THREE.MeshBasicMaterial, base: new THREE.Color(MAT.amber), kind: 'vent' });
    addLight(lx, 3, lz, 0xffb066, 6, 9);
  }
  // containers / crates / barrels
  group.add(box(5, 2.6, 2.6, MAT.teal, 16, 1.3, -4, 'container1'));
  group.add(box(5, 2.6, 2.6, MAT.teal, 16.6, 1.3, -1, 'container2'));
  for (const [cx, cz, s] of [
    [-14, 6, 1.2],
    [-13, 7.4, 1],
    [-14.6, 7.2, 0.9],
  ]) {
    group.add(box(s, s, s, MAT.olive, cx, s / 2, cz, 'crate'));
  }
  for (const [bx, bz] of [
    [13, 6],
    [13.8, 6.6],
  ]) {
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 1.2, 10), new THREE.MeshLambertMaterial({ color: MAT.rust }));
    barrel.position.set(bx, 0.6, bz);
    barrel.castShadow = true;
    group.add(barrel);
  }
  // generator + transformer
  group.add(box(2.6, 1.6, 1.6, MAT.industrial, -11, 0.8, 8, 'generator'));
  const stack = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 1.6, 6), new THREE.MeshLambertMaterial({ color: MAT.rustDark }));
  stack.position.set(-11.6, 2.2, 8);
  group.add(stack);
  const ventGlow = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.7), new THREE.MeshBasicMaterial({ color: MAT.amber }));
  ventGlow.position.set(-11, 1, 8.82);
  group.add(ventGlow);
  emissives.push({ mat: ventGlow.material as THREE.MeshBasicMaterial, base: new THREE.Color(MAT.amber), kind: 'vent' });
  addLight(-11, 1.4, 9, 0xff8833, 4, 6);
  group.add(box(1.4, 1.8, 1.2, MAT.industrialDark, -15, 0.9, 4, 'transformer'));
  // vehicle
  const veh = new THREE.Group();
  veh.add(box(4.4, 0.7, 2.2, MAT.industrial, 0, 0.75, 0));
  veh.add(box(1.8, 1.3, 2, MAT.cream, 1.4, 1.6, 0));
  const vwin = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ color: MAT.teal }));
  vwin.position.set(2.32, 1.8, 0);
  vwin.rotation.y = Math.PI / 2;
  veh.add(vwin);
  veh.add(box(2.2, 0.9, 2, MAT.olive, -1.2, 1.35, 0));
  for (const [wx, wz] of [
    [-1.5, 1.15],
    [-1.5, -1.15],
    [1.5, 1.15],
    [1.5, -1.15],
  ]) {
    const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.35, 10), new THREE.MeshLambertMaterial({ color: MAT.industrialDark }));
    wheel.rotation.x = Math.PI / 2;
    wheel.position.set(wx, 0.45, wz);
    veh.add(wheel);
  }
  veh.position.set(7, 0, 10);
  veh.rotation.y = -0.5;
  veh.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
  group.add(veh);
  // rocks + debris + vegetation
  const rockGeo = new THREE.DodecahedronGeometry(1, 0);
  for (const [rx, rz, s] of [
    [-18, 12, 1.4],
    [18, 14, 1.1],
    [-8, 16, 0.8],
    [22, -8, 1.6],
    [-24, -6, 1.2],
  ]) {
    const rock = new THREE.Mesh(rockGeo, new THREE.MeshLambertMaterial({ color: MAT.stone, flatShading: true }));
    rock.scale.set(s, s * 0.6, s * 0.8);
    rock.position.set(rx, s * 0.25, rz);
    rock.rotation.y = rx;
    rock.castShadow = true;
    rock.receiveShadow = true;
    group.add(rock);
  }
  for (let i = 0; i < 26; i++) {
    const dx = Math.sin(i * 12.9898) * 24;
    const dz = Math.cos(i * 78.233) * 18;
    const deb = box(0.3 + (i % 3) * 0.15, 0.12, 0.25, i % 2 ? MAT.industrial : MAT.rustDark, dx, 0.06, dz);
    deb.rotation.y = i;
    group.add(deb);
  }
  for (let i = 0; i < 20; i++) {
    const vx = Math.sin(i * 3.7) * 26;
    const vz = Math.cos(i * 5.3) * 20;
    const shrub = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.7, 5), new THREE.MeshLambertMaterial({ color: MAT.olive }));
    shrub.position.set(vx, 0.35, vz);
    group.add(shrub);
  }

  // ------------------------------------------------------------ interior (cutaway-inspectable)
  const interior = new THREE.Group();
  const consoleBox = box(2.4, 1.2, 0.8, MAT.industrial, -3, 0.9, -3.4, 'intConsole');
  interior.add(consoleBox);
  const consoleScreen = new THREE.Mesh(new THREE.PlaneGeometry(2, 0.7), new THREE.MeshBasicMaterial({ color: MAT.cyan }));
  consoleScreen.position.set(-3, 1.35, -2.98);
  interior.add(consoleScreen);
  emissives.push({ mat: consoleScreen.material as THREE.MeshBasicMaterial, base: new THREE.Color(MAT.cyan), kind: 'window' });
  interior.add(box(1, 1, 1, MAT.olive, 3.4, 0.5, -3.2, 'intCrate1'));
  interior.add(box(0.8, 0.8, 0.8, MAT.rust, 4.3, 0.4, -2.6, 'intCrate2'));
  const intMark = new THREE.Mesh(new THREE.PlaneGeometry(6, 0.5), new THREE.MeshLambertMaterial({ color: 0xb08c22 }));
  intMark.rotation.x = -Math.PI / 2;
  intMark.position.set(0, 0.32, 1.5);
  interior.add(intMark);
  const intLight = new THREE.PointLight(0x9ff0f0, 2.2, 8, 1.8);
  intLight.position.set(-3, 2.2, -3);
  interior.add(intLight);
  group.add(interior);

  // ------------------------------------------------------------ character billboard
  const charTex = new THREE.CanvasTexture(document.createElement('canvas'));
  charTex.magFilter = THREE.NearestFilter;
  charTex.minFilter = THREE.NearestFilter;
  charTex.generateMipmaps = false;
  const character = new THREE.Mesh(
    new THREE.PlaneGeometry(1.1, 1.9),
    new THREE.MeshBasicMaterial({ map: charTex, transparent: true, alphaTest: 0.4 }),
  );
  character.position.set(2.5, 0.95, 7.5);
  group.add(character);
  const contact = new THREE.Mesh(new THREE.CircleGeometry(0.5, 12), new THREE.MeshBasicMaterial({ color: 0x1b1210, transparent: true, opacity: 0.45 }));
  contact.rotation.x = -Math.PI / 2;
  contact.position.set(2.5, 0.04, 7.5);
  group.add(contact);

  // ------------------------------------------------------------ lights
  const hemi = new THREE.HemisphereLight(0xbfd0e0, 0x6b4a33, 0.7);
  const sun = new THREE.DirectionalLight(0xffd9a0, 1.15);
  sun.position.set(-18, 26, -12);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.left = -30;
  sun.shadow.camera.right = 30;
  sun.shadow.camera.top = 30;
  sun.shadow.camera.bottom = -30;
  sun.shadow.camera.far = 80;
  group.add(hemi, sun);
  addLight(0, 2.6, 5.6, 0xffb066, 5, 8); // door

  const setTOD = (tod: 'day' | 'dusk' | 'night') => {
    if (tod === 'day') {
      sun.intensity = 1.9;
      sun.color.set(0xfff2dc);
      hemi.intensity = 0.95;
      hemi.color.set(0xcfe0ee);
      points.forEach((p) => (p.intensity = ((p.userData.base as number) ?? 4) * 0.3));
    } else if (tod === 'dusk') {
      sun.intensity = 1.2;
      sun.color.set(0xffd0a0);
      hemi.intensity = 0.45;
      hemi.color.set(0x8894a8);
      points.forEach((p) => (p.intensity = (p.userData.base as number) ?? p.intensity));
    } else {
      sun.intensity = 0.3;
      sun.color.set(0x90a0d0);
      hemi.intensity = 0.25;
      hemi.color.set(0x405070);
      points.forEach((p) => (p.intensity = ((p.userData.base as number) ?? 4) * 1.3));
    }
  };
  points.forEach((p) => (p.userData.base = p.intensity));
  setTOD('dusk');

  return {
    group,
    sun,
    hemi,
    points,
    emissives,
    roof,
    southWall: wallS,
    character,
    setCharacterTexture: (tex) => {
      (character.material as THREE.MeshBasicMaterial).map = tex;
      (character.material as THREE.MeshBasicMaterial).needsUpdate = true;
    },
    setTOD,
    setShadows: (on) => {
      sun.castShadow = on;
    },
    setCutaway: (on) => {
      roof.visible = !on;
      wallS.visible = !on;
    },
    setLightQuality: (high) => {
      sun.shadow.mapSize.set(high ? 1024 : 512, high ? 1024 : 512);
      if (sun.shadow.map) {
        sun.shadow.map.dispose();
        sun.shadow.map = null as unknown as THREE.WebGLRenderTarget;
      }
    },
    update: (t) => {
      const on = t % 2.2 < 0.35;
      for (const e of emissives) {
        if (e.kind === 'beacon') e.mat.color.copy(e.base).multiplyScalar(on ? 1 : 0.15);
      }
    },
  };
}
