import * as THREE from 'three';
import { buildOutpost3D, type Outpost3D } from './outpost3d';
import { CameraRig, PRESET_ORDER } from './cameraRig';
import { PixelPost, type PostSettings } from './post';
import { rigPlacements, FULL_KIT, type RigPose2, type Orient2 } from '../entities/CompositeRig';

/**
 * Scene 4 — 3D PIXEL ART CAMERA LAB.
 *
 * Real 3D scene graph (three.js) rendered into a deliberate low-resolution
 * target, then treated as pixel art (dither quantisation, depth outlines,
 * vignette) and upscaled with nearest-neighbour. The camera is fully free:
 * orbit / zoom / pan, orthographic + perspective, reproducible presets.
 */

export const INTERNAL_RES = {
  PIXEL480: [480, 270] as [number, number],
  PIXEL320: [320, 180] as [number, number],
  PIXEL240: [240, 135] as [number, number],
};

export class CameraLab {
  readonly renderer: THREE.WebGLRenderer;
  readonly rig = new CameraRig();
  readonly outpost: Outpost3D;
  readonly post = new PixelPost();
  private rt: THREE.WebGLRenderTarget;
  private internal: [number, number] = [...INTERNAL_RES.PIXEL480] as [number, number];
  private time = 0;
  private charCanvas: HTMLCanvasElement;
  private charTex: THREE.CanvasTexture;
  private charOrient: Orient2 = 's';

  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.BasicShadowMap; // hard, pixel-crisp shadows
    this.renderer.setClearColor(0x1a120e, 1);
    this.outpost = buildOutpost3D();
    this.rt = new THREE.WebGLRenderTarget(this.internal[0], this.internal[1], {
      minFilter: THREE.NearestFilter,
      magFilter: THREE.NearestFilter,
      depthBuffer: true,
    });
    this.rt.depthTexture = new THREE.DepthTexture(this.internal[0], this.internal[1]);
    this.post.material.uniforms.tDiffuse.value = this.rt.texture;
    this.post.material.uniforms.tDepth.value = this.rt.depthTexture;

    // character billboard texture from the 2D composite rig
    this.charCanvas = document.createElement('canvas');
    this.charCanvas.width = 40;
    this.charCanvas.height = 44;
    this.charTex = new THREE.CanvasTexture(this.charCanvas);
    this.charTex.magFilter = THREE.NearestFilter;
    this.charTex.minFilter = THREE.NearestFilter;
    this.charTex.generateMipmaps = false;
    this.outpost.setCharacterTexture(this.charTex);
    this.drawChar('s');
  }

  setInternalRes(res: [number, number]): void {
    this.internal = [...res] as [number, number];
    this.rt.setSize(this.internal[0], this.internal[1]);
    const old = this.rt.depthTexture;
    if (old) old.dispose();
    const dt = new THREE.DepthTexture(this.internal[0], this.internal[1]);
    this.rt.depthTexture = dt;
    this.post.material.uniforms.tDepth.value = dt;
  }

  get internalRes(): [number, number] {
    return this.internal;
  }

  /** css integer scale is handled by the view; renderer draws at internal res */
  resizeCanvas(): void {
    this.renderer.setSize(this.internal[0], this.internal[1], false);
  }

  private drawChar(orient: Orient2): void {
    const ctx = this.charCanvas.getContext('2d')!;
    ctx.clearRect(0, 0, this.charCanvas.width, this.charCanvas.height);
    const pose: RigPose2 = { state: 'idle', phase: 0, orient, breath: 0, look: 0 };
    const lay = rigPlacements(pose, FULL_KIT);
    // rig local feet at (0,0); body spans roughly x -8..10, y -28..0
    const offX = 14;
    const offY = 40;
    const P: Record<string, string> = CHAR_COLORS;
    for (const pl of lay.list) {
      const w = Math.max(...pl.map.map((r) => r.length));
      for (let ry = 0; ry < pl.map.length; ry++) {
        for (let rx = 0; rx < pl.map[ry].length; rx++) {
          const c = P[pl.map[ry][rx]];
          if (!c) continue;
          const px = pl.x + (pl.flip ? w - 1 - rx : rx);
          const py = pl.y + ry;
          ctx.fillStyle = c;
          ctx.fillRect(offX + px, offY + py, 1, 1);
        }
      }
    }
    this.charTex.needsUpdate = true;
  }

  frame(dt: number, settings: PostSettings): void {
    this.time += dt;
    this.outpost.update(this.time);

    // billboard the character toward the camera, swapping rig orientation
    const cam = this.rig.active();
    const cp = this.outpost.character.position;
    const az = Math.atan2(cam.position.x - cp.x, cam.position.z - cp.z);
    this.outpost.character.rotation.y = az;
    const azDeg = ((az * 180) / Math.PI + 360) % 360;
    const quadrants: Orient2[] = ['s', 'e', 'n', 'w']; // az 0 = camera south of char
    const q = quadrants[Math.round(azDeg / 90) % 4];
    if (q !== this.charOrient) {
      this.charOrient = q;
      this.drawChar(q);
    }

    this.rig.update(this.internal[0] / this.internal[1]);
    this.post.apply(settings, this.internal);

    this.renderer.setRenderTarget(this.rt);
    this.renderer.render(this.outpost.group.parent ?? this.sceneFor(this.outpost.group), this.rig.active());
    this.renderer.setRenderTarget(null);
    this.renderer.render(this.post.scene, this.post.camera);
  }

  private _scene: THREE.Scene | null = null;
  private sceneFor(group: THREE.Group): THREE.Scene {
    if (!this._scene) {
      this._scene = new THREE.Scene();
      this._scene.add(group);
      this._scene.fog = new THREE.Fog(0x2a1d17, 40, 110);
    }
    return this._scene;
  }
  get scene(): THREE.Scene {
    return this.sceneFor(this.outpost.group);
  }

  cutaway = false;
  toggleCutaway(): void {
    this.cutaway = !this.cutaway;
    this.outpost.setCutaway(this.cutaway);
  }

  setTOD(tod: 'day' | 'dusk' | 'night'): void {
    this.outpost.setTOD(tod);
    const fog = this.scene.fog as THREE.Fog;
    if (tod === 'day') {
      fog.color.set(0x8a6c5c);
      this.renderer.setClearColor(0x8a6c5c, 1);
    } else if (tod === 'dusk') {
      fog.color.set(0x4a3626);
      this.renderer.setClearColor(0x4a3626, 1);
    } else {
      fog.color.set(0x10131c);
      this.renderer.setClearColor(0x10131c, 1);
    }
  }

  /** renders the five QA views into one labelled sheet canvas */
  captureSheet(settings: PostSettings): HTMLCanvasElement {
    const views = ['TOP-DOWN', 'TILTED ORTHO', 'STRONG 3/4', 'SHALLOW 3/4', 'LOW'];
    const [w, h] = this.internal;
    const sheet = document.createElement('canvas');
    sheet.width = w * 3;
    sheet.height = h * 2;
    const ctx = sheet.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = '#0b0c0e';
    ctx.fillRect(0, 0, sheet.width, sheet.height);
    const savedPreset = this.rig.presetName;
    const savedCfg = { ...this.rig.config };
    views.forEach((v, i) => {
      this.rig.applyPreset(v);
      this.frame(0, settings);
      const cx = (i % 3) * w;
      const cy = Math.floor(i / 3) * h;
      ctx.drawImage(this.renderer.domElement, 0, 0, this.renderer.domElement.width, this.renderer.domElement.height, cx, cy, w, h);
      ctx.fillStyle = 'rgba(8,9,11,0.75)';
      ctx.fillRect(cx + 4, cy + 4, 150, 14);
      ctx.fillStyle = '#8ceeee';
      ctx.font = '10px monospace';
      ctx.fillText(`${String.fromCharCode(65 + i)} · ${v}`, cx + 8, cy + 14);
    });
    this.rig.config = savedCfg;
    this.rig.presetName = savedPreset;
    this.frame(0, settings);
    return sheet;
  }

  presetList(): string[] {
    return PRESET_ORDER;
  }
}

/** mirror of the rig palette as css colors for the billboard canvas */
const CHAR_COLORS: Record<string, string> = {
  s: '#2b343b',
  S: '#4c5962',
  t: '#7d8a90',
  d: '#20272d',
  k: '#282220',
  K: '#514740',
  a: '#b6b8b0',
  A: '#7d868e',
  b: '#484f59',
  B: '#23272d',
  w: '#4a5636',
  W: '#151a12',
  p: '#354028',
  P: '#616d47',
  v: '#17818f',
  V: '#8ceeee',
  c: '#25aebc',
  o: '#e9a02c',
  r: '#a03a35',
  q: '#3b332e',
  Q: '#6a5d52',
  x: '#171312',
  y: '#25aebc',
  m: '#282220',
  H: '#7d868e',
  h: '#b6b8b0',
  g: '#484f59',
  G: '#343a42',
};
