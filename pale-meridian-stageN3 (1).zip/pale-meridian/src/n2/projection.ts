/**
 * N2 PROJECTION — tilted orthographic / top-down, derived from Scene 1's world.
 *
 * Visual hint (3D Camera Lab preset N2): orthographic, yaw ~153.2°,
 * pitch ~50.4°. Not copied as 3D math — reconstructed as an own 2D
 * camera-like orthographic system:
 *
 *  - camera high, looking down at a noticeable tilt;
 *  - roof reads large (ground/roof planes keep ~77% of depth);
 *  - walls are tall and vertical (height scale ~64% of true height);
 *  - two faces visible (south front + east side) with ~0.26 shear;
 *  - ground stays a readable gameplay plane;
 *  - not isometric, not flat top-down, not the old Scene 3 system.
 *
 * The module is pure math and knows nothing about the building.
 */

export interface FaceQuadN2 {
  pts: number[][];
  origin: [number, number];
  u: [number, number];
  v: [number, number];
  uw: number;
  vh: number;
}

export interface N2Params {
  /** horizontal shear per depth unit (yaw feel, east-face reveal) */
  shear: number;
  /** screen depth per depth unit (roof/ground foreshortening, sin pitch) */
  squash: number;
  /** screen height per height unit (wall presence, cos pitch) */
  heightScale: number;
  /** ground-plane shadow direction per height unit */
  shadowDir: { x: number; y: number };
}

export const N2_PARAMS: N2Params = {
  shear: 0.26,
  squash: 0.77,
  heightScale: 0.64,
  shadowDir: { x: 0.7, y: 0.4 },
};

export class N2Projection {
  constructor(public p: N2Params = N2_PARAMS) {}

  /** world point (x, y ground, z height) -> screen point */
  projectPoint(x: number, y: number, z = 0): [number, number] {
    return [x + this.p.shear * y, this.p.squash * y - this.projectHeight(z)];
  }

  project(x: number, y: number, z = 0): [number, number] {
    return this.projectPoint(x, y, z);
  }

  /** inverse of the ground lattice (screen -> world, z = 0) */
  invPoint(sx: number, sy: number): [number, number] {
    const y = sy / this.p.squash;
    return [sx - this.p.shear * y, y];
  }

  projectHeight(h: number): number {
    return Math.round(h * this.p.heightScale);
  }

  /** the visible faces of a box; footprint front-left (x, y), w east, d depth, h height */
  projectBox(x: number, y: number, w: number, d: number, h: number) {
    const H = this.projectHeight(h);
    const [fx, fy] = this.projectPoint(x, y + d); // front-left ground
    const [fx2, fy2] = this.projectPoint(x + w, y + d); // front-right ground
    const [ex, ey] = this.projectPoint(x + w, y); // east-back ground
    const [bx, by] = this.projectPoint(x, y); // back-left ground
    const front: FaceQuadN2 = {
      pts: [
        [fx, fy],
        [fx2, fy2],
        [fx2, fy2 - H],
        [fx, fy - H],
      ],
      origin: [fx, fy - H],
      u: [1, 0],
      v: [0, 1],
      uw: w,
      vh: H,
    };
    const east: FaceQuadN2 = {
      pts: [
        [fx2, fy2],
        [ex, ey],
        [ex, ey - H],
        [fx2, fy2 - H],
      ],
      origin: [fx2, fy2 - H],
      u: [(ex - fx2) / Math.max(1, d), (ey - fy2) / Math.max(1, d)],
      v: [0, 1],
      uw: d,
      vh: H,
    };
    const back: FaceQuadN2 = {
      pts: [
        [bx, by],
        [this.projectPoint(x + w, y)[0], this.projectPoint(x + w, y)[1]],
        [this.projectPoint(x + w, y)[0], this.projectPoint(x + w, y)[1] - H],
        [bx, by - H],
      ],
      origin: [bx, by - H],
      u: [1, 0],
      v: [0, 1],
      uw: w,
      vh: H,
    };
    const west: FaceQuadN2 = {
      pts: [
        [fx, fy],
        [bx, by],
        [bx, by - H],
        [fx, fy - H],
      ],
      origin: [fx, fy - H],
      u: [(bx - fx) / Math.max(1, d), (by - fy) / Math.max(1, d)],
      v: [0, 1],
      uw: d,
      vh: H,
    };
    const roof: FaceQuadN2 = {
      pts: [
        [fx, fy - H],
        [fx2, fy2 - H],
        [ex, ey - H],
        [bx, by - H],
      ],
      origin: [fx, fy - H],
      u: [1, 0],
      v: [(ex - fx2) / Math.max(1, d), (ey - fy2) / Math.max(1, d)],
      uw: w,
      vh: d,
    };
    return { front, east, west, back, roof, H };
  }

  projectWall(x: number, y: number, w: number, d: number, h: number): FaceQuadN2 {
    return this.projectBox(x, y, w, d, h).front;
  }
  projectRoof(x: number, y: number, w: number, d: number, h: number): FaceQuadN2 {
    return this.projectBox(x, y, w, d, h).roof;
  }
  /** ground quad of a footprint (decals, shadows, floors) */
  projectQuad(x: number, y: number, w: number, d: number): [number, number][] {
    return [this.projectPoint(x, y + d), this.projectPoint(x + w, y + d), this.projectPoint(x + w, y), this.projectPoint(x, y)];
  }
  shadowOffset(h: number): [number, number] {
    return [this.p.shadowDir.x * h * 0.5, this.p.shadowDir.y * h * 0.5];
  }
  /** painter depth: view-direction coordinate of a ground anchor + height/bias */
  depth(x: number, y: number, baseZ = 0, bias = 0): number {
    return y + x * this.p.shear * 0.5 + baseZ * 0.02 + bias;
  }
}
