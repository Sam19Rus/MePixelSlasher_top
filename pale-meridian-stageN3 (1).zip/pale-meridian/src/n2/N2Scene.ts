import { PixelSurface } from '../rendering/PixelSurface';
import { LightingSystem, type TimeOfDay } from '../lighting/LightingSystem';
import { VIEW_H, VIEW_W } from '../data/config';
import { bayer4 } from '../rendering/dither';
import { mix, packRGBA, withAlpha } from '../rendering/color';
import { N2Projection } from './projection';
import { bakeN2World, type N2World } from './worldN2';
import { Mercenary } from '../entities/Mercenary';
import { Robot } from '../entities/Robot';
import { L, WALK_MIN_X, WALK_MIN_Y, WALK_MAX_X, WALK_MAX_Y } from '../data/layout';
import type { Input } from '../input/Input';

/**
 * N2 SCENE — the Scene 1 world (same layout, terrain recipe, building,
 * props, interior set, lighting language, same merc + drone entities)
 * presented through the N2 tilted-orthographic projection. Cutaway works
 * in the same world coordinates: the roof, south wall and entrance module
 * hide, the interior stays physically inside the hall footprint.
 */

export class N2Scene {
  readonly lighting = new LightingSystem();
  readonly proj = new N2Projection();
  world: N2World;
  zone: 'ext' | 'int' = 'ext';
  time = 0;
  review = { lighting: true, timeOfDay: 'dusk' as TimeOfDay, debug: false };
  prompt = false;

  readonly merc: Mercenary;
  readonly robot: Robot;

  private camX = 0;
  private camY = 0;
  private atmo: PixelSurface | null = null;
  private fade = 0;
  private pending: 'ext' | 'int' | null = null;

  constructor() {
    this.world = bakeN2World(this.proj);
    this.lighting.resize(VIEW_W, VIEW_H);
    // start slightly closer than Scene 1's spawn so the building reads large
    this.merc = new Mercenary(L.doorReturn.x, L.doorReturn.y + 34);
    this.robot = new Robot(L.robotPatrol.map((p) => ({ ...p })));
    this.snapCam();
  }

  private toScreen(wx: number, wy: number): [number, number] {
    const [sx, sy] = this.proj.projectPoint(wx, wy);
    return [sx + this.world.ox, sy + this.world.oy];
  }

  private snapCam(): void {
    const [gx, gy] = this.toScreen(this.merc.x, this.merc.y);
    this.camX = this.clamp(gx - VIEW_W / 2, this.world.width - VIEW_W);
    this.camY = this.clamp(gy - 26 - VIEW_H / 2, this.world.height - VIEW_H);
  }
  private clamp(v: number, max: number): number {
    if (max <= 0) return Math.round(max / 2);
    return Math.round(Math.max(0, Math.min(max, v)));
  }

  get nearEntrance(): boolean {
    if (this.zone === 'ext') {
      const d = L.doorZone;
      return this.merc.x > d.x && this.merc.x < d.x + d.w && this.merc.y > d.y && this.merc.y < d.y + d.h;
    }
    const e = this.world.entrance.int;
    return Math.hypot(this.merc.x - e.x, this.merc.y - e.y) < 11;
  }

  update(dt: number, input: Input): void {
    this.time += dt;
    if (this.pending) {
      this.fade = Math.min(1, this.fade + dt * 5);
      if (this.fade >= 1) {
        this.zone = this.pending;
        this.pending = null;
        if (this.zone === 'int') {
          const e = this.world.entrance.int;
          this.merc.x = e.x;
          this.merc.y = e.y;
        } else {
          this.merc.x = L.doorReturn.x;
          this.merc.y = L.doorReturn.y;
        }
        this.merc.vx = 0;
        this.merc.vy = 0;
        this.merc.moving = false;
        this.snapCam();
      }
    } else if (this.fade > 0) this.fade = Math.max(0, this.fade - dt * 4);

    const frozen = this.pending !== null;
    if (!frozen) {
      const axis = input.axis();
      const colliders = this.zone === 'ext' ? this.world.collidersExt : this.world.collidersInt;
      const bounds =
        this.zone === 'ext'
          ? { x: WALK_MIN_X, y: WALK_MIN_Y, w: WALK_MAX_X - WALK_MIN_X, h: WALK_MAX_Y - WALK_MIN_Y }
          : {
              x: this.world.interiorRect.x,
              y: this.world.interiorRect.y,
              w: this.world.interiorRect.w,
              h: this.world.interiorRect.h,
            };
      this.merc.update(dt, axis, input.running, colliders, bounds);
      if (this.zone === 'ext') this.robot.update(dt, this.merc);
      this.prompt = this.nearEntrance;
      if (this.prompt && input.consume('KeyE', 'Enter')) this.pending = this.zone === 'ext' ? 'int' : 'ext';
    }

    const [gx, gy] = this.toScreen(this.merc.x, this.merc.y);
    const tx = this.clamp(gx - VIEW_W / 2, this.world.width - VIEW_W);
    const ty = this.clamp(gy - 26 - VIEW_H / 2, this.world.height - VIEW_H);
    const k = 1 - Math.exp(-7.5 * dt);
    this.camX += (tx - this.camX) * k;
    this.camY += (ty - this.camY) * k;
    input.endFrame();
  }

  render(): PixelSurface {
    const s = new PixelSurface(VIEW_W, VIEW_H);
    const w = this.world;
    const camX = Math.round(this.camX);
    const camY = Math.round(this.camY);

    // ground
    for (let y = 0; y < VIEW_H; y++) {
      const sy = camY + y;
      const row = y * VIEW_W;
      if (sy < 0 || sy >= w.height) {
        s.data.fill(0xff0d0b0a, row, row + VIEW_W);
        continue;
      }
      const srcRow = sy * w.width;
      if (camX >= 0 && camX + VIEW_W <= w.width) s.data.set(w.ground.data.subarray(srcRow + camX, srcRow + camX + VIEW_W), row);
      else {
        for (let x = 0; x < VIEW_W; x++) {
          const sx = camX + x;
          s.data[row + x] = sx >= 0 && sx < w.width ? w.ground.data[srcRow + sx] : 0xff0d0b0a;
        }
      }
    }
    // baked shadows
    const sh = this.zone === 'ext' ? w.shadow : w.shadowCut;
    for (let y = 0; y < VIEW_H; y++) {
      const sy = camY + y;
      if (sy < 0 || sy >= w.height) continue;
      const srcRow = sy * w.width;
      for (let x = 0; x < VIEW_W; x++) {
        const sx = camX + x;
        if (sx < 0 || sx >= w.width) continue;
        const c = sh.data[srcRow + sx];
        if (((c >>> 24) & 0xff) === 0) continue;
        if (bayer4(x, y) > 0.9) continue;
        const i = y * VIEW_W + x;
        const sa = (c >>> 24) & 0xff;
        const isa = 255 - sa;
        const d0 = s.data[i];
        s.data[i] = packRGBA(
          (((c & 0xff) * sa + (d0 & 0xff) * isa) / 255) | 0,
          ((((c >>> 8) & 0xff) * sa + ((d0 >>> 8) & 0xff) * isa) / 255) | 0,
          ((((c >>> 16) & 0xff) * sa + ((d0 >>> 16) & 0xff) * isa) / 255) | 0,
          255,
        );
      }
    }
    // depth-sorted renderables
    const list = w.renderables.filter((o) => o.mode === 'both' || (o.mode === 'ext') === (this.zone === 'ext'));
    list.sort((a, b) => a.depth - b.depth);
    for (const o of list) s.blit(o.sprite, o.x - camX, o.y - camY);

    // entities: world-space movement, screen-space draw (positions swapped)
    if (this.zone === 'ext') {
      const [rx, ry] = this.toScreen(this.robot.x, this.robot.y);
      const ox = this.robot.x;
      const oy = this.robot.y;
      this.robot.x = rx;
      this.robot.y = ry;
      this.robot.draw(s, camX, camY, false);
      this.robot.x = ox;
      this.robot.y = oy;
    }
    const [mx, my] = this.toScreen(this.merc.x, this.merc.y);
    const mox = this.merc.x;
    const moy = this.merc.y;
    this.merc.x = mx;
    this.merc.y = my;
    this.merc.draw(s, camX, camY, this.time, false);
    this.merc.x = mox;
    this.merc.y = moy;

    // lights
    this.lighting.timeOfDay = this.review.timeOfDay;
    this.lighting.enabled = this.review.lighting;
    this.lighting.begin();
    for (const l of w.lights) {
      if (l.mode !== 'both' && (l.mode === 'int') !== (this.zone === 'int')) continue;
      const [lx, ly] = this.toScreen(l.x, l.y);
      this.lighting.addLight(
        { x: lx - camX, y: ly - camY, radius: l.r, r: l.c[0], g: l.c[1], b: l.c[2], intensity: l.i, flicker: l.flicker, blink: l.blink },
        this.time,
        [],
        0,
        0,
      );
    }
    this.lighting.addLight({ x: mx - camX, y: my - camY - 22, radius: 9, r: 0.25, g: 0.85, b: 0.95, intensity: 0.18 }, this.time, [], 0, 0);
    if (this.zone === 'ext') {
      const [rx, ry] = this.toScreen(this.robot.x, this.robot.y);
      this.lighting.addLight({ x: rx - camX, y: ry - camY - 8, radius: 10, r: 0.25, g: 0.9, b: 1, intensity: 0.3 }, this.time, [], 0, 0);
    }
    this.lighting.apply(s);

    // atmosphere vignette
    if (!this.atmo) this.atmo = this.bakeAtmo();
    for (let i = 0; i < this.atmo.data.length; i++) {
      const c = this.atmo.data[i];
      if (((c >>> 24) & 0xff) === 0) continue;
      s.data[i] = blendOver(s.data[i], c);
    }

    if (this.review.debug) {
      for (const c of this.zone === 'ext' ? w.collidersExt : w.collidersInt) {
        const q = [this.toScreen(c.x, c.y), this.toScreen(c.x + c.w, c.y), this.toScreen(c.x + c.w, c.y + c.h), this.toScreen(c.x, c.y + c.h)];
        for (let i = 0; i < 4; i++) {
          const a = q[i];
          const b = q[(i + 1) % 4];
          s.line(a[0] - camX, a[1] - camY, b[0] - camX, b[1] - camY, packRGBA(80, 255, 120, 200));
        }
      }
    }

    if (this.fade > 0.01) {
      for (let y = 0; y < VIEW_H; y++) for (let x = 0; x < VIEW_W; x++) if (bayer4(x, y) < this.fade) s.data[y * VIEW_W + x] = 0xff080708;
    }
    return s;
  }

  private bakeAtmo(): PixelSurface {
    const a = new PixelSurface(VIEW_W, VIEW_H);
    for (let y = 0; y < VIEW_H; y++) {
      for (let x = 0; x < VIEW_W; x++) {
        const dx = (x - VIEW_W / 2) / (VIEW_W / 2);
        const dy = (y - VIEW_H / 2) / (VIEW_H / 2);
        const d = Math.sqrt(dx * dx * 0.8 + dy * dy * 1.15);
        // distance haze toward the north (top of frame)
        if (y < 70) {
          const ht = (1 - y / 70) * 0.4;
          if (bayer4(x, y) <= ht) a.data[y * VIEW_W + x] = withAlpha(mix(0x00000000, 0x2a2019, 1), Math.round(ht * 235));
        }
        if (d < 0.78) continue;
        const t = Math.min(1, (d - 0.78) / 0.45) * 0.34;
        if (bayer4(x, y) <= t) a.data[y * VIEW_W + x] = withAlpha(mix(0x00000000, 0x0c0a09, 1), Math.round(t * 255));
      }
    }
    return a;
  }
}

function blendOver(dst: number, src: number): number {
  const sa = (src >>> 24) & 0xff;
  if (sa === 255) return src;
  const isa = 255 - sa;
  const da = (dst >>> 24) & 0xff;
  const oa = sa + ((da * isa) >> 8);
  if (oa === 0) return 0;
  const r = (((src & 0xff) * sa + ((dst & 0xff) * da * isa) / 255) / oa) | 0;
  const g = ((((src >>> 8) & 0xff) * sa + (((dst >>> 8) & 0xff) * da * isa) / 255) / oa) | 0;
  const b = ((((src >>> 16) & 0xff) * sa + (((dst >>> 16) & 0xff) * da * isa) / 255) / oa) | 0;
  return packRGBA(r, g, b, oa);
}
