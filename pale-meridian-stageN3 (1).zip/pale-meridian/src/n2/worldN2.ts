import { mix, packRGBA } from '../rendering/color';
import { bayer4, bayer8 } from '../rendering/dither';
import { fbm, makeRng, valueNoise } from '../rendering/noise';
import { PixelSurface } from '../rendering/PixelSurface';
import { amber, cyan, dust, grime, hazard, metal, olive, rock, rust, slate, teal, warm } from '../data/palette';
import { drawText } from '../rendering/text';
import { N2Projection, type FaceQuadN2 } from './projection';
import { B, L, COLLIDERS } from '../data/layout';
import * as props from '../assets/props';

/**
 * N2 WORLD — the SAME world as Scene 1 (same layout, same terrain recipe,
 * same props, same interior set) re-presented through N2Projection.
 * Nothing here is a transform of Scene 1 pixels: terrain, walls, roof,
 * interior and shadows are rebuilt through the N2 lattice, so all surfaces
 * share exact edges and consistent depth.
 */

export interface N2Renderable {
  sprite: PixelSurface;
  x: number;
  y: number;
  depth: number;
  mode: 'both' | 'ext' | 'int';
  name: string;
}

export interface N2World {
  width: number;
  height: number;
  ox: number;
  oy: number;
  ground: PixelSurface;
  shadow: PixelSurface;
  shadowCut: PixelSurface;
  renderables: N2Renderable[];
  lights: { x: number; y: number; r: number; c: [number, number, number]; i: number; flicker?: number; blink?: number; mode: 'both' | 'ext' | 'int' }[];
  collidersExt: { x: number; y: number; w: number; h: number }[];
  collidersInt: { x: number; y: number; w: number; h: number }[];
  entrance: { ext: { x: number; y: number }; int: { x: number; y: number } };
  interiorRect: { x: number; y: number; w: number; h: number };
  worldW: number;
  worldH: number;
}

const WORLD_W = 780;
const WORLD_H = 580;

interface Baked {
  sprite: PixelSurface;
  ax: number;
  ay: number;
}

type Faces = { front: FaceQuadN2; east: FaceQuadN2; west: FaceQuadN2; back: FaceQuadN2; roof: FaceQuadN2; H: number };

const facePx = (s: PixelSurface, f: FaceQuadN2, u: number, v: number, c: number) => {
  s.set(Math.round(f.origin[0] + f.u[0] * u + f.v[0] * v), Math.round(f.origin[1] + f.u[1] * u + f.v[1] * v), c);
};
const faceLine = (s: PixelSurface, f: FaceQuadN2, u0: number, v0: number, u1: number, v1: number, c: number) => {
  s.line(
    Math.round(f.origin[0] + f.u[0] * u0 + f.v[0] * v0),
    Math.round(f.origin[1] + f.u[1] * u0 + f.v[1] * v0),
    Math.round(f.origin[0] + f.u[0] * u1 + f.v[0] * v1),
    Math.round(f.origin[1] + f.u[1] * u1 + f.v[1] * v1),
    c,
  );
};
const faceRect = (s: PixelSurface, f: FaceQuadN2, u0: number, v0: number, uw: number, vh: number, c: number) => {
  const p = (u: number, v: number): [number, number] => [
    Math.round(f.origin[0] + f.u[0] * u + f.v[0] * v),
    Math.round(f.origin[1] + f.u[1] * u + f.v[1] * v),
  ];
  s.polygon([p(u0, v0), p(u0 + uw, v0), p(u0 + uw, v0 + vh), p(u0, v0 + vh)], c);
};
const faceRamp = (s: PixelSurface, f: FaceQuadN2, stops: number[]) => {
  for (let v = 0; v < f.vh; v++) {
    const t = f.vh === 1 ? 0 : v / (f.vh - 1);
    const tt = t * (stops.length - 1);
    const i = Math.floor(tt);
    const c = bayer4(0, v) < tt - i ? stops[Math.min(stops.length - 1, i + 1)] : stops[i];
    faceLine(s, f, 0, v, f.uw, v, c);
  }
};
const fillFace = (s: PixelSurface, f: FaceQuadN2, c: number) => s.polygon(f.pts, c);

function bakeBoxN2(
  pr: N2Projection,
  r: { x: number; y: number; w: number; d: number; h: number },
  anchor: { x: number; y: number },
  faces: (s: PixelSurface, f: Faces) => void,
  opts: { front?: boolean; east?: boolean; west?: boolean; roof?: boolean } = {},
): Baked {
  const o = { front: true, east: true, west: true, roof: true, ...opts };
  const f = pr.projectBox(r.x, r.y, r.w, r.d, r.h);
  const all = [...f.front.pts, ...f.east.pts, ...f.west.pts, ...f.roof.pts];
  const xs = all.map((p) => p[0]);
  const ys = all.map((p) => p[1]);
  const minX = Math.floor(Math.min(...xs)) - 4;
  const minY = Math.floor(Math.min(...ys)) - 4;
  const maxX = Math.ceil(Math.max(...xs)) + 4;
  const maxY = Math.ceil(Math.max(...ys)) + 4;
  const s = new PixelSurface(maxX - minX, maxY - minY);
  const lx = -minX;
  const ly = -minY;
  const sh = (q: FaceQuadN2): FaceQuadN2 => ({ ...q, origin: [q.origin[0] + lx, q.origin[1] + ly] as [number, number], pts: q.pts.map((p) => [p[0] + lx, p[1] + ly]) });
  const F: Faces = { front: sh(f.front), east: sh(f.east), west: sh(f.west), back: sh(f.back), roof: sh(f.roof), H: f.H };
  void o;
  faces(s, F);
  const [gx, gy] = pr.projectPoint(anchor.x, anchor.y);
  return { sprite: s, ax: Math.round(gx - minX), ay: Math.round(gy - minY) };
}

const CREAM = { hi: mix(metal.m8, dust.d7, 0.3), mid: mix(metal.m6, dust.d6, 0.3), lo: mix(metal.m4, dust.d5, 0.3), dark: metal.m2, edge: metal.m1 };
const RUSTM = { hi: mix(rust.x6, dust.d7, 0.25), mid: rust.x4, lo: rust.x2, dark: rust.x1, edge: rust.x0 };

/** layout convention: `y` is the FRONT ground line, the body extends -y */
const mass = (b: { x: number; y: number; w: number; d: number; h: number }) => ({ x: b.x, y: b.y - b.d, w: b.w, d: b.d, h: b.h });

export function bakeN2World(pr: N2Projection): N2World {
  const rnd = makeRng(9137);
  const renderables: N2Renderable[] = [];
  const lights: N2World['lights'] = [];

  const cs = [pr.projectPoint(-40, -40), pr.projectPoint(WORLD_W + 40, -40), pr.projectPoint(WORLD_W + 40, WORLD_H + 40), pr.projectPoint(-40, WORLD_H + 40)];
  const xs = cs.map((c) => c[0]);
  const ys = cs.map((c) => c[1]);
  const minX = Math.floor(Math.min(...xs));
  const maxX = Math.ceil(Math.max(...xs));
  const minY = Math.floor(Math.min(...ys));
  const maxY = Math.ceil(Math.max(...ys));
  const W = maxX - minX;
  const H = maxY - minY;
  const ox = -minX;
  const oy = -minY;
  const gp = (wx: number, wy: number): [number, number] => {
    const [sx, sy] = pr.projectPoint(wx, wy);
    return [Math.round(sx + ox), Math.round(sy + oy)];
  };

  // ------------------------------------------------------------ terrain (Scene 1 recipe through N2)
  const ground = new PixelSurface(W, H);
  const field = new Float32Array(W * H);
  for (let py = 0; py < H; py++) {
    for (let px = 0; px < W; px++) {
      const [wx, wy] = pr.invPoint(px - ox, py - oy);
      field[py * W + px] = fbm(wx / 150, wy / 96, 3, 11);
    }
  }
  const F = (px: number, py: number) => field[Math.max(0, Math.min(H - 1, py)) * W + Math.max(0, Math.min(W - 1, px))];
  const CRUST = [dust.d0, dust.d1, dust.d2];
  const RUSTY = [dust.d1, mix(rust.x1, dust.d1, 0.55), mix(rust.x2, dust.d2, 0.55), mix(rust.x3, dust.d3, 0.6), mix(rust.x4, dust.d4, 0.7)];
  const OCHRE = [dust.d1, dust.d2, dust.d3, dust.d4, dust.d5];
  const PALE = [dust.d3, dust.d4, dust.d5, dust.d6, dust.d7];
  const ROCKY = [rock.r1, rock.r2, rock.r3, rock.r4];
  for (let py = 0; py < H; py++) {
    for (let px = 0; px < W; px++) {
      const [wx, wy] = pr.invPoint(px - ox, py - oy);
      const form = F(px, py);
      const sx = F(px + 4, py) - F(px - 4, py);
      const sy = F(px, py + 4) - F(px, py - 4);
      let lit = -sx * 5.2 - sy * 6.4;
      lit = Math.max(-1, Math.min(1, lit));
      const q = Math.round(lit * 2) / 2;
      const litT = bayer4(px, py) < Math.abs(lit * 2 - Math.round(Math.abs(lit * 2))) ? Math.abs(q) + 0.25 : Math.abs(q);
      const grain = fbm(wx / 13, wy / 10, 3, 41);
      const micro = valueNoise(wx / 2.7, wy / 2.7, 77);
      const north = 1 - Math.min(1, wy / 260);
      const biome = fbm(wx / 82, wy / 70, 3, 5) * 0.8 + form * 0.2 + north * 0.16;
      let v = grain * 0.62 + form * 0.28 + (micro - 0.5) * 0.1 + 0.12;
      v = Math.max(0, Math.min(0.999, v));
      const bEdge = bayer8(px, py) * 0.1 - 0.05;
      let c: number;
      if (biome + bEdge < 0.33) c = bayer4(px, py) < v * 2.7 % 1 ? CRUST[Math.min(2, Math.floor(v * 2.7) + 1)] : CRUST[Math.floor(v * 2.7)];
      else if (biome + bEdge < 0.44) {
        const t = v * 4;
        c = bayer4(px, py) < t - Math.floor(t) ? RUSTY[Math.min(4, Math.floor(t) + 1)] : RUSTY[Math.floor(t)];
      } else if (biome + bEdge < 0.75) {
        const t = v * 4;
        c = bayer4(px, py) < t - Math.floor(t) ? OCHRE[Math.min(4, Math.floor(t) + 1)] : OCHRE[Math.floor(t)];
      } else {
        const t = v * 4;
        c = bayer4(px, py) < t - Math.floor(t) ? PALE[Math.min(4, Math.floor(t) + 1)] : PALE[Math.floor(t)];
      }
      if (north > 0.3 && bayer8(px + 3, py) < Math.min(1, (north - 0.3) / 0.55) * 0.62) {
        const t = v * 3;
        c = bayer4(px, py) < t - Math.floor(t) ? ROCKY[Math.min(3, Math.floor(t) + 1)] : ROCKY[Math.floor(t)];
      }
      if (q > 0) c = mix(c, dust.d8, Math.min(0.17, litT * 0.2));
      else c = mix(c, dust.d0, Math.min(0.22, litT * 0.26));
      ground.setRaw(px, py, packRGBA(c & 0xff, (c >>> 8) & 0xff, (c >>> 16) & 0xff));
    }
  }
  // speckles
  for (let i = 0; i < 9000; i++) {
    const wx = rnd.range(0, WORLD_W);
    const wy = rnd.range(60, WORLD_H);
    if (valueNoise(wx / 30, wy / 30, 3) < 0.68) continue;
    const [px, py] = gp(wx, wy);
    ground.set(px, py, rnd.chance(0.5) ? dust.d7 : dust.d2);
  }
  // cracks
  for (let i = 0; i < 16; i++) {
    let wx = rnd.range(40, WORLD_W - 40);
    let wy = rnd.range(150, WORLD_H - 20);
    if (wx > L.pad.x - 30 && wx < L.pad.x + L.pad.w + 30 && wy > L.pad.y - 20 && wy < L.pad.y + L.pad.h + 20) continue;
    let ang = rnd() * Math.PI * 2;
    for (let k = 0; k < 40; k++) {
      ang += (rnd() - 0.5) * 0.5;
      wx += Math.cos(ang) * 1.6;
      wy += Math.sin(ang) * 1.1;
      const [px, py] = gp(wx, wy);
      ground.set(px, py, mix(dust.d0, dust.d1, 0.4));
      if (rnd() < 0.2) ground.set(px, py + 1, dust.d5);
    }
  }
  // pad + plates + stencil + arrows
  const padQ = pr.projectQuad(L.pad.x, L.pad.y, L.pad.w, L.pad.h).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
  ground.polygon(padQ, mix(dust.d5, dust.d6, 0.5));
  const padQ2 = pr.projectQuad(L.pad.x + 3, L.pad.y + 3, L.pad.w - 6, L.pad.h - 6).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
  ground.polygon(padQ2, mix(dust.d6, dust.d7, 0.45));
  for (const [dx, dy, dw, dd] of [
    [266, 372, 26, 16],
    [350, 368, 30, 18],
    [404, 386, 24, 14],
  ]) {
    const q = pr.projectQuad(dx, dy, dw, dd).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
    ground.polygon(q, mix(warm.w3, dust.d3, 0.45));
    for (let i = 0; i < 4; i++) {
      const a = q[i];
      const b2 = q[(i + 1) % 4];
      ground.line(a[0], a[1], b2[0], b2[1], mix(warm.w2, dust.d2, 0.4));
    }
  }
  for (let i = 0; i < 26; i++) {
    const sx0 = L.pad.x + rnd.range(4, L.pad.w - 24);
    const sy0 = L.pad.y + rnd.range(4, L.pad.h - 16);
    const sw = rnd.range(6, 22);
    const sd = rnd.range(4, 12);
    const q = pr.projectQuad(sx0, sy0, sw, sd).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
    ground.polygon(q, rnd.chance(0.5) ? mix(dust.d5, dust.d4, 0.6) : mix(dust.d6, warm.w3, 0.35));
  }
  for (let i = 0; i < 5; i++) {
    let wx = L.pad.x + rnd.range(10, L.pad.w - 10);
    let wy = L.pad.y + rnd.range(8, L.pad.h - 8);
    let ang = rnd() * Math.PI * 2;
    for (let k = 0; k < 18; k++) {
      ang += (rnd() - 0.5) * 0.6;
      wx += Math.cos(ang) * 1.4;
      wy += Math.sin(ang) * 1.0;
      const p = gp(wx, wy);
      ground.set(p[0], p[1], mix(dust.d3, dust.d2, 0.5));
    }
  }
  for (let i = 0; i < 10; i++) {
    const bx0 = L.pad.x + rnd.range(8, L.pad.w - 30);
    const by0 = L.pad.y + rnd.range(6, L.pad.h - 20);
    for (let wy = 0; wy < 8; wy++) {
      const t = (wy - 4) / 4;
      const hw = 9 * Math.sqrt(Math.max(0, 1 - t * t));
      const a = gp(bx0 - hw, by0 + wy);
      const b = gp(bx0 + hw, by0 + wy);
      for (let x = a[0]; x <= b[0]; x++) if (bayer4(x, a[1]) < 0.8) ground.set(x, a[1], mix(dust.d3, dust.d2, 0.6));
    }
  }
  const st = gp(L.pad.x + 12, L.pad.y + L.pad.h - 8);
  drawText(ground, st[0], st[1], 'K-7 OUTPOST', mix(metal.m6, dust.d6, 0.5), { worn: 0.45, seed: 3 });
  // tracks
  for (const side of [-6, 6]) {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 30; t++) {
      const wx = 337 + side + Math.sin(t / 7) * 5;
      const wy = WORLD_H + 10 - t * 5.4;
      const p = gp(wx, wy);
      if (prev) ground.line(prev[0], prev[1], p[0], p[1], mix(dust.d2, grime.g2, 0.45));
      prev = p;
    }
  }
  // footprints to door
  for (let i = 0; i < 18; i++) {
    const wx = L.doorReturn.x + (i % 2 === 0 ? -2 : 2);
    const wy = L.doorReturn.y + 4 + i * 2.2;
    const [px, py] = gp(wx, wy);
    ground.set(px, py, mix(dust.d2, dust.d3, 0.5));
  }
  // pipe trench generator -> building
  {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 34; t++) {
      const wx = L.generator.x - 10 - t * 5.4;
      const wy = L.generator.y - 4 - Math.max(0, t - 26) * 3.4;
      const p = gp(wx, wy);
      if (prev) {
        ground.line(prev[0], prev[1], p[0], p[1], warm.w2);
        ground.line(prev[0], prev[1] - 1, p[0], p[1] - 1, warm.w4);
      }
      prev = p;
    }
  }
  // interior floor (hall) baked into ground
  const IR = { x: B.hall.x + 4, y: B.hall.y - B.hall.d + 4, w: B.hall.w - 8, h: B.hall.d - 8 };
  const fq = pr.projectQuad(IR.x, IR.y, IR.w, IR.h).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
  ground.polygon(fq, mix(slate.s5, slate.s6, 0.5));
  const fq2 = pr.projectQuad(IR.x + 1, IR.y + 1, IR.w - 2, IR.h - 2).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
  ground.polygon(fq2, mix(slate.s4, slate.s5, 0.6));
  for (let u = 8; u < IR.w - 4; u += 12) {
    const a = gp(IR.x + u, IR.y + 2);
    const b = gp(IR.x + u, IR.y + IR.h - 2);
    ground.line(a[0], a[1], b[0], b[1], slate.s3);
  }
  for (let u = 10; u < IR.w - 10; u += 3) {
    const a = gp(IR.x + u, IR.y + IR.h / 2 - 3);
    const b = gp(IR.x + u, IR.y + IR.h / 2 + 3);
    ground.line(a[0], a[1], b[0], b[1], u % 6 === 0 ? slate.s6 : slate.s3);
  }
  // cable on interior floor
  {
    let prev: [number, number] | null = null;
    for (let t = 0; t <= 14; t++) {
      const p = gp(IR.x + 8 + t * 3.4, IR.y + IR.h - 6 + Math.sin(t) * 1.5);
      if (prev) ground.line(prev[0], prev[1], p[0], p[1], slate.s2);
      prev = p;
    }
  }
  // baked rocks (same places as Scene 1)
  const rocks: [number, number, number, number][] = [
    [86, 262, 22, 12],
    [146, 220, 14, 8],
    [646, 246, 24, 13],
    [706, 306, 17, 10],
    [58, 452, 20, 11],
    [744, 452, 19, 11],
    [302, 180, 26, 12],
    [452, 194, 16, 9],
    [560, 168, 21, 11],
    [196, 306, 11, 7],
    [616, 374, 12, 7],
    [128, 534, 24, 13],
    [664, 548, 19, 10],
    [394, 572, 14, 8],
  ];
  for (const [rx, ry, rr, rry0] of rocks) {
    const s = new PixelSurface(rr * 2 + 8, rry0 + 10);
    const ccx = rr + 4;
    const ccy = rry0 + 3;
    const rry = Math.max(3, Math.round(rry0 * 0.62));
    for (let y = -rry - 1; y <= rry; y++) {
      for (let x = -rr - 1; x <= rr + 1; x++) {
        const wob = 0.76 + valueNoise((ccx + x) / 4, (ccy + y) / 4, 7) * 0.46;
        const d = Math.sqrt((x * x) / (rr * rr) + (y * y) / (rry * rry)) / wob;
        if (d > 1) continue;
        const nl = (-x / rr) * 0.5 + (-y / rry) * 0.8;
        let v = 0.34 + nl * 0.33 + (valueNoise((ccx + x) / 3, (ccy + y) / 3, 8) - 0.5) * 0.4;
        v = Math.max(0, Math.min(0.999, v));
        const ramp = [rock.r1, rock.r2, rock.r3, rock.r4, rock.r5];
        const t = v * 4;
        s.set(ccx + x, ccy + y, bayer4(x, y) < t - Math.floor(t) ? ramp[Math.min(4, Math.floor(t) + 1)] : ramp[Math.floor(t)]);
      }
    }
    const [px, py] = gp(rx, ry);
    renderables.push({ sprite: s, x: px - ccx, y: py - (ccy + rry - 1), depth: pr.depth(rx, ry), mode: 'both', name: 'rock' });
  }
  // scrub (same recipe as Scene 1)
  for (let i = 0; i < 44; i++) {
    const wx = rnd.range(16, WORLD_W - 16);
    const wy = rnd.range(170, WORLD_H - 12);
    if (valueNoise(wx / 44, wy / 44, 17) < 0.55) continue;
    const s = new PixelSurface(14, 14);
    const blades = 4 + rnd.int(0, 4);
    for (let b = 0; b < blades; b++) {
      const h = 3 + rnd.int(0, 6);
      const lean = (rnd() - 0.5) * 4;
      for (let k = 0; k < h; k++) {
        const t = k / h;
        s.set(Math.round(7 + lean * t * t + (b - blades / 2) * 0.8), 12 - k, k === h - 1 ? mix(olive.o5, rust.x5, 0.4) : t > 0.5 ? mix(olive.o3, rust.x3, 0.25) : olive.o2);
      }
    }
    const [px, py] = gp(wx, wy);
    renderables.push({ sprite: s, x: px - 7, y: py - 12, depth: pr.depth(wx, wy), mode: 'both', name: 'scrub' });
  }

  // contact shadow strips along front bases
  for (const b of [B.hall, B.westWing, B.garage, B.module]) {
    const q = pr.projectQuad(b.x + 1, b.y, b.w - 2, 2).map((p) => [Math.round(p[0] + ox), Math.round(p[1] + oy)]);
    ground.polygon(q, mix(dust.d1, dust.d0, 0.4));
  }

  // ------------------------------------------------------------ baked shadows
  const shadow = new PixelSurface(W, H);
  const shadowCut = new PixelSurface(W, H);
  const castBox = (target: PixelSurface, r: { x: number; y: number; w: number; d: number; h: number }) => {
    const [dx, dy] = pr.shadowOffset(r.h);
    const q = pr.projectQuad(r.x, r.y, r.w, r.d).map((p) => [p[0] + ox, p[1] + oy]);
    const far = q.map((p) => [p[0] + dx, p[1] + dy]);
    target.polygon([q[0], q[1], far[1], far[0]], packRGBA(34, 20, 18, 150));
    target.polygon([q[1], q[2], far[2], far[1]], packRGBA(34, 20, 18, 150));
    target.polygon(q, packRGBA(34, 20, 18, 150));
  };
  castBox(shadow, mass(B.hall));
  castBox(shadow, mass(B.westWing));
  castBox(shadow, mass(B.garage));
  castBox(shadow, mass(B.module));
  castBox(shadowCut, { x: B.hall.x, y: B.hall.y - B.hall.d, w: B.hall.w, d: 4, h: B.hall.h });
  castBox(shadowCut, mass(B.westWing));
  castBox(shadowCut, mass(B.garage));
  for (const target of [shadow, shadowCut]) {
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = y * W + x;
        if ((target.data[i] >>> 24) === 0) continue;
        let outside = false;
        for (const o of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ]) {
          const nx = x + o[0];
          const ny = y + o[1];
          if (nx < 0 || ny < 0 || nx >= W || ny >= H || (target.data[ny * W + nx] >>> 24) === 0) outside = true;
        }
        if (outside && bayer8(x, y) < 0.6) target.data[i] = 0;
      }
    }
  }

  // ------------------------------------------------------------ building
  const push = (bk: Baked, wx: number, wy: number, depth: number, mode: N2Renderable['mode'], name: string) => {
    const [sx, sy] = pr.projectPoint(wx, wy);
    renderables.push({ sprite: bk.sprite, x: Math.round(sx + ox) - bk.ax, y: Math.round(sy + oy) - bk.ay, depth, mode, name });
  };

  const innerFace = (s: PixelSurface, f: FaceQuadN2) => {
    faceRamp(s, f, [mix(slate.s7, dust.d7, 0.35), slate.s6, slate.s5]);
    faceLine(s, f, 0, 0, f.uw, 0, mix(warm.w6, slate.s6, 0.45));
    faceLine(s, f, 0, 4, f.uw, 4, mix(rust.x3, hazard.h2, 0.35));
    faceLine(s, f, 0, 5, f.uw, 5, mix(rust.x2, slate.s4, 0.5));
    for (let u = 10; u < f.uw - 10; u += 24) {
      faceRect(s, f, u, 9, 16, 6, slate.s4);
      faceLine(s, f, u + 1, 11, u + 14, 11, slate.s3);
    }
    // conduit pipes + posters + lived-in marks
    faceLine(s, f, 2, 18, f.uw - 2, 18, warm.w2);
    faceLine(s, f, 2, 19, f.uw - 2, 19, metal.m3);
    faceRect(s, f, 34, 8, 7, 9, teal.t2);
    faceRect(s, f, 35, 9, 5, 4, teal.t4);
    faceRect(s, f, 88, 8, 7, 9, mix(amber.a2, rust.x3, 0.4));
    facePx(s, f, 60, 22, slate.s3);
    facePx(s, f, 74, 24, slate.s3);
    faceLine(s, f, 4, f.vh - 3, f.uw - 4, f.vh - 3, slate.s4);
    faceLine(s, f, 4, f.vh - 2, f.uw - 4, f.vh - 2, slate.s3);
    for (let u = 6; u < f.uw - 6; u += 9) facePx(s, f, u, 7, mix(slate.s7, dust.d8, 0.4));
  };
  const creamFront = (s: PixelSurface, f: FaceQuadN2) => {
    faceRamp(s, f, [CREAM.hi, CREAM.mid, CREAM.lo]);
    faceLine(s, f, 0, f.vh - 3, f.uw, f.vh - 3, mix(hazard.h2, CREAM.lo, 0.5));
    for (let u = 6; u < f.uw - 6; u += 3) facePx(s, f, u, f.vh - 2, mix(dust.d4, CREAM.lo, 0.5));
  };

  // hall shell (N+W+E walls, inner faces for cutaway)
  const hallShell = bakeBoxN2(
    pr,
    mass(B.hall),
    { x: B.hall.x + B.hall.w / 2, y: B.hall.y - B.hall.d },
    (s, f) => {
      innerFace(s, f.back); // interior north wall (seen in cutaway)
      innerFace(s, f.west); // interior west wall
      creamFront(s, f.east); // exterior east face
      for (let u = 10; u < f.east.uw - 10; u += 16) faceRect(s, f.east, u, 10, 10, 10, metal.m2);
    },
  );
  push(hallShell, B.hall.x + B.hall.w / 2, B.hall.y - B.hall.d, pr.depth(B.hall.x + B.hall.w / 2, B.hall.y - B.hall.d) - 1, 'both', 'hallShell');
  // hall south wall (ext only)
  const hallS = bakeBoxN2(
    pr,
    { x: B.hall.x, y: B.hall.y - 4, w: B.hall.w, d: 4, h: B.hall.h },
    { x: B.hall.x + B.hall.w / 2, y: B.hall.y },
    (s, f) => {
      creamFront(s, f.front);
      for (let u = 12; u < f.front.uw - 10; u += 26) faceLine(s, f.front, u, 4, u, f.front.vh - 5, metal.m4);
      for (const ux of [14, 108]) {
        faceRect(s, f.front, ux, 10, 26, 12, metal.m2);
        faceRect(s, f.front, ux + 1, 11, 24, 10, teal.t1);
        faceLine(s, f.front, ux + 2, 13, ux + 16, 13, teal.t3);
        faceLine(s, f.front, ux + 1, 11, ux + 1, 20, teal.t2);
        faceLine(s, f.front, ux, 22, ux + 26, 22, metal.m7);
        faceLine(s, f.front, ux, 23, ux + 26, 23, mix(metal.m3, CREAM.lo, 0.5));
      }
      for (let u = 8; u < f.front.uw - 8; u += 11) facePx(s, f.front, u, 6, metal.m8);
      for (const u0 of [18, 24, 112, 118]) for (let v = 23; v < f.front.vh - 4; v += 1) if ((v + u0) % 3 !== 0) facePx(s, f.front, u0 + ((v >> 2) & 1), v, mix(rust.x2, CREAM.lo, 0.55));
    },
    { roof: false, east: false, west: false },
  );
  push(hallS, B.hall.x + B.hall.w / 2, B.hall.y, pr.depth(B.hall.x + B.hall.w / 2, B.hall.y), 'ext', 'hallS');
  // hall roof
  const hallRoof = bakeBoxN2(
    pr,
    { x: B.hall.x - 2, y: B.hall.y - B.hall.d - 2, w: B.hall.w + 4, d: B.hall.d + 4, h: B.hall.h + 2 },
    { x: B.hall.x + B.hall.w / 2, y: B.hall.y + 2 },
    (s, f) => {
      fillFace(s, f.roof, mix(metal.m8, dust.d7, 0.4));
      for (let u = 16; u < f.roof.uw - 8; u += 26) faceLine(s, f.roof, u, 2, u, f.roof.vh - 2, metal.m6);
      for (let v = 10; v < f.roof.vh - 6; v += 14) faceLine(s, f.roof, 4, v, f.roof.uw - 4, v, metal.m7);
      faceRect(s, f.roof, 18, 10, 20, 12, metal.m5);
      faceRect(s, f.roof, 20, 12, 16, 8, mix(teal.t1, metal.m2, 0.35));
      faceRect(s, f.roof, 96, 16, 16, 10, metal.m6);
      faceLine(s, f.roof, 97, 18, 110, 18, metal.m8);
      faceRect(s, f.roof, 52, 26, 12, 9, metal.m4);
      faceLine(s, f.roof, 53, 28, 62, 28, metal.m6);
      faceLine(s, f.roof, 74, 6, 74, f.roof.vh - 6, metal.m6);
      faceLine(s, f.roof, 77, 6, 77, f.roof.vh - 6, metal.m5);
      // comm dish on a short mast
      const dx0 = 12;
      const dy0 = f.roof.vh - 12;
      faceLine(s, f.roof, dx0 + 3, dy0, dx0 + 3, dy0 - 6, metal.m3);
      for (let k = 0; k < 5; k++) facePx(s, f.roof, dx0 + 1 + (k >> 1), dy0 - 7 - (k >> 1), metal.m7);
      facePx(s, f.roof, dx0 + 4, dy0 - 8, metal.m9);
      facePx(s, f.roof, dx0 + 5, dy0 - 9, cyan.c4);
      for (let u = 8; u < f.roof.uw - 8; u += 9) facePx(s, f.roof, u, f.roof.vh - 3, dust.d6);
      for (let i = 0; i < 260; i++) facePx(s, f.roof, 4 + ((i * 37) % (f.roof.uw - 8)), 3 + ((i * 53) % (f.roof.vh - 6)), i % 3 === 0 ? dust.d6 : metal.m6);
      faceLine(s, f.roof, f.roof.uw - 1, 0, f.roof.uw - 1, f.roof.vh - 1, metal.m9);
      faceLine(s, f.roof, 0, 0, f.roof.uw, 0, metal.m9);
      faceLine(s, f.front, 0, 0, f.front.uw, 0, metal.m7);
      faceLine(s, f.front, 0, 1, f.front.uw, 1, metal.m5);
      faceLine(s, f.front, 0, 2, f.front.uw, 2, metal.m2);
    },
    { front: true, east: false, west: false },
  );
  push(hallRoof, B.hall.x + B.hall.w / 2, B.hall.y + 2, pr.depth(B.hall.x + B.hall.w / 2, B.hall.y + 2), 'ext', 'hallRoof');

  // west wing
  const wingShell = bakeBoxN2(
    pr,
    mass(B.westWing),
    { x: B.westWing.x + B.westWing.w / 2, y: B.westWing.y },
    (s, f) => {
      creamFront(s, f.front);
      faceRect(s, f.front, 6, 6, 10, 8, metal.m2);
      faceRect(s, f.front, 7, 7, 8, 6, teal.t1);
      faceRect(s, f.front, 26, 6, 10, 8, metal.m2);
      faceRect(s, f.front, 27, 7, 8, 6, teal.t1);
      fillFace(s, f.roof, mix(metal.m8, dust.d7, 0.42));
      for (let i = 0; i < 4; i++) {
        faceRect(s, f.roof, 4 + i * 8, 5, 7, 12, teal.t1);
        faceLine(s, f.roof, 4 + i * 8, 5, 4 + i * 8 + 6, 5, teal.t3);
        faceLine(s, f.roof, 4 + i * 8, 11, 4 + i * 8 + 6, 11, teal.t2);
        facePx(s, f.roof, 4 + i * 8, 5, metal.m8);
      }
      faceRect(s, f.roof, 38, 7, 6, 8, metal.m5);
      faceLine(s, f.roof, 0, 0, f.roof.uw, 0, metal.m9);
    },
    { east: false },
  );
  push(wingShell, B.westWing.x + B.westWing.w / 2, B.westWing.y, pr.depth(B.westWing.x + B.westWing.w / 2, B.westWing.y), 'both', 'wing');

  // garage
  const garage = bakeBoxN2(
    pr,
    mass(B.garage),
    { x: B.garage.x + B.garage.w / 2, y: B.garage.y },
    (s, f) => {
      creamFront(s, f.front);
      faceRect(s, f.front, 8, 6, 30, f.front.vh - 8, metal.m3);
      for (let v = 8; v < f.front.vh - 4; v += 3) faceLine(s, f.front, 9, v, 37, v, metal.m4);
      faceLine(s, f.front, 9, f.front.vh - 5, 37, f.front.vh - 5, hazard.h2);
      faceRect(s, f.front, 44, 8, 10, 10, metal.m2);
      faceRect(s, f.front, 45, 9, 8, 8, teal.t1);
      faceRamp(s, f.east, [CREAM.lo, CREAM.dark]);
      faceRect(s, f.east, 10, 8, 12, 10, metal.m3);
      for (let v = 10; v < 18; v += 3) faceLine(s, f.east, 11, v, 21, v, metal.m2);
      fillFace(s, f.roof, mix(metal.m8, dust.d7, 0.42));
      faceRect(s, f.roof, 12, 8, 12, 9, metal.m4);
      faceLine(s, f.roof, 13, 10, 22, 10, metal.m6);
      faceLine(s, f.roof, 40, 6, 40, f.roof.vh - 6, metal.m6);
      faceLine(s, f.roof, 0, 0, f.roof.uw, 0, metal.m9);
    },
    { west: false },
  );
  push(garage, B.garage.x + B.garage.w / 2, B.garage.y, pr.depth(B.garage.x + B.garage.w / 2, B.garage.y), 'both', 'garage');

  // module (entrance tower, ext only: hidden in cutaway)
  const moduleShell = bakeBoxN2(
    pr,
    mass(B.module),
    { x: B.module.x + B.module.w / 2, y: B.module.y },
    (s, f) => {
      faceRamp(s, f.front, [RUSTM.hi, RUSTM.mid, RUSTM.lo]);
      for (let u = 3; u < f.front.uw - 2; u += 4) faceLine(s, f.front, u, 3, u, f.front.vh - 4, mix(rust.x3, rust.x2, 0.5));
      faceRect(s, f.front, 5, 10, 16, 6, rust.x2);
      const tx = Math.round(f.front.origin[0] + f.front.u[0] * 6 + f.front.v[0] * 11);
      const ty = Math.round(f.front.origin[1] + f.front.u[1] * 6 + f.front.v[1] * 11);
      drawText(s, tx, ty, 'K-7', mix(rust.x7, metal.m8, 0.35), { worn: 0.15 });
      // signage band across the facade
      faceRect(s, f.front, 2, 16, f.front.uw - 4, 7, mix(rust.x2, metal.m2, 0.5));
      faceLine(s, f.front, 2, 16, f.front.uw - 2, 16, mix(rust.x5, dust.d6, 0.4));
      faceLine(s, f.front, 2, 22, f.front.uw - 2, 22, rust.x1);
      const stx = Math.round(f.front.origin[0] + f.front.u[0] * 8 + f.front.v[0] * 18);
      const sty = Math.round(f.front.origin[1] + f.front.u[1] * 8 + f.front.v[1] * 18);
      drawText(s, stx, sty, 'MERIDIAN', mix(metal.m8, warm.w6, 0.3), { worn: 0.2 });
      faceRect(s, f.front, 8, 22, 10, 5, rust.x1);
      faceLine(s, f.front, 9, 24, 16, 24, teal.t3);
      // entrance door recess (B.door sits in this face)
      const du = B.door.x - B.module.x;
      faceRect(s, f.front, du - 1, f.front.vh - 20, B.door.w + 2, 20, metal.m2);
      faceRect(s, f.front, du, f.front.vh - 19, B.door.w, 19, mix(warm.w1, metal.m1, 0.4));
      faceLine(s, f.front, du + B.door.w / 2, f.front.vh - 18, du + B.door.w / 2, f.front.vh - 2, metal.m3);
      faceLine(s, f.front, du + 2, f.front.vh - 16, du + B.door.w / 2 - 2, f.front.vh - 16, mix(warm.w4, amber.a3, 0.4));
      faceLine(s, f.front, du, f.front.vh - 1, du + B.door.w, f.front.vh - 1, hazard.h2);
      faceRamp(s, f.east, [RUSTM.lo, RUSTM.dark]);
      for (let v = 6; v < f.east.vh - 4; v += 5) faceLine(s, f.east, 4, v, f.east.uw - 4, v, rust.x2);
      fillFace(s, f.roof, mix(rust.x6, dust.d7, 0.3));
      for (let i = 0; i < 90; i++) facePx(s, f.roof, 2 + ((i * 29) % (f.roof.uw - 4)), 2 + ((i * 41) % (f.roof.vh - 4)), i % 3 === 0 ? rust.x7 : mix(rust.x4, dust.d5, 0.4));
      faceLine(s, f.roof, f.roof.uw / 2, 1, f.roof.uw / 2, f.roof.vh - 1, mix(rust.x4, dust.d4, 0.4));
      faceLine(s, f.roof, f.roof.uw - 1, 0, f.roof.uw - 1, f.roof.vh - 1, rust.x7);
      faceLine(s, f.roof, 0, 0, f.roof.uw, 0, rust.x7);
      faceRect(s, f.roof, f.roof.uw - 14, 4, 8, 6, metal.m4);
      faceLine(s, f.roof, f.roof.uw - 13, 6, f.roof.uw - 8, 6, metal.m6);
      const ax = Math.round(f.roof.origin[0] + f.roof.u[0] * 8 + f.roof.v[0] * 6);
      const ay = Math.round(f.roof.origin[1] + f.roof.u[1] * 8 + f.roof.v[1] * 6);
      s.vline(ax, ay - 20, 20, metal.m4);
      s.vline(ax + 1, ay - 20, 20, metal.m2);
      s.hline(ax - 4, ay - 14, 9, metal.m3);
      s.hline(ax - 3, ay - 8, 7, metal.m3);
      s.set(ax, ay - 21, mix(rust.x5, amber.a3, 0.2));
    },
    { west: false },
  );
  push(moduleShell, B.module.x + B.module.w / 2, B.module.y, pr.depth(B.module.x + B.module.w / 2, B.module.y), 'ext', 'module');
  // porch canopy + stairs (ext)
  const porch = bakeBoxN2(
    pr,
    { x: B.porch.x, y: B.porch.y - 2 - B.porch.d, w: B.porch.w, d: B.porch.d, h: 26 },
    { x: B.porch.x + B.porch.w / 2, y: B.porch.y },
    (s, f) => {
      fillFace(s, f.roof, mix(metal.m7, dust.d6, 0.35));
      faceLine(s, f.roof, 0, 0, f.roof.uw, 0, metal.m9);
      faceLine(s, f.front, 0, 0, f.front.uw, 0, metal.m7);
      faceLine(s, f.front, 0, 1, f.front.uw, 1, mix(hazard.h2, metal.m4, 0.5));
      faceLine(s, f.front, 0, 2, f.front.uw, 2, mix(metal.m1, warm.w0, 0.5));
      for (const lu of [10, f.front.uw - 12]) {
        facePx(s, f.front, lu, 3, warm.w6);
        facePx(s, f.front, lu, 4, warm.w4);
      }
      for (const pu of [2, f.roof.uw - 3]) {
        const px = Math.round(f.roof.origin[0] + f.roof.u[0] * pu + f.roof.v[0] * f.roof.vh);
        const py = Math.round(f.roof.origin[1] + f.roof.u[1] * pu + f.roof.v[1] * f.roof.vh);
        s.vline(px, py, 15, metal.m4);
        s.vline(px + 1, py, 15, metal.m2);
        s.set(px, py + 15, metal.m1);
      }
    },
    { front: true, east: false, west: false },
  );
  push(porch, B.porch.x + B.porch.w / 2, B.porch.y, pr.depth(B.porch.x + B.porch.w / 2, B.porch.y, 0, 0.5), 'ext', 'porch');
  const stairs = (() => {
    const s = new PixelSurface(64, 30);
    const base = pr.projectPoint(B.door.x + B.door.w / 2, B.door.y);
    for (const side of [-1, 1]) {
      const rx0 = B.door.x + B.door.w / 2 + side * (B.door.w / 2 + 6);
      const a = pr.projectPoint(rx0, B.door.y + 9);
      const b = pr.projectPoint(rx0, B.door.y + 1);
      s.line(Math.round(a[0] - base[0] + 32), Math.round(a[1] - base[1] + 24 - 10), Math.round(b[0] - base[0] + 32), Math.round(b[1] - base[1] + 24 - 12), metal.m5);
      s.vline(Math.round(a[0] - base[0] + 32), Math.round(a[1] - base[1] + 24 - 10), 10, metal.m4);
    }
    for (let i = 0; i < 3; i++) {
      const sw = B.door.w + 10 + i * 6;
      const q = pr.projectQuad(B.door.x + B.door.w / 2 - sw / 2, B.door.y + 2 + i * 3, sw, 3).map((p) => [Math.round(p[0] - base[0] + 32), Math.round(p[1] - base[1] + 24 - pr.projectHeight(2 - i))]);
      s.polygon(q, mix(metal.m4, dust.d4, 0.35 + i * 0.15));
      s.line(Math.round(q[0][0]), Math.round(q[0][1]), Math.round(q[1][0]), Math.round(q[1][1]), mix(metal.m6, dust.d6, 0.3 + i * 0.2));
    }
    return { sprite: s, ax: 32, ay: 26 };
  })();
  push(stairs, B.door.x + B.door.w / 2, B.door.y, pr.depth(B.door.x + B.door.w / 2, B.door.y + 6), 'ext', 'stairs');

  // ------------------------------------------------------------ interior furniture (Scene 1 set, hall footprint)
  const furn = (r: { x: number; y: number; w: number; d: number; h: number }, name: string, detail?: (s: PixelSurface, f: Faces) => void) => {
    const bk = bakeBoxN2(pr, r, { x: r.x + r.w / 2, y: r.y + r.d }, (s, f) => detail?.(s, f));
    push(bk, r.x + r.w / 2, r.y + r.d, pr.depth(r.x + r.w / 2, r.y + r.d), 'int', name);
  };
  // layout keeps >=10px aisles: central N-S route x320..352, mid E-W band y303..314
  furn({ x: 266, y: 296, w: 24, d: 7, h: 14 }, 'console1', (s, f) => {
    faceRamp(s, f.front, [slate.s6, slate.s5, slate.s4]);
    faceRect(s, f.front, 3, 3, 18, 7, cyan.c0);
    faceLine(s, f.front, 4, 5, 15, 5, cyan.c3);
    faceLine(s, f.front, 4, 7, 11, 7, cyan.c2);
    facePx(s, f.front, 18, 5, amber.a4);
    fillFace(s, f.roof, slate.s6);
    facePx(s, f.roof, 5, 3, metal.m8);
  });
  furn({ x: 352, y: 296, w: 24, d: 7, h: 14 }, 'console2', (s, f) => {
    faceRamp(s, f.front, [slate.s6, slate.s5, slate.s4]);
    faceRect(s, f.front, 3, 3, 18, 7, cyan.c0);
    faceLine(s, f.front, 4, 4, 13, 4, cyan.c2);
    faceLine(s, f.front, 4, 6, 9, 6, cyan.c2);
    fillFace(s, f.roof, slate.s6);
    facePx(s, f.roof, 6, 3, metal.m8);
  });
  furn({ x: 296, y: 314, w: 16, d: 9, h: 8 }, 'holotable', (s, f) => {
    faceRamp(s, f.front, [slate.s5, slate.s4, slate.s3]);
    fillFace(s, f.roof, cyan.c0);
    facePx(s, f.roof, 6, 4, cyan.c5);
    facePx(s, f.roof, 9, 5, cyan.c3);
  });
  furn({ x: 262, y: 314, w: 6, d: 14, h: 15 }, 'lockers', (s, f) => {
    faceRamp(s, f.east, [slate.s6, slate.s5, slate.s4]);
    for (let v = 2; v < f.east.uw - 2; v += 5) faceLine(s, f.east, v, 2, v, f.east.vh - 2, slate.s3);
    facePx(s, f.east, 3, 5, metal.m8);
    facePx(s, f.east, 3, 10, metal.m8);
    fillFace(s, f.roof, slate.s6);
  });
  furn({ x: 394, y: 300, w: 6, d: 16, h: 15 }, 'armory', (s, f) => {
    faceRamp(s, f.west, [slate.s6, slate.s5, slate.s4]);
    for (let v = 2; v < f.west.uw - 2; v += 4) {
      faceLine(s, f.west, v, 3, v, 9, metal.m2);
      facePx(s, f.west, v, 4, warm.w4);
    }
    fillFace(s, f.roof, slate.s6);
  });
  furn({ x: 386, y: 322, w: 10, d: 8, h: 10 }, 'crateE', (s, f) => {
    faceRamp(s, f.front, [mix(rust.x5, dust.d6, 0.3), rust.x4, rust.x2]);
    facePx(s, f.front, 2, 3, metal.m8);
    fillFace(s, f.roof, mix(rust.x5, dust.d6, 0.3));
  });
  furn({ x: 272, y: 325, w: 18, d: 7, h: 10 }, 'workbench', (s, f) => {
    faceRamp(s, f.front, [warm.w4, warm.w3, warm.w2]);
    fillFace(s, f.roof, warm.w5);
    facePx(s, f.roof, 4, 3, metal.m8);
    facePx(s, f.roof, 8, 4, cyan.c3); // drone part
    facePx(s, f.roof, 12, 3, warm.w6);
    facePx(s, f.roof, 15, 4, rust.x4);
  });
  furn({ x: 352, y: 322, w: 12, d: 8, h: 10 }, 'genblock', (s, f) => {
    faceRamp(s, f.front, [metal.m5, metal.m4, metal.m3]);
    faceRect(s, f.front, 2, 2, 8, 5, warm.w1);
    faceLine(s, f.front, 3, 3, 8, 3, amber.a3);
    facePx(s, f.front, 9, 6, cyan.c4);
    fillFace(s, f.roof, metal.m5);
  });
  // baked ceiling light pools on the floor (Scene 1 interior language)
  for (const [px0, py0] of [
    [300, 312],
    [360, 312],
  ]) {
    for (let wy = py0 - 6; wy <= py0 + 6; wy++) {
      const t = (wy - py0) / 6;
      if (Math.abs(t) >= 1) continue;
      const hw = 15 * Math.sqrt(1 - t * t);
      const a = gp(px0 - hw, wy);
      const b = gp(px0 + hw, wy);
      for (let x = a[0]; x <= b[0]; x++) {
        const edge = Math.min(x - a[0], b[0] - x) / 4;
        const k = 0.3 * Math.min(1, edge + 0.35) * (bayer4(x, a[1]) < 0.75 ? 1 : 0.55);
        const d0 = ground.get(x, a[1]);
        ground.set(x, a[1], mix(d0, warm.w6, k));
      }
    }
  }

  // ------------------------------------------------------------ props (Scene 1 billboards, N2 placement)
  const prop = (p: props.Prop, wx: number, wy: number, bias = 0, name = 'prop') => {
    const [sx, sy] = pr.projectPoint(wx, wy);
    renderables.push({ sprite: p.sprite, x: Math.round(sx + ox) - p.ax, y: Math.round(sy + oy) - p.ay, depth: pr.depth(wx, wy) + bias, mode: 'both', name });
  };
  prop(props.container(), L.container.x, L.container.y, 0, 'container');
  prop(props.crate('lg', 0), L.crates[0].x, L.crates[0].y, 0, 'crate');
  prop(props.crate('md', 1), L.crates[1].x, L.crates[1].y, 0, 'crate');
  prop(props.crate('sm', 2), L.crates[2].x, L.crates[2].y, 0, 'crate');
  prop(props.drum(0), L.drums[0].x, L.drums[0].y, 0, 'drum');
  prop(props.drum(1), L.drums[1].x, L.drums[1].y, 0, 'drum');
  prop(props.drum(2), L.drums[2].x, L.drums[2].y, 0, 'drum');
  prop(props.generator(), L.generator.x, L.generator.y, 0, 'generator');
  prop(props.mast(), L.mast.x, L.mast.y, 0.1, 'mast');
  prop(props.floodPole(), L.floodPole.x, L.floodPole.y, 0.1, 'flood');
  prop(props.cart(), L.cart.x, L.cart.y, 0, 'cart');
  prop(props.scrapPile(), L.scrapPile.x, L.scrapPile.y, 0, 'scrap');
  prop(props.barrier(), L.barrier.x, L.barrier.y, 0, 'barrier');
  prop(props.ventUnit(), 492, 344, 0, 'tankVent');
  prop(props.ventUnit(), 286, 352, 0, 'vent');
  prop(props.cableSpool(), 470, 372, 0, 'spool');
  prop(props.groundLamp(), 300, 386, 0.1, 'lamp');
  prop(props.groundLamp(), 396, 386, 0.1, 'lamp');
  prop(props.targetDummy(), L.dummy.x, L.dummy.y, 0, 'dummy');

  // ------------------------------------------------------------ lights (Scene 1 language)
  lights.push({ x: B.door.x + B.door.w / 2, y: B.door.y + 2, r: 24, c: [1, 0.66, 0.34], i: 0.8, mode: 'ext' });
  lights.push({ x: B.hall.x + 16, y: B.hall.y + B.hall.d + 2, r: 11, c: [0.2, 0.8, 0.9], i: 0.35, mode: 'ext' });
  lights.push({ x: B.hall.x + 118, y: B.hall.y + B.hall.d + 2, r: 11, c: [0.2, 0.8, 0.9], i: 0.35, mode: 'ext' });
  lights.push({ x: B.module.x + 17, y: B.module.y - 40, r: 9, c: [1, 0.22, 0.18], i: 0.5, blink: 2.2, mode: 'ext' });
  lights.push({ x: L.generator.x, y: L.generator.y - 8, r: 14, c: [1, 0.5, 0.2], i: 0.45, flicker: 0.25, mode: 'both' });
  lights.push({ x: 300, y: 366, r: 24, c: [1, 0.72, 0.4], i: 0.55, mode: 'both' });
  lights.push({ x: 396, y: 366, r: 24, c: [1, 0.72, 0.4], i: 0.55, mode: 'both' });
  lights.push({ x: L.floodPole.x, y: L.floodPole.y - 30, r: 40, c: [1, 0.74, 0.42], i: 0.6, mode: 'both' });
  lights.push({ x: IR.x + IR.w / 2, y: IR.y + IR.h / 2, r: 46, c: [1, 0.84, 0.6], i: 1.5, mode: 'int' });
  lights.push({ x: 278, y: 300, r: 12, c: [0.25, 0.85, 0.9], i: 0.5, mode: 'int' });
  lights.push({ x: 364, y: 300, r: 12, c: [0.25, 0.85, 0.9], i: 0.5, mode: 'int' });
  lights.push({ x: 304, y: 318, r: 14, c: [0.2, 0.9, 1], i: 0.55, mode: 'int' });
  lights.push({ x: 281, y: 328, r: 12, c: [1, 0.7, 0.4], i: 0.45, flicker: 0.1, mode: 'int' });

  // ------------------------------------------------------------ colliders
  const collidersExt = COLLIDERS.map((c) => ({ ...c }));
  const IRc = IR;
  const collidersInt = [
    { x: IRc.x - 4, y: IRc.y - 4, w: IRc.w + 8, h: 4 },
    { x: IRc.x - 4, y: IRc.y, w: 4, h: IRc.h },
    { x: IRc.x + IRc.w, y: IRc.y, w: 4, h: IRc.h },
    { x: IRc.x, y: IRc.y + IRc.h, w: IRc.w, h: 4 },
    { x: 266, y: 296, w: 24, h: 7 },
    { x: 352, y: 296, w: 24, h: 7 },
    { x: 296, y: 314, w: 16, h: 9 },
    { x: 262, y: 314, w: 6, h: 14 },
    { x: 394, y: 300, w: 6, h: 16 },
    { x: 386, y: 322, w: 10, h: 8 },
    { x: 272, y: 325, w: 18, h: 7 },
    { x: 352, y: 322, w: 12, h: 8 },
  ];

  return {
    width: W,
    height: H,
    ox,
    oy,
    ground,
    shadow,
    shadowCut,
    renderables,
    lights,
    collidersExt,
    collidersInt,
    entrance: { ext: { x: L.doorZone.x + L.doorZone.w / 2, y: L.doorZone.y + L.doorZone.h - 4 }, int: { x: B.door.x + B.door.w / 2, y: IR.y + IR.h - 6 } },
    interiorRect: IR,
    worldW: WORLD_W,
    worldH: WORLD_H,
  };
}

