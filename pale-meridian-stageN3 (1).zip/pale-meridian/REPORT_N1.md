# PALE MERIDIAN — STAGE N1 REPORT
## N1 · Frontier Technical Building — новая 2D-проекция + составной персонаж

Отчёт по этапу N1 отдельным файлом (история Stage 1–4 — в `REPORT.md`).

---

## 1. Что сделано

Создана **полностью новая сцена N1** (не переработка Scene 2/3): одно прямоугольное
техническое здание на пыльной планете, новая camera-like 2D-проекция, настоящий
составной персонаж из отдельных pixel-art частей, дрон, одна техническая комната
с cutaway, освещение уровня Stage 1.

Из рабочего flow удалены: старая Scene 2, старая Scene 3, Character Showcase
(физически остаются в git-истории и архивах, не удалены). Переключение:
`1` = Scene 1 (эталон), `2` = N1, `TAB` — цикл.

## 2. Новая 2D-проекция

Модуль `src/n1/projection.ts` — чистая математика без знаний о сцене:
`projectPoint(x, y, z)`, `projectBox(...) → front/east/west/roof`, `projectWall`,
`projectRoof`, `projectHeight`, `projectQuad`, `shadowOffset`, `depth`.

Параметры (`N1_PARAMS`):
- `shear 0.34` — yaw-feel: глубина смещается по X, видны **две грани** (фронт + боковая);
- `squash 0.62` — roof/ground foreshortening (крыша хорошо читается);
- `heightScale 0.78` — стены существенной высоты, вертикали пиксельно-вертикальные;
- `shadowDir (0.66, 0.4)` — согласованные тени.

Визуальный ориентир — preset N1 из Camera Lab (ortho, yaw ≈128.4°, pitch ≈37.2°)
как подсказка, не как формула. Результат: высокая камера смотрит сверху под
заметным наклоном; крыша читаема; стены вертикальны и высоки; объект не плоский;
глубина есть; это НЕ старая Scene 3 (иная система: две грани + вертикальные
стены + согласованные рёбра, а не tilted-ленты).

Самопроверка проекции:
- Высота стен ощущается: да (фасад ~44 px при крыше ~52 px глубины).
- Крыша читается: да (плита с machinery, фасция, rim).
- Глубина: да (две грани + тени + cutaway).
- Плоским объект не выглядит: подтверждено кадрами `out/n1-ext.png`,
  `out/n1-browser-ext.png`.
- Ощущения старой Scene 3 нет: геометрия стен/граней иная (см. сравнение кадров).

## 3. Здание

Один прямоугольный корпус 132×84, h=54, стены толщиной 4 (реальные 4 стены +
крыша-плита, а не «ромб + прямоугольники»):
- фронт: дверь/шлюз с canopy на стойках и ступенями, 2 окна с тёмно-teal
  стеклом, панели/швы/заклёпки, hazard-полоса, dirt у основания, signage «N1»,
  настенные лампы;
- боковая грань: louvres, тех-коробка с cyan-индикатором, трубы, кабель;
- крыша: AC-блок, 2 вента, hatch, pipe run, solar-полоса, antenna + beacon,
  maintenance crate, dust-патчи, gutter rim + тонкая фасция;
- никаких утечек интерьера наружу: стены и крыша непрозрачны, интерьер виден
  только в cutaway.

## 4. Интерьер / cutaway

Одна техническая комната (терминал, консоль, верстак, стол, локеры, ген-блок,
ящик; кабели, grating, панели, оранжевая полоса на внутренних стенах).
Cutaway: крыша + южная стена скрываются; внутренние грани N/W/E остаются
(интерьерные детали: slate-рампа, полоса, панели); интерьер находится физически
там же (те же мировые координаты, тот же пол, тот же свет); вход через `E`
без teleport-ощущения (fade + та же дверь). Внешний мир согласован: terrain,
пропсы, свет, тени не меняются. Кадр: `out/n1-int.png`,
`out/n1-browser-int-walk.png`.

## 5. Персонаж (composite)

`src/n1/character/parts.ts` — **каждая часть — отдельный asset** (эквивалент
head.png/torso.png/arm_l.png/…): head_side/front, torso_side/front, 4×arm side
(down/swingA/swingB/aim × near/far), 2×arm front (hold/aim), 4×leg side,
2×leg front, pack side/front, weapon side/front. Все части пекутся в отдельные
PixelSurface (`bakePart`), соединяются только через якоря: neck, shoulder,
shoulderFar, hipNear/Far, hipL/R, hand, packMount, weapon grip/hand2/muzzle
(`src/n1/character/CompositeCharacter.ts`, `assembleCharacter`).

Самопроверка:
- Части — отдельные sprites: да (exploded-лист `out/n1-char-parts.png`).
- Настоящие anchor points: да (поза меняет только размещение частей).
- Поза без перерисовки тела: да (idle/walk×4/aim собираются из тех же частей).
- Человек, не chibi: голова ~1/3.7 роста, читаемые конечности, экипировка
  меняет силуэт (helmet/plate/pack/weapon).
- Оружие: отдельный sprite, крепится к grip/hand2 якорям, поворачивается с
  рукой (aim поднимает), cyan/amber акценты.
- Позы: idle (дыхание), walking (4 фазы, независимые ноги/руки), aiming.
  Архитектура позволяет добавлять позы без перерисовки.

Кадр: `out/n1-char.png`, позы `out/n1-char-poses.png`.

## 6. Дрон

Отдельный pixel-art объект: chassis с sensor-lens, manipulator arm (2 фазы),
thruster-glow, контактная тень; патруль по 4 точкам; реагирует на присутствие
игрока (align). Виден на всех кадрах.

## 7. Окружение и композиция

Пыльная поверхность с дюнным светом, ветровыми штрихами, трещинами, галькой;
compacted pad у двери; колеи техники; тропы; кабель по земле; pipe rack;
pallet; контейнер FRG; генератор с louvres и amber-свечением; ящики; бочки;
2 ламповых поста с пулами света; rocks (mid + foreground framing); scrub;
cable coil; distant mesas с haze на горизонте. Композиция: здание = фокус,
персонаж + дрон = второй план, лампы ведут взгляд к входу.

## 8. Свет

LightingSystem Stage 1: ambient по времени суток (`F3` dusk/night/day),
directional sun (запечённые тени здания/пропсов, cutaway-вариант тени),
локальные источники (дверь, окна cyan, лампы amber, генератор flicker, beacon
blink), внутренний свет (2 пула + cyan терминалов + amber ген-блока),
emissive-ядра, атмосферная виньетка. Свет читает геометрию: крыша/стены/углы/
вход/интерьер различимы (`out/n1-int.png`).

## 9. Техническая архитектура

- `src/n1/projection.ts` — projection math (без знаний о сцене);
- `src/n1/world.ts` — bakes: terrain, shadows(+cut), стены/крыша/интерьер/пропсы,
  lights, colliders, entrance;
- `src/n1/character/*` — composite character system (parts + anchors + poses);
- `src/n1/N1Scene.ts` — scene definition + play logic (move/enter/exit/camera/
  lights/render);
- `src/components/N1View.tsx` — host + integer upscale + minimal HUD;
- рендер-инфраструктура Stage 1 переиспользована (PixelSurface, LightingSystem,
  dither, noise, text) — pixel pipeline неизменен.

## 10. Проверки

- `tsc --noEmit`: чисто. `vite build`: ok.
- `tools/smoke.ts`: Scene 1 + регрессии — зелёные (Stage 1 не сломан).
- Headless-browser (SwiftShader): N1 рендерится, `E` входит в интерьер,
  ходьба внутри работает, console/page errors: none
  (`out/n1-browser-ext.png`, `out/n1-browser-int-walk.png`).
- Node-кадры: `out/n1-ext.png`, `out/n1-int.png`, `out/n1-char.png`,
  `out/n1-char-poses.png`, `out/n1-char-parts.png`.

## 11. Ограничения (честно)

- Диагонали движения используют ближайшие ориентации (side/front) — диагональные
  наборы частей не авторены (архитектура позволяет добавить).
- Интерьер намеренно простой (одна комната) по брифу; плотность ниже Scene 1,
  но материалы/свет/детали согласованы.
- Cutaway скрывает крышу+южную стену целиком (без частичных clip-зон).
- Дрон — компактный пиксель-объект, не full-3D/-rig.
- Фасад на dusk слегка приглушён (атмосфера); day-режим даёт читамую альтернативу.

## 12. Статус

Этап N1 завершён. Остановился до визуального решения по новой проекции.
N2 и новые projection variants НЕ начаты. Scene 1 не изменена.
