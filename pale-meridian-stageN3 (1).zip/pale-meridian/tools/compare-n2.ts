/** Comparison sheet: Scene 1 (etalon) vs N2 (same world, new projection). */
import { Game } from '../src/game/Game';
import { N2Scene } from '../src/n2/N2Scene';
import { writePng } from './png';
import { Input } from '../src/input/Input';

// ---- Scene 1 exterior, framed on the building
const g = new Game();
g.player.x = 352;
g.player.y = 430;
g.camera.snapTo(g.player.x, g.player.y - 10);
for (let i = 0; i < 30; i++) g.update(1 / 60);
writePng('out/cmp-s1-ext.png', g.render(), 2);

// ---- Scene 1 interior
(g as never as { zone: string }).zone = 'int';
g.player.x = 240;
g.player.y = 150;
g.camera.snapTo(g.player.x, g.player.y - 10);
for (let i = 0; i < 20; i++) g.update(1 / 60);
writePng('out/cmp-s1-int.png', g.render(), 2);

// ---- N2 exterior
const n = new N2Scene();
const inp = new Input();
n.merc.x = 352;
n.merc.y = 430;
(n as never as { snapCam: () => void }).snapCam();
for (let i = 0; i < 30; i++) n.update(1 / 60, inp);
writePng('out/cmp-n2-ext.png', n.render(), 2);

// ---- N2 interior
const any = n as never as { zone: 'ext' | 'int'; snapCam: () => void };
any.zone = 'int';
n.merc.x = n.world.entrance.int.x;
n.merc.y = n.world.entrance.int.y + 4;
any.snapCam();
for (let i = 0; i < 20; i++) n.update(1 / 60, inp);
writePng('out/cmp-n2-int.png', n.render(), 2);
console.log('compare shots written');
