import { chromium } from 'playwright';
const b = await chromium.launch({ args: ['--enable-unsafe-swiftshader'] });
const p = await b.newPage({ viewport: { width: 960, height: 540 } });
const errs = [];
p.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
p.on('pageerror', (e) => errs.push(String(e)));
await p.goto('http://localhost:4173/');
await p.waitForTimeout(1200);
await p.keyboard.press('Digit2');
await p.waitForTimeout(800);
await p.screenshot({ path: 'out/n2-browser-ext.png' });
// walk to the door and enter
await p.keyboard.down('KeyW');
await p.waitForTimeout(1100);
await p.keyboard.up('KeyW');
await p.waitForTimeout(200);
await p.keyboard.press('KeyE');
await p.waitForTimeout(1300);
await p.screenshot({ path: 'out/n2-browser-int.png' });
// wander inside
await p.keyboard.down('KeyA');
await p.waitForTimeout(600);
await p.keyboard.up('KeyA');
await p.keyboard.down('KeyW');
await p.waitForTimeout(400);
await p.keyboard.up('KeyW');
await p.screenshot({ path: 'out/n2-browser-int2.png' });
// exit
await p.keyboard.down('KeyS');
await p.waitForTimeout(500);
await p.keyboard.up('KeyS');
await p.keyboard.down('KeyD');
await p.waitForTimeout(300);
await p.keyboard.up('KeyD');
await p.keyboard.press('KeyE');
await p.waitForTimeout(1300);
await p.screenshot({ path: 'out/n2-browser-ext2.png' });
// back to scene 1 regression
await p.keyboard.press('Digit1');
await p.waitForTimeout(700);
await p.screenshot({ path: 'out/n2-browser-s1.png' });
console.log('console errors:', errs.length ? errs : 'none');
await b.close();
