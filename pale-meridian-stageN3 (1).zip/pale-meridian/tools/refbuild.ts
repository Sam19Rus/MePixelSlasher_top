import { PixelSurface } from '../src/rendering/PixelSurface';
import { Proj, SCENE_PROFILES } from '../src/lab/profiles';
import { paintBox, windowOnFace, LocalProj, CREAM } from '../src/lab/kit';
import { faceRect, faceLine } from '../src/lab/facePaint';
import { writePng } from './png';
import { mix, packRGBA } from '../src/rendering/color';
import { metal, hazard, amber } from '../src/data/palette';

for (const key of ['scene3', 'scene2'] as const) {
  const pr = new Proj(SCENE_PROFILES[key]);
  const W = 220, H = 180;
  const s = new PixelSurface(W, H);
  // ground
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) s.setRaw(x, y, packRGBA(150, 116, 82));
  const mass = { x: 60, y: 50, w: 80, d: 50, h: 26 };
  const lp = new LocalProj(pr, 20, 30);
  paintBox(s, lp, mass.x, mass.y, mass.w, mass.d, mass.h, CREAM, (f) => {
    // door on near facade
    faceRect(s, f.front, 34, 4, 12, f.front.vh - 4, metal.m3);
    faceLine(s, f.front, 40, 4, 40, f.front.vh - 1, amber.a5);
    // windows
    windowOnFace(s, f.front, 10, 6, 14, 7, true);
    windowOnFace(s, f.front, 56, 6, 14, 7, true);
    faceLine(s, f.front, 0, f.front.vh - 3, f.front.uw, f.front.vh - 3, mix(hazard.h2, metal.m3, 0.5));
    // roof machinery
    faceRect(s, f.top, 10, 10, 14, 10, metal.m4);
    faceRect(s, f.top, 11, 11, 12, 8, metal.m2);
    faceRect(s, f.top, 50, 20, 12, 9, metal.m5);
    faceLine(s, f.top, 30, 6, 30, f.top.vh - 6, metal.m5);
    void s;
  });
  // sun shadow
  const L = pr.p.shadow;
  const base = pr.quad(mass.x, mass.y, mass.w, mass.d).map((p) => [p[0] + 20, p[1] + 30]);
  const far = base.map((p) => [p[0] + L.x * mass.h, p[1] + L.y * mass.h]);
  s.polygon([base[0], base[1], far[1], far[0]], packRGBA(60, 36, 30, 110));
  s.polygon([base[1], base[2], far[2], far[1]], packRGBA(60, 36, 30, 110));
  writePng(`out/68-ref-${key}.png`, s, 3);
  console.log('ref', key);
}
