/**
 * Minimal PNG writer (no dependencies) so the offline preview tools can dump
 * frames of the real software renderer to disk for visual review.
 */
import { deflateSync } from 'node:zlib';
import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import type { PixelSurface } from '../src/rendering/PixelSurface';

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type: string, data: Buffer): Buffer {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

/** Nearest-neighbour upscale (integer only) for readable review images. */
export function upscale(src: PixelSurface, k: number): PixelSurface {
  if (k <= 1) return src;
  const out = new (src.constructor as typeof PixelSurface)(src.width * k, src.height * k);
  for (let y = 0; y < src.height; y++) {
    for (let x = 0; x < src.width; x++) {
      const c = src.data[y * src.width + x];
      for (let j = 0; j < k; j++) {
        const row = (y * k + j) * out.width;
        for (let i = 0; i < k; i++) out.data[row + x * k + i] = c;
      }
    }
  }
  return out;
}

export function surfaceToPngBuffer(src: PixelSurface, background = 0xff101014): Buffer {
  const w = src.width;
  const h = src.height;
  const raw = Buffer.alloc((w * 4 + 1) * h);
  let o = 0;
  for (let y = 0; y < h; y++) {
    raw[o++] = 0; // filter: none
    for (let x = 0; x < w; x++) {
      const c = src.data[y * w + x];
      const a = (c >>> 24) & 0xff;
      let r = c & 0xff;
      let g = (c >>> 8) & 0xff;
      let b = (c >>> 16) & 0xff;
      if (a < 255) {
        const br = background & 0xff;
        const bg = (background >>> 8) & 0xff;
        const bb = (background >>> 16) & 0xff;
        const ia = 255 - a;
        r = ((r * a + br * ia) / 255) | 0;
        g = ((g * a + bg * ia) / 255) | 0;
        b = ((b * a + bb * ia) / 255) | 0;
      }
      raw[o++] = r;
      raw[o++] = g;
      raw[o++] = b;
      raw[o++] = 255;
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // colour type RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

export function writePng(path: string, src: PixelSurface, scale = 1): void {
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, surfaceToPngBuffer(upscale(src, scale)));
}
