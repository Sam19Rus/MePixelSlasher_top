import { chromium } from 'playwright';
import { writeFileSync, mkdirSync } from 'node:fs';

const url = process.env.URL ?? 'http://localhost:4173/';
mkdirSync('out', { recursive: true });

const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('console', (m) => {
  if (m.type() === 'error') errors.push(m.text());
});
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
await page.goto(url, { waitUntil: 'networkidle' });
await page.waitForTimeout(1200);
await page.keyboard.press('Digit4');
await page.waitForTimeout(800);
await page.waitForFunction(() => !!window.__labShots, null, { timeout: 30000 });
await page.waitForTimeout(1500);
const shots = await page.evaluate(() => window.__labShots());
for (const [k, v] of Object.entries(shots)) {
  const name = k === 'SHEET' ? '91-camera-sheet' : `90-${k}`;
  writeFileSync(`out/${name}.png`, Buffer.from(v.split(',')[1], 'base64'));
  console.log('saved', name);
}
// cutaway inspection shot (same scene, roof + south wall hidden)
const cut = await page.evaluate(() => {
  const lab = window.__camLab;
  lab.outpost.setCutaway(true);
  lab.rig.applyPreset('STRONG 3/4');
  lab.frame(0, { dither: true, posterize: 8, outline: true, vignette: true });
  const d = lab.renderer.domElement.toDataURL('image/png');
  lab.outpost.setCutaway(false);
  return d;
});
writeFileSync('out/94-cutaway.png', Buffer.from(cut.split(',')[1], 'base64'));
console.log('saved 94-cutaway');
// also a live HUD screenshot for the report
await page.screenshot({ path: 'out/92-lab-hud.png' });
console.log('console errors:', errors.length ? errors.slice(0, 5) : 'none');
await browser.close();
