/**
 * Single review sheet: Scene 1 (etalon) vs N2 (same world, new projection).
 * 2x2 grid at logical resolution: ext/int per scene, nearest-neighbour x2 out.
 * Top row: exterior. Bottom row: interior (N2 = cutaway of the same building).
 */
import { Game } from '../src/game/Game';
import { N2Scene } from '../src/n2/N2Scene';
import { Input } from '../src/input/Input';
import { PixelSurface } from '../src/rendering/PixelSurface';
import { drawText, textWidth } from '../src/rendering/text';
import { packRGBA } from '../src/rendering/color';
import { writePng } from './png';

const CW = 480;
const CH = 270;
const GUT = 2;
const sheet = new PixelSurface(CW * 2 + GUT, CH * 2 + GUT, packRGBA(8, 8, 12));

function place(src: PixelSurface, ox: number, oy: number, label: string): void {
  for (let y = 0; y < CH; y++) {
    const row = (oy + y) * sheet.width + ox;
    sheet.data.set(src.data.subarray(y * CW, y * CW + CW), row);
  }
  const pw = textWidth(label) + 4;
  sheet.rect(ox + 3, oy + 3, pw, 9, packRGBA(6, 6, 10));
  drawText(sheet, ox + 5, oy + 5, label, packRGBA(232, 222, 196));
}

// ---- Scene 1 (etalon)
const g = new Game();
g.player.x = 352;
g.player.y = 430;
g.camera.snapTo(g.player.x, g.player.y - 10);
for (let i = 0; i < 30; i++) g.update(1 / 60);
// render() hands back the renderer's internal buffer — clone immediately,
// otherwise the next render mutates the frame we already captured.
const s1ext = g.render().clone();

(g as never as { zone: string }).zone = 'int';
g.player.x = 240;
g.player.y = 150;
g.camera.snapTo(g.player.x, g.player.y - 10);
for (let i = 0; i < 20; i++) g.update(1 / 60);
const s1int = g.render().clone();

// ---- N2 (same world, tilted orthographic)
const n = new N2Scene();
const inp = new Input();
n.merc.x = 352;
n.merc.y = 430;
(n as never as { snapCam: () => void }).snapCam();
for (let i = 0; i < 30; i++) n.update(1 / 60, inp);
const n2ext = n.render().clone();

const anyN = n as never as { zone: 'ext' | 'int'; snapCam: () => void };
anyN.zone = 'int';
n.merc.x = n.world.entrance.int.x;
n.merc.y = n.world.entrance.int.y + 4;
anyN.snapCam();
for (let i = 0; i < 20; i++) n.update(1 / 60, inp);
const n2int = n.render().clone();

place(s1ext, 0, 0, 'SCENE 1 EXT  ETALON');
place(n2ext, CW + GUT, 0, 'N2 EXT  TILTED ORTHO');
place(s1int, 0, CH + GUT, 'SCENE 1 INT');
place(n2int, CW + GUT, CH + GUT, 'N2 INT  CUTAWAY SAME BUILDING');

writePng('out/cmp-sheet-s1-n2.png', sheet, 2);
console.log('compare sheet written: out/cmp-sheet-s1-n2.png');
