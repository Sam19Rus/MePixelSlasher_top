/**
 * Performance bench: ms per simulated frame (update + full software render)
 * for each quality preset, in both zones. Use it to pick the balance with
 * real numbers instead of guesses:
 *
 *   npm run bench
 */
import { Game } from '../src/game/Game';
import { cloneQuality, QUALITY_PRESETS } from '../src/data/quality';
import { ROOM_H, ROOM_W, WORLD_H, WORLD_W } from '../src/data/config';

const game = new Game();

function measure(zone: 'ext' | 'int', frames: number): number {
  game.zone = zone;
  if (zone === 'ext') {
    game.player.x = 352;
    game.player.y = 428;
    game.camera.setWorld(WORLD_W, WORLD_H);
  } else {
    game.player.x = ROOM_W / 2;
    game.player.y = ROOM_H / 2 + 30;
    game.camera.setWorld(ROOM_W, ROOM_H);
  }
  game.camera.snapTo(game.player.x, game.player.y - 70);
  for (let i = 0; i < 10; i++) {
    game.update(1 / 60);
    game.render();
  }
  const t0 = performance.now();
  for (let i = 0; i < frames; i++) {
    game.update(1 / 60);
    game.render();
  }
  return (performance.now() - t0) / frames;
}

const FRAMES = 120;
console.log(`frame budget at 60fps = 16.67 ms (update + software render, 480x270)\n`);
for (const preset of ['cinematic', 'balanced', 'performance'] as const) {
  game.quality = cloneQuality(QUALITY_PRESETS[preset]);
  const ext = measure('ext', FRAMES);
  const int = measure('int', FRAMES);
  const tag = ext < 8 ? 'comfortable' : ext < 16.67 ? 'ok' : 'over budget';
  console.log(
    `${preset.padEnd(12)} ext ${ext.toFixed(2)} ms/frame (${(1000 / ext).toFixed(0)} fps)   int ${int.toFixed(2)} ms/frame (${(1000 / int).toFixed(0)} fps)   [${tag}]`,
  );
}
console.log(`\ntoggles: 1 lamp shadows · 2 sun shadows · 3 entity shadows · 4 ambient fx · 5 atmosphere · 6 light budget · F5 preset`);

// ---- scenes 2/3 bench
{
  const { getOutpost } = await import('../src/scenes/registry');
  const { Input } = await import('../src/input/Input');
  for (const key of ['scene2', 'scene3'] as const) {
    const sc = getOutpost(key);
    const inp = new Input();
    for (let i = 0; i < 5; i++) { sc.update(1 / 60, inp); sc.render(); }
    const t0 = performance.now();
    const N = 90;
    for (let i = 0; i < N; i++) { sc.update(1 / 60, inp); sc.render(); }
    const ms = (performance.now() - t0) / N;
    console.log(`${key}: ${ms.toFixed(2)} ms/frame (${(1000 / ms).toFixed(0)} fps)`);
  }
}

// ---- projection lab bench
{
  const { getSharedLab } = await import('../src/lab/labShared');
  const lab = getSharedLab();
  lab.time = 3;
  for (let i = 0; i < 5; i++) {
    lab.update(1 / 60);
    lab.render();
  }
  const t0 = performance.now();
  const N = 60;
  for (let i = 0; i < N; i++) {
    lab.update(1 / 60);
    lab.render();
  }
  const ms = (performance.now() - t0) / N;
  console.log(`\nPROJECTION LAB (6 panels, 960x540): ${ms.toFixed(2)} ms/frame (${(1000 / ms).toFixed(0)} fps)`);
}
