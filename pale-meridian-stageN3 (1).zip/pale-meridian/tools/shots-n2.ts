import { N2Scene } from '../src/n2/N2Scene';
import { writePng } from './png';
import { Input } from '../src/input/Input';

const sc = new N2Scene();
const inp = new Input();
for (let i = 0; i < 40; i++) sc.update(1 / 60, inp);
writePng('out/n2-ext.png', sc.render(), 2);

// interior cutaway
const any = sc as never as { merc: { x: number; y: number }; zone: 'ext' | 'int'; snapCam: () => void };
any.zone = 'int';
any.merc.x = sc.world.entrance.int.x;
any.merc.y = sc.world.entrance.int.y + 2;
any.snapCam();
for (let i = 0; i < 20; i++) sc.update(1 / 60, inp);
writePng('out/n2-int.png', sc.render(), 2);

// day mode exterior
any.zone = 'ext';
sc.review.timeOfDay = 'day';
any.merc.x = 352;
any.merc.y = 428;
any.snapCam();
for (let i = 0; i < 20; i++) sc.update(1 / 60, inp);
writePng('out/n2-ext-day.png', sc.render(), 2);
console.log('n2 shots written');
