/** Headless functional smoke test: walk to the door, enter, look around, leave. */
import { Game } from '../src/game/Game';
import { Input } from '../src/input/Input';

const g = new Game();
const step = (n: number) => {
  for (let i = 0; i < n; i++) g.update(1 / 60);
};
const hold = (code: string, n: number) => {
  g.input.press(code);
  step(n);
  g.input.release(code);
  step(4);
};

console.log('spawn', g.player.x.toFixed(1), g.player.y.toFixed(1), 'zone', g.zone);
hold('KeyW', 60);
hold('KeyW', 60);
console.log('after walk north', g.player.x.toFixed(1), g.player.y.toFixed(1), 'nearDoor', g.nearDoor);
g.input.press('KeyE');
step(2);
g.input.release('KeyE');
step(40); // fade through
console.log('zone after E:', g.zone, 'player', g.player.x.toFixed(1), g.player.y.toFixed(1));
if (g.zone !== 'int') throw new Error('failed to enter interior');
hold('KeyW', 40);
hold('KeyD', 40);
hold('KeyS', 60);
console.log('inside pos', g.player.x.toFixed(1), g.player.y.toFixed(1), 'nearDoor', g.nearDoor);
// walk back to the airlock
hold('KeyA', 30);
hold('KeyS', 60);
console.log('near airlock', g.nearDoor, g.player.x.toFixed(1), g.player.y.toFixed(1));
g.input.press('KeyE');
step(2);
g.input.release('KeyE');
step(40);
console.log('zone after exit:', g.zone, 'player', g.player.x.toFixed(1), g.player.y.toFixed(1));
if ((g.zone as string) !== 'ext') throw new Error('failed to exit interior');
// wander a while to shake out runtime errors
const codes = ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ShiftLeft'];
for (let i = 0; i < 40; i++) {
  const c = codes[i % codes.length];
  g.input.press(c);
  step(20);
  g.input.release(c);
  g.render();
}
console.log('render frames ok; fps field', g.fps, 'time', g.time.toFixed(1));
// ---- projection lab regression
{
  const { getSharedLab } = await import('../src/lab/labShared');
  const lab = getSharedLab();
  for (let i = 0; i < 120; i++) lab.update(1 / 60);
  lab.render();
  lab.panels.forEach((p) => (p.interior = true));
  lab.render();
  lab.hover = 2;
  lab.render();
  lab.showParams = true;
  lab.lighting = false;
  lab.render();
  lab.hover = -1;
  lab.lighting = true;
  lab.showParams = false;
  lab.panels.forEach((p) => (p.interior = false));
  console.log('lab regression OK');
}
// ---- scenes 2 & 3 full user flow: approach, enter, move inside, exit
{
  const { getOutpost } = await import('../src/scenes/registry');
  for (const key of ['scene2', 'scene3'] as const) {
    const sc = getOutpost(key);
    const inp = new Input();
    sc.setZoneForced('ext');
    sc['px'] = sc['bake'].entrance.ext.x - 4;
    sc['py'] = sc['bake'].entrance.ext.y + 26;
    for (let i = 0; i < 30; i++) sc.update(1 / 60, inp);
    // walk north to the door
    inp.press('KeyW');
    for (let i = 0; i < 90 && sc.zone === 'ext'; i++) {
      sc.update(1 / 60, inp);
      if (sc.nearEntrance && sc.zone === 'ext') {
        inp.release('KeyW');
        inp.press('KeyE');
        sc.update(1 / 60, inp);
        inp.release('KeyE');
        break;
      }
    }
    for (let i = 0; i < 40; i++) sc.update(1 / 60, inp); // fade through
    if ((sc.zone as string) !== 'int') throw new Error(`${key}: failed to enter`);
    // move inside
    inp.press('KeyD');
    for (let i = 0; i < 40; i++) sc.update(1 / 60, inp);
    inp.release('KeyD');
    inp.press('KeyW');
    for (let i = 0; i < 30; i++) sc.update(1 / 60, inp);
    inp.release('KeyW');
    sc.render();
    // back to the door and exit
    inp.press('KeyS');
    for (let i = 0; i < 90 && sc.zone === 'int'; i++) {
      sc.update(1 / 60, inp);
      if (sc.nearEntrance && sc.zone === 'int') {
        inp.release('KeyS');
        inp.press('KeyE');
        sc.update(1 / 60, inp);
        inp.release('KeyE');
        break;
      }
    }
    for (let i = 0; i < 40; i++) sc.update(1 / 60, inp);
    if ((sc.zone as string) !== 'ext') throw new Error(`${key}: failed to exit`);
    // aim + turn animation states
    inp.press('Space');
    for (let i = 0; i < 30; i++) sc.update(1 / 60, inp);
    inp.release('Space');
    inp.press('KeyA');
    for (let i = 0; i < 40; i++) sc.update(1 / 60, inp);
    inp.release('KeyA');
    sc.render();
    console.log(`${key}: enter/move/exit/aim/turn OK`);
  }
}
console.log('SMOKE OK');

// quality presets must all render without errors
import { cloneQuality, QUALITY_PRESETS } from '../src/data/quality';
for (const preset of ['cinematic', 'balanced', 'performance'] as const) {
  g.quality = cloneQuality(QUALITY_PRESETS[preset]);
  g.render();
}
g.input.press('F5');
g.update(1 / 60);
g.input.release('F5');
g.render();
console.log('quality presets OK');

// regression: a negative / zero first delta (browser rAF quirk) must not crash
g.update(-0.016);
g.render();
g.update(0);
g.render();
console.log('negative-dt regression OK');
