/**
 * N3 camera test (stage spec section 10):
 *   A) target camera  B) slightly lower  C) slightly higher
 *   D) exterior with roof  E) cutaway interior
 * plus day/night variants and a wall-detail zoom.
 */
import { N3Scene } from '../src/n3/N3Scene';
import { Input } from '../src/input/Input';
import { writePng } from './png';

const inp = new Input();
const settle = (sc: N3Scene, frames = 36) => {
  for (let i = 0; i < frames; i++) sc.update(1 / 60, inp);
};

// A / B / C camera candidates, exterior
for (const key of ['A', 'B', 'C'] as const) {
  const sc = new N3Scene(key);
  settle(sc, 40);
  writePng(`out/n3-cam${key}.png`, sc.render().clone(), 2);
  console.log(`cam ${key} (${sc.camLabel}) rendered`);
}

// D/E on the default camera
const sc = new N3Scene();
settle(sc, 40);
writePng('out/n3-ext.png', sc.render().clone(), 2);
sc.toggleZone();
settle(sc, 30);
writePng('out/n3-cut.png', sc.render().clone(), 2);

// night exterior + cutaway
sc.review.timeOfDay = 'night';
sc.toggleZone();
settle(sc, 30);
writePng('out/n3-ext-night.png', sc.render().clone(), 2);
sc.toggleZone();
settle(sc, 24);
writePng('out/n3-cut-night.png', sc.render().clone(), 2);
sc.review.timeOfDay = 'dusk';

// day exterior
sc.toggleZone();
sc.review.timeOfDay = 'day';
settle(sc, 24);
writePng('out/n3-ext-day.png', sc.render().clone(), 2);
sc.review.timeOfDay = 'dusk';

// wall detail zoom: tower/hall west junction, exterior dusk
settle(sc, 24);
{
  const frame = sc.render().clone();
  const zoom = frame.crop(44, 56, 208, 156);
  writePng('out/n3-wall-zoom.png', zoom, 4);
}
console.log('n3 shots written');
