import { PixelSurface } from '../src/rendering/PixelSurface';
import { assembleCharacter, drawAssembly, explodedSheet, type CharPose } from '../src/n1/character/CompositeCharacter';
import { writePng } from './png';

const sheet = new PixelSurface(8 * 34, 40);
sheet.fill(0xff23272d);
const poses: CharPose[] = [
  { state: 'idle', phase: 0, orient: 'side', breath: 0, look: 0 },
  { state: 'walk', phase: 0, orient: 'side', breath: 0, look: 0 },
  { state: 'walk', phase: 1, orient: 'side', breath: 0, look: 0 },
  { state: 'walk', phase: 2, orient: 'side', breath: 0, look: 0 },
  { state: 'aim', phase: 0, orient: 'side', breath: 0, look: 0 },
  { state: 'idle', phase: 0, orient: 'front', breath: 0, look: 0 },
  { state: 'walk', phase: 2, orient: 'front', breath: 0, look: 0 },
  { state: 'aim', phase: 0, orient: 'front', breath: 0, look: 0 },
];
// redo properly with offsets
const sheet2 = new PixelSurface(8 * 34, 44);
sheet2.fill(0xff23272d);
poses.forEach((p, i) => {
  const a = assembleCharacter(p, 16 + i * 34, 38, false);
  drawAssembly(sheet2, a);
});
writePng('out/n1-char-poses.png', sheet2, 6);
writePng('out/n1-char-parts.png', explodedSheet(), 6);
console.log('char sheets written');
