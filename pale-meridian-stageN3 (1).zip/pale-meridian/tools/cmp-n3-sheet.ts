/**
 * N3 final-camera review sheet (stage spec section 10):
 *   row 1: A) candidate 42°  B) TARGET/selected 36°  C) candidate 50°
 *   row 2: D) exterior w/ roof (selected cam)  E) cutaway interior  + wall-detail zoom
 * Logical resolution grid, nearest-neighbour x2 out.
 */
import { N3Scene } from '../src/n3/N3Scene';
import { Input } from '../src/input/Input';
import { PixelSurface } from '../src/rendering/PixelSurface';
import { drawText, textWidth } from '../src/rendering/text';
import { packRGBA } from '../src/rendering/color';
import { writePng } from './png';

const CW = 480;
const CH = 270;
const GUT = 2;
const sheet = new PixelSurface(CW * 3 + GUT * 2, CH * 2 + GUT, packRGBA(8, 8, 12));

function place(src: PixelSurface, ox: number, oy: number, label: string): void {
  for (let y = 0; y < CH; y++) {
    const row = (oy + y) * sheet.width + ox;
    sheet.data.set(src.data.subarray(y * CW, y * CW + CW), row);
  }
  const pw = textWidth(label) + 6;
  sheet.rect(ox + 3, oy + 3, pw, 9, packRGBA(6, 6, 10, 220));
  drawText(sheet, ox + 6, oy + 5, label, packRGBA(232, 222, 196));
}

const inp = new Input();
const settle = (sc: N3Scene, n = 36) => {
  for (let i = 0; i < n; i++) sc.update(1 / 60, inp);
};

const shots: Record<string, PixelSurface> = {};
for (const key of ['A', 'B', 'C'] as const) {
  const sc = new N3Scene(key);
  settle(sc, 40);
  shots[key] = sc.render().clone();
}
const sc = new N3Scene();
settle(sc, 40);
shots.D = sc.render().clone();
sc.toggleZone();
settle(sc, 28);
shots.E = sc.render().clone();
sc.toggleZone();
settle(sc, 24);
const zoom = sc.render().clone().crop(44, 56, 208, 156);

place(shots.A, 0, 0, 'A · CANDIDATE 42°  ROOF-HEAVY');
place(shots.B, CW + GUT, 0, 'B · TARGET 36°  SELECTED  (CROSSCODE/UNSIGHTED READ)');
place(shots.C, (CW + GUT) * 2, 0, 'C · CANDIDATE 50°  TOO TOP-DOWN');
place(shots.D, 0, CH + GUT, 'D · EXTERIOR + ROOF  (SELECTED CAM, DUSK)');
place(shots.E, CW + GUT, CH + GUT, 'E · CUTAWAY INTERIOR  SAME WORLD, SAME PROJECTION');

// zoom cell: wall detail (lean + cornice + wall thickness)
{
  const ox = (CW + GUT) * 2;
  const oy = CH + GUT;
  sheet.rect(ox, oy, CW, CH, packRGBA(12, 12, 16));
  sheet.blit(zoom, ox + 8, oy + 26);
  const pw = textWidth('WALL DETAIL x4 · 2° LEAN + CORNICE') + 6;
  sheet.rect(ox + 3, oy + 3, pw, 9, packRGBA(6, 6, 10, 220));
  drawText(sheet, ox + 6, oy + 5, 'WALL DETAIL x4 · 2° LEAN + CORNICE', packRGBA(232, 222, 196));
  drawText(sheet, ox + 10, oy + 190, 'TRAPEZOID BATTER: TOP EDGE INSET', packRGBA(150, 158, 165));
  drawText(sheet, ox + 10, oy + 198, 'BY h*tan(2°) ≈ 2-3px. READS AS', packRGBA(150, 158, 165));
  drawText(sheet, ox + 10, oy + 206, '"MORE SURFACE", NOT "TILTED".', packRGBA(150, 158, 165));
}

writePng('out/cmp-sheet-n3.png', sheet, 2);
console.log('sheet written: out/cmp-sheet-n3.png');
