import { N1Scene } from '../src/n1/N1Scene';
import { writePng } from './png';
import { Input } from '../src/input/Input';

const sc = new N1Scene();
const inp = new Input();
for (let i = 0; i < 40; i++) sc.update(1 / 60, inp);
writePng('out/n1-ext.png', sc.render(), 2);
// interior
(sc as never as { px: number; py: number }).px = sc.world.entrance.int.x;
(sc as never as { px: number; py: number }).py = sc.world.entrance.int.y + 4;
(sc as never as { zone: 'ext' | 'int' }).zone = 'int';
(sc as never as { snapCam: () => void }).snapCam();
for (let i = 0; i < 20; i++) sc.update(1 / 60, inp);
writePng('out/n1-int.png', sc.render(), 2);
// character closeup
(sc as never as { zone: 'ext' | 'int' }).zone = 'ext';
(sc as never as { px: number; py: number }).px = sc.world.entrance.ext.x + 20;
(sc as never as { px: number; py: number }).py = sc.world.entrance.ext.y + 30;
(sc as never as { snapCam: () => void }).snapCam();
for (let i = 0; i < 10; i++) sc.update(1 / 60, inp);
const f = sc.render();
const p = (sc as never as { proj: { projectPoint: (x: number, y: number) => [number, number] }; world: { ox: number; oy: number }; camX: number; camY: number });
const [gx, gy] = p.proj.projectPoint((sc as never as { px: number }).px, (sc as never as { py: number }).py);
const cx = Math.round(gx + p.world.ox - p.camX);
const cy = Math.round(gy + p.world.oy - p.camY);
writePng('out/n1-char.png', f.crop(Math.max(0, cx - 40), Math.max(0, cy - 46), 80, 60), 5);
console.log('n1 shots written');
