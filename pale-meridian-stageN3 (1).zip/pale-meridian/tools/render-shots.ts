/**
 * Offline preview renderer.
 *
 * Runs the *real* software renderer in Node and dumps PNGs to /out so frames
 * can be inspected pixel by pixel without a browser. This is the review loop
 * used to tune the art direction.
 */
import { mkdirSync } from 'node:fs';
import { PixelSurface } from '../src/rendering/PixelSurface';
import { writePng } from './png';
import { bakeExteriorGround } from '../src/assets/terrain';
import { bakeBuilding, buildingShadow } from '../src/assets/architecture';
import { buildMerc } from '../src/assets/character';
import { buildRobot } from '../src/assets/robot';
import { Game } from '../src/game/Game';
import { PROFILES, PROFILE_ORDER, Proj } from '../src/lab/profiles';
import { getSharedLab } from '../src/lab/labShared';
import { getOutpost } from '../src/scenes/registry';
import { Input } from '../src/input/Input';
import { ShowcaseScene } from '../src/scenes/showcase';
import { drawComposite, FULL_KIT, type RigPose2 } from '../src/entities/CompositeRig';
import { dust, metal, rust } from '../src/data/palette';
import { packRGBA } from '../src/rendering/color';
import { fillFace, faceOutline, groundQuad } from '../src/lab/facePaint';
import type { TimeOfDay } from '../src/lighting/LightingSystem';
import { VIEW_H, VIEW_W } from '../src/data/config';
import { blendOver } from '../src/rendering/color';

mkdirSync('out', { recursive: true });

function overlay(base: PixelSurface, layer: PixelSurface, ox = 0, oy = 0): void {
  for (let y = 0; y < layer.height; y++) {
    for (let x = 0; x < layer.width; x++) {
      const c = layer.data[y * layer.width + x];
      if (((c >>> 24) & 0xff) === 0) continue;
      const dx = x + ox;
      const dy = y + oy;
      if (dx < 0 || dy < 0 || dx >= base.width || dy >= base.height) continue;
      base.data[dy * base.width + dx] = blendOver(base.data[dy * base.width + dx], c);
    }
  }
}

let cachedGround: PixelSurface | null = null;
let cachedShadow: PixelSurface | null = null;
function ground(): { ground: PixelSurface; shadow: PixelSurface } {
  if (!cachedGround) {
    const t0 = Date.now();
    const g = bakeExteriorGround();
    console.log(`terrain baked in ${Date.now() - t0}ms`);
    cachedGround = g.ground;
    cachedShadow = g.shadow;
  }
  return { ground: cachedGround!, shadow: cachedShadow! };
}

function shotTerrain(): void {
  const { ground: g, shadow } = ground();
  const frame = g.clone();
  overlay(frame, shadow);
  writePng('out/01-terrain-world.png', frame);
  writePng('out/02-terrain-view.png', frame.crop((780 - VIEW_W) / 2, 200, VIEW_W, VIEW_H), 2);
}

function shotBuilding(): void {
  const { ground: g, shadow } = ground();
  const frame = g.clone();
  overlay(frame, shadow);
  const b = bakeBuilding();
  const sh = buildingShadow();
  overlay(frame, sh.surface, sh.origin.x, sh.origin.y);
  overlay(frame, b.sprite, b.origin.x, b.origin.y);
  writePng('out/04-building.png', frame.crop(150, 150, 420, 300), 2);
  writePng('out/05-building-close.png', frame.crop(230, 200, 260, 200), 3);
}

function shotScene(name: string, opts: { zone?: 'ext' | 'int'; tod?: TimeOfDay; px?: number; py?: number; t?: number; lighting?: boolean; scale?: number; crop?: [number, number, number, number] }): void {
  const game = new Game();
  game.review.timeOfDay = opts.tod ?? 'dusk';
  game.lighting.timeOfDay = game.review.timeOfDay;
  if (opts.lighting === false) {
    game.review.lighting = false;
    game.lighting.enabled = false;
  }
  game.time = opts.t ?? 3.2;
  if (opts.zone === 'int') {
    game.zone = 'int';
    game.player.x = opts.px ?? 240;
    game.player.y = opts.py ?? 190;
  } else {
    game.player.x = opts.px ?? 352;
    game.player.y = opts.py ?? 452;
  }
  game.camera.setWorld(opts.zone === 'int' ? 480 : 780, opts.zone === 'int' ? 270 : 580);
  game.camera.snapTo(game.player.x, game.player.y - 10);
  // settle animations deterministically
  for (let i = 0; i < 30; i++) game.update(1 / 60);
  game.time = opts.t ?? 3.2;
  const frame = game.render();
  if (game.review.debug) game.drawDebug(frame);
  const out = opts.crop ? frame.crop(...opts.crop) : frame;
  writePng(`out/${name}.png`, out, opts.scale ?? 2);
  console.log(`shot ${name} (${out.width}x${out.height})`);
}

const which = process.argv[2] ?? 'all';
if (which === 'terrain' || which === 'all') shotTerrain();
if (which === 'building' || which === 'all') shotBuilding();
console.log('shots written to ./out');

function shotCharacter(): void {
  const m = buildMerc();
  const sheet = new PixelSurface(4 * 34 + 8, 4 * 34 + 8);
  sheet.fill(0xff23272d);
  const dirs = ['s', 'e', 'n', 'w'] as const;
  dirs.forEach((d, di) => {
    for (let ph = 0; ph < 4; ph++) {
      const f = m.frames[d][ph];
      sheet.blit(f, 6 + di * 34 - m.ax + 13, 4 + ph * 34 - m.ay + 31);
    }
  });
  writePng('out/06-merc-sheet.png', sheet, 6);
}

if (which === 'char' || which === 'all') shotCharacter();

if (which === 'scene' || which === 'all') {
  shotScene('10-scene-dusk', {});
  shotScene('11-scene-night', { tod: 'night', t: 5.1 });
  shotScene('12-scene-day', { tod: 'day', t: 1.4 });
  shotScene('13-scene-nolight', { lighting: false });
  shotScene('14-interior', { zone: 'int', t: 2.2 });
  shotScene('15-scene-close', { px: 340, py: 400, crop: [120, 60, 240, 150], scale: 3 });
}

function shotRobot(): void {
  const r = buildRobot();
  const sheet = new PixelSurface(4 * 30 + 8, 40);
  sheet.fill(0xff23272d);
  for (let f = 0; f < 4; f++) sheet.blit(r.frames[f], 6 + f * 30 - r.ax + 13, 6 - r.ay + 24);
  writePng('out/07-robot-sheet.png', sheet, 6);
}
if (which === 'robot' || which === 'all') shotRobot();

function shotProj(): void {
  const sheet = new PixelSurface(6 * 152 + 8, 130);
  sheet.fill(0xff14161a);
  PROFILE_ORDER.forEach((id, i) => {
    const pr = new Proj(PROFILES[id]);
    const s = new PixelSurface(150, 126);
    const [ox, oy] = pr.p.mode === 'axon' ? pr.inv(62, 88) : [44, 88];
    s.fill(dust.d4);
    groundQuad(s, pr, ox - 30, oy - 26, 90, 60, dust.d5);
    const b0 = pr.box(ox, oy, 44, 28, 30);
    s.polygon(b0.front.pts.map((p) => [p[0] + 14, p[1] + 8]), packRGBA(40, 24, 20, 110));
    const b = pr.box(ox, oy, 44, 28, 30);
    fillFace(s, b.top, metal.m7);
    fillFace(s, b.front, metal.m5);
    fillFace(s, b.east, metal.m2);
    if (pr.p.mode === 'axon') fillFace(s, b.west, metal.m3);
    faceOutline(s, b.top, metal.m1);
    faceOutline(s, b.front, metal.m1);
    const c = pr.box(ox + 52, oy + 10, 12, 10, 10);
    fillFace(s, c.top, rust.x5);
    fillFace(s, c.front, rust.x4);
    fillFace(s, c.east, rust.x2);
    if (pr.p.mode === 'axon') fillFace(s, c.west, rust.x3);
    sheet.blit(s, 4 + i * 152, 2);
  });
  writePng('out/20-proj-math.png', sheet, 3);
  console.log('shot 20-proj-math');
}
if (which === 'proj') shotProj();

function shotLab(): void {
  const t0 = Date.now();
  const game = getSharedLab();
  console.log(`lab bakes ready in ${Date.now() - t0}ms`);
  game.time = 3.0;
  game.hover = -1;
  game.update(1 / 60);
  const frame = game.render();
  writePng('out/30-lab.png', frame, 1);
  writePng('out/31-lab-C.png', frame.crop(640, 0, 320, 270), 2);
  writePng('out/31-lab-A.png', frame.crop(0, 0, 320, 270), 2);
  writePng('out/31-lab-D.png', frame.crop(0, 270, 320, 270), 2);
  game.panels.forEach((p) => (p.interior = true));
  const f2 = game.render();
  writePng('out/32-lab-int.png', f2, 1);
  writePng('out/33-lab-int-C.png', f2.crop(640, 0, 320, 270), 2);
  game.panels.forEach((p) => (p.interior = false));
  game.hover = 2;
  writePng('out/34-lab-focus.png', game.render(), 1);
  game.hover = -1;
  game.showParams = true;
  writePng('out/35-lab-params.png', game.render(), 1);
  game.showParams = false;
  console.log('shots 30-35 lab');
}
if (which === 'lab') shotLab();

function shotScenes(): void {
  for (const key of ['scene2', 'scene3'] as const) {
    const sc = getOutpost(key);
    const inp = new Input();
    sc.time = 4.0;
    sc.setZoneForced('ext');
    for (let i = 0; i < 40; i++) sc.update(1 / 60, inp);
    writePng(`out/50-${key}-ext.png`, sc.render(), 2);
    sc.setZoneForced('int');
    for (let i = 0; i < 20; i++) sc.update(1 / 60, inp);
    writePng(`out/51-${key}-int.png`, sc.render(), 2);
    sc.setZoneForced('ext');
    for (let i = 0; i < 10; i++) sc.update(1 / 60, inp);
    const frame = sc.render();
    const p = sc.playerScreenPos();
    writePng(`out/52-${key}-char.png`, frame.crop(Math.max(0, p.x - 60), Math.max(0, p.y - 70), 120, 90), 4);
    const v = sc.worldToScreen(322, 236);
    writePng(`out/53-${key}-vehicle.png`, frame.crop(Math.max(0, v.x - 60), Math.max(0, v.y - 60), 130, 90), 4);
  }
  console.log('shots 50-52 scenes');
}
function shotRig2(): void {
  const sheet = new PixelSurface(6 * 40 + 8, 5 * 40 + 8);
  sheet.fill(0xff23272d);
  const poses: RigPose2[] = [
    { state: 'idle', phase: 0, orient: 'e', breath: 0, look: 0 },
    { state: 'walk', phase: 0, orient: 'e', breath: 0, look: 0 },
    { state: 'walk', phase: 1, orient: 'e', breath: 0, look: 0 },
    { state: 'walk', phase: 2, orient: 'e', breath: 0, look: 0 },
    { state: 'aim', phase: 0, orient: 'e', breath: 0, look: 0 },
    { state: 'idle', phase: 0, orient: 'w', breath: 0, look: 0 },
    { state: 'walk', phase: 1, orient: 'w', breath: 0, look: 0 },
    { state: 'aim', phase: 0, orient: 'w', breath: 0, look: 0 },
    { state: 'idle', phase: 0, orient: 's', breath: 0, look: 0 },
    { state: 'walk', phase: 1, orient: 's', breath: 0, look: 0 },
    { state: 'aim', phase: 0, orient: 's', breath: 0, look: 0 },
    { state: 'idle', phase: 0, orient: 'n', breath: 0, look: 0 },
    { state: 'walk', phase: 2, orient: 'n', breath: 0, look: 0 },
    { state: 'walk', phase: 3, orient: 's', breath: 0, look: 0 },
    { state: 'idle', phase: 0, orient: 'e', breath: 1, look: 1 },
  ];
  poses.forEach((p, i) => {
    const col = i % 6;
    const row = Math.floor(i / 6);
    drawComposite(sheet, 6 + col * 40 + 16, 4 + row * 40 + 34, p, FULL_KIT);
  });
  writePng('out/62-rig2-sheet.png', sheet, 6);
  console.log('shot 62 rig2 sheet');
}
function shotCompare(): void {
  const g1 = new Game();
  g1.time = 3.2;
  const inp = new Input();
  for (let i = 0; i < 30; i++) g1.update(1 / 60);
  const f1 = g1.render();
  const s2 = getOutpost('scene2');
  const s3 = getOutpost('scene3');
  s2.setZoneForced('ext');
  s3.setZoneForced('ext');
  for (let i = 0; i < 30; i++) {
    s2.update(1 / 60, inp);
    s3.update(1 / 60, inp);
  }
  const f2 = s2.render();
  const f3 = s3.render();
  const stack = new PixelSurface(480, 270 * 3);
  stack.blit(f1, 0, 0);
  stack.blit(f2, 0, 270);
  stack.blit(f3, 0, 540);
  writePng('out/70-compare-ext.png', stack, 1);
  // interiors
  g1.zone = 'int';
  g1.player.x = 240;
  g1.player.y = 190;
  g1.camera.snapTo(g1.player.x, g1.player.y - 10);
  for (let i = 0; i < 10; i++) g1.update(1 / 60);
  const i1 = g1.render();
  s2.setZoneForced('int');
  s3.setZoneForced('int');
  for (let i = 0; i < 10; i++) {
    s2.update(1 / 60, inp);
    s3.update(1 / 60, inp);
  }
  const i2 = s2.render();
  const i3 = s3.render();
  const stack2 = new PixelSurface(480, 270 * 3);
  stack2.blit(i1, 0, 0);
  stack2.blit(i2, 0, 270);
  stack2.blit(i3, 0, 540);
  writePng('out/71-compare-int.png', stack2, 1);
  console.log('shots 70-71 compare');
}
if (which === 'rig2') shotRig2();
if (which === 'compare') shotCompare();

function shotShowcase(): void {
  const sc = new ShowcaseScene();
  const inp = new Input();
  sc.auto = false;
  sc.state = 'idle';
  for (let i = 0; i < 30; i++) sc.update(1 / 60, inp);
  writePng('out/80-show-idle.png', sc.render(), 2);
  sc.state = 'walk';
  for (let i = 0; i < 20; i++) sc.update(1 / 60, inp);
  writePng('out/81-show-walk.png', sc.render(), 2);
  sc.state = 'aim';
  for (let i = 0; i < 10; i++) sc.update(1 / 60, inp);
  writePng('out/82-show-aim.png', sc.render(), 2);
  sc.debug = true;
  writePng('out/83-show-debug.png', sc.render(), 2);
  sc.debug = false;
  sc.eq = { helmet: false, shoulderArmor: false, torsoPlate: false, backpack: false, weapon: true };
  writePng('out/84-show-noeq.png', sc.render(), 2);
  console.log('shots 80-84 showcase');
}
if (which === 'show') shotShowcase();

function shotScene3QA(): void {
  const sc = getOutpost('scene3');
  const inp = new Input();
  const spots: [number, number, string][] = [
    [200, 260, 'south'],
    [120, 150, 'west'],
    [330, 150, 'east'],
    [192, 176, 'door'],
  ];
  for (const [x, y, name] of spots) {
    sc.setZoneForced('ext');
    (sc as never as { px: number; py: number }).px = x;
    (sc as never as { px: number; py: number }).py = y;
    (sc as never as { snapCam: () => void }).snapCam?.();
    for (let i = 0; i < 12; i++) sc.update(1 / 60, inp);
    writePng(`out/85-s3-${name}.png`, sc.render(), 2);
  }
  console.log('shots 85 scene3 QA');
}
if (which === 's3qa') shotScene3QA();
if (which === 'scenes') shotScenes();
