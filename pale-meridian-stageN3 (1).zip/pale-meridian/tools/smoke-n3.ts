/**
 * N3 smoke test: bake + render both zones on every camera candidate,
 * toggle the cutaway back and forth, assert frames are alive and distinct.
 */
import { N3Scene } from '../src/n3/N3Scene';
import { Input } from '../src/input/Input';

const inp = new Input();
const run = (sc: N3Scene, n: number) => {
  for (let i = 0; i < n; i++) sc.update(1 / 60, inp);
  return sc.render().clone();
};
const variance = (d: Uint32Array) => {
  let mean = 0;
  for (let i = 0; i < d.length; i += 7) mean += d[i] & 0xff;
  mean /= d.length / 7;
  let v = 0;
  for (let i = 0; i < d.length; i += 7) v += ((d[i] & 0xff) - mean) ** 2;
  return v / (d.length / 7);
};

let fails = 0;
const check = (ok: boolean, msg: string) => {
  if (!ok) {
    fails++;
    console.error('FAIL:', msg);
  } else console.log('ok  :', msg);
};

for (const key of ['A', 'B', 'C'] as const) {
  const sc = new N3Scene(key);
  const ext = run(sc, 40);
  check(variance(ext.data) > 200, `cam ${key}: exterior frame has content`);
  sc.toggleZone();
  const cut = run(sc, 30);
  check(variance(cut.data) > 200, `cam ${key}: cutaway frame has content`);
  let diff = 0;
  for (let i = 0; i < ext.data.length; i += 11) if (ext.data[i] !== cut.data[i]) diff++;
  check(diff > ext.data.length / 22, `cam ${key}: cutaway differs from exterior`);
  sc.toggleZone();
  run(sc, 24);
  check(sc.zone === 'ext', `cam ${key}: back to exterior`);
}

// input-driven toggle like a player would
const sc = new N3Scene();
run(sc, 10);
inp.press('KeyE');
run(sc, 40);
check(sc.zone === 'int', 'E opens the cutaway');
inp.press('KeyE');
run(sc, 40);
check(sc.zone === 'ext', 'E closes the cutaway');
inp.press('BracketLeft');
run(sc, 4);
check(sc.camKey === 'A', '[ cycles camera down');
inp.press('BracketRight');
run(sc, 4);
check(sc.camKey === 'B', '] cycles camera up');

if (fails > 0) {
  console.error(`SMOKE N3 FAILED (${fails})`);
  process.exit(1);
}
console.log('SMOKE N3 OK');
