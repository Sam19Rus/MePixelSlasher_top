/**
 * N2 INTERIOR MOVEMENT SMOKE TEST (mandatory stage gate).
 *
 * ENTER -> move up -> move left -> move right -> move down ->
 * approach furniture -> return to door -> EXIT, while asserting:
 *   - player remains inside the room bounds
 *   - no wall / furniture clipping (circle vs collider rects)
 *   - no stuck state (every intended move phase actually moves)
 *   - no teleport (per-frame step bounded)
 *   - no position drift while idle
 */
import { N2Scene } from '../src/n2/N2Scene';
import { Input } from '../src/input/Input';

const sc = new N2Scene();
const inp = new Input();
const R = sc.merc.radius; // exact merc collision radius
let maxStep = 0;
let lastX = sc.merc.x;
let lastY = sc.merc.y;

let prevZone = sc.zone;
const step = (n: number) => {
  for (let i = 0; i < n; i++) {
    sc.update(1 / 60, inp);
    const zoneChanged = sc.zone !== prevZone;
    prevZone = sc.zone;
    const d = Math.hypot(sc.merc.x - lastX, sc.merc.y - lastY);
    // zone switches are fade transitions, not movement: not sampled
    if (!zoneChanged && d > maxStep) maxStep = d;
    lastX = sc.merc.x;
    lastY = sc.merc.y;
  }
};
const hold = (code: string, n: number) => {
  inp.press(code);
  step(n);
  inp.release(code);
  step(4);
};
const overlaps = (x: number, y: number) => {
  const cols = sc.zone === 'ext' ? sc.world.collidersExt : sc.world.collidersInt;
  return cols.filter((c) => x + R > c.x && x - R < c.x + c.w && y + R > c.y && y - R < c.y + c.h);
};
const insideRoom = () => {
  const r = sc.world.interiorRect;
  return sc.merc.x - R >= r.x - 0.5 && sc.merc.x + R <= r.x + r.w + 0.5 && sc.merc.y - R >= r.y - 0.5 && sc.merc.y + R <= r.y + r.h + 0.5;
};
const assert = (cond: boolean, msg: string) => {
  if (!cond) {
    console.error('FAIL:', msg, `pos=${sc.merc.x.toFixed(1)},${sc.merc.y.toFixed(1)} zone=${sc.zone}`);
    process.exit(1);
  }
  console.log('ok  :', msg);
};
const phase = (name: string, keys: [string, number][], expectMove: boolean) => {
  const x0 = sc.merc.x;
  const y0 = sc.merc.y;
  for (const [k, n] of keys) hold(k, n);
  const moved = Math.hypot(sc.merc.x - x0, sc.merc.y - y0);
  console.log(`phase ${name}: moved ${moved.toFixed(1)} -> (${sc.merc.x.toFixed(1)}, ${sc.merc.y.toFixed(1)})`);
  if (expectMove) assert(moved > 3, `phase ${name} must move the player (not stuck)`);
  if (sc.zone === 'int') {
    assert(insideRoom(), `phase ${name}: player stays inside room`);
    assert(overlaps(sc.merc.x, sc.merc.y).length === 0, `phase ${name}: no collider clipping`);
  }
};

// ---- walk to the door from spawn and ENTER
step(10);
for (let i = 0; i < 12 && !sc.nearEntrance; i++) hold('KeyW', 30);
assert(sc.nearEntrance, 'reached exterior door zone');
inp.press('KeyE');
step(2);
inp.release('KeyE');
step(50);
assert(sc.zone === 'int', 'ENTER switched to interior');
const e = sc.world.entrance.int;
assert(Math.hypot(sc.merc.x - e.x, sc.merc.y - e.y) < 1.5, 'spawned directly behind the door');
assert(overlaps(sc.merc.x, sc.merc.y).length === 0, 'interior spawn free of colliders');

// ---- mandatory movement sequence
phase('up', [['KeyW', 26]], true);
phase('left', [['KeyA', 40]], true);
phase('right', [['KeyD', 55]], true);
phase('down', [['KeyS', 22]], true);
phase('approach console2', [['KeyW', 20], ['KeyD', 26], ['KeyW', 22]], true);
phase('approach holotable', [['KeyS', 16], ['KeyA', 46], ['KeyW', 10]], true);
phase('approach workbench', [['KeyS', 26], ['KeyA', 16]], true);

// ---- drift check: idle 45 frames
const ix = sc.merc.x;
const iy = sc.merc.y;
step(45);
assert(Math.hypot(sc.merc.x - ix, sc.merc.y - iy) < 0.01, 'no position drift while idle');

// ---- return to door and EXIT
for (let i = 0; i < 10 && !sc.nearEntrance; i++) {
  const dx = e.x - sc.merc.x;
  const dy = e.y - sc.merc.y;
  const keys: [string, number][] = [];
  if (Math.abs(dx) > 2) keys.push([dx > 0 ? 'KeyD' : 'KeyA', Math.min(30, Math.abs(dx) * 2)]);
  if (Math.abs(dy) > 2) keys.push([dy > 0 ? 'KeyS' : 'KeyW', Math.min(30, Math.abs(dy) * 2)]);
  if (keys.length === 0) break;
  phase(`return-${i}`, keys, i < 8);
}
assert(sc.nearEntrance, 'returned to interior door');
inp.press('KeyE');
step(2);
inp.release('KeyE');
step(50);
assert(sc.zone === 'ext', 'EXIT switched back to exterior');
assert(Math.hypot(sc.merc.x - 337, sc.merc.y - 372) < 2, 'exterior return point stable');

assert(maxStep < 2.0, `no teleport (max frame step ${maxStep.toFixed(2)} px)`);
console.log(`\nN2 INTERIOR SMOKE: PASS (max step ${maxStep.toFixed(2)} px/frame)`);
